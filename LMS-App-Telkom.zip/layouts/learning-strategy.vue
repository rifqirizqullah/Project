<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <Navbar />
            <ContentHeader
                headerTitle='Learning Strategy Management'
                headerDescription='to Manage all Learning Strategy'
                headerSubDescription= 'Telkom Corporate University'
            />
            <!-- <div class="navbar navbar-expand-sm navbar-submenu navbar-light h-auto p-0">
                <div class="container page__container flex-column flex-sm-row">
                    <nuxt-link to="/" class="mx-4"> <i class="material-icons">home</i></nuxt-link>
                    <h4 class="flex ml-3 mb-0 mr-sm-24pt d-none d-sm-block">
                        <nuxt-link to="/learning-strategy">Dashboard</nuxt-link>
                    </h4>
                </div>
            </div> -->
            <div class="navbar navbar-expand-sm navbar-submenu navbar-light p-sm-0 ">
                <div class="container page__container">

                    <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                        data-target="#navbar-submenu2">
                        <span class="material-icons">menu</span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbar-submenu2">
                        <div class="navbar-collapse__content pb-16pt pb-sm-0">
                            <ul class="nav navbar-nav">

                                <li class="nav-item">
                                    <nuxt-link to='/' class='nav-link'><i class="material-icons">home</i></nuxt-link>
                                </li>
                                <li class="nav-item active">
                                    <nuxt-link to='/learning-strategy' class='nav-link'>Learning Strategy
                                    </nuxt-link>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <nuxt />
            <Footer/>
        </div>
    </div>
</template>

<script>
import Navbar from '@@/components/Navbar'
import Footer from '@@/components/Footer'
import ContentHeader from '@@/components/ContentHeader'

export default {
    middleware : 'auth',
    components: {
        Navbar,
        Footer,
        ContentHeader
    },
    data() {
        return {
        }
    },
}
</script>


<style>


</style>

