<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <Navbar />

            <!-- <headerEventComponent/> -->
            <!-- <div v-if="batch" class="card p-0 m-0" style="border-radius: 0 0 3px 3px; margin-top:-2px;">
                <div class="card-header bg-primary text-center" style="border-radius: 0 0 3px 3px">
                    <h3 class="card-title text-light">{{batch.batch_id}} {{batch.batch_name}}</h3>
                </div>
            </div> -->

            <div class="navbar navbar-expand-sm navbar-submenu navbar-light p-sm-0 ">
                <div class="container page__container">

                    <!-- Navbar toggler -->
                    <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                        data-target="#navbar-submenu2">
                        <span class="material-icons">menu</span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbar-submenu2">
                        <div class="navbar-collapse__content pb-16pt pb-sm-0">
                            <ul class="nav navbar-nav">

                               <li class="nav-item" :class="{ active : $route.path == '/peserta/activity/' }">
                                    <nuxt-link :to="'/peserta/activity?type='+type" class='nav-link'>Session
                                    </nuxt-link>
                                </li>
                                <li class="nav-item" :class="{ active : $route.path == '/peserta/activity/schedule' }">
                                    <nuxt-link :to="'/peserta/activity/schedule?type='+type" class='nav-link'>Schedule
                                    </nuxt-link>
                                </li>
                                <li class="nav-item" :class="{ active : $route.path == '/peserta/activity/mentoring' }">
                                    <nuxt-link :to="'mentoring?type='+type" class='nav-link'>Mentoring
                                    </nuxt-link>
                                </li>
                                <li class="nav-item" :class="{ active : $route.path == '/peserta/activity/absensi' }">
                                    <nuxt-link :to="'absensi?type='+type" class='nav-link'>Absensi
                                    </nuxt-link>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="nav-item mr-3">
                       <strong><i class="material-icons">person</i> {{student.username}}</strong>
                    </div>
                </div>
            </div>

            <nuxt />
            <Footer />
        </div>
    </div>
</template>

<script>
    import Navbar from '@@/components/Navbar'
    import Footer from '@@/components/Footer'
    import headerEventComponent from '@@/components/headerEventComponent'

    export default {
        components: {
            Navbar,
            Footer,
            headerEventComponent,
        },
        data() {
            return {
                student : this.$store.state.auth.user,
                type :this.$route.query.type
            }
        },
        computed: {
            batch() {
                return this.$store.state.batch.detail
            }
        },
    }

</script>


<style>


</style>
