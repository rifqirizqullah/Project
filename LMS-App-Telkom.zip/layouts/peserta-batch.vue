<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <Navbar />

            <!-- <headerEventComponent/> -->
            <!-- <div v-if="batch" class="card p-0 m-0" style="border-radius: 0 0 3px 3px; margin-top:-2px;">
                <div class="card-header bg-primary text-center" style="border-radius: 0 0 3px 3px">
                    <h3 class="card-title text-light">{{batch.batch_id}} {{batch.batch_name}}</h3>
                </div>
            </div> -->

            <div class="navbar navbar-expand-sm navbar-submenu navbar-light p-sm-0 ">
                <div class="container page__container">

                    <!-- Navbar toggler -->
                    <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                        data-target="#navbar-submenu2">
                        <span class="material-icons">menu</span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbar-submenu2">
                        <div class="navbar-collapse__content pb-16pt pb-sm-0">
                            <ul class="nav navbar-nav">

                                <li class="nav-item" :class="{ active : $route.path == '/peserta' }">
                                    <nuxt-link to='/peserta' class='nav-link'>My Learning</nuxt-link>
                                </li>
                                <li class="nav-item" :class="{ active : $route.path == '/peserta/activity' }">
                                    <nuxt-link to="/peserta/activity" class='nav-link'>Session</nuxt-link>
                                </li>
                                <li class="nav-item" :class="{ active : $route.path == '/peserta/forum' }">
                                    <nuxt-link to="/peserta/forum" class='nav-link'>Forum</nuxt-link>
                                </li>
                                <li class="nav-item " :class="{ active : $route.path == '/peserta/insight' }">
                                    <nuxt-link to="/peserta/insight" class='nav-link'>insight</nuxt-link>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="nav-item mr-3">
                       <strong><i class="material-icons">person</i> {{student.username}}</strong>
                    </div>
                </div>
            </div>

            <nuxt />
            <Footer />
        </div>
    </div>
</template>

<script>
    import Navbar from '@@/components/Navbar'
    import Footer from '@@/components/Footer'
    import headerEventComponent from '@@/components/headerEventComponent'

    export default {
        components: {
            Navbar,
            Footer,
            headerEventComponent,
        },
        data() {
            return {
                student : this.$store.state.auth.user,
                type :this.$route.query.type
            }
        },
        computed: {
            batch() {
                return this.$store.state.batch.detail
            }
        },
    }

</script>


<style>


</style>
