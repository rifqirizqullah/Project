<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <Navbar />
            <ContentHeader headerTitle='Event Management' headerDescription='to Manage all Event'
                headerSubDescription='Telkom Corporate University' />
            <div class="navbar navbar-expand-sm navbar-submenu navbar-light p-sm-0">
                <div class="container page__container">

                    <!-- Navbar toggler -->
                    <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                        data-target="#navbar-submenu2">
                        <span class="material-icons">menu</span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbar-submenu2">
                        <div class="navbar-collapse__content pb-16pt pb-sm-0">
                            <ul class="nav navbar-nav">
                                <li class="nav-item" :class="{ active : $route.path == '/event/batch/detail/mentoring' }">
                                    <nuxt-link :to="'/event/batch/detail/mentoring?type='+type" class='nav-link'>Mentoring
                                    </nuxt-link>
                                </li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <nuxt />
            <Footer />
        </div>
    </div>
</template>

<script>
    import Navbar from '@@/components/Navbar'
    import Footer from '@@/components/Footer'
    import ContentHeader from '@@/components/ContentHeader'

    export default {
        components: {
            Navbar,
            Footer,
            ContentHeader
        },
        data() {
            return {
                type :this.$route.query.type
            }
        },
    }

</script>


<style>


</style>
