<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">

            <Navbar/>

            <nuxt />

            <section>
                <div class="bg-white border-top-2">
                    <div class="bg-footer page-section py-3">
                        <div class="container">
                            <div class="row">
                                <div class="col text-center">
                                    <p class="text-white-50 mb-0">Copyright 2019 © All rights reserved.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </div>
    </div>
</template>


<script>
import Navbar from '@@/components/Navbar'

export default {
    components: {
        Navbar,
    },
}
</script>
