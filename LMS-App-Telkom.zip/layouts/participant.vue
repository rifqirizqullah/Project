<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <Navbar />
            <ContentHeader
                headerTitle='Participant Management'
                headerDescription='to Manage all Participant'
                headerSubDescription= 'Telkom Corporate University'
            />
            <div class="navbar navbar-expand-sm navbar-submenu navbar-light h-auto p-0">
                <div class="container page__container flex-column flex-sm-row">
                    <h4 class="flex mb-0 mr-sm-24pt d-none d-sm-block">
                        <nuxt-link to="/participant">Participant Index</nuxt-link>
                    </h4>
                </div>
            </div>
            <nuxt />
            <Footer/>
        </div>
    </div>
</template>

<script>
import Navbar from '@@/components/Navbar'
import Footer from '@@/components/Footer'
import ContentHeader from '@@/components/ContentHeader'

export default {
    components: {
        Navbar,
        Footer,
        ContentHeader
    },
    data() {
        return {
        }
    },
}
</script>


<style>


</style>

