<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <Navbar />
            <ContentHeader headerTitle='Event Management' headerDescription='to Manage all Event'
                headerSubDescription='Telkom Corporate University' />
            <!-- <div class="navbar navbar-expand-sm navbar-submenu navbar-light p-sm-0">
                <div class="container page__container">

                    <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                        data-target="#navbar-submenu2">
                        <span class="material-icons">menu</span>
                    </button>

                </div>
            </div> -->
            <br>

            <nuxt />
            <Footer />
        </div>
    </div>
</template>

<script>
    import Navbar from '@@/components/Navbar'
    import Footer from '@@/components/Footer'
    import ContentHeader from '@@/components/ContentHeader'

    export default {
        components: {
            Navbar,
            Footer,
            ContentHeader
        },
        data() {
            return {
                type :this.$route.query.type
            }
        },
    }

</script>


<style>


</style>
