<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <Navbar />

            <div class="border-bottom-white py-32pt bg-gradient-purple" >
                <div class="container my-4 d-flex flex-column flex-md-row align-items-center text-center text-md-left">
                    <img src="/img/studentoutline.svg" width="104" class="mr-md-32pt mb-32pt mb-md-0" alt="student">
                    <div class="flex mb-32pt mb-md-0">
                        <h2 class="text-white mb-0">{{ student.email }}</h2>
                        <p class="lead text-white-50 d-flex align-items-center">
                            <i class="material-icons mr-3 icon-16pt" >account_balance</i>    {{ student.company }}
                            <span class="ml-16pt d-flex align-items-center">
                                <i class="material-icons icon-16pt mr-4pt">place</i>
                                {{student.company_address}}
                            </span>
                        </p>
                        <p class="lead text-white-50 d-flex align-items-center">
                            <span class="d-flex align-items-center">
                                <i class="material-icons mr-3 icon-16pt">label</i>
                                <div v-for="(item, index) in student.role" :key="index">
                                    {{ item }}
                                </div>
                            </span>
                        </p>
                    </div>
                    <!-- <a href="student-edit-account.html" class="btn btn-outline-white">Edit account</a> -->
                </div>
            </div>

            <div class="navbar navbar-expand-sm navbar-submenu navbar-light p-sm-0">
                <div class="container page__container">

                    <!-- Navbar toggler -->
                    <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                        data-target="#navbar-submenu2">
                        <span class="material-icons">menu</span>
                    </button>
                    
                    <div class="collapse navbar-collapse" id="navbar-submenu2">
                        <div class="navbar-collapse__content pb-16pt pb-sm-0">
                            <ul class="nav navbar-nav">

                                <li class="nav-item">
                                    <nuxt-link to='/' class='nav-link'><i class="material-icons">home</i></nuxt-link>
                                </li>
                                <li class="nav-item" :class="{ active : $route.path == '/peserta' }">
                                    <nuxt-link to='/peserta' class='nav-link'>My Learning</nuxt-link>
                                </li>
                                 <li class="nav-item">
                                    <a @click="detail" class='nav-link'>My Data</a>
                                </li> 
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <nuxt />
            <Footer />
        </div>
    </div>
</template>

<script>
    import Navbar from '@@/components/Navbar'
    import Footer from '@@/components/Footer'
    import {mapState, mapActions} from 'vuex'
    export default {
        components: {
            Navbar,
            Footer,
        },
        data() {
            return {

                student : this.$store.state.auth.user,
                parid : '2',
                // avatar:Array[0]
                // company:"Telkomsigma"
                // company_address:"Jln BSD"
                // email:"adminLMS@telkom.co.id"
                // notification:Array[0]
                // role:Array[1]
                //      0:"ADMINLMS"
                // username:Array[0]


                type :this.$route.query.type
            }
        },
         methods: {
            ...mapActions({                
                getParticipantDetail: 'participant/getOne',                
            }),
            async detail(){            
                await this.getParticipantDetail({participant_id : [this.parid]});                            
                this.$router.push('/resource/participant/detail')
            },   
        }
    }

</script>


<style>


</style>
