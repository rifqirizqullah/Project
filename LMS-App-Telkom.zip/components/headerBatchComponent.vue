<template>
    <div class="">
        <div v-if="batch" class="card p-0" style="border-radius: 0 0 3px 3px; margin-top:-2px;">
            <div class="card-header bg-primary text-center" style="border-radius: 0 0 3px 3px">
                <h3 class="card-title text-light">{{batch.batch_id}} {{batch.batch_name}}</h3>
            </div>
            <div class="row card-body">
                <div class="col-lg-3">
                    <small>Location</small>
                    <p>{{batch.location.value}}</p>
                </div>
                <div class="col-lg-3">
                    <small>Begin/End Date</small>
                    <p>{{formatDate(batch.begin_date)}} - {{formatDate(batch.end_date)}}</p>
                </div>
                <div class="col-lg-2" v-if="event.event_type.id == '01'">
                    <small>Curriculum</small>
                    <p>{{batch.curriculum && batch.curriculum.value}}</p>
                </div>
                <div class="col-lg-2">
                    <small>Vendor</small>
                    <p>{{batch.vendor.company_name}}</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'

export default {
    data() {
        return {
            type : this.$route.query.type
        }
    },
    computed: {
        batch(){
            return this.$store.state.batch.detail
        },
        event(){
            if (this.type == 'event') {
                return this.$store.state.event.detail
            } else {
                return this.$store.state.eventPlan.detail
            }
        },
    },
    methods: {
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>

<style>

</style>
