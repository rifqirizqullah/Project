<template>
    <div v-if="schedule" class="row p-2">
        <div class="col card p-0">
            <div class="card-header bg-primary ">
                <h3 class="card-title text-light"><i class="material-icons text-light">access_time</i> {{schedule.schedule_name}}</h3>
            </div>
            <div class="row card-body">
                <div class="col-lg-3">
                    <small>Time</small>
                    <p>{{ schedule.begin_time }} - {{ schedule.end_time }}</p>
                </div>
                <div class="col-lg-3">
                    <small>Topic</small>
                    <p>{{schedule.topic}}</p>
                </div>
                <div class="col-lg-3">
                    <small>Begin/End Date</small>
                    <p>{{formatDate(schedule.begin_date)}} - {{formatDate(schedule.end_date)}}</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'

export default {
    computed: {
        schedule(){
            return this.$store.state.schedule.detail
        },
    },
    methods: {
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>

<style>

</style>
