<template>
    <div v-if="schedule_templateQuestioner" class="row p-2">
        <div class="col card p-0">
            <div class="card-header bg-primary ">
                <h3 class="card-title text-light"><i class="material-icons text-light">access_time</i> {{schedule_templateQuestioner.template_code.value}}</h3>
            </div>
            <div class="row card-body">
                <div class="col-lg-3">
                    <small>Subject</small>
                    <p v-if="schedule_templateQuestioner.relation_type.id == 'ROOMS'">{{ schedule_templateQuestioner.relation_type.value }} - {{ schedule_templateQuestioner.id.room_name }} </p>
                    <p v-if="schedule_templateQuestioner.relation_type.id == 'MATER'">{{ schedule_templateQuestioner.relation_type.value }} - {{ schedule_templateQuestioner.id.materi_name }} </p>
                    <p v-if="schedule_templateQuestioner.relation_type.id == 'TRAINR'">{{ schedule_templateQuestioner.relation_type.value }} - {{ schedule_templateQuestioner.id.trainer_name }} </p>
                    <p v-if="schedule_templateQuestioner.relation_type.id == 'EVENT'">{{ schedule_templateQuestioner.relation_type.value }} - {{ schedule_templateQuestioner.id.event_name }} </p>                    
                </div>
                <div class="col-lg-3">
                    <small>Type</small>
                    <p>{{schedule_templateQuestioner.template_type.value}}</p>
                </div>
                <div class="col-lg-3">
                    <small>Begin/End Date</small>
                    <p>{{formatDate(schedule_templateQuestioner.begin_date)}} - {{formatDate(schedule_templateQuestioner.end_date)}}</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'

export default {
    computed: {
        schedule_templateQuestioner(){
            return this.$store.state.schedule_templateQuestioner.detail
        },
    },
    methods: {
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>

<style>

</style>
