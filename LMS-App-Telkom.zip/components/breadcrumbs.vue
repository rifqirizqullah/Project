<template>
    <div>
        <!-- Include after Vue -->
        <!-- Local files -->
        <script src="vue-2-breadcrumbs/dist/vue-2-breadcrumbs.js"></script>

        <!-- From CDN -->
        <script src="https://unpkg.com/vue-2-breadcrumbs.js"></script>
        <div id="app" class="container">
            <ul class="nav">
                <li class="nav-item  dropdown">
                    <router-link to="/feeds" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button"
                        aria-haspopup="true" aria-expanded="false">Feeds</router-link>
                    <div class="dropdown-menu">
                        <router-link to="/feeds/foo" class="dropdown-item">Foo</router-link>
                        <router-link to="/feeds/bar" class="dropdown-item">Bar</router-link>
                        <router-link to="/feeds/baz" class="dropdown-item">Baz</router-link>
                        <router-link to="/feeds/1" class="dropdown-item">Other Feed 1</router-link>
                        <router-link to="/feeds/2" class="dropdown-item">Other Feed 2</router-link>
                        <router-link to="/feeds/3" class="dropdown-item">Other Feed 3</router-link>
                    </div>
                </li>
            </ul>
            <breadcrumbs />
            <router-view />
        </div>
    </div>
</template>
<script>
    import Vue from 'vue';
    import Breabcrumbs from 'vue-2-breadcrumbs';
    export default {

    }

</script>
<style>

</style>
