<template>
    <ul v-if="state && state.paginationR" class="pagination justify-content-center pagination-sm">
        <li class="page-item" :class="{disabled : state.paginationR.current_page < 2}">
            <button class="page-link" @click="callPage({page: state.paginationR.current_page-1})">
                <span aria-hidden="true" class="material-icons">chevron_left</span>
                <span>Prev</span>
            </button>
        </li>
        <li v-for="(page, index) in state.paginationR.total_pages" :key="index" class="page-item"
            :class="{ active: state.paginationR.current_page == index+1 }">
            <button class="page-link" @click="state.paginationR.current_page != index+1 && callPage({page : index+1})" >
                <span>{{index+1}}</span>
            </button>
        </li>
        <li class="page-item" :class="{disabled : state.paginationR.current_page >= state.paginationR.total_pages}">
            <button class="page-link" @click="callPage({page : state.paginationR.current_page+1})">
                <span>Next</span>
                <span aria-hidden="true" class="material-icons">chevron_right</span>
            </button>
        </li>
    </ul>
</template>

<script>
import { mapState, mapActions } from "vuex";
export default {
    props : ['state','storeModuleName','api'],
    computed: {

    },
    mounted() {
    },
    methods: {
        callPage(page) {
            let params = {
                ...this.$route.query,
                ...page,
            }
            this.$store.dispatch(`${this.storeModuleName}/getReference`, params)
        }
    },

}
</script>

<style>

</style>
