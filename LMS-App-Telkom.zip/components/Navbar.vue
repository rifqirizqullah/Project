<template>
    <section>
        <div class="div navbar"> </div>
        <b-navbar fixed="top" id="header" class="header bg-dark mb-0 mdk-header--shadow-show mdk-header--shadow"
            data-effects="waterfall blend-background" data-fixed data-condenses>
            <div class="mdk-header__content">

                <div class="navbar navbar-expand-sm navbar-dark bg-dark pr-0 pr-md-16pt" id="navbar" data-primary>

                    <!-- <button class="navbar-toggler navbar-toggler-right d-block d-md-none" type="button"
                        data-toggle="sidebar">
                        <span class="navbar-toggler-icon"></span>
                    </button> -->

                    <nuxt-link to='/' class="navbar-brand">
                        <img class="navbar-brand-icon mr-0 mr-md-8pt" src="/img/Corpu.png" width="30" alt="Corpu">
                        <span class="d-none d-md-block">Corpu</span>
                    </nuxt-link>

                    <button class="btn btn-black mr-16pt" @click="$refs.courses.show()">
                        Layar <i class="material-icons">arrow_drop_down</i>
                    </button>

                    <b-modal id="courses" ref="courses" size="lg" title="Menu Layar" hide-footer hide-header>
                        <MenuLayar />
                    </b-modal>

                    <!-- <form class="search-form search-form--black search-form-courses d-none d-md-flex"
                        action="library-filters.html">
                        <input type="text" class="form-control" placeholder="What would you like to learn?">
                        <button class="btn" type="submit" role="button"><i class="material-icons">search</i></button>
                    </form> -->

                    <nav v-if="$auth.user" class="nav navbar-nav ml-auto flex-nowrap">
                        <div class="nav-item dropdown d-sm-flex ml-16pt">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">

                                <p class="text-white ml-16pt d-none d-sm-flex align-items-center">{{$auth.user.username}}</p>
                                <img style="width:32px;height:32px;margin-left:15px" class="rounded-circle"
                                    src="~static/img/guy-3.jpg" alt="student" />
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">

                                <h6 class="dropdown-header">Role</h6>
                                <a class="dropdown-item disabled" href="#">Under Construction</a>
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item" @click.prevent="logout">Logout</a>

                            </div>
                        </div>
                        <div class="nav-item dropdown dropdown-notifications dropdown-full-xs">
                            <button class="nav-link btn-flush dropdown-toggle" type="button" data-toggle="dropdown"
                                data-caret="false">
                                <i class="material-icons">notifications</i>
                                <span class="badge badge-pill badge-accent">2</span>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right">
                                <div class="list-group list-group-flush">
                                    <a href="#" class="list-group-item list-group-item-action">
                                        <small class="text-muted list-group-item-meta">3 min ago</small>
                                        <div class="media">
                                            <div class="media-left align-self-center">
                                                <i class="material-icons md-2 icon--left text-danger">account_circle</i>
                                            </div>
                                            <div class="media-body align-self-center">
                                                <p class="mb-1 lh-1">Your profile information has not been synced
                                                    correctly.</p>
                                            </div>
                                        </div>
                                    </a>
                                    <div class="list-group-item list-group-item-action">
                                        <small class="text-muted list-group-item-meta">5 hrs ago</small>
                                        <div class="media">
                                            <div class="media-left align-self-center">
                                                <i class="material-icons md-2 icon--left text-success">group_add</i>
                                            </div>
                                            <div class="media-body align-self-center">
                                                <p class="mb-1 lh-1"><a href="#" class="flex-inline">Adrian. D</a> wants
                                                    to join you.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="#" class="list-group-item list-group-item-action">
                                        <small class="text-muted list-group-item-meta">1 day ago</small>
                                        <div class="media">
                                            <div class="media-left align-self-center">
                                                <i class="material-icons md-2 icon--left text-warning">storage</i>
                                            </div>
                                            <div class="media-body align-self-center">
                                                <p class="mb-1 lh-1">Your deploy was successful.</p>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </nav>
                    <ul v-else class="nav navbar-nav ml-auto d-none d-sm-flex">
                        <li class="nav-item">
                            <nuxt-link to="/login" class="nav-link">Login</nuxt-link>
                        </li>
                    </ul>

                </div>

            </div>
        </b-navbar>
    </section>
</template>

<script>
    import MenuLayar from '@@/components/MenuLayar'

    export default {
        components: {
            MenuLayar
        },
        data() {
            return {

            }
        },
        methods: {
            async logout() {
                await this.$auth.logout();
                this.$router.push('/login')
            },
        }
    }

</script>

<style scoped>
    /* .bg-dark {
        background-color: #3e3f40 !important;
    } */

</style>
