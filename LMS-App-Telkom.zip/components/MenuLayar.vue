<template>
    <div id="courses">
        <div class="">
            <div class="">
                <div class="modal-body">
                    <div class="row" style=" min-width: 300px;">
                        <div class="col-md-6 col-sm-6 col-i8-plus bg-body pr-0">
                            <div class="py-16pt pl-16pt menu">
                                <ul class="nav flex-column">
                                    <li v-for="(parent, index) in parents" :key="index" class="nav-item">
                                        <a class="nav-link" :href="`${parent.id}`"
                                            data-toggle="tab">{{parent.label}}</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-6 col-i8-plus-auto tab-content">
                            <!-- Front Page -->
                            <!-- <span v-for="(children, index) in childrens" :key="index"> -->
                            <div v-for="(children, index) in childrens" :key="index" :id="children.parentId"
                                class="tab-pane">
                                <div class="row no-gutters">
                                    <div class="col-md-12 p-0">
                                        <div class="p-24pt d-flex h-100 flex-column">
                                            <div class="flex">
                                                <ul v-for="(link, index) in children.links" :key="index"
                                                    class="nav flex-column">
                                                    <li class="nav-item">
                                                        <nuxt-link :to="link.link" class="nav-link px-0"
                                                            data-dismiss="modal">{{link.label}}</nuxt-link>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- </span> -->




                        </div>
                    </div>
                    <button @click="$bvModal.hide('courses')" type="button" class="close" data-dismiss="modal">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        data() {
            return {

                parents: [{
                        id: '#frontPage',
                        label: 'Homepage / Login'
                    },
                    {
                        id: '#learningStrategy',
                        label: 'Learning Strategy'
                    },
                    {
                        id: '#curriculums',
                        label: 'Curriculum'
                    },
                    {
                        id: '#learningActivity',
                        label: 'Learning Activity'
                    },
                    {
                        id: '#event',
                        label: 'Event'
                    },
                    {
                        id: '#resource',
                        label: 'Resource'
                    },
                    {
                        id: '#layarmockup',
                        label: 'Layar Mentahan'
                    },
                ],

                // childs ---------------
                childrens: [{
                        parentId: 'frontPage',
                        links: [{
                                link: '/',
                                label: 'Landing'
                            },
                            {
                                link: '/login',
                                label: 'Login'
                            }
                        ]
                    },
                    {
                        parentId: 'curriculums',
                        links: [{
                                link: '/curriculum',
                                label: 'Index'
                            },{
                                link: '/curriculum/request',
                                label: 'Curriculum Request'
                            },{
                                link: '/curriculum/learning-path',
                                label: 'Learning Path'
                            },
                        ]
                    },
                    {
                        parentId: 'learningActivity',
                        links: [{
                            link: '/learning-activity',
                            label: 'Index'
                        }, ]
                    },
                    {
                        parentId: 'learningPlan',
                        links: [{
                                link: '/learning-plan',
                                label: 'Index'
                            },

                        ]
                    },
                    {
                        parentId: 'learningStrategy',
                        links: [{
                            link: '/learning-strategy',
                            label: 'Index'
                        }, ]
                    },
                    {
                        parentId: 'event',
                        links: [{
                                link: '/event/event',
                                label: 'Event  Realization'
                            },
                            {
                                link: '/event/event-plan',
                                label: 'Event Planning'
                            },
                        ]
                    },
                    {
                        parentId: 'resource',
                        links: [{
                            link: '/resource',
                            label: 'Master (Participant, Trainer, Room, ...)'
                        },{
                            link: '/resource/object',
                            label: 'Object'
                        }, ]
                    },
                    {
                        parentId: 'event',
                        links: [{
                            link: '/event/event',
                            label: 'Index'
                        }, ]
                    },
                    {
                        parentId: 'layarmockup',
                        links: [
                            { link: '/mockups/Layar15-manage-question', label: 'Layar15-manage-question' },
                            { link: '/mockups/Layar16a&16b-manage-question', label: 'Layar16a&16b-manage-question' },
                            { link: '/mockups/Layar20a-manage-feedback-bank', label: 'Layar20a-manage-feedback-bank' },
                            { link: '/mockups/Layar20b-feedback-test-add', label: 'Layar20b-feedback-test-add' },
                            { link: '/mockups/Layar23-manage-test-template', label: 'Layar23-manage-test-template' },
                            { link: '/mockups/Layar26-event-plan', label: 'Layar26-event-plan' },
                            { link: '/mockups/Layar27-event-plan-add', label: 'Layar27-event-plan-add' },
                            { link: '/mockups/Layar28-add-c1', label: 'Layar28-add-c1' },
                            { link: '/mockups/Layar28-recap-expert', label: 'Layar28-recap-expert' },
                            { link: '/mockups/Layar29-add-c2', label: 'Layar29-add-c2' },
                            { link: '/mockups/Layar30-add-c3', label: 'Layar30-add-c3' },
                            { link: '/mockups/Layar31-add-c4', label: 'Layar31-add-c4' },
                            { link: '/mockups/Layar32-add-c5', label: 'Layar32-add-c5' },
                            { link: '/mockups/Layar33-add-c6', label: 'Layar33-add-c6' },
                            { link: '/mockups/Layar34-add-c3-classroom', label: 'Layar34-add-c3-classroom' },
                            { link: '/mockups/Layar35-add-c3-budget', label: 'Layar35-add-c3-budget' },
                            { link: '/mockups/Layar36add-c3-expert', label: 'Layar36add-c3-expert' },
                            { link: '/mockups/Layar37-index', label: 'Layar37-index' },
                            { link: '/mockups/Layar38-edit', label: 'Layar38-edit' },
                            { link: '/mockups/Layar39-add-c3-work', label: 'Layar39-add-c3-work' },
                            { link: '/mockups/Layar40-add-c3-delivery', label: 'Layar40-add-c3-delivery' },
                            { link: '/mockups/Layar41-index', label: 'Layar41-index' },
                            { link: '/mockups/Layar42-index', label: 'Layar42-index' },
                            { link: '/mockups/Layar43-proposed-learning', label: 'Layar43-proposed-learning' },
                            { link: '/mockups/Layar44-forum', label: 'Layar44-forum' },
                            { link: '/mockups/Layar45-insight', label: 'Layar45-insight' },
                            { link: '/mockups/Layar46-cycle-1', label: 'Layar46-cycle-1' },
                            { link: '/mockups/Layar47-cycle-2', label: 'Layar47-cycle-2' },
                            { link: '/mockups/Layar48-cycle-3', label: 'Layar48-cycle-3' },
                            { link: '/mockups/Layar49-cycle-4', label: 'Layar49-cycle-4' },
                            { link: '/mockups/Layar50-cycle-5', label: 'Layar50-cycle-5' },
                            { link: '/mockups/Layar51-cycle-6', label: 'Layar51-cycle-6' },
                            { link: '/mockups/Layar52-53-54-feedback_penyelenggara', label: 'Layar52-53-54-feedback_penyelenggara' },
                            { link: '/mockups/Layar55-quiz', label: 'Layar55-quiz' },
                            { link: '/mockups/Layar56-event-detail-4', label: 'Layar56-event-detail-4' },
                        ]
                    }
                ]
            }
        },

    }

</script>

<style>

</style>
