<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Curriculum </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <input type="text" class="form-control" name="company" id="company"
                    v-bind:class="{ 'is-danger': errors.has('collection.company') }"
                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId" :value="learningActivity.detail.business_code.company_name" disabled>
                <p v-show="errors.has('collection.company')" class="help is-danger"> {{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="learningactivity">Learning Activity</label>
                <input type="text" class="form-control" name="learningactivity" id="learningactivity"
                    v-bind:class="{ 'is-danger': errors.has('collection.learningactivity') }"
                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId" :value="learningActivity.detail.activity_name" disabled>
                <p v-show="errors.has('collection.learningactivity')" class="help is-danger"> {{ errors.first('collection.learningactivity') }}</p>
            </div>

            <div class="form-group">
                <label for="plcode">Procifiency Level</label>
                <select v-model="plcode" class="form-control" name="plcode" id="plcode"
                    v-bind:class="{ 'is-danger': errors.has('collection.plcode') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in PLCOD.list" :key="index" :value="item.id">
                        {{item.value}}
                    </option>
                </select>
                <p v-show="errors.has('collection.plcode')" class="help is-danger">{{ errors.first('collection.plcode') }}</p>
            </div>

            <div class="form-group">
                <label for="competence">Competence</label>
                <select v-model="competence" class="form-control" name="competence" id="competence"
                    v-bind:class="{ 'is-danger': errors.has('collection.competence') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in CMPTY.list" :key="index" :value="item.id">
                        {{item.value}}
                    </option>
                </select>
                <p v-show="errors.has('collection.competence')" class="help is-danger">{{ errors.first('collection.competence') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('competenceActivityForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            business_code : null,
            competence : null,
            plcode: null,
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.competence_activity.detail) this.getData()

        this.getParam()
    },
    computed: {
        ...mapState({
            learningActivity : state => state.learningActivity,
            PLCOD : state => state.PLCOD,
            CMPTY: state => state.CMPTY,
            competence_activity: state => state.competence_activity,
            
        })
    },
    methods: {
        getParam(){
            this.$store.dispatch('CMPTY/getAll', {business_code:['*', this.learningActivity.detail.business_code.business_code]})
            this.$store.dispatch('PLCOD/getAll', {business_code:['*', this.learningActivity.detail.business_code.business_code]})
        },
        getData() {
            this.object_identifier = this.competence_activity.detail.object_identifier
            // this.learningpath =  this.competence_activity.detail.learningpath.id
            this.competence =  this.competence_activity.detail.object2.id
            this.plcode =  this.competence_activity.detail.object1.id
            this.business_code =  this.competence_activity.detail.business_code.business_code
            this.begin_date = this.competence_activity.detail.begin_date
            this.end_date = this.competence_activity.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/lmsrelation2object', {
                business_code : this.learningActivity.detail.business_code.business_code,
                table_code : "LRACT",
                id : this.learningActivity.detail.activity_id,
                relation : "L001",
                otype1: "PLCOD",
                object1 : this.plcode,
                otype2: "CMPTY",
                object2 : this.competence,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('competenceActivityForm')
                this.$store.dispatch('competence_activity/getAll',{id:[this.learningActivity.detail.activity_id]});  
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/lmsrelation2object', {
                object_identifier : this.object_identifier,
                business_code : this.learningActivity.detail.business_code.business_code,
                table_code : "LRACT",
                id : this.learningActivity.detail.activity_id,
                relation : "L001",
                otype1: "PLCOD",
                object1 : this.plcode,
                otype2: "CMPTY",
                object2 : this.competence,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('competenceActivityForm')
                this.$store.dispatch('competence_activity/getAll',{id:[this.learningActivity.detail.activity_id]});  
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.business_code = null
            this.competence =  null
            this.plcode =  null
            this.begin_date = null
            this.end_date = null

            this.$validator.reset('collection')
        },


    },
}

</script>
