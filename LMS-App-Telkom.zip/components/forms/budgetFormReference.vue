<template>
    <div class="">
        <div class="card " v-if="type == 'event' && batch.reference.batch_id">
            <div class="">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Cost Item</th>
                            <th>Unit Price</th>
                            <th>Quantity</th>
                            <th>Subtotal Price</th>
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in batchBudgetReferenceList" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td>{{ item.wage_type.wage_name }}</td>
                            <td>{{ numberFormat(item.price) }}</td>
                            <td>{{ item.quantity }}</td>
                            <td>{{ numberFormat(item.price * item.quantity) }}</td>
                            <td>{{ moment(item.begin_date) }}</td>
                            <td>{{ moment(item.end_date) }}</td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier)">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="batchBudget.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='batchBudget' :storeModuleName="'batchBudget'" />
            </div>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState, mapActions } from 'vuex';
import paginationBar from '@@/components/paginationBar'


export default {
    components : { paginationBar },
    created() {        
        this.$store.dispatch('session/getReference');
    },
    data() {
        return {
            type : this.$route.query.type
        }
    },
    computed: {
        ...mapState({
            batch : state => state.batch.detail,
            batchBudget : state => state.batchBudget,
        }),
        batchBudgetReferenceList(){
            return this.batchBudget.listReference.filter((sessRef, index) => {
                return this.batchBudget.list.find(batchBudget => batchBudget.reference.session_id == sessRef.session_id ) === undefined
            })
        }
    },
    methods: {

        submit(plannedSession){
            this.$axios.post('lms/api/session', {
                business_code : this.batch.business_code.business_code,
                batch : this.batch.batch_id,
                session_name : plannedSession.session_name,
                learning_activity : plannedSession.learning_activity.activity_id || ' ',
                reference : plannedSession.session_id,
                begin_date : plannedSession.begin_date,
                end_date : plannedSession.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.$store.dispatch('session/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },


        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }

    },
}

</script>
