<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Batch Participant </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="batch_name">Batch</label>
                <select v-model="batch_name" class="form-control" name="batch_name" id="batch_name"
                    :class="{ 'is-danger': errors.has('collection.batch_name') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <option v-for="(item, index) in batch.list" :key="index" :value="item.batch_id">
                        {{ item.batch_name }}
                    </option>
                </select>
                <p v-show="errors.has('collection.batch_name')" class="help is-danger">
                    {{ errors.first('collection.batch_name') }}</p>
            </div>

            <div class="form-group">
                <label for="participant_name">Participant</label>
                <select v-model="participant_name" class="form-control" name="participant_name" id="participant_name"
                    :class="{ 'is-danger': errors.has('collection.participant') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <option v-for="(item, index) in participant.list" :key="index" :value="item.participant_id">
                        {{ item.complete_name }}
                    </option>
                </select>
                <p v-show="errors.has('collection.participant')" class="help is-danger">
                    {{ errors.first('collection.participant') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger">
                                {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                                data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('batchParticipantForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
    import {
        mapState
    } from 'vuex';

    export default {
        data() {
            return {
                object_identifier: null,

                begin_date: null,
                end_date: null,
                business_code: null,

                batch_name: null,
                participant_name: null,
            }
        },
        created() {
            if (this.batchParticipant.detail) this.getData()

            this.$store.dispatch('batch/getAll');
            this.$store.dispatch('participant/getAll');
        },
        computed: {
            ...mapState({
                batchParticipant: state => state.batchParticipant,
                batch: state => state.batch,
                participant: state => state.participant,
            })
        },
        methods: {

            getData() {
                this.object_identifier = this.batchParticipant.detail.object_identifier
                this.batch_name = this.batchParticipant.detail.batch.batch_id
                this.participant_name = this.batchParticipant.detail.participant.participant_id
                this.business_code = this.batchParticipant.detail.business_code.business_code
                this.begin_date = this.batchParticipant.detail.begin_date
                this.end_date = this.batchParticipant.detail.end_date
            },

            async storeData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.post('lms/api/batchparticipant', {
                        batch: this.batch_name,
                        participant: this.participant_name,
                        business_code: this.batch.detail.business_code.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('batchParticipantForm')
                        this.$store.dispatch('batchParticipant/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            async updateData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.put('lms/api/batchparticipant', {
                        object_identifier: this.object_identifier,
                        batch: this.batch_name,
                        participant: this.participant_name,
                        business_code: this.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Updated!',
                            'Successfully update data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('batchParticipantForm')
                        this.$store.dispatch('batchParticipant/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            resetForm() {
                this.object_identifier = null

                this.batch_name = null
                this.participant_name = null
                this.business_code = null
                this.begin_date = null
                this.end_date = null

                this.$validator.reset('collection')
            },
        },
    }

</script>
