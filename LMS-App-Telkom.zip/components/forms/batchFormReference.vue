<template>
    <div class="">
            <div class="card">
                <div class="">
                    <table class="table table-responsive table-flush table-hover">
                        <thead class="">
                            <tr>
                                <th>No</th>
                                <th>Batch</th>
                                <th>Location</th>
                                <th v-if="currentEvent.event_type.id == '01'">Curriculum</th>
                                <th>Vendor</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in batchReferenceList" :key="index">
                                <td>{{index+1}}</td>
                                <td>{{item.batch_name}}</td>
                                <td>{{item.location.value}}</td>
                                <th v-if="currentEvent.event_type.id == '01'">{{item.curriculum.value}}</th>
                                <td>{{item.vendor && item.vendor.company_name}}</td>
                                <td>
                                    <button type="button" class="btn btn-success btn-sm" @click="submit(item)">
                                        + Add
                                    </button>
                                </td>
                            </tr>
                            <tr v-if="batch.isLoadingR">
                                <td colspan="10">
                                    <div class="row">
                                        <div class="col d-flex justify-content-center">
                                            <div class="loader loader-accent text-center"></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <paginationBarR :state='batch' :storeModuleName="'batch'" />
                </div>
            </div>

    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';
import paginationBarR from '@@/components/paginationBarR'

export default {
    components : { paginationBarR },
    created() {        
        this.$store.dispatch('batch/getReference', { 'type' : this.type });
    },
    data() {
        return {
            type : this.$route.query.type
        }
    },
    computed: {
        ...mapState({
            currentEvent : state => state.event.detail,
            batch : state => state.batch,
        }),
        batchReferenceList(){
            return this.batch.listReference.filter((batchRef, index) => {
                return this.batch.list.find(batch => batch.reference.batch_id == batchRef.batch_id ) === undefined
            })
        }
    },
    methods: {
        submit(plannedBatch){
            this.$axios.post('lms/api/batch', {
                business_code : this.currentEvent.business_code.business_code,
                event : this.currentEvent.event_id,
                batch_name : plannedBatch.batch_name,
                location : plannedBatch.location.id,
                curriculum : plannedBatch.curriculum.id || ' ',
                vendor : plannedBatch.vendor.business_code || ' ',
                reference : plannedBatch.batch_id,
                begin_date : plannedBatch.begin_date,
                end_date : plannedBatch.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.$store.dispatch('batch/getAll',{'type':this.type});
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
