<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Component Curriculum </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="learning_activity">Learning Activity</label>
                <select v-model="learning_activity" class="form-control" name="learning_activity" id="learning_activity"
                    v-bind:class="{ 'is-danger': errors.has('collection.learning_activity') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in learningActivity.list" :key="index" :value="item.activity_id">
                        {{item.activity_name}}
                    </option>
                </select>
                <p v-show="errors.has('collection.learning_activity')" class="help is-danger">{{ errors.first('collection.learning_activity') }}</p>
            </div>
            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Begin Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('compCurriForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,
            learning_activity : null,
            begin_date : null,
            end_date : null,
            business_code : null,
        }
    },
    created() {
        if(this.relation.detail) this.getData()

        this.$store.dispatch('learningActivity/getAll',{business_code:['*', this.curriculum.business_code.business_code]})
    },
    computed: {
        ...mapState({
            relation : state => state.relation,
            curriculum: state => state.curriculum.detail,
            learningActivity : state => state.learningActivity,
        })
    },
    methods: {

        getData() {
            this.object_identifier = this.relation.detail.object_identifier

            this.learning_activity = this.relation.detail.id.activity_id
            this.begin_date = this.relation.detail.begin_date
            this.end_date = this.relation.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/lmsrelationobject', {
                table_code : "LRACT",
                id : this.learning_activity,
                relation : "C001",
                otype : "CURID",
                object : this.curriculum.curriculum.id,
                begin_date : this.begin_date,
                end_date : this.end_date,
                business_code : this.curriculum.business_code.business_code,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('compCurriForm')
                this.$store.dispatch('relation/getAll',{'object[]':this.curriculum.curriculum.id,'table_code[]':'LRACT','relation[]':'C001','otype[]':'CURID'})
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/lmsrelationobject', {
                object_identifier : this.object_identifier,
                table_code : "LRACT",
                id : this.learning_activity,
                relation : "C001",
                otype : "CURID",
                object : this.relation.detail.object.id,
                begin_date : this.begin_date,
                end_date : this.end_date,
                business_code : this.curriculum.business_code.business_code,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('compCurriForm')
                this.$store.dispatch('relation/getAll',{'object[]':this.curriculum.curriculum.id,'table_code[]':'LRACT','relation[]':'C001','otype[]':'CURID'})
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.learning_activity = null
            this.object_identifier = null
            this.begin_date = null,
            this.end_date = null,

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }

    },
}

</script>
