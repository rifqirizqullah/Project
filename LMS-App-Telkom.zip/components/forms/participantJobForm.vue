<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Participant Job</h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <input v-model="business_code" type="text" name="company" id="company" class="form-control"
                    :placeholder="participant.business_code.company_name" aria-describedby="company"
                    v-bind:class="{ 'is-danger': errors.has('collection.company')}" v-validate="'required'"
                    data-vv-scope="collection" disabled />
                <p v-show="errors.has('collection.company')" class="help is-danger">
                    {{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="participant_company">Participant Company</label>
                <select v-model="participant_company" class="form-control" name="participant_company"
                    id="participant_company" :class="{ 'is-danger': errors.has('collection.participant_company') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(data, index) in companies" :key="index" :value="data">
                        {{data.value}}</option>
                </select>
                <p v-show="errors.has('collection.participant_company')" class="help is-danger">
                    {{ errors.first('collection.participant_company') }}</p>
            </div>

            <div class="form-group" v-if="participant.participant_type.id == 1">
                <label for="gender">Unit</label>
                <select v-model="unit" class="form-control" name="unit" id="unit"
                    v-bind:class="{ 'is-danger': errors.has('collection.unit') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <!-- <option disabled value="">-</option> -->
                    <option v-for="(data, index) in unitMaster" :key="index" :value="data">
                        {{data.value}}</option>
                </select>
                <p v-show="errors.has('collection.unit')" class="help is-danger">
                    {{ errors.first('collection.unit') }}</p>
            </div>
            <div class="form-group" v-else>
                <label for="religion">Unit</label>
                <input v-model="unit" type="text" name="unit" id="unit" class="form-control" placeholder="Unit"
                    aria-describedby="unit" v-bind:class="{ 'is-danger': errors.has('collection.unit')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.unit')" class="help is-danger">
                    {{ errors.first('collection.unit') }}</p>
            </div>

            <div class="form-group" v-if="participant.participant_type.id == 1">
                <label for="religion">Job</label>
                <select v-model="job" class="form-control" name="job" id="job"
                    v-bind:class="{ 'is-danger': errors.has('collection.job') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <!-- <option disabled value="">-</option> -->
                    <option v-for="(data, index) in jobMaster" :key="index" :value="data">
                        {{data.value}}</option>
                </select>
                <p v-show="errors.has('collection.job')" class="help is-danger">
                    {{ errors.first('collection.job') }}</p>
            </div>
            <div class="form-group" v-else>
                <label for="religion">Job</label>
                <input v-model="job" type="text" name="job" id="job" class="form-control" placeholder="Job"
                    aria-describedby="job" v-bind:class="{ 'is-danger': errors.has('collection.job')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.job')" class="help is-danger">
                    {{ errors.first('collection.job') }}</p>
            </div>

            <div class="form-group" v-if="participant.participant_type.id == 1">
                <label for="language">Position</label>
                <select v-model="position" class="form-control" name="position" id="position"
                    v-bind:class="{ 'is-danger': errors.has('collection.position') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <!-- <option disabled value="">-</option> -->
                    <option v-for="(data, index) in positionMaster" :key="index" :value="data">
                        {{data.value}}</option>
                </select>
                <p v-show="errors.has('collection.position')" class="help is-danger">
                    {{ errors.first('collection.position') }}</p>
            </div>
            <div class="form-group" v-else>
                <label for="religion">Position</label>
                <input v-model="position" type="text" name="position" id="position" class="form-control"
                    placeholder="Position" aria-describedby="position"
                    v-bind:class="{ 'is-danger': errors.has('collection.position')}" v-validate="'required'"
                    data-vv-scope="collection">
                <p v-show="errors.has('collection.position')" class="help is-danger">
                    {{ errors.first('collection.position') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger">
                                {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                                data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('participantJobForm')">Cancel</b-button>
            <!-- <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button> -->
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
    import moment from 'moment'
    import {
        mapState
    } from 'vuex';

    export default {
        data() {
            return {
                object_identifier: null,
                business_code: null,
                personnel_number: null,
                begin_date: null,
                end_date: null,
                participant_id: null,
                participant_company: null,
                unit: null,
                job: null,
                position: null,

                companies: [],
                jobMaster: [],
                positionMaster: [],
                unitMaster: [],
            }
        },
        created() {
            if (this.participantJob.detail) this.getData()
            this.getCompany();
            this.getJobMaster()
            this.getPositionMaster()
            this.getUnitMaster()
        },
        computed: {
            ...mapState({
                participant: state => state.participant.detail,
                participantJob: state => state.participantJob,
            })
        },
        methods: {

            getCompany() {
                this.$axios.get(
                        'hcis/api/company?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD")
                    )
                    .then(response => {
                        this.companies = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.companies.push({
                                id: data.business_code,
                                value: data.company_name,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getJobMaster() {
                this.$axios.get(
                        'hcis/api/organization-data?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&organization_type[]=C&business_code[]=' + this.participant.business_code.business_code +
                        '&per_page=999'
                    )
                    .then(response => {
                        this.jobMaster = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.jobMaster.push({
                                id: data.organization_code,
                                value: data.organization_name,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getPositionMaster() {
                this.$axios.get(
                        'hcis/api/organization-data?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&organization_type[]=S&business_code[]=' + this.participant.business_code.business_code +
                        '&per_page=999'
                    )
                    .then(response => {
                        this.positionMaster = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.positionMaster.push({
                                id: data.organization_code,
                                value: data.organization_name,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getUnitMaster() {
                this.$axios.get(
                        'hcis/api/organization-data?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&organization_type[]=O&business_code[]=' + this.participant.business_code.business_code +
                        '&per_page=999'
                    )
                    .then(response => {
                        this.unitMaster = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.unitMaster.push({
                                id: data.organization_code,
                                value: data.organization_name,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },

            getData() {
                if (this.participantJob.detail.participant.participant_type.id == 1) {
                    var unit = {
                        id: this.participantJob.detail.unit_code,
                        value: this.participantJob.detail.unit_name
                    }
                    var job = {
                        id: this.participantJob.detail.job_code,
                        value: this.participantJob.detail.job_name
                    }
                    var position = {
                        id: this.participantJob.detail.position_code,
                        value: this.participantJob.detail.position_name
                    }
                } else {
                    var unit = this.participantJob.detail.unit_name
                    var job = this.participantJob.detail.job_name
                    var position = this.participantJob.detail.position_name
                }
                this.object_identifier = this.participantJob.detail.object_identifier;
                this.business_code = this.participantJob.detail.business_code.company_name;
                this.begin_date = this.participantJob.detail.begin_date;
                this.end_date = this.participantJob.detail.end_date;
                this.participant_id = this.participantJob.detail.participant.participant_id;
                this.participant_company = {
                    id: this.participantJob.detail.company_code,
                    value: this.participantJob.detail.company_name
                };
                this.unit = unit;
                this.job = job;
                this.position = position;
            },

            async storeData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                if (this.participant.participant_type.id == 2) {
                    var unit_code = ' ';
                    var unit_value = this.unit;
                    var job_code = ' ';
                    var job_value = this.job;
                    var position_code = ' ';
                    var position_value = this.position;
                } else {
                    var unit_code = this.unit.id;
                    var unit_value = this.unit.value
                    var job_code = this.job.id;
                    var job_value = this.job.value;
                    var position_code = this.position.id;
                    var position_value = this.position.value;
                }
                this.$axios.post('lms/api/participantjob', {
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.participant.business_code.business_code,
                        participant: this.participant.participant_id,
                        company_code: this.participant_company.id,
                        company_name: this.participant_company.value,
                        unit_code: unit_code,
                        unit_name: unit_value,
                        job_name: job_value,
                        job_code: job_code,
                        position_code: position_code,
                        position_name: position_value,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        // this.resetForm()
                        this.$bvModal.hide('participantJobForm')
                        this.$store.dispatch('participantJob/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            async updateData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                if (this.participant.participant_type.id == 2) {
                    var unit_code = ' ';
                    var unit_value = this.unit;
                    var job_code = ' ';
                    var job_value = this.job;
                    var position_code = ' ';
                    var position_value = this.position;
                } else {
                    var unit_code = this.unit.id;
                    var unit_value = this.unit.value
                    var job_code = this.job.id;
                    var job_value = this.job.value;
                    var position_code = this.position.id;
                    var position_value = this.position.value;
                }
                this.$axios
                    .put('lms/api/participantjob', {
                        object_identifier: this.object_identifier,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.participant.business_code.business_code,
                        participant: this.participant.participant_id,
                        company_code: this.participant_company.id,
                        company_name: this.participant_company.value,
                        unit_code: unit_code,
                        unit_name: unit_value,
                        job_name: job_value,
                        job_code: job_code,
                        position_code: position_code,
                        position_name: position_value,
                    })
                    .then(() => {
                        this.$swal(
                            'Updated!',
                            'Successfully update data.',
                            'success'
                        )
                        // this.resetForm()
                        this.$bvModal.hide('participantJobForm')
                        this.$store.dispatch('participantJob/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            resetForm() {
                this.object_identifier = null
                this.business_code = null
                this.begin_date = null
                this.end_date = null
                this.participant_id = null
                this.participant_company = null
                this.unit = null
                this.job = null
                this.position = null

                this.$validator.reset('collection')
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            },
        },
    }

</script>
