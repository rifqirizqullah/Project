<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Room </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="business_code">Company</label>
                <select
                    v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }"
                    v-validate="'required'" data-vv-scope="collection"
                    @change="syncCompanyParams()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger"> {{ errors.first('collection.business_code') }}</p>
            </div>

            <div class="form-group">
                <label for="room_name">Room Name</label>
                <input v-model="room_name" type="text" name="room_name"
                    id="room_name" class="form-control" placeholder="Room Name"
                    aria-describedby="room_name" v-bind:class="{ 'is-danger': errors.has('collection.room_name')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.room_name')" class="help is-danger"> {{ errors.first('collection.room_name') }}</p>
            </div>

            <div class="form-group">
                <label for="building">Building</label>
                <select v-model="building" class="form-control" name="building"
                    id="building" v-bind:class="{ 'is-danger': errors.has('collection.building') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in building_list" :key="index" :value="item.build_code">
                        {{item.build_name}}</option>
                </select>
                <p v-show="errors.has('collection.building')" class="help is-danger">{{ errors.first('collection.building') }}</p>
            </div>

            <div class="form-group">
                <label for="floor">Floor</label>
                <input v-model="floor" type="text" name="floor"
                    id="floor" class="form-control" placeholder="floor"
                    aria-describedby="floor" v-bind:class="{ 'is-danger': errors.has('collection.floor')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.floor')" class="help is-danger"> {{ errors.first('collection.floor') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('roomForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            business_code : null,
            room_name  : null,
            building : null,
            floor : null,
            begin_date : null,
            end_date : null,

        }
    },
    created() {
        if(this.room.detail) {
            this.getData()
            this.syncCompanyParams()
        }
        this.$store.dispatch('company/getAll');
    },
    computed: {
        ...mapState({
            room : state => state.room,
            building_list : state => state.building.list,
            company : state => state.company,
        })
    },
    methods: {

        syncCompanyParams() {
            this.$store.dispatch('building/getAll', {business_code : ['*', this.business_code]})
        },

        getData() {
            this.object_identifier = this.room.detail.object_identifier

            this.business_code = this.room.detail.business_code.business_code
            this.room_name  = this.room.detail.room_name
            this.building = this.room.detail.building.building_code
            this.floor = this.room.detail.floor
            this.begin_date = this.room.detail.begin_date
            this.end_date = this.room.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            this.$axios.post('lms/api/room', {
                business_code : this.business_code,
                room_name  : this.room_name,
                building : this.building,
                floor : this.floor,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then((res) => {
                console.log(res);
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('roomForm')
                this.$store.dispatch('room/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            this.$axios.put('lms/api/room', {
                object_identifier : this.object_identifier,
                business_code : this.business_code,
                room_name  : this.room_name,
                building : this.building,
                floor : this.floor,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('roomForm')
                this.$store.dispatch('room/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.business_code = null
            this.room_name  = null
            this.building = null
            this.floor = null
            this.begin_date = null
            this.end_date = null

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
