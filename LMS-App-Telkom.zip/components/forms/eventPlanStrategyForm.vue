<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Event Plan Strategy </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="learningStrategy">Learning Strategy</label>
                <select
                    v-model="child" class="form-control" name="learningStrategy" id="learningStrategy"
                    :class="{ 'is-danger': errors.has('collection.learningStrategy') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in learningStrategy.list" :key="index" :value="item.organization_strategy_id">{{item.organization_strategy_name}}</option>
                </select>
                <p v-show="errors.has('collection.learningStrategy')" class="help is-danger">{{ errors.first('collection.learningStrategy') }}</p>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('eventPlanStrategyForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            parent : null,
            child : null,
            business_code : null,
            otype_parent : "EVENT",
            otype_child : "ORGST",
            relation : "E002",
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        this.$store.dispatch('learningStrategy/getAll', {
            per_page : 30,
            business_code : [this.current_eventPlan.business_code.business_code]
        });
    },
    computed: {
        ...mapState({
            eventPlan_id: state => state.eventPlan.detail.event_id,
            learningStrategy: state => state.learningStrategy,
            current_eventPlan: state => state.eventPlan.detail
        })
    },
    methods: {

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/lmsrelation', {
                parent : this.eventPlan_id,
                child : this.child,
                business_code : this.current_eventPlan.business_code.business_code,
                otype_parent : "EVENT",
                otype_child : "ORGST",
                relation : "E002",
                begin_date : this.formatDate(new Date),
                end_date : "9999-12-30",
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventPlanStrategyForm')
                this.$store.dispatch('eventPlanStrategy/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null

            this.parent = null
            this.child = null
            this.business_code = null
            this.otype_parent = "EVENT"
            this.otype_child = "ORGST"
            this.relation = "E002"
            this.begin_date = this.formatDate(new Date)
            this.end_date = "9999-12-30"

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
