<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Penyelenggaraan Event </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="business_code">Company</label>
                <select
                    v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }"
                    v-validate="'required'" data-vv-scope="collection"
                    @change="syncCompanyParams()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger"> {{ errors.first('collection.business_code') }}</p>
            </div>

            <div class="form-group">
                <label for="organization">Unit</label>
                <select
                    v-model="organization" class="form-control" name="organization" id="organization"
                    :class="{ 'is-danger': errors.has('collection.organization') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in unit.list" :key="index" :value="item.organization_code">{{item.organization_name}}</option>
                </select>
                <p v-show="errors.has('collection.organization')" class="help is-danger">{{ errors.first('collection.organization') }}</p>
            </div>

            <div class="form-group">
                <label for="event_name">Event Name</label>
               <input v-model="event_name" type="text" name="event_name"
                    id="event_name" class="form-control" placeholder="Event Name ..."
                    v-bind:class="{ 'is-danger': errors.has('collection.event_name')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.event_name')" class="help is-danger">{{ errors.first('collection.event_name') }}</p>
            </div>

            <div class="form-group">
                <label for="event_type">Event Type</label>
                <select
                    v-model="event_type" class="form-control" name="event_type" id="event_type"
                    :class="{ 'is-danger': errors.has('collection.event_type') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in eventType.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.event_type')" class="help is-danger">{{ errors.first('collection.event_type') }}</p>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <input
                    v-model="description" type="text" class="form-control" name="description" id="description" placeholder="Description ..."
                    :class="{ 'is-danger': errors.has('collection.description') }"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <p v-show="errors.has('collection.description')" class="help is-danger">{{ errors.first('collection.description') }}</p>
            </div>

            <div class="form-group">
                <label for="event_status">Event Status</label>
                <select
                    v-model="event_status" class="form-control" name="event_status" id="event_status"
                    :class="{ 'is-danger': errors.has('collection.event_status') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in LEVST.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.event_status')" class="help is-danger">{{ errors.first('collection.event_status') }}</p>
            </div>

            <div class="form-group">
                <label for="vendor">Vendor</label>
                <select
                    v-model="vendor" class="form-control" name="vendor" id="vendor"
                    :class="{ 'is-danger': errors.has('collection.vendor') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in companyRelation.list" :key="index" :value="item.child_company.business_code">{{item.child_company.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.vendor')" class="help is-danger">{{ errors.first('collection.vendor') }}</p>
            </div>

            <div class="form-group">
                <label for="reference">Reference Plan</label>
                <select
                    v-model="reference" class="form-control" name="reference" id="reference"
                    :class="{ 'is-danger': errors.has('collection.reference') }"
                    v-validate="''" data-vv-scope="collection"
                >
                    <option :value="0" class="text-muted"> No Reference </option>
                    <option v-for="(item, index) in eventPlan.list" :key="index" :value="item.event_id">{{item.event_name}}</option>
                </select>
                <p v-show="errors.has('collection.reference')" class="help is-danger">{{ errors.first('collection.reference') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>




        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('eventForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            business_code : null,
            organization : null,
            event_name :  null,
            event_type : null,
            description : null,
            event_status : null,
            vendor :  null,
            event_situation : null,
            reference: null,
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.event.detail) {
            this.getData()
            this.syncCompanyParams()
        }
        this.$store.dispatch('company/getAll');
        
    },
    computed: {
        ...mapState({
            event : state => state.event,
            eventPlan : state => state.eventPlan,
            eventType : state => state.EVNTY,
            LEVST : state => state.LEVST,
            unit : state => state.unit,
            companyRelation : state => state.companyRelation,
            company : state => state.company,
        })
    },
    methods: {

        syncCompanyParams() {
            this.$store.dispatch('LEVST/getAll' , { business_code : ['*', this.business_code] });
            this.$store.dispatch('EVNTY/getAll', { business_code : ['*', this.business_code] });
            this.$store.dispatch('unit/getAll', { business_code : ['*', this.business_code] });
            this.$store.dispatch('companyRelation/getAll', { business_code : ['*', this.business_code] });
            this.$store.dispatch('eventPlan/getAll', { business_code : ['*', this.business_code] });
        },

        getData() {
            this.object_identifier = this.event.detail.object_identifier
            this.description = this.event.detail.description
            this.event_status = this.event.detail.event_status.id
            this.vendor =  this.event.detail.vendor.business_code
            this.business_code = this.event.detail.business_code.business_code
            this.begin_date = this.event.detail.begin_date
            this.end_date = this.event.detail.end_date
            this.event_name = this.event.detail.event_name
            this.event_type = this.event.detail.event_type.id
            this.organization = this.event.detail.organization.organization_code
            this.reference = this.event.detail.reference.event_id
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/event', {
                business_code : this.business_code,
                organization : this.organization,
                event_name : this.event_name,
                event_type : this.event_type,
                description : this.description,
                event_situation : "2",
                event_status : this.event_status,
                vendor :  this.vendor,
                reference : this.reference || 0,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventForm')
                this.$store.dispatch('event/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/event', {
                object_identifier : this.object_identifier,
                business_code : this.business_code,
                organization : this.organization,
                event_name : this.event_name,
                event_type : this.event_type,
                description : this.description,
                event_situation : "2",
                event_status : this.event_status,
                vendor :  this.vendor,
                reference : this.reference || 0,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventForm')
                this.$store.dispatch('event/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.description = null
            this.event_status = null
            this.vendor =  null
            this.business_code = null
            this.begin_date = null
            this.end_date = null
            this.event_name = null
            this.event_type = null
            this.organization = null
            this.reference = null
            // this.event_situation = null

            this.$validator.reset('collection')
        },


    },
}

</script>
