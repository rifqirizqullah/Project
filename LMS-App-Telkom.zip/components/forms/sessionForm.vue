<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Activity </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="session_name">Activity Name</label>
                <input
                    v-model="session_name" type="text" class="form-control" name="session_name" id="session_name" placeholder="Activity Name ..."
                    :class="{ 'is-danger': errors.has('collection.session_name') }"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <p v-show="errors.has('collection.session_name')" class="help is-danger">{{ errors.first('collection.session_name') }}</p>
            </div>

            <div class="form-group" v-if="batch.curriculum.id">
                <label for="learning_activity">Learning Activity</label>
                <select v-model="learning_activity" class="form-control" name="learning_activity" id="learning_activity"
                    v-bind:class="{ 'is-danger': errors.has('collection.learning_activity') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in learningActivity.list" :key="index" :value="item.id.activity_id">
                        {{item.id.activity_name}}
                    </option>
                </select>
                <p v-show="errors.has('collection.learning_activity')" class="help is-danger">{{ errors.first('collection.learning_activity') }}</p>
            </div>
            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Begin Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('sessionForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            session_name : null,
            learning_activity : null,
            begin_date : null,
            end_date : null,
            business_code : null,
        }
    },
    created() {
        if(this.session.detail) this.getData()
        this.$store.dispatch('relation/getAll', {
            'object[]':this.batch.curriculum.id,
            'table_code[]':'LRACT',
            'relation[]':'C001',
            'otype[]':'CURID'
        })
    },
    computed: {
        ...mapState({
            batch: state => state.batch.detail,
            session : state => state.session,
            learningActivity : state => state.relation,
        })
    },
    methods: {

        getData() {
            this.object_identifier = this.session.detail.object_identifier
            this.session_name = this.session.detail.session_name
            this.learning_activity = this.session.detail.learning_activity.activity_id || 0
            this.reference = this.session.detail.reference.session_id || 0
            this.begin_date = this.session.detail.begin_date
            this.end_date = this.session.detail.end_date
            this.business_code = this.session.detail.business_code.business_code
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/session', {
                batch : this.batch.batch_id,
                session_name : this.session_name,
                learning_activity : this.learning_activity || 0,
                reference : 0,
                begin_date : this.begin_date,
                end_date : this.end_date,
                business_code : this.batch.business_code.business_code,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('sessionForm')
                this.$store.dispatch('session/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/session', {
                object_identifier : this.object_identifier,
                batch : this.batch.batch_id,
                session_name : this.session_name,
                learning_activity : this.learning_activity || 0,
                reference : 0,
                begin_date : this.begin_date,
                end_date : this.end_date,
                business_code : this.batch.business_code.business_code,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('sessionForm')
                this.$store.dispatch('session/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.session_name = null,
            this.learning_activity = null,
            this.reference = null,
            this.begin_date = null,
            this.end_date = null,
            this.business_code = null,

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }

    },
}

</script>
