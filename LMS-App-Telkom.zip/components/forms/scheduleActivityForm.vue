<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Schedule Activity </h4>
        </div>
        <div class='card-body p-4'>


            <div class="form-group">
                <label for="unit">Unit</label>
                <select
                    v-model="unit" class="form-control" name="unit" id="unit"
                    :class="{ 'is-danger': errors.has('collection.unit') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in units.list" :key="index" :value="item.organization_code">{{item.organization_name}}</option>
                </select>
                <p v-show="errors.has('collection.unit')" class="help is-danger">{{ errors.first('collection.unit') }}</p>
            </div>

            <div class="form-group">
                <label for="method">Method</label>
                <select
                    v-model="methodSchedule" class="form-control" name="method" id="method"
                    :class="{ 'is-danger': errors.has('collection.method') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in methodSchedules.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.method')" class="help is-danger">{{ errors.first('collection.method') }}</p>
            </div>

            <div class="form-group">
                <label for="company">Company</label>
                <select
                    v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in companies.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger">{{ errors.first('collection.business_code') }}</p>
            </div>
            <div class="form-group">
                    <label for="topic">Topic</label>
                    <input v-model="topic" type="text" name="topic"
                        id="topic" class="form-control" placeholder="topic"
                        aria-describedby="topic" v-bind:class="{ 'is-danger': errors.has('collection.topic')}"
                        v-validate="'required'" data-vv-scope="collection">
                    <p v-show="errors.has('collection.topic')" class="help is-danger"> {{ errors.first('collection.topic') }}</p>
            </div>                                
            <div class="form-group">
                    <label for="time_class">Time Class</label>
                    <input v-model="time_class" type="number" name="time_class"
                        id="time_class" class="form-control" placeholder="time_class"
                        aria-describedby="time_class" v-bind:class="{ 'is-danger': errors.has('collection.time_class')}"
                        v-validate="'required'" data-vv-scope="collection">
                    <p v-show="errors.has('collection.time_class')" class="help is-danger"> {{ errors.first('collection.time_class') }}</p>
            </div>
            <div class="form-group">
                    <label for="start">Start Time</label>
                    <input v-model="begin_time" type="time" name="start"
                        id="start" class="form-control" placeholder="start time"
                        aria-describedby="start" v-bind:class="{ 'is-danger': errors.has('collection.start')}"
                        v-validate="'required'" data-vv-scope="collection">
                    <p v-show="errors.has('collection.start')" class="help is-danger"> {{ errors.first('collection.start') }}</p>
            </div>
            <div class="form-group">
                    <label for="end">End Time</label>
                    <input v-model="end_time" type="time" name="end"
                        id="end" class="form-control" placeholder="end time"
                        aria-describedby="end" v-bind:class="{ 'is-danger': errors.has('collection.end')}"
                        v-validate="'required'" data-vv-scope="collection">
                    <p v-show="errors.has('collection.end')" class="help is-danger"> {{ errors.first('collection.end') }}</p>
            </div>
            <div class="form-group">
                    <label for="time_class">Time Class</label>
                    <input v-model="time_class" type="number" name="time_class"
                        id="time_class" class="form-control" placeholder="time_class"
                        aria-describedby="time_class" v-bind:class="{ 'is-danger': errors.has('collection.time_class')}"
                        v-validate="'required'" data-vv-scope="collection">
                    <p v-show="errors.has('collection.time_class')" class="help is-danger"> {{ errors.first('collection.time_class') }}</p>
            </div>                                
            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>



        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('scheduleActivityForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,
            schedule_id : null,

            business_code : null,
            unit : null,
            begin_time: null,
            end_time : null,
            methodSchedule : null,            
            time_class : null,
            topic : null,
            begin_date : null,
            end_date : null,

        }
    },
    created() {
        if(this.scheduleActivity.detail) this.getData()

        this.$store.dispatch('unit/getAll');
        this.$store.dispatch('TCMTD/getAll');
        this.$store.dispatch('company/getAll');
    },
    computed: {
        ...mapState({
            event_activity_id: state => state.eventActivity.detail.event_activity_id,
            scheduleActivity: state => state.scheduleActivity,
            companies: state => state.company,
            methodSchedules: state => state.TCMTD,
            units: state => state.unit,
        })
    },
    methods: {

        getData() {
            this.object_identifier = this.scheduleActivity.detail.object_identifier
            this.schedule_id = this.scheduleActivity.detail.schedule_id

            this.business_code = this.scheduleActivity.detail.business_code.business_code
            this.unit = this.scheduleActivity.detail.unit.organization_code
            this.methodSchedule = this.scheduleActivity.detail.method.id
            this.topic = this.scheduleActivity.detail.topic
            this.time_class = this.scheduleActivity.detail.time_class
            this.begin_date = this.scheduleActivity.detail.begin_date
            this.end_date = this.scheduleActivity.detail.end_date
            this.begin_time = this.scheduleActivity.detail.begin_time
            this.end_time = this.scheduleActivity.detail.end_time
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/scheduleactivity', {
                business_code:this.business_code,
                event_activity: this.event_activity_id,
                begin_time:this.begin_time,
                end_time:this.end_time,
                topic: this.topic,
                method: this.methodSchedule,
                time_class: this.time_class,
                unit : this.unit,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('scheduleActivityForm')
                this.$store.dispatch('scheduleActivity/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/scheduleactivity', {
                object_identifier : this.object_identifier,
                business_code:this.business_code,
                event_activity: this.event_activity_id,
                begin_time:this.begin_time,
                end_time:this.end_time,
                topic: this.topic,
                method: this.methodSchedule,
                time_class: this.time_class,
                unit : this.unit,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('scheduleActivityForm')
                this.$store.dispatch('scheduleActivity/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.schedule_id = null

            this.business_code = null
            this.unit = null
            this.methodSchedule = null
            this.topic = null
            this.time_class = null
            this.begin_date = null
            this.end_date = null
            this.begin_time = null
            this.end_time = null

            this.$validator.reset('collection')
        },


    },
}

</script>
