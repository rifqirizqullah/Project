<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Learning Activity </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <select
                    v-model="business_code" class="form-control" name="company" id="company"
                    :class="{ 'is-danger': errors.has('collection.company') }"
                    v-validate="'required'" data-vv-scope="collection" @change="getParam()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.company')" class="help is-danger">{{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="activity_name">Actvity Name</label>
                <input
                    v-model="activity_name" type="text" class="form-control" name="activity_name" id="activity_name" placeholder="Learning Activity Name .."
                    :class="{ 'is-danger': errors.has('collection.activity_name') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                <p v-show="errors.has('collection.activity_name')" class="help is-danger">{{ errors.first('collection.activity_name') }}</p>
            </div>

            <div class="form-group">
                <label for="activity_type">Learning Activity Type</label>
                <select
                    v-model="activity_type" class="form-control" name="activity_type" id="activity_type"
                    :class="{ 'is-danger': errors.has('collection.activity_type') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in ACTTY.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.activity_type')" class="help is-danger">{{ errors.first('collection.activity_type') }}</p>
            </div>

            <div class="form-group">
                <label for="cycle">Cycle</label>
                <select
                    v-model="cycle" class="form-control" name="cycle" id="cycle"
                    :class="{ 'is-danger': errors.has('collection.cycle') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in CYCLE.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.cycle')" class="help is-danger">{{ errors.first('collection.cycle') }}</p>
            </div>

            <div class="form-group">
                <label for="flag_online">Flag Online</label>

                <select
                    v-model="flag_online" class="form-control" name="flag_online" id="flag_online"
                    :class="{ 'is-danger': errors.has('collection.flag_online') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in flag_online_options" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.flag_online')" class="help is-danger">{{ errors.first('collection.flag_online') }}</p>
            </div>

            <div class="form-row form-group mt-4">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="my-1 btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="my-1 btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('learningActivityForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            activity_name: null,
            business_code : null,
            activity_type: null,
            cycle: null,
            flag_online: null,
            begin_date : null,
            end_date : null,

            flag_online_options : [
                {id : true, value : 'Online'},
                {id : false, value : 'Offline'}
            ],
        }
    },
    created() {
        if(this.learningActivity.detail) {
            this.getData()
            this.getParam()
        }
        // this.$store.dispatch('company/getAll');
    },
    computed: {
        ...mapState(['learningActivity','company','ACTTY','CYCLE'])
    },
    methods: {
        getParam(){
            this.$store.dispatch('ACTTY/getAll', {business_code:['*', this.business_code]});
            this.$store.dispatch('CYCLE/getAll', {business_code:['*', this.business_code]});
        },
        getData() {
            this.object_identifier = this.learningActivity.detail.object_identifier
            this.activity_name = this.learningActivity.detail.activity_name
            this.business_code  = this.learningActivity.detail.business_code.business_code
            this.activity_type = this.learningActivity.detail.activity_type.id
            this.cycle = this.learningActivity.detail.cycle.id
            this.flag_online = this.learningActivity.detail.flag_online
            this.begin_date  = this.learningActivity.detail.begin_date
            this.end_date  = this.learningActivity.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/learningactivity', {
                activity_name: this.activity_name,
                business_code : this.business_code,
                activity_type: this.activity_type,
                cycle: this.cycle,
                flag_online: this.flag_online,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('learningActivityForm')
                this.$store.dispatch('learningActivity/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/learningactivity', {
                object_identifier: this.object_identifier,
                activity_name: this.activity_name,
                business_code : this.business_code,
                activity_type: this.activity_type,
                cycle: this.cycle,
                flag_online: this.flag_online,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('learningActivityForm')
                this.$store.dispatch('learningActivity/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.activity_name = null
            this.business_code  = null
            this.activity_type = null
            this.cycle = null
            this.flag_online = null
            this.begin_date  = null
            this.end_date  = null

            this.$validator.reset('collection')
        },


    },
}

</script>
