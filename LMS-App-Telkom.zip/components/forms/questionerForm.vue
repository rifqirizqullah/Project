<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Test </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="business_code">Company</label>
                <select
                    v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }"
                    v-validate="'required'" data-vv-scope="collection"
                    @change="syncCompanyParams()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger"> {{ errors.first('collection.business_code') }}</p>
            </div>

            <div class="form-group">
                <label for="quesioner_title">Title</label>
                <input v-model="quesioner_title" type="text" name="Title"
                    id="quesioner_title" class="form-control" placeholder="quesioner_title"
                    aria-describedby="quesioner_title" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_title')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.quesioner_title')" class="help is-danger"> {{ errors.first('collection.quesioner_title') }}</p>
            </div>

            <div class="form-group">
                <label for="quesioner_text">Text</label>
                <input v-model="quesioner_text" type="text" name="Title"
                    id="quesioner_text" class="form-control" placeholder="quesioner_text"
                    aria-describedby="quesioner_text" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_text')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.quesioner_text')" class="help is-danger"> {{ errors.first('collection.quesioner_text') }}</p>
            </div>

            <div class="form-group">
                <label for="quesioner_type">Type</label>
                <select v-model="quesioner_type" class="form-control" name="quesioner_type"
                    id="quesioner_type" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_type') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(quesioner_type, index) in QSNTY.list" :key="index" :value="quesioner_type.id">
                        {{quesioner_type.value}}</option>
                </select>
                <p v-show="errors.has('collection.quesioner_type')" class="help is-danger">{{ errors.first('collection.quesioner_type') }}</p>
            </div>

            <div class="form-group">
                <label for="quesioner_category">Category</label>
                <select v-model="quesioner_category" class="form-control" name="quesioner_category"
                    id="quesioner_category" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_category') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(quesioner_category, index) in QSTCT.list" :key="index" :value="quesioner_category.id">
                        {{quesioner_category.value}}</option>
                </select>
                <p v-show="errors.has('collection.quesioner_category')" class="help is-danger">{{ errors.first('collection.quesioner_category') }}</p>
            </div>

            <div class="form-group">
                <label for="quesioner_purpose">Purpose</label>
                <select v-model="quesioner_purpose" class="form-control" name="quesioner_purpose"
                    id="quesioner_purpose" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_purpose') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(quesioner_purpose, index) in QSTPR.list" :key="index" :value="quesioner_purpose.id">
                        {{quesioner_purpose.value}}</option>
                </select>
                <p v-show="errors.has('collection.quesioner_purpose')" class="help is-danger">{{ errors.first('collection.quesioner_purpose') }}</p>
            </div>

            <div class="form-group">
                <label for="number_of_choice">Num Of Choices</label>
                <input v-model.number="number_of_choice" type="number" name="Choices"
                    id="number_of_choice" class="form-control"
                    aria-describedby="number_of_choice" v-bind:class="{ 'is-danger': errors.has('collection.number_of_choice')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.number_of_choice')" class="help is-danger"> {{ errors.first('collection.number_of_choice') }}</p>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('questionerForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            quesioner_title : null,
            quesioner_type : null,
            quesioner_purpose : null,
            quesioner_category : null,
            quesioner_text : null,
            number_of_choice : null,
            business_code : null,
            begin_date : null,
            end_date : null,

        }
    },
    created() {
        if(this.questioner.detail) {
            this.getData()
            this.syncCompanyParams()
        }

        this.$store.dispatch('company/getAll');

    },
    computed: {
        ...mapState({
            company : state => state.company,
            questioner : state => state.questioner,
            QSNTY : state => state.QSNTY,
            QSTCT : state => state.QSTCT,
            QSTPR : state => state.QSTPR,
        })
    },
    methods: {

        syncCompanyParams() {
            this.$store.dispatch('building/getAll', {business_code : ['*', this.business_code]})
            this.$store.dispatch('QSNTY/getAll', {business_code : ['*', this.business_code]})
            this.$store.dispatch('QSTCT/getAll', {business_code : ['*', this.business_code]})
            this.$store.dispatch('QSTPR/getAll', {business_code : ['*', this.business_code]})
        },

        getData() {
            this.object_identifier = this.questioner.detail.object_identifier

            this.quesioner_title = this.questioner.detail.quesioner_title
            this.quesioner_type = this.questioner.detail.quesioner_type.id
            this.quesioner_purpose = this.questioner.detail.quesioner_purpose.id
            this.quesioner_category = this.questioner.detail.quesioner_category.id
            this.quesioner_text = this.questioner.detail.quesioner_text
            this.number_of_choice = this.questioner.detail.number_of_choice
            this.business_code = this.questioner.detail.business_code.business_code
            this.begin_date = this.questioner.detail.begin_date
            this.end_date = this.questioner.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            this.$axios.post('lms/api/quesioner', {
                quesioner_title : this.quesioner_title,
                quesioner_type : this.quesioner_type,
                quesioner_purpose : this.quesioner_purpose,
                quesioner_category : this.quesioner_category,
                quesioner_text : this.quesioner_text,
                number_of_choice : this.number_of_choice,
                business_code : this.business_code,
                begin_date : this.formatDate(new Date),
                end_date : "9999-12-12",
            })
            .then((res) => {
                console.log(res);
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('questionerForm')
                this.$store.dispatch('questioner/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            this.$axios.put('lms/api/quesioner', {
                object_identifier : this.object_identifier,
                quesioner_title : this.quesioner_title,
                quesioner_type : this.quesioner_type,
                quesioner_purpose : this.quesioner_purpose,
                quesioner_category : this.quesioner_category,
                quesioner_text : this.quesioner_text,
                number_of_choice : this.number_of_choice,
                business_code : this.business_code,
                begin_date : this.formatDate(new Date),
                end_date : "9999-12-12",
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('questionerForm')
                this.$store.dispatch('questioner/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.quesioner_title = null
            this.quesioner_type = null
            this.quesioner_purpose = null
            this.quesioner_category = null
            this.quesioner_text = null
            this.number_of_choice = null
            this.business_code = null
            this.begin_date = null
            this.end_date = null

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
