<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Mentor </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="business_code">Company</label>
                <select
                    v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }"
                    v-validate="'required'" data-vv-scope="collection"
                    @change="syncCompanyParams()"
                >
                    <option v-for="(item, index) in companies.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger"> {{ errors.first('collection.business_code') }}</p>
            </div>
            <span v-show="business_code">
            <div class="form-group">
                <label for="building">Type</label>
                <select v-model="mentor_status" class="form-control" name="mentor_status"
                    id="building" v-bind:class="{ 'is-danger': errors.has('collection.mentor_status') }"
                    v-validate="'required'" data-vv-scope="collection" v-if="object_identifier" disabled>
                    <!-- <option v-for="(item, index) in MENTY.list" :key="index" :value="item.id">
                        {{item.value}}</option> -->
                    <option value="01">
                        Internal</option>
                    <option value="02">
                        External</option>
                </select>
                <select v-model="mentor_status" class="form-control" name="mentor_status"
                    id="building" v-bind:class="{ 'is-danger': errors.has('collection.mentor_status') }"
                    v-validate="'required'" data-vv-scope="collection" v-else>
                    <!-- <option v-for="(item, index) in MENTY.list" :key="index" :value="item.id">
                        {{item.value}}</option> -->
                    <option value="01">
                        Internal</option>
                    <option value="02">
                        External</option>
                </select>
                <p v-show="errors.has('collection.mentor_status')" class="help is-danger">{{ errors.first('collection.mentor_status') }}</p>
            </div>

            <div class="form-group">
                <label for="building">Personnel Number</label>
                <vue-autosuggest v-if="mentor_status=='01'" name="personnel_number" ref="reference" :suggestions="filterEmployee"
                    @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                    v-bind:class="{ 'is-danger': errors.has('collection.personnel_number')}" v-validate="'required'" 
                    data-vv-scope="collection" v-model="personnel_number">
                </vue-autosuggest>
                <div class="control" v-else>
                    <input name="personnel_number" class="form-control" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="personnel_number" v-bind:class="{ 'is-danger': errors.has('collection.personnel_number')}"
                      v-validate="'required'" data-vv-scope="collection">
                  </div>                
                <p v-show="errors.has('collection.personnel_number')" class="help is-danger">{{ errors.first('collection.personnel_number') }}</p>
            </div>

            <div class="form-group">
                <label for="floor">Name</label>
                <input v-model="mentor_name" type="text" name="mentor_name"
                    id="mentor_name" class="form-control" placeholder="mentor_name"
                    aria-describedby="mentor_name" v-bind:class="{ 'is-danger': errors.has('collection.mentor_name')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.mentor_name')" class="help is-danger"> {{ errors.first('collection.mentor_name') }}</p>
            </div>

            <div class="form-group">
                <label for="floor">Company</label>
                <select
                    v-model="company" class="form-control" name="company" id="company"
                    :class="{ 'is-danger': errors.has('collection.company') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in companies.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.company')" class="help is-danger"> {{ errors.first('collection.company') }}</p>
            </div>
            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>
            </span>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('mentorForm')">Cancel</b-button>
            <!-- <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button> -->
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import VueAutosuggest from "vue-autosuggest";
import Vue from 'vue';
Vue.use(VueAutosuggest);
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,
            mentor_id:null,
            business_code : null,
            mentor_status  : null,
            personnel_number : null,
            mentor_name : null,
            company: null,
            begin_date : null,
            end_date : null,
            options: [{
                data: []
            }],
            filterEmployee: [],
            inputEmployee: {
                id: "autosuggest__input",
                name: "personnel_number",
                class: "form-control",
                onInputChange: this.getEmployee,
                placeholder: "Nomor Induk Karyawan"
            },
        }
    },
    created() {
        if(this.mentor.detail) {
            this.getData()
            this.syncCompanyParams()
        }
        this.$store.dispatch('company/getAll');
    },
    computed: {
        ...mapState({
            mentor : state => state.mentor,
            MENTY : state => state.MENTY.list,
            companies : state => state.company,
        })
    },
    methods: {        
        syncCompanyParams() {
            this.$store.dispatch('MENTY/getAll', {business_code : ['*', this.business_code]})
        },
        getEmployee(text) {
          if (text === '' || text === undefined) {
            return;
          }
          this.$axios
            .get(
              "hcis/api/personals?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&business_code[]=" + this.business_code
            )
            .then(response => {
              this.options[0].data = [];
              response.data.data.forEach(async (employee, key) => {
                await this.options[0].data.push(
                  employee.personnel_number,
                );
              });

              const filteredData = this.options[0].data.filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

              this.filterEmployee = [{
                data: filteredData
              }];
            })
            .catch(e => {
              console.log(e);
            });
        },
        selectEmployee(option) {
          if (option == null) {
            this.personnel_number = null;            
          } else {
            this.personnel_number = option.item;
            if (this.business_code == null) {
              this.$swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
            } else {
              this.selfData(option.item);              
            }
          }
        },
        selfData(nik){
          this.$axios
                .get(
                  "hcis/api/organization-assignment?begin_date_lte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&end_date_gte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&personnel_number[]=" +
                  nik + "&business_code[]=" +this.business_code
                )
                .then(async response => {
                  this.mentor_name = response.data.data[0].personnel_number.complete_name;
                  this.company = this.business_code                  
                })
                .catch(e => {
                  console.log(e);
                });
        },   
        getData() {
            this.object_identifier = this.mentor.detail.object_identifier
            this.mentor_id = this.mentor.detail.mentor_id
            this.business_code = this.mentor.detail.business_code.business_code
            this.mentor_status  = this.mentor.detail.mentor_status.id
            this.personnel_number = this.mentor.detail.personnel_number
            this.mentor_name = this.mentor.detail.mentor_name
            this.company = this.mentor.detail.company.business_code
            this.begin_date = this.mentor.detail.begin_date
            this.end_date = this.mentor.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            this.$axios.post('lms/api/mentor', {
                business_code : this.business_code,                
                begin_date : this.begin_date,
                end_date : this.end_date,
                mentor_name : this.mentor_name,
                mentor_status : this.mentor_status,
                company : this.company,
                personnel_number : this.personnel_number
            })
            .then((res) => {
                console.log(res);
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                //this.resetForm()
                this.$bvModal.hide('mentorForm')
                this.$store.dispatch('mentor/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            this.$axios.put('lms/api/mentor', {
                object_identifier : this.object_identifier,
                mentor_id : this.mentor_id,
                business_code : this.business_code,                
                begin_date : this.begin_date,
                end_date : this.end_date,
                mentor_name : this.mentor_name,
                mentor_status : this.mentor_status,
                company : this.company,
                personnel_number : this.personnel_number
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                //this.resetForm()
                this.$bvModal.hide('mentorForm')
                this.$store.dispatch('mentor/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.business_code = null            
            this.mentor_status  = null
            this.personnel_number = null
            this.mentor_name = null
            this.company = null            
            this.begin_date = null
            this.end_date = null    
            this.mentor_id = null
            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
<style>
.autosuggest__results-container {
    position: relative;
    width: 100%;
}

.autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
}

.autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
}

.autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
}

#autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
}

.autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
}

.autosuggest__results .autosuggest__results_item:active,
.autosuggest__results .autosuggest__results_item:hover,
.autosuggest__results .autosuggest__results_item:focus,
.autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
}
</style>
