<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Participant </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <select v-model="business_code" class="form-control" name="company" id="company"
                    :class="{ 'is-danger': errors.has('collection.company') }" v-validate="'required'"
                    data-vv-scope="collection" @change="clearEmployee();getParam()">
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">
                        {{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.company')" class="help is-danger">
                    {{ errors.first('collection.company') }}</p>
            </div>

            <span v-show="business_code">
                <div class="form-group">
                    <label for="participant_type">Participant Type</label>
                    <select v-model="participant_type" v-if="object_identifier" class="form-control"
                        name="participant_type" id="participant_type"
                        v-bind:class="{ 'is-danger': errors.has('collection.participant_type') }"
                        v-validate="'required'" data-vv-scope="collection" disabled>
                        <option v-for="(item, index) in PARTY.list" :key="index" :value="item.id">
                            {{item.value}}
                        </option>
                    </select>
                    <select v-model="participant_type" v-else class="form-control" name="participant_type"
                        id="participant_type" v-bind:class="{ 'is-danger': errors.has('collection.participant_type') }"
                        v-validate="'required'" data-vv-scope="collection">
                        <option v-for="(item, index) in PARTY.list" :key="index" :value="item.id">
                            {{item.value}}
                        </option>
                    </select>
                    <p v-show="errors.has('collection.participant_type')" class="help is-danger">
                        {{ errors.first('collection.participant_type') }}</p>
                </div>

                <div class="form-group">
                    <label for="personnel_number">Personel Number</label>
                    <div v-if="participant_type == '01'">
                        <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                            @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                            v-bind:class="{ 'is-danger': errors.has('collection.personnel_number')}"
                            v-validate="'required'" data-vv-scope="collection">
                        </vue-autosuggest>
                    </div>
                    <div v-else>
                        <input v-model="personnel_number" type="text" name="personnel_number" id="personnel_number"
                            class="form-control" placeholder="Personel Number" aria-describedby="personnel_number"
                            v-bind:class="{ 'is-danger': errors.has('collection.personnel_number')}"
                            v-validate="'required'" data-vv-scope="collection">
                    </div>
                    <p v-show="errors.has('collection.personnel_number')" class="help is-danger">
                        {{ errors.first('collection.personnel_number') }}</p>
                </div>

                <div class="form-group">
                    <label for="complete_name">Complete Name</label>
                    <input v-model="complete_name" type="text" name="complete_name" id="complete_name"
                        class="form-control" placeholder="Complete Name" aria-describedby="complete_name"
                        v-bind:class="{ 'is-danger': errors.has('collection.complete_name')}" v-validate="'required'"
                        data-vv-scope="collection">
                    <p v-show="errors.has('collection.complete_name')" class="help is-danger">
                        {{ errors.first('collection.complete_name') }}</p>
                </div>

                <div class="form-group">
                    <label for="nickname">Nickname</label>
                    <input v-model="nickname" type="text" name="nickname" id="nickname" class="form-control"
                        placeholder="Nickname" aria-describedby="nickname"
                        v-bind:class="{ 'is-danger': errors.has('collection.nickname')}" v-validate="'required'"
                        data-vv-scope="collection">
                    <p v-show="errors.has('collection.nickname')" class="help is-danger">
                        {{ errors.first('collection.nickname') }}</p>
                </div>

                <div class="form-group">
                    <label for="born_city">Born City</label>
                    <input v-model="born_city" type="text" name="born_city" id="born_city" class="form-control"
                        placeholder="Born City" aria-describedby="born_city"
                        v-bind:class="{ 'is-danger': errors.has('collection.born_city')}" v-validate="'required'"
                        data-vv-scope="collection">
                    <p v-show="errors.has('collection.born_city')" class="help is-danger">
                        {{ errors.first('collection.born_city') }}</p>
                </div>

                <div class="form-group">
                    <label for="born_date">Born Date</label>
                    <flat-pickr v-model="born_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                        class="form-control" placeholder="Select Born Date" name="born_date" id="born_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.born_date')}" v-validate="'required'"
                        data-vv-scope="collection" />
                    <p v-show="errors.has('collection.born_date')" class="help is-danger">
                        {{ errors.first('collection.born_date') }}</p>
                </div>

                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select v-model="gender" class="form-control" name="gender" id="gender"
                        v-bind:class="{ 'is-danger': errors.has('collection.gender') }" v-validate="'required'"
                        data-vv-scope="collection">
                        <option v-for="(item, index) in GENDR.list" :key="index" :value="item.id">
                            {{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.gender')" class="help is-danger">
                        {{ errors.first('collection.gender') }}</p>
                </div>

                <div class="form-group">
                    <label for="religion">Religion</label>
                    <select v-model="religion" class="form-control" name="religion" id="religion"
                        v-bind:class="{ 'is-danger': errors.has('collection.religion') }" v-validate="'required'"
                        data-vv-scope="collection">
                        <option v-for="(item, index) in RELIG.list" :key="index" :value="item.id">
                            {{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.religion')" class="help is-danger">
                        {{ errors.first('collection.religion') }}</p>
                </div>

                <div class="form-group">
                    <label for="language">Language</label>
                    <select v-model="language" class="form-control" name="language" id="language"
                        v-bind:class="{ 'is-danger': errors.has('collection.language') }" v-validate="'required'"
                        data-vv-scope="collection">
                        <option v-for="(item, index) in LANGU.list" :key="index" :value="item.id">
                            {{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.language')" class="help is-danger">
                        {{ errors.first('collection.language') }}</p>
                </div>

                <div class="form-group">
                    <label for="nationality">Nationality</label>
                    <select v-model="nationality" class="form-control" name="nationality" id="nationality"
                        v-bind:class="{ 'is-danger': errors.has('collection.nationality') }" v-validate="'required'"
                        data-vv-scope="collection">
                        <option v-for="(item, index) in NATIO.list" :key="index" :value="item.id">
                            {{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.nationality')" class="help is-danger">
                        {{ errors.first('collection.nationality') }}</p>
                </div>

                <div class="form-group">
                    <label for="tribe">Tribe</label>
                    <select v-model="tribe" class="form-control" name="tribe" id="tribe"
                        v-bind:class="{ 'is-danger': errors.has('collection.tribe') }" v-validate="'required'"
                        data-vv-scope="collection">
                        <option v-for="(item, index) in TRIBE.list" :key="index" :value="item.id">
                            {{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.tribe')" class="help is-danger">
                        {{ errors.first('collection.tribe') }}</p>
                </div>

                <div class="form-row">
                    <div class="col-6 ">
                        <div class="form-group">
                            <label for="begin_date">Start Date</label>
                            <div class="form-inline">
                                <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                    placeholder="Select start date" name="begin_date" id="begin_date"
                                    v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                    v-validate="'required'" data-vv-scope="collection" />
                                <button type="button" class="btn btn-info"
                                    @click="begin_date = new Date()">Today</button>
                                <p v-show="errors.has('collection.begin_date')" class="help is-danger">
                                    {{ errors.first('collection.begin_date') }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div v-show="begin_date" class="form-group">
                            <label for="end_date">End Date</label>
                            <div class="form-inline">
                                <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                    class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                    v-validate="'required'" data-vv-scope="collection" />
                                <button type="button" class="btn btn-info"
                                    @click="end_date = '9999-12-31' ">Max</button>
                                <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                    {{ errors.first('collection.end_date') }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </span>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('participantForm')">Cancel</b-button>
            <!-- <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button> -->
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
    import {
        mapState
    } from 'vuex';
    import {
        VueAutosuggest
    } from "vue-autosuggest";
    import moment from "moment";

    export default {
        components: {
            VueAutosuggest
        },
        data() {
            return {
                object_identifier: null,
                business_code: null,
                personnel_number: null,
                begin_date: null,
                end_date: null,
                participant_id: null,
                participant_type: null,
                complete_name: '',
                nickname: '',
                born_city: '',
                born_date: null,
                gender: null,
                religion: null,
                language: null,
                nationality: null,
                tribe: null,

                options: [{
                    data: []
                }],
                filterEmployee: [],
                inputEmployee: {
                    id: "autosuggest__input",
                    name: "personnel_number",
                    class: "form-control",
                    onInputChange: this.getEmployee,
                    placeholder: "Personel Number"
                },
                limit: 10,
            }
        },
        created() {
            if (this.participant.detail) this.getData()
            this.getParam()
        },
        computed: {
            ...mapState(['participant', 'company', 'PARTY', 'NATIO', 'RELIG', 'LANGU', 'GENDR', 'TRIBE'])
        },
        methods: {
            getEmployee(text) {
                if (text === '' || text === undefined) {
                    return;
                }
                this.$axios
                    .get(
                        "hcis/api/personals?begin_date_lte=" +
                        moment(new Date()).format("YYYY-MM-DD") +
                        "&end_date_gte=" +
                        moment(new Date()).format("YYYY-MM-DD") +
                        "&business_code[]=*" +
                        "&business_code[]=" + this.business_code
                    )
                    .then(response => {
                        this.options[0].data = [];
                        response.data.data.forEach(async (personnel_number, key) => {
                            await this.options[0].data.push(
                                personnel_number.personnel_number,
                            );
                        });

                        const filteredData = this.options[0].data.filter(item => {
                            return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
                        }).slice(0, this.limit);

                        this.filterEmployee = [{
                            data: filteredData
                        }];
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getEmployeeData(nik) {
                this.$axios
                    .get(
                        "hcis/api/personals?begin_date_lte=" +
                        moment(new Date()).format("YYYY-MM-DD") +
                        "&end_date_gte=" +
                        moment(new Date()).format("YYYY-MM-DD") +
                        "&personnel_number[]=" + nik +
                        "&business_code[]=*" +
                        "&business_code[]=" + this.business_code
                    )
                    .then(async response => {
                        this.complete_name = response.data.data[0].complete_name;
                        this.nickname = response.data.data[0].nickname;
                        this.born_city = response.data.data[0].birth_city;
                        this.born_date = response.data.data[0].birth_date;
                        this.gender = response.data.data[0].gender.id;
                        this.religion = response.data.data[0].religion.id;
                        this.language = response.data.data[0].language.id;
                        this.nationality = response.data.data[0].nationality.id;
                        this.tribe = response.data.data[0].tribe.id;
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            selectEmployee(option) {
                if (option == null) {
                    this.personnel_number = null;
                } else {
                    this.personnel_number = option.item;
                    this.getEmployeeData(option.item);
                }
            },
            clearEmployee() {
                if (this.personnel_number != null) {
                    this.$refs.reference = '';
                }
                this.filterEmployee = []
                this.personnel_number = null;

                this.$nextTick(() => this.$validator.reset());
            },

            getData() {
                this.object_identifier = this.participant.detail.object_identifier;
                this.business_code = this.participant.detail.business_code.business_code;
                this.personnel_number = this.participant.detail.personnel_number;
                this.begin_date = this.participant.detail.begin_date;
                this.end_date = this.participant.detail.end_date;
                this.participant_id = this.participant.detail.participant_id;
                this.participant_type = this.participant.detail.participant_type.id;
                this.complete_name = this.participant.detail.complete_name;
                this.nickname = this.participant.detail.nickname;
                this.born_city = this.participant.detail.born_city;
                this.born_date = this.participant.detail.bord_date;
                this.gender = this.participant.detail.gender.id;
                this.religion = this.participant.detail.religion.id;
                this.language = this.participant.detail.language.id;
                this.nationality = this.participant.detail.nationality.id;
                this.tribe = this.participant.detail.tribe.id;
            },

            getParam() {
                this.$store.dispatch('PARTY/getAll', {
                    business_code: ['*', this.business_code]
                });
                this.$store.dispatch('NATIO/getAll', {
                    business_code: ['*', this.business_code]
                });
                this.$store.dispatch('RELIG/getAll', {
                    business_code: ['*', this.business_code]
                });
                this.$store.dispatch('LANGU/getAll', {
                    business_code: ['*', this.business_code]
                });
                this.$store.dispatch('GENDR/getAll', {
                    business_code: ['*', this.business_code]
                });
                this.$store.dispatch('TRIBE/getAll', {
                    business_code: ['*', this.business_code]
                });
            },

            async storeData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.post('lms/api/participant', {
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.business_code,
                        participant_type: this.participant_type,
                        personnel_number: this.personnel_number,
                        complete_name: this.complete_name,
                        nickname: this.nickname,
                        born_city: this.born_city,
                        born_date: this.born_date,
                        gender: this.gender,
                        religion: this.religion,
                        language: this.language,
                        nationality: this.nationality,
                        tribe: this.tribe

                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        // this.resetForm()
                        this.$bvModal.hide('participantForm')
                        this.$store.dispatch('participant/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            async updateData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.put('lms/api/participant', {
                        object_identifier: this.object_identifier,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.business_code,
                        participant_type: this.participant_type,
                        personnel_number: this.personnel_number,
                        complete_name: this.complete_name,
                        nickname: this.nickname,
                        born_city: this.born_city,
                        born_date: this.born_date,
                        gender: this.gender,
                        religion: this.religion,
                        language: this.language,
                        nationality: this.nationality,
                        tribe: this.tribe
                    })
                    .then(() => {
                        this.$swal(
                            'Updated!',
                            'Successfully update data.',
                            'success'
                        )
                        // this.resetForm()
                        this.$bvModal.hide('participantForm')
                        this.$store.dispatch('participant/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            resetForm() {
                this.object_identifier = null
                this.business_code = null
                this.personnel_number = null
                this.begin_date = null
                this.end_date = null
                this.participant_id = null
                this.participant_type = null
                this.complete_name = null
                this.nickname = null
                this.born_city = null
                this.born_date = null
                this.gender = null
                this.religion = null
                this.language = null
                this.nationality = null
                this.tribe = null

                this.$validator.reset('collection')
            },
        },
    }

</script>

<style>
    .autosuggest__results-container {
        position: relative;
        width: 100%;
    }

    .autosuggest__results {
        font-weight: 300;
        margin: 0;
        position: absolute;
        z-index: 10000001;
        width: 100%;
        border: 1px solid #e0e0e0;
        border-bottom-left-radius: 4px;
        border-bottom-right-radius: 4px;
        background: white;
        padding: 0px;
        overflow: scroll;
        max-height: 200px;
    }

    .autosuggest__results ul {
        list-style: none;
        padding-left: 0;
        margin: 0;
    }

    .autosuggest__results .autosuggest__results_item {
        cursor: pointer;
        padding: 15px;
    }

    #autosuggest ul:nth-child(1)>.autosuggest__results_title {
        border-top: none;
    }

    .autosuggest__results .autosuggest__results_title {
        color: gray;
        font-size: 11px;
        margin-left: 0;
        padding: 15px 13px 5px;
        border-top: 1px solid lightgray;
    }

    .autosuggest__results .autosuggest__results_item:active,
    .autosuggest__results .autosuggest__results_item:hover,
    .autosuggest__results .autosuggest__results_item:focus,
    .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
        background-color: #ddd;
    }

</style>
