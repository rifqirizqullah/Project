<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Materi </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <select
                    v-model="business_code" class="form-control" name="company" id="company"
                    :class="{ 'is-danger': errors.has('collection.company') }"
                    v-validate="'required'" data-vv-scope="collection" @change="getObject()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.company')" class="help is-danger">{{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="materi_name">Name</label>
                <input v-model="materi_name" type="text" name="Title"
                    id="materi_name" class="form-control" placeholder="materi_name"
                    aria-describedby="materi_name" v-bind:class="{ 'is-danger': errors.has('collection.materi_name')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.materi_name')" class="help is-danger"> {{ errors.first('collection.materi_name') }}</p>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <input v-model="description" type="text" name="Title"
                    id="description" class="form-control" placeholder="description"
                    aria-describedby="description" v-bind:class="{ 'is-danger': errors.has('collection.description')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.description')" class="help is-danger"> {{ errors.first('collection.description') }}</p>
            </div>

            <div class="form-group">
                <label for="materi_type">Materi Type</label>
                <select
                    v-model="materi_type" class="form-control" name="materi_type" id="materi_type"
                    :class="{ 'is-danger': errors.has('collection.materi_type') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in MATTY.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.materi_type')" class="help is-danger">{{ errors.first('collection.materi_type') }}</p>
            </div>

            <div class="form-group">
                <label for="method">Method</label>
                <select
                    v-model="method" class="form-control" name="method" id="method"
                    :class="{ 'is-danger': errors.has('collection.method') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in TCMTD.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.method')" class="help is-danger">{{ errors.first('collection.method') }}</p>
            </div>

            <div class="form-group">
                <label for="address">Address</label>
                <b-form-file
                    accept="image/*"
                    v-model="address"
                    :state="Boolean(address)"
                    placeholder="Choose a file..."
                    drop-placeholder="Drop file here..."
                ></b-form-file>
            </div>

            <div class="form-group">
                <label for="competence">Competency</label>
                <select v-model="competence" class="form-control" name="competence"
                    id="competence" v-bind:class="{ 'is-danger': errors.has('collection.competence') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(competencies, index) in CMPTY.list" :key="index" :value="competencies.id">
                        {{competencies.value}}
                    </option>
                </select>
                <p v-show="errors.has('collection.competence')" class="help is-danger">{{ errors.first('collection.competence') }}</p>
            </div>

            <div class="form-group">
                <label for="pl_code">Proficiency Level</label>
                <select v-model="pl_code" class="form-control" name="pl_code"
                    id="pl_code" v-bind:class="{ 'is-danger': errors.has('collection.pl_code') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(pl_code, index) in PLCOD.list" :key="index" :value="pl_code.id">
                        {{pl_code.value}}</option>
                </select>
                <p v-show="errors.has('collection.pl_code')" class="help is-danger">{{ errors.first('collection.pl_code') }}</p>
            </div>

            <div class="form-group">
                <label for="selling_price">Selling Price</label>
                <input v-model.number="selling_price" type="number" min="1" name="Title"
                    id="selling_price" class="form-control" placeholder="Rp"
                    aria-describedby="selling_price" v-bind:class="{ 'is-danger': errors.has('collection.selling_price')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.selling_price')" class="help is-danger"> {{ errors.first('collection.selling_price') }}</p>
            </div>

            <div class="form-group">
                <label for="purchase_price">Purchase Price</label>
                <input v-model.number="purchase_price" type="number" min="1" name="Title"
                    id="purchase_price" class="form-control" placeholder="Rp"
                    aria-describedby="purchase_price" v-bind:class="{ 'is-danger': errors.has('collection.purchase_price')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.purchase_price')" class="help is-danger"> {{ errors.first('collection.purchase_price') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('materiForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,
            //MATTY : null,
            materi_name : null,
            description: null,
            materi_type : null,
            method : null,
            address: null,
            competence : null,
            pl_code : null,
            business_code : null,
            selling_price : null,
            purchase_price : null,
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.materi.detail) this.getData()
        this.$store.dispatch('company/getAll')
        this.getObject()
    },
    computed: {
        ...mapState({
            company : state => state.company,
            materi : state => state.materi,
            MATTY : state => state.MATTY,
            TCMTD : state => state.TCMTD,
            CMPTY : state => state.CMPTY,
            PLCOD : state => state.PLCOD,
        })
    },
    methods: {

        getObject(){
            this.$store.dispatch('MATTY/getAll', {business_code : ['*', this.business_code]})
            this.$store.dispatch('TCMTD/getAll', {business_code : ['*', this.business_code]})
            this.$store.dispatch('CMPTY/getAll', {business_code : ['*', this.business_code]})
            this.$store.dispatch('PLCOD/getAll', {business_code : ['*', this.business_code]})
        },

        getData() {
            this.object_identifier = this.materi.detail.object_identifier
            this.business_code = this.materi.detail.business_code.business_code
            this.materi_name = this.materi.detail.materi_name
            this.description = this.materi.detail.description
            this.materi_type = this.materi.detail.materi_type.id
            this.method = this.materi.detail.method.id
            this.address = this.materi.detail.address
            this.competence = this.materi.detail.competence.id
            this.pl_code = this.materi.detail.pl_code.id
            this.begin_date = this.materi.detail.begin_date
            this.end_date = this.materi.detail.end_date
            this.selling_price = this.materi.detail.selling_price
            this.purchase_price = this.materi.detail.purchase_price
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            let data = new FormData();

            data.append('materi_name', this.materi_name)
            data.append('description', this.description)
            data.append('materi_type', this.materi_type)
            data.append('method', this.method)
            data.append('address', this.address)
            data.append('competence', this.competence)
            data.append('pl_code', this.pl_code)
            data.append('business_code', this.business_code)
            data.append('selling_price', this.selling_price)
            data.append('purchase_price', this.purchase_price)
            data.append('begin_date', this.begin_date)
            data.append('end_date', this.end_date)

            this.$axios.post('lms/api/materi', data)
            .then((res) => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('materiForm')
                this.$store.dispatch('materi/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            let data = new FormData();

            data.append('object_identifier', this.object_identifier)
            data.append('materi_name', this.materi_name)
            data.append('description', this.description)
            data.append('materi_type', this.materi_type)
            data.append('method', this.method)
            data.append('address', this.address)
            data.append('competence', this.competence)
            data.append('pl_code', this.pl_code)
            data.append('business_code', this.business_code)
            data.append('selling_price', this.selling_price)
            data.append('purchase_price', this.purchase_price)
            data.append('begin_date', this.begin_date)
            data.append('end_date', this.end_date)

            this.$axios.post('lms/api/materi', data)
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('materiForm')
                this.$store.dispatch('materi/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.business_code = null
            this.materi_name = null
            this.description = null
            this.materi_type = null
            this.method = null
            this.address = null
            this.competence = null
            this.pl_code = null
            this.begin_date = null
            this.end_date = null
            this.selling_price = null
            this.purchase_price = null

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
