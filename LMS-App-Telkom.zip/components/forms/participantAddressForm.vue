<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Participant Address</h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <input v-model="business_code" type="text" name="company" id="company" class="form-control"
                    :placeholder="participant.business_code.company_name" aria-describedby="company"
                    v-bind:class="{ 'is-danger': errors.has('collection.company')}" v-validate="'required'"
                    data-vv-scope="collection" disabled />
                <p v-show="errors.has('collection.company')" class="help is-danger">
                    {{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="address_type">Address Type</label>
                <select v-model="address_type" class="form-control" name="address_type" id="address_type"
                    v-bind:class="{ 'is-danger': errors.has('collection.address_type') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <option v-for="(item, index) in ADDTY.list" :key="index" :value="item.id">
                        {{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.address_type')" class="help is-danger">
                    {{ errors.first('collection.address_type') }}</p>
            </div>

            <div class="form-group">
                <label for="street" class="form-label">Street</label>
                <textarea v-model="street" class="form-control" name="street" id="street" rows="3" placeholder="Street"
                    v-bind:class="{ 'is-danger': errors.has('collection.street')}" v-validate="'required'"
                    data-vv-scope="collection"></textarea>
                <p v-show="errors.has('collection.street')" class="help is-danger">
                    {{ errors.first('collection.street') }}</p>
            </div>

            <div class="form-group">
                <label for="postal_code">Postal Code</label>
                <input v-model="postal_code" type="text" name="postal_code" id="postal_code" class="form-control"
                    placeholder="Postal Code" aria-describedby="postal_code" @keypress="onlyNumber"
                    v-bind:class="{ 'is-danger': errors.has('collection.postal_code')}" v-validate="'required'"
                    data-vv-scope="collection">
                <p v-show="errors.has('collection.postal_code')" class="help is-danger">
                    {{ errors.first('collection.postal_code') }}</p>
            </div>

            <div class="form-group">
                <label for="country">Country</label>
                <select v-model="country" class="form-control" name="country" id="country"
                    v-bind:class="{ 'is-danger': errors.has('collection.country') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <option v-for="(item, index) in CONTR.list" :key="index" :value="item.id">
                        {{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.country')" class="help is-danger">
                    {{ errors.first('collection.country') }}</p>
            </div>

            <div class="form-group">
                <label for="province">Province</label>
                <select v-model="province" class="form-control" name="province" id="province"
                    v-bind:class="{ 'is-danger': errors.has('collection.province') }" v-validate="'required'"
                    data-vv-scope="collection" @change="getCity()">
                    <option v-for="(item, index) in PRVNC.list" :key="index" :value="item.id">
                        {{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.province')" class="help is-danger">
                    {{ errors.first('collection.province') }}</p>
            </div>

            <div class="form-group">
                <label for="city">City</label>
                <select v-model="city" class="form-control" name="city" id="city"
                    v-bind:class="{ 'is-danger': errors.has('collection.city') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <option v-for="(item, index) in PRVNC_CITY.list" :key="index" :value="item.child.id">
                        {{item.child.value}}</option>
                </select>
                <p v-show="errors.has('collection.city')" class="help is-danger">
                    {{ errors.first('collection.city') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger">
                                {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                                data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('participantAddressForm')">Cancel</b-button>
            <!-- <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button> -->
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
    import {
        mapState
    } from 'vuex';

    export default {
        data() {
            return {
                object_identifier: null,
                business_code: null,
                begin_date: null,
                end_date: null,
                participant_id: null,
                address_type: null,
                street: null,
                postal_code: null,
                country: null,
                province: null,
                city: null,
            }
        },
        created() {
            if (this.participantAddress.detail) this.getData()
            this.$store.dispatch('company/getAll')
            this.$store.dispatch("ADDTY/getAll", {
                'business_code': ['*', this.participant.business_code.business_code]
            });
            this.$store.dispatch("CONTR/getAll", {
                'business_code': ['*', this.participant.business_code.business_code]
            });
            this.$store.dispatch("PRVNC/getAll", {
                'business_code': ['*', this.participant.business_code.business_code]
            });
            this.getCity()
        },
        computed: {
            ...mapState({
                participant: state => state.participant.detail,
                participantAddress: state => state.participantAddress,
                company: state => state.company,
                ADDTY: state => state.ADDTY,
                CONTR: state => state.CONTR,
                PRVNC: state => state.PRVNC,
                PRVNC_CITY: state => state.PRVNC_CITY,
            })
        },
        methods: {
            getCity() {
                this.$store.dispatch('PRVNC_CITY/getAll', {
                    business_code: ['*', this.company],
                    parent: [this.province],
                });
            },

            getData() {
                this.object_identifier = this.participantAddress.detail.object_identifier;
                this.business_code = this.participantAddress.detail.business_code.company_name;
                this.begin_date = this.participantAddress.detail.begin_date;
                this.end_date = this.participantAddress.detail.end_date;
                this.participant_id = this.participantAddress.detail.participant.participant_id;
                this.address_type = this.participantAddress.detail.address_type.id;
                this.street = this.participantAddress.detail.street;
                this.postal_code = this.participantAddress.detail.postal_code;
                this.country = this.participantAddress.detail.country.id;
                this.province = this.participantAddress.detail.province.id;
                this.city = this.participantAddress.detail.city.id;
            },

            async storeData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.post('lms/api/participantaddress', {
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.participant.business_code.business_code,
                        participant: this.participant.participant_id,
                        address_type: this.address_type,
                        street: this.street,
                        postal_code: this.postal_code,
                        country: this.country,
                        province: this.province,
                        city: this.city,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        // this.resetForm()
                        this.$bvModal.hide('participantAddressForm')
                        this.$store.dispatch('participantAddress/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            async updateData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.put('lms/api/participantaddress', {
                        object_identifier: this.object_identifier,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.participant.business_code.business_code,
                        participant: this.participant.participant_id,
                        address_type: this.address_type,
                        street: this.street,
                        postal_code: this.postal_code,
                        country: this.country,
                        province: this.province,
                        city: this.city,
                    })
                    .then(() => {
                        this.$swal(
                            'Updated!',
                            'Successfully update data.',
                            'success'
                        )
                        // this.resetForm()
                        this.$bvModal.hide('participantAddressForm')
                        this.$store.dispatch('participantAddress/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            resetForm() {
                this.object_identifier = null
                this.business_code = null
                this.begin_date = null
                this.end_date = null
                this.participant_id = null
                this.address_type = null
                this.street = null
                this.postal_code = null
                this.country = null
                this.province = null
                this.city = null

                this.$validator.reset('collection')
            },
            onlyNumber($event) {
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
                    $event.preventDefault();
                }
            }
        },
    }

</script>
