<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Organization Strategy </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company_code">Company</label>
                <select
                    v-model="company_code" class="form-control" name="company_code" id="company_code"
                    :class="{ 'is-danger': errors.has('collection.company_code') }"
                    v-validate="'required'" data-vv-scope="collection" @change="getParam()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.company_code')" class="help is-danger"> {{ errors.first('collection.company_code') }}</p>
            </div>

            <span v-show="company_code">

                <div class="form-group">
                    <label for="organization_code">Unit</label>
                    <select
                        v-model="organization_code" class="form-control" name="organization_code" id="organization_code"
                        :class="{ 'is-danger': errors.has('collection.organization_code') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                        <option v-for="(item, index) in organizationData.list" :key="index" :value="item.organization_code">{{item.organization_name}}</option>
                    </select>
                    <p v-show="errors.has('collection.organization_code')" class="help is-danger"> {{ errors.first('collection.organization_code') }}</p>
                </div>

                <div class="form-group">
                    <label for="year">Year</label>
                    <select
                        v-model="year" class="form-control" name="year" id="year"
                        :class="{ 'is-danger': errors.has('collection.year') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                        <option v-for="(year, index) in 10" :key="index">{{2016 + index}}</option>
                    </select>
                    <p v-show="errors.has('collection.year')" class="help is-danger">{{ errors.first('collection.year') }}</p>
                </div>

                <div class="form-group">
                    <label for="strategyName">Strategy Name</label>
                    <input
                        v-model="organization_strategy_name" type="text" class="form-control" name="strategyName" id="strategyName" placeholder="Org Strategy Name"
                        :class="{ 'is-danger': errors.has('collection.strategyName') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                    <p v-show="errors.has('collection.strategyName')" class="help is-danger">{{ errors.first('collection.strategyName') }}</p>
                </div>



                <div class="form-group">
                    <label for="businessIssue">Strategic Initiative</label>
                    <select
                        v-model="object_parent" class="form-control" name="businessIssue" id="businessIssue"
                        :class="{ 'is-danger': errors.has('collection.businessIssue') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                        <option v-for="(item, index) in LOSID.list" :key="index" :value="item.id">{{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.businessIssue')" class="help is-danger"> {{ errors.first('collection.businessIssue') }}</p>
                </div>

                <div class="form-group">
                    <label for="issueType">Issue Type</label>
                    <select
                        v-model="otype_child1" class="form-control" name="issueType" id="issueType"
                        :class="{ 'is-danger': errors.has('collection.issueType') }"
                        v-validate="'required'" data-vv-scope="collection" @change="fetchissue()"
                    >
                        <option v-for="(item, index) in OTYPEISSUE.list" :key="index" :value="item.object_type">{{item.object_name}}</option>
                    </select>
                    <p v-show="errors.has('collection.issueType')" class="help is-danger"> {{ errors.first('collection.issueType') }}</p>
                </div>

                <div v-if="otype_child1" class="form-group">
                    <label for="performanceIssue">Issue</label>
                    <select
                        v-model="object_child1" class="form-control" name="performanceIssue" id="performanceIssue"
                        :class="{ 'is-danger': errors.has('collection.performanceIssue') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                        <option v-for="(item, index) in OBJECTISSUE.list" :key="index" :value="item.id">{{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.performanceIssue')" class="help is-danger"> {{ errors.first('collection.performanceIssue') }}</p>
                </div>

                <div class="form-group">
                    <label for="competencyIssue">Proficiency Level</label>
                    <select
                        v-model="object_child2" class="form-control" name="competencyIssue" id="competencyIssue"
                        :class="{ 'is-danger': errors.has('collection.competencyIssue') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                        <option v-for="(item, index) in PLCOD.list" :key="index" :value="item.id">{{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.competencyIssue')" class="help is-danger"> {{ errors.first('collection.competencyIssue') }}</p>
                </div>

                <div class="form-group">
                    <label for="learningFocus">Learning Focus</label>
                    <select
                        v-model="learning_focus" class="form-control" name="learningFocus" id="learningFocus"
                        :class="{ 'is-danger': errors.has('collection.learningFocus') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                        <option v-for="(item, index) in LFCOD.list" :key="index" :value="item.id">{{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.learningFocus')" class="help is-danger"> {{ errors.first('collection.learningFocus') }}</p>
                </div>

                <div class="form-group">
                    <label for="employeeCluster">Employee Cluster</label>
                    <select
                        v-model="employee_cluster" class="form-control" name="employeeCluster" id="employeeCluster"
                        :class="{ 'is-danger': errors.has('collection.employeeCluster') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                        <option v-for="(item, index) in EMPCL.list" :key="index" :value="item.id">{{item.value}}</option>
                    </select>
                    <p v-show="errors.has('collection.employeeCluster')" class="help is-danger"> {{ errors.first('collection.employeeCluster') }}</p>
                </div>

                <div class="form-row">
                    <div class="col-6 ">
                        <div class="form-group">
                            <label for="begin_date">Start Date</label>
                            <div class="form-inline">
                                <flat-pickr
                                    v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                    placeholder="Select start date" name="begin_date" id="begin_date"
                                    v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                    v-validate="'required'" data-vv-scope="collection"
                                />
                                <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                                <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div v-show="begin_date" class="form-group">
                            <label for="end_date">End Date</label>
                            <div class="form-inline">
                                <flat-pickr
                                    v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                    placeholder="Select end date" name="end_date" id="end_date"
                                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                    v-validate="'required'" data-vv-scope="collection"
                                />
                                <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                            </div>
                        </div>
                    </div>
                </div>

            </span>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('learningStrategyForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            company_code: null,
            year : null,
            organization_strategy_name : '',
            organization_code : '',
            object_parent : null,
            otype_child1 : null,
            object_child1 : null,
            object_child2 : null,
            learning_focus : null,
            employee_cluster : null,
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.learningStrategy.detail) this.getData()

        this.getParam();
        // this.$store.dispatch('company/getAll');
        this.$store.dispatch('OTYPEISSUE/getAll');

    },
    computed: {
        ...mapState(['organizationData','company','LOSID','OBJECTISSUE','PLCOD','LFCOD','EMPCL','OTYPEISSUE','learningStrategy'])
    },
    methods: {
        getParam(){
            this.$store.dispatch('organizationData/getAll', {business_code:['*', this.company_code]});
            this.$store.dispatch('LOSID/getAll', {business_code:['*', this.company_code]});
            this.$store.dispatch('PLCOD/getAll', {business_code:['*', this.company_code]});
            this.$store.dispatch('LFCOD/getAll', {business_code:['*', this.company_code]});
            this.$store.dispatch('EMPCL/getAll', {business_code:['*', this.company_code]});
        },
        fetchissue(){
            this.object_child1 = null;
            this.$store.dispatch('OBJECTISSUE/getAll', {object_type:[this.otype_child1], business_code:['*', this.company_code]});
        },
        getData() {
            this.object_identifier = this.learningStrategy.detail.object_identifier
            this.year = this.learningStrategy.detail.year
            this.organization_strategy_name = this.learningStrategy.detail.organization_strategy_name
            this.company_code = this.learningStrategy.detail.business_code.business_code
            this.begin_date = this.learningStrategy.detail.begin_date
            this.end_date = this.learningStrategy.detail.end_date
            this.object_parent = this.learningStrategy.detail.object_parent.id
            this.otype_child1 = this.learningStrategy.detail.otype_child1
            this.fetchissue()
            this.object_child1 = this.learningStrategy.detail.object_child1.id
            this.object_child2 = this.learningStrategy.detail.object_child2.id
            this.learning_focus = this.learningStrategy.detail.learning_focus.id
            this.employee_cluster = this.learningStrategy.detail.employee_cluster.id
            this.organization_code = this.learningStrategy.detail.organization_code.organization_code
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/organizationstrategy', {
                year : this.year,
                begin_date : this.begin_date,
                end_date : this.end_date,
                learning_focus : this.learning_focus,
                business_code : this.company_code,
                organization_code: this.organization_code,
                organization_type: 'O',
                organization_strategy_name: this.organization_strategy_name,
                otype_parent: 'LOSID',
                object_parent: this.object_parent,
                otype_child1: this.otype_child1,
                object_child1: this.object_child1,
                otype_child2: 'PLCOD',
                object_child2: this.object_child2,
                employee_cluster : this.employee_cluster,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('learningStrategyForm')
                this.$store.dispatch('learningStrategy/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/organizationstrategy', {
                object_identifier: this.object_identifier,
                year : this.year,
                begin_date : this.begin_date,
                end_date : this.end_date,
                learning_focus : this.learning_focus,
                business_code : this.company_code,
                organization_code: this.organization_code,
                organization_type: 'O',
                organization_strategy_name: this.organization_strategy_name,
                otype_parent: 'LOSID',
                object_parent: this.object_parent,
                otype_child1: this.otype_child1,
                object_child1: this.object_child1,
                otype_child2: 'PLCOD',
                object_child2: this.object_child2,
                employee_cluster : this.employee_cluster,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('learningStrategyForm')
                this.$store.dispatch('learningStrategy/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.year = null
            this.organization_strategy_name = null,
            this.company_code = null,
            this.organization_code = null,
            this.begin_date = null
            this.end_date = null
            this.object_parent = null
            this.otype_child1 = null
            this.object_child1 = null
            this.object_child2 = null
            this.learning_focus = null
            this.employee_cluster = null

            this.$validator.reset('collection')
        },


    },
}

</script>
