<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Curriculum Request </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="request_type">Company</label>
                <select
                    v-model="business_code" class="form-control" name="company" id="company"
                    :class="{ 'is-danger': errors.has('collection.company') }"
                    v-validate="'required'" data-vv-scope="collection" @change="getParam()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.company')" class="help is-danger">{{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="request_name">Curriculum Request Name</label>
                <input
                    v-model="request_name" type="text" class="form-control" name="request_name" id="request_name" placeholder="Curriculum Request Name .."
                    :class="{ 'is-danger': errors.has('collection.request_name') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                <p v-show="errors.has('collection.request_name')" class="help is-danger">{{ errors.first('collection.request_name') }}</p>
            </div>

            <div class="form-group">
                <label for="request_description">Description</label>
                <input
                    v-model="request_description" type="text" class="form-control" name="request_description" id="request_description" placeholder="Curriculum Request Desc .."
                    maxlength="255"
                    :class="{ 'is-danger': errors.has('collection.request_description') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                <p v-show="errors.has('collection.request_description')" class="help is-danger">{{ errors.first('collection.request_description') }}</p>
            </div>

            <div class="form-group">
                <label for="request_type">Type</label>
                <select
                    v-model="request_type" class="form-control" name="request_type" id="request_type"
                    :class="{ 'is-danger': errors.has('collection.request_type') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in REQTY.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.request_type')" class="help is-danger">{{ errors.first('collection.request_type') }}</p>
            </div>

            <div class="form-group">
                <label for="competence">Competency</label>
                <select
                    v-model="competence" class="form-control" name="competence" id="competence"
                    :class="{ 'is-danger': errors.has('collection.competence') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in CMPTY.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.competence')" class="help is-danger">{{ errors.first('collection.competence') }}</p>
            </div>

            <div class="form-group">
                <label for="pl_code">Proficiency Level</label>
                <select
                    v-model="pl_code" class="form-control" name="pl_code" id="pl_code"
                    :class="{ 'is-danger': errors.has('collection.pl_code') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in PLCOD.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.pl_code')" class="help is-danger">{{ errors.first('collection.pl_code') }}</p>
            </div>


            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>



        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('curriculumRequestForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,
            request_id : null,

            request_name: "",
            request_description: "",
            request_type: "",
            competence: "",
            pl_code: "",
            business_code : null,
            begin_date : "",
            end_date : "",

        }
    },
    created() {
        if(this.curriculumRequest.detail) this.getData()
        this.getParam();
        // this.$store.dispatch('company/getAll');

    },
    computed: {
        ...mapState(['curriculumRequest', 'REQTY','company', 'CMPTY', 'PLCOD'])
    },
    methods: {

        getParam(){
            this.$store.dispatch('CMPTY/getAll', {business_code:['*', this.business_code]});
            this.$store.dispatch('PLCOD/getAll', {business_code:['*', this.business_code]});
            this.$store.dispatch('REQTY/getAll', {business_code:['*', this.business_code]});
        },

        getData() {
            this.object_identifier = this.curriculumRequest.detail.object_identifier
            this.request_id = this.curriculumRequest.detail.request_id

            this.request_name = this.curriculumRequest.detail.request_name
            this.request_description = this.curriculumRequest.detail.request_description
            this.request_type = this.curriculumRequest.detail.request_type.id
            this.competence = this.curriculumRequest.detail.competence.id
            this.pl_code = this.curriculumRequest.detail.pl_code.id
            this.business_code = this.curriculumRequest.detail.business_code.business_code
            this.begin_date = this.curriculumRequest.detail.begin_date
            this.end_date = this.curriculumRequest.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/curriculumrequest', {
                begin_date : this.begin_date,
                end_date : this.end_date,
                business_code : this.business_code,
                request_name: this.request_name,
                request_type: this.request_type,
                request_description: this.request_description,
                competence: this.competence,
                pl_code: this.pl_code,

            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('curriculumRequestForm')
                this.$store.dispatch('curriculumRequest/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/curriculumrequest', {
                object_identifier : this.object_identifier,
                request_id : this.request_id,

                begin_date : this.begin_date,
                end_date : this.end_date,
                business_code :this.business_code,
                request_name: this.request_name,
                request_type: this.request_type,
                request_description: this.request_description,
                competence: this.competence,
                pl_code: this.pl_code,

            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('curriculumRequestForm')
                this.$store.dispatch('curriculumRequest/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null,
            this.request_id = null,

            this.begin_date = "",
            this.end_date = "",
            this.business_code = "",
            this.request_name = "",
            this.request_type = "",
            this.request_description = "",
            this.competence = "",
            this.pl_code = ""

            this.$validator.reset('collection')
        },


    },
}

</script>
