<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Event Participant </h4>
        </div>
        <div class='card-body p-4'>


            <div class="form-group">
                <label for="participant">Participant</label>
                <select
                    v-model="participant" class="form-control" name="participant" id="participant"
                    :class="{ 'is-danger': errors.has('collection.participant') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in participant_list" :key="index" :value="item.participant_id">{{item.complete_name}}</option>
                </select>
                <p v-show="errors.has('collection.participant')" class="help is-danger">{{ errors.first('collection.participant') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>



        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('eventParticipantForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            begin_date : null,
            end_date : null,
            business_code : null,
            participant : null,
        }
    },
    created() {
        if(this.eventParticipant.detail) this.getData()

        this.$store.dispatch('participant/getAll');
    },
    computed: {
        ...mapState({
            event_id: state => state.event.detail.event_id,
            eventParticipant: state => state.eventParticipant,
            current_event : state => state.event.detail,

            participant_list: state => state.participant.list,
        })
    },
    methods: {

        getData() {
            this.object_identifier = this.eventParticipant.detail.object_identifier

            this.begin_date = this.eventParticipant.detail.begin_date
            this.end_date = this.eventParticipant.detail.end_date
            this.business_code = this.eventParticipant.detail.business_code.business_code
            this.participant = this.eventParticipant.detail.participant.participant_id
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/eventparticipant', {
                event : this.event_id ,
                business_code : this.current_event.business_code.business_code,
	            participant : this.participant,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventParticipantForm')
                this.$store.dispatch('eventParticipant/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/eventparticipant', {
                object_identifier : this.object_identifier,
                event : this.event_id ,
                business_code : this.business_code,
                participant : this.participant,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventParticipantForm')
                this.$store.dispatch('eventParticipant/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null

            this.begin_date = null
            this.end_date = null
            this.business_code = null
            this.participant = null

            this.$validator.reset('collection')
        },


    },
}

</script>
