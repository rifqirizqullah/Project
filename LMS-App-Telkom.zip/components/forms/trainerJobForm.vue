<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Trainer Job</h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <input v-model="business_code" type="text" name="company" id="company" class="form-control"
                    :placeholder="trainer.business_code.company_name" aria-describedby="company"
                    v-bind:class="{ 'is-danger': errors.has('collection.company')}" v-validate="'required'"
                    data-vv-scope="collection" disabled />
                <p v-show="errors.has('collection.company')" class="help is-danger">
                    {{ errors.first('collection.company') }}</p>
            </div>


            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger">
                                {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                                data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('trainerJobForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
    import {
        mapState
    } from 'vuex';

    export default {
        data() {
            return {
                object_identifier: null,
                business_code: null,
                personnel_number: null,
                begin_date: null,
                end_date: null,
                trainer_id: null,
                company_code: null,
                company_name: null,
                unit_code: null,
                unit_name: null,
                job_code: null,
                job_name: null,
                position_code: null,
                position_name: null
            }
        },
        created() {
            if (this.trainerJob.detail) this.getData()
            this.$store.dispatch('company/getAll')
        },
        computed: {
            ...mapState(['trainerJob', 'company'])
        },
        methods: {

            getData() {
                this.object_identifier = this.trainerJob.detail.object_identifier;
                this.business_code = this.trainerJob.detail.business_code.company_name;
                this.begin_date = this.trainerJob.detail.begin_date;
                this.end_date = this.trainerJob.detail.end_date;
                this.trainer_id = this.trainerJob.detail.trainer.trainer_id;
            },

            async storeData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.post('lms/api/trainerjob', {
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.trainer.business_code.business_code,
                        trainer: this.trainer.trainer_id,

                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('trainerJobForm')
                        this.$store.dispatch('trainerJob/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            async updateData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.put('lms/api/trainerjob', {
                        object_identifier: this.object_identifier,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.trainer.business_code.business_code,
                        trainer: this.trainer.trainer_id,

                    })
                    .then(() => {
                        this.$swal(
                            'Updated!',
                            'Successfully update data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('trainerJobForm')
                        this.$store.dispatch('trainerJob/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            resetForm() {
                this.object_identifier = null


                this.$validator.reset('collection')
            },


        },
    }

</script>
