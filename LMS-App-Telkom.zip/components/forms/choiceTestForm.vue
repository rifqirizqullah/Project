<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Choice </h4>
        </div>
        <div class='card-body p-4'>
            <div class="form-group">
                <label for="text_choice">Choice Text</label>
               <input v-model="text_choice" type="text" name="text_choice"
                    id="text_choice" class="form-control"
                    v-bind:class="{ 'is-danger': errors.has('collection.text_choice')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.text_choice')" class="help is-danger">{{ errors.first('collection.text_choice') }}</p>
            </div>
            <div class="form-group">
                <label for="sequence_no">Sequence Number</label>
               <input v-model="sequence_no" type="text" name="sequence_no"
                    id="sequence_no" class="form-control"
                    v-bind:class="{ 'is-danger': errors.has('collection.sequence_no')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.sequence_no')" class="help is-danger">{{ errors.first('collection.sequence_no') }}</p>
            </div>
            <div class="form-group">
                <label for="score">Score</label>
               <input v-model="score" type="number" name="score"
                    id="score" class="form-control"
                    v-bind:class="{ 'is-danger': errors.has('collection.score')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.score')" class="help is-danger">{{ errors.first('collection.score') }}</p>
            </div>
            <div class="col">
                <label class="form-label" for="flag_true">True</label><br>
                <div class="custom-control custom-checkbox-toggle custom-control-inline mr-1">
                    <input
                        v-model="flag_true" checked="" type="checkbox" name="flag_true" id="flag_true" class="custom-control-input"
                        true-value="true" false-value="false"
                        :class="{ 'is-danger': errors.has('collection.flag_true') }"
                        v-validate="'required'" data-vv-scope="collection"
                    >
                    <label class="custom-control-label" for="flag_true">{{flag_true}}</label>
                </div>
            </div>            
            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Begin Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('choiceTestForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,
            business_code : null,
            text_choice: '',
            sequence_no:null,            
            begin_date : null,
            end_date : null,  
            score:null,
            flag_true:null          
        }
    },
    created() {
        if(this.choice.detail) this.getData()        
    },
    computed: {        
        ...mapState({
            choice: state=> state.test_question_choice,            
            bank: state=> state.testquestionbank.detail            
        })

    },
    methods: {

        getData() {
            this.text_choice = this.choice.detail.text_choice
            this.sequence_no = this.choice.detail.sequence_no            
            this.object_identifier = this.choice.detail.object_identifier            
            this.score  = this.choice.detail.score
            this.flag_true  = this.choice.detail.flag_true
            this.begin_date  = this.choice.detail.begin_date
            this.end_date  = this.choice.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false            
            this.$axios.post('lms/api/testquestionchoice', {
                business_code: this.bank.business_code.business_code,                
                begin_date : this.begin_date,
                end_date : this.end_date,
                question: this.bank.question_id,
                flag_true : this.flag_true,
                score   : this.score,
                text_choice: this.text_choice,
                sequence_no : this.sequence_no,                
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('choiceTestForm')
                this.$store.dispatch('test_question_choice/getAll', { 'question[]' : this.bank.question_id });
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false            
            this.$axios.put('lms/api/testquestionchoice', {
                object_identifier:this.object_identifier,
                business_code: this.bank.business_code.business_code,                
                begin_date : this.begin_date,
                end_date : this.end_date,
                flag_true : this.flag_true,
                score   : this.score,
                question: this.bank.question_id,
                text_choice: this.text_choice,
                sequence_no : this.sequence_no,                
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('choiceTestForm')
                this.$store.dispatch('test_question_choice/getAll', { 'question[]' : this.bank.question_id });
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.text_choice = ''
            this.sequence_no = null
            this.object_identifier = null            
            this.begin_date  = null
            this.end_date  = null
            this.score = null
            this.flag_true = null
            this.$validator.reset('collection')
        },


    },
}

</script>
