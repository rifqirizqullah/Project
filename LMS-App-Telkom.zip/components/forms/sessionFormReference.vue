<template>
    <div class="">
        <div class="card " v-if="type == 'event' && batch.reference.batch_id">
            <div class="">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Name</th>
                            <th v-if="batch.curriculum.id">Learning Activity</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in sessionReferenceList" :key="index">
                            <td> {{index+1}} </td>
                            <td> {{ item.session_name }} </td>
                            <td v-if="batch.curriculum.id">{{ item.learning_activity.activity_name }}</td>
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item)">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="session.isLoadingR" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='session' :storeModuleName="'session'" />
            </div>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState, mapActions } from 'vuex';
import paginationBarR from '@@/components/paginationBarR'


export default {
    components : { paginationBarR },
    created() {        
        this.$store.dispatch('session/getReference');
    },
    data() {
        return {
            type : this.$route.query.type
        }
    },
    computed: {
        ...mapState({
            batch : state => state.batch.detail,
            session : state => state.session,
        }),
        sessionReferenceList(){
            return this.session.listReference.filter((sessRef, index) => {
                return this.session.list.find(session => session.reference.session_id == sessRef.session_id ) === undefined
            })
        }
    },
    methods: {

        submit(plannedSession){
            this.$axios.post('lms/api/session', {
                business_code : this.batch.business_code.business_code,
                batch : this.batch.batch_id,
                session_name : plannedSession.session_name,
                learning_activity : plannedSession.learning_activity.activity_id || ' ',
                reference : plannedSession.session_id,
                begin_date : plannedSession.begin_date,
                end_date : plannedSession.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.$store.dispatch('session/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },


        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }

    },
}

</script>
