<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Batch </h4>
        </div>
        <div class='card-body p-4'>
            <div class="form-group">
                <label for="batch_name">Batch Name</label>
               <input v-model="batch_name" type="text" name="batch_name"
                    id="batch_name" class="form-control"
                    v-bind:class="{ 'is-danger': errors.has('collection.batch_name')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.batch_name')" class="help is-danger">{{ errors.first('collection.batch_name') }}</p>
            </div>
            <div class="form-group" v-if="event.event_type.id == '01'">
                <label for="curriculum">Curriculum</label>
                <select v-model="curriculum" class="form-control" name="curriculum"
                    id="curriculum" v-bind:class="{ 'is-danger': errors.has('collection.curriculum') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(data, index) in curriculums.list" :key="index" :value="data.curriculum.id">
                        {{data.curriculum.value}}</option>
                </select>
                <p v-show="errors.has('collection.curriculum')" class="help is-danger">{{ errors.first('collection.curriculum') }}</p>
            </div>
            <div class="form-group">
                <label for="location">Location</label>
                <select v-model="location" class="form-control" name="location"
                    id="location" v-bind:class="{ 'is-danger': errors.has('collection.location') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(data, index) in LOCID.list" :key="index" :value="data.id">
                        {{data.value}}</option>
                </select>
                <p v-show="errors.has('collection.location')" class="help is-danger">{{ errors.first('collection.location') }}</p>
            </div>
            <div class="form-group">
                <label for="vendor">Vendor</label>
                <select
                    v-model="vendor" class="form-control" name="vendor" id="vendor"
                    :class="{ 'is-danger': errors.has('collection.vendor') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in vendors.list" :key="index" :value="item.child_company.business_code">{{item.child_company.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.vendor')" class="help is-danger">{{ errors.first('collection.vendor') }}</p>
            </div>
            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Begin Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('batchForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            business_code : null,
            batch_name: null,
            curriculum:null,
            location: null,
            vendor:null,
            begin_date : null,
            end_date : null,
            type:this.$route.query.type
        }
    },
    created() {
        if(this.batch.detail) this.getData()

        this.$store.dispatch('curriculum/getAll', { business_code : ['*', this.event.business_code.business_code] });
        this.$store.dispatch('LOCID/getAll', { business_code : ['*', this.event.business_code.business_code] });
        this.$store.dispatch('companyRelation/getAll', {  parent_company : ['*', this.event.business_code.business_code] });
    },
    computed: {
        event(){
            if (this.type == 'event') {
                return this.$store.state.event.detail
            } else {
                return this.$store.state.eventPlan.detail
            }

        },
        ...mapState({
            batch: state=> state.batch,
            LOCID: state=> state.LOCID,
            curriculums: state=> state.curriculum,
            vendors: state=> state.companyRelation,
        })

    },
    methods: {

        getData() {
            this.curriculum = this.batch.detail.curriculum.id || ' '
            this.vendor = this.batch.detail.vendor.business_code
            this.reference = this.batch.detail.reference.batch_id || 0
            this.object_identifier = this.batch.detail.object_identifier
            this.batch_name = this.batch.detail.batch_name;
            this.location = this.batch.detail.location.id;
            this.begin_date  = this.batch.detail.begin_date
            this.end_date  = this.batch.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            if (this.curriculum == null)this.curriculum=' ';
            this.$axios.post('lms/api/batch', {
                business_code: this.event.business_code.business_code,
                location: this.location,
                begin_date : this.begin_date,
                end_date : this.end_date,
                event: this.event.event_id,
                batch_name: this.batch_name,
                location : this.location,
                curriculum: this.curriculum,
                vendor: this.vendor,
                reference : 0
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('batchForm')
                this.$store.dispatch('batch/getAll',{'type':this.type});
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            if (this.curriculum == null)this.curriculum=' ';
            this.$axios.put('lms/api/batch', {
                object_identifier:this.object_identifier,
                business_code: this.event.business_code.business_code,
                location: this.location,
                begin_date : this.begin_date,
                end_date : this.end_date,
                event: this.event.event_id,
                batch_name: this.batch_name,
                location : this.location,
                curriculum: this.curriculum,
                vendor: this.vendor,
                reference : this.reference
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('batchForm')
                this.$store.dispatch('batch/getAll',{'type':this.type});
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {

            this.curriculum = null
            this.vendor = null
            this.reference = null
            this.object_identifier = null
            this.batch_name = null
            this.location = null
            this.begin_date  = null
            this.end_date  = null
            this.$validator.reset('collection')
        },


    },
}

</script>
