<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Trainer </h4>
        </div>
        <div class='card-body p-4'>


            <div class="form-group">
                <label for="wage_type">Wage Type</label>
                <select
                    v-model="wage_type" class="form-control" name="wage_type" id="wage_type"
                    :class="{ 'is-danger': errors.has('collection.wage_type') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in wage.list" :key="index" :value="item.wage_type">{{item.wage_name}}</option>
                </select>
                <p v-show="errors.has('collection.wage_type')" class="help is-danger">{{ errors.first('collection.wage_type') }}</p>
            </div>

            <div class="form-group">
                <label for="budget_type">Budget Type</label>
                <select
                    v-model="budget_type" class="form-control" name="budget_type" id="budget_type"
                    :class="{ 'is-danger': errors.has('collection.budget_type') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in BTYPE.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.budget_type')" class="help is-danger">{{ errors.first('collection.budget_type') }}</p>
            </div>

            <div class="form-group">
                <label for="quantity">Quantity</label>
                <input
                    v-model="quantity" type="number" class="form-control" name="quantity" id="quantity" placeholder="Quantity .."
                    :class="{ 'is-danger': errors.has('collection.quantity') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                <p v-show="errors.has('collection.quantity')" class="help is-danger">{{ errors.first('collection.quantity') }}</p>
            </div>

            <div class="form-group">
                <label for="price">Price</label>
                <input
                    v-model="price" type="number" class="form-control" name="price" id="price" placeholder="Price .."
                    :class="{ 'is-danger': errors.has('collection.price') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                <p v-show="errors.has('collection.price')" class="help is-danger">{{ errors.first('collection.price') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>





        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('eventBudgetForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            business_code : null,
            wage_type : null,
            budget_type : null,
            quantity : null,
            price : null,
            begin_date : null,
            end_date : null,

        }
    },
    created() {
        if(this.eventBudget.detail) this.getData()

        this.$store.dispatch('wage/getAll');
        this.$store.dispatch('BTYPE/getAll');
    },
    computed: {
        ...mapState({
            eventBudget: state => state.eventBudget,
            event_id: state => state.event.detail.event_id,
            current_event : state => state.event.detail,
            wage: state => state.wage,
            BTYPE: state => state.BTYPE,
        })
    },
    methods: {

        getData() {
            this.object_identifier = this.eventBudget.detail.object_identifier
            this.begin_date = this.eventBudget.detail.begin_date
            this.end_date = this.eventBudget.detail.end_date
            this.business_code = this.eventBudget.detail.business_code.business_code
            this.event = this.event_id
            this.wage_type = this.eventBudget.detail.wage_type.wage_type
            this.quantity = this.eventBudget.detail.quantity
            this.price = this.eventBudget.detail.price
            this.budget_type = this.eventBudget.detail.budget_type.id
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/eventbudget', {
                begin_date : this.begin_date ,
                end_date : this.end_date ,
                business_code : this.current_event.business_code.business_code ,
                event : this.event_id ,
                wage_type : this.wage_type ,
                quantity : this.quantity ,
                price : this.price ,
                budget_type : this.budget_type

            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventBudgetForm')
                this.$store.dispatch('eventBudget/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/eventbudget', {
                object_identifier : this.object_identifier,
                begin_date : this.begin_date ,
                end_date : this.end_date ,
                business_code : this.business_code ,
                event : this.event_id ,
                wage_type : this.wage_type ,
                quantity : this.quantity ,
                price : this.price ,
                budget_type : this.budget_type

            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventBudgetForm')
                this.$store.dispatch('eventBudget/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null

            this.begin_date = null
            this.end_date = null
            this.business_code = null
            this.wage_type = null
            this.quantity = null
            this.price = null
            this.budget_type = null

            this.$validator.reset('collection')
        },


    },
}

</script>
