<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Budget </h4>
        </div>
        <div class='card-body p-4'>
            <div class="form-group">
                <label for="costItem">Cost Item</label>
                <select v-model="wage_type" class="form-control" name="costItem" id="costItem"
                    v-bind:class="{ 'is-danger': errors.has('collection.costItem') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option disabled value="">Cost Item</option>
                    <option v-for="(wage, index) in wage.list" :key="index" :value="wage.wage_type">
                        {{ wage.wage_name }}
                    </option>
                </select>
                <p v-show="errors.has('collection.costItem')" class="help is-danger">
                    {{ errors.first('collection.costItem') }}</p>
            </div>
            <div class="form-group">
                <label for="unitPrice">Unit Price</label>
                <input type="text" v-model="price" @keypress="onlyNumber" class="form-control"
                    name="unitPrice" id="unitPrice"
                    v-bind:class="{ 'is-danger': errors.has('collection.unitPrice') }"
                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId"
                    placeholder="Unit Price">
                <small id="helpId" class="form-text text-muted">Price</small>
                <p v-show="errors.has('collection.unitPrice')" class="help is-danger">
                    {{ errors.first('collection.unitPrice') }}</p>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity</label>
                <input type="text" v-model="quantity" @keypress="onlyNumber" class="form-control"
                    name="quantity" id="quantity"
                    v-bind:class="{ 'is-danger': errors.has('collection.quantity') }"
                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId"
                    placeholder="Quantity">
                <small id="helpId" class="form-text text-muted">Quantity</small>
                <p v-show="errors.has('collection.quantity')" class="help is-danger">
                    {{ errors.first('collection.quantity') }}</p>
            </div>
            <div class="form-group">
                <label for="subtotal">Subtotal</label>
                <input type="number" v-model="subtotal" class="form-control" name="subtotal"
                    id="subtotal" v-bind:class="{ 'is-danger': errors.has('collection.subtotal') }"
                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId"
                    placeholder="Subtotal" disabled>
                <small id="helpId" class="form-text text-muted">Subtotal</small>
                <p v-show="errors.has('collection.subtotal')" class="help is-danger">
                    {{ errors.first('collection.subtotal') }}</p>
            </div>
            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Begin Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('budgetForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
    import {
        mapState
    } from 'vuex';

    export default {
        data() {
            return {
                object_identifier: null,

                begin_date: null,
                end_date: null,
                business_code: null,

                wage_type: null,
                quantity: null,
                price: null,
            }
        },
        created() {
            if (this.batchBudget.detail) this.getData()
            this.$store.dispatch('wage/getAll', { business_code : ['*', this.batch.business_code.business_code] });
        },
        computed: {
            ...mapState({
                batchBudget: state => state.batchBudget,
                batch: state => state.batch.detail,
                wage: state => state.wage,
            }),
            subtotal: function () {
                return Number(this.price) * Number(this.quantity)
            }

        },
        methods: {

            getData() {
                this.object_identifier = this.batchBudget.detail.object_identifier
                this.price = this.batchBudget.detail.price
                this.quantity = this.batchBudget.detail.quantity
                this.wage_type = this.batchBudget.detail.wage_type.wage_type
                this.business_code = this.batchBudget.detail.business_code.business_code
                this.begin_date = this.batchBudget.detail.begin_date
                this.end_date = this.batchBudget.detail.end_date
            },

            async storeData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.post('lms/api/batchbudget', {
                        batch: this.batch.batch_id,
                        price: this.price,
                        quantity: this.quantity,
                        wage_type: this.wage_type,
                        business_code: this.batch.business_code.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('budgetForm')
                        this.$store.dispatch('batchBudget/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            async updateData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.put('lms/api/batchbudget', {
                        object_identifier: this.object_identifier,
                        batch: this.batch.batch_id,
                        price: this.price,
                        quantity: this.quantity,
                        wage_type: this.wage_type,
                        business_code: this.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Updated!',
                            'Successfully update data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('budgetForm')
                        this.$store.dispatch('batchBudget/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            resetForm() {
                this.object_identifier = null

                this.price = null
                this.quantity = null
                this.wage_type = null
                this.business_code = null
                this.begin_date = null
                this.end_date = null

                this.$validator.reset('collection')
            },

            onlyNumber($event) {
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
                    $event.preventDefault();
                }
            },
        },
    }

</script>
