<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Test </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="business_code">Company</label>
                <select
                    v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }"
                    v-validate="'required'" data-vv-scope="collection"
                    @change="syncCompanyParams()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger"> {{ errors.first('collection.business_code') }}</p>
            </div>

            <div class="form-group">
                <label for="question_name">Name</label>
                <input v-model="question_name" type="text" name="Title"
                    id="question_name" class="form-control" placeholder="question_name"
                    aria-describedby="question_name" v-bind:class="{ 'is-danger': errors.has('collection.question_name')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.question_name')" class="help is-danger"> {{ errors.first('collection.question_name') }}</p>
            </div>

            <div class="form-group">
                <label for="question_type">Type</label>
                <select v-model="question_type" class="form-control" name="question_type"
                    id="question_type" v-bind:class="{ 'is-danger': errors.has('collection.question_type') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(question_type, index) in QSTTY.list" :key="index" :value="question_type.id">
                        {{question_type.value}}</option>
                </select>
                <p v-show="errors.has('collection.question_type')" class="help is-danger">{{ errors.first('collection.question_type') }}</p>
            </div>

            <div class="form-group">
                <label for="question_text">Text</label>
                <input v-model="question_text" type="text" name="text"
                    id="question_text" class="form-control" placeholder="question_text"
                    aria-describedby="question_text" v-bind:class="{ 'is-danger': errors.has('collection.question_text')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.question_text')" class="help is-danger"> {{ errors.first('collection.question_text') }}</p>
            </div>

            <div class="form-group">
                <label for="question_image">Image</label>
                <b-form-file
                    accept="image/*"
                    v-model="question_image"
                    :state="Boolean(question_image)"
                    placeholder="Choose a file..."
                    drop-placeholder="Drop file here..."
                ></b-form-file>
            </div>

            <div class="form-group">
                <label for="score">Score</label>
                <select v-model="score" class="form-control" name="score"
                    id="score" v-bind:class="{ 'is-danger': errors.has('collection.score') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in [0,30,50,80,100]" :key="index" :value="item">
                        {{item}}
                    </option>
                </select>
                <p v-show="errors.has('collection.score')" class="help is-danger">{{ errors.first('collection.score') }}</p>
            </div>

            <div class="form-group">
                <label for="competence">Competency</label>
                <select v-model="competence" class="form-control" name="competence"
                    id="competence" v-bind:class="{ 'is-danger': errors.has('collection.competence') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(competencies, index) in CMPTY.list" :key="index" :value="competencies.id">
                        {{competencies.value}}
                    </option>
                </select>
                <p v-show="errors.has('collection.competence')" class="help is-danger">{{ errors.first('collection.competence') }}</p>
            </div>

            <div class="form-group">
                <label for="pl_code">Proficiency Level</label>
                <select v-model="pl_code" class="form-control" name="pl_code"
                    id="pl_code" v-bind:class="{ 'is-danger': errors.has('collection.pl_code') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(pl_code, index) in PLCOD.list" :key="index" :value="pl_code.id">
                        {{pl_code.value}}</option>
                </select>
                <p v-show="errors.has('collection.pl_code')" class="help is-danger">{{ errors.first('collection.pl_code') }}</p>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('testquestionbankForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            question_name : null,
            question_type : null,
            question_text : null,
            question_image : null,
            score : null,
            competence : null,
            pl_code : null,
            business_code : null,
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.testquestionbank.detail) {
            this.getData()
            this.syncCompanyParams()
        }
    },
    computed: {
        ...mapState({
            testquestionbank : state => state.testquestionbank,
            company : state => state.company,
            QSTTY : state => state.QSTTY,
            CMPTY : state => state.CMPTY,
            PLCOD : state => state.PLCOD,
        })
    },
    methods: {

        syncCompanyParams() {
            this.$store.dispatch('company/getAll' , { business_code : ['*', this.business_code] });
            this.$store.dispatch('CMPTY/getAll' , { business_code : ['*', this.business_code] });
            this.$store.dispatch('QSTTY/getAll', { business_code : ['*', this.business_code] });
            this.$store.dispatch('PLCOD/getAll', { business_code : ['*', this.business_code] });
        },

        getData() {
            this.object_identifier = this.testquestionbank.detail.object_identifier
            this.business_code = this.testquestionbank.detail.business_code.business_code
            this.question_name = this.testquestionbank.detail.question_name
            this.question_type = this.testquestionbank.detail.question_type.id
            this.question_text = this.testquestionbank.detail.question_text
            this.question_image = this.testquestionbank.detail.question_image
            this.score = this.testquestionbank.detail.score
            this.competence = this.testquestionbank.detail.competence.id
            this.pl_code = this.testquestionbank.detail.pl_code.id
            this.begin_date = this.testquestionbank.detail.begin_date
            this.end_date = this.testquestionbank.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            let data = new FormData();

            data.append('question_name', this.question_name)
            data.append('question_type', this.question_type)
            data.append('question_text', this.question_text)
            data.append('question_image', this.question_image)
            data.append('score', this.score)
            data.append('competence', this.competence)
            data.append('pl_code', this.pl_code)
            data.append('business_code', this.business_code)
            data.append('begin_date', this.formatDate(new Date))
            data.append('end_date', '9999-12-30')

            this.$axios.post('lms/api/testquestionbank', data)
            .then((res) => {
                console.log(res);
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('testquestionbankForm')
                this.$store.dispatch('testquestionbank/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            let data = new FormData();

            data.append('object_identifier', this.object_identifier)
            data.append('question_name', this.question_name)
            data.append('question_type', this.question_type)
            data.append('question_text', this.question_text)
            data.append('question_image', this.question_image)
            data.append('score', this.score)
            data.append('competence', this.competence)
            data.append('pl_code', this.pl_code)
            data.append('business_code', this.business_code)
            data.append('begin_date', this.formatDate(new Date))
            data.append('end_date', '9999-12-30')

            this.$axios.post('lms/api/testquestionbank', data)
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('testquestionbankForm')
                this.$store.dispatch('testquestionbank/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.question_name = null
            this.question_type = null
            this.question_text = null
            this.question_image = null
            this.score = null
            this.competence = null
            this.pl_code = null
            this.begin_date = null
            this.end_date = null

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
