<template>
    <div class="">
        <div class="card-header bg-info">
            <h4>{{object_identifier ? 'Update' : 'Create'}} Object</h4>
        </div>
        <div class='card-body p-4'>

            <div v-if="object_identifier == null" class="form-group">
                <label for="business_code">Company</label>
                <select v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">
                        {{ item.company_name }}
                    </option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger">
                    {{ errors.first('collection.business_code') }}</p>
            </div>
            <div v-else class="form-group">
                <label for="business_code">Company</label>
                <select v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }" v-validate="'required'"
                    data-vv-scope="collection" disabled>
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">
                        {{ item.company_name }}
                    </option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger">
                    {{ errors.first('collection.business_code') }}</p>
            </div>

            <div v-if="object_identifier == null" class="form-group">
                <label for="short_text">Object ID</label>
                <input v-model="short_text" type="text" class="form-control" name="short_text" id="short_text"
                    placeholder="Object ID" :class="{ 'is-danger': errors.has('collection.short_text') }"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.short_text')" class="help is-danger">
                    {{ errors.first('collection.short_text') }}</p>
            </div>
            <div v-else class="form-group">
                <label for="short_text">Object ID</label>
                <input v-model="short_text" type="text" class="form-control" name="short_text" id="short_text"
                    placeholder="Object ID" :class="{ 'is-danger': errors.has('collection.short_text') }"
                    v-validate="'required'" data-vv-scope="collection" disabled>
                <p v-show="errors.has('collection.short_text')" class="help is-danger">
                    {{ errors.first('collection.short_text') }}</p>
            </div>

            <div class="form-group">
                <label for="long_text">Object Name</label>
                <input v-model="long_text" type="text" class="form-control" name="long_text" id="long_text"
                    placeholder="Object Name" :class="{ 'is-danger': errors.has('collection.long_text') }"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.long_text')" class="help is-danger">
                    {{ errors.first('collection.long_text') }}</p>
            </div>

            <div class="form-group">
                <label for="object_description">Object Description</label>
                <input v-model="object_description" type="text" class="form-control" name="object_description"
                    id="object_description" placeholder="Object Description"
                    :class="{ 'is-danger': errors.has('collection.object_description') }" v-validate="'required'"
                    data-vv-scope="collection">
                <p v-show="errors.has('collection.object_description')" class="help is-danger">
                    {{ errors.first('collection.object_description') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger">
                                {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                                data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('objectForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
    import {
        mapState
    } from 'vuex';

    export default {
        data() {
            return {
                object_identifier: null,

                object_type: this.$route.query.otype,
                object_description: null,
                plan_version: null,
                short_text: null,
                long_text: null,

                begin_date: null,
                end_date: null,
                business_code: null,

            }
        },
        created() {
            if (this.object.detail) this.getData()

            this.$store.dispatch('company/getAll');
        },
        computed: {
            ...mapState({
                object: state => state.object,
                company: state => state.company
            })
        },
        methods: {
            getData() {
                this.object_identifier = this.object.detail.object_identifier

                this.short_text = this.object.detail.id
                this.long_text = this.object.detail.value
                this.object_description = this.object.detail.object_description
                this.plan_version = this.object.detail.plan_version
                this.business_code = this.object.detail.business_code.business_code
                this.begin_date = this.object.detail.begin_date
                this.end_date = this.object.detail.end_date
            },

            async storeData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.post('ldap/api/objects', {
                        short_text: this.short_text,
                        long_text: this.long_text,
                        object_description: this.object_description,
                        plan_version: "01",
                        business_code: this.business_code,
                        object_type: this.object_type,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('objectForm')
                        this.$store.dispatch('object/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            async updateData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.put('ldap/api/objects', {
                        object_identifier: this.object_identifier,
                        short_text: this.short_text,
                        long_text: this.long_text,
                        object_description: this.object_description,
                        plan_version: "01",
                        business_code: this.business_code,
                        object_type: this.object_type,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Updated!',
                            'Successfully update data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('objectForm')
                        this.$store.dispatch('object/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            resetForm() {
                this.object_identifier = null

                this.object_type = null
                this.object_description = null
                this.plan_version = null
                this.short_text = null
                this.long_text = null
                this.business_code = null
                this.begin_date = null
                this.end_date = null

                this.$validator.reset('collection')
            },
        },
    }

</script>
