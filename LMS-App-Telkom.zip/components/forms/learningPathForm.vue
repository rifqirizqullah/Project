<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Curriculum </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <input type="text" class="form-control" name="company" id="company"
                    v-bind:class="{ 'is-danger': errors.has('collection.company') }"
                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId" :value="LPTID.detail.business_code.company_name" disabled>
                <p v-show="errors.has('collection.company')" class="help is-danger"> {{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="learningpath">Learning Path</label>
                <input type="text" class="form-control" name="learningpath" id="learningpath"
                    v-bind:class="{ 'is-danger': errors.has('collection.learningpath') }"
                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId" :value="LPTID.detail.value" disabled>
                <p v-show="errors.has('collection.learningpath')" class="help is-danger"> {{ errors.first('collection.learningpath') }}</p>
            </div>

            <div class="form-group">
                <label for="curriculum">Curriculum</label>
                <select v-model="curriculum" class="form-control" name="curriculum" id="curriculum"
                    v-bind:class="{ 'is-danger': errors.has('collection.curriculum') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in curriculums" :key="index" :value="item.curriculum.id">
                        {{item.curriculum.value}}
                    </option>
                </select>
                <p v-show="errors.has('collection.curriculum')" class="help is-danger">{{ errors.first('collection.curriculum') }}</p>
            </div>

            <div class="form-group">
                <label for="sequence">Sequence</label>
                <input type="number" v-model.number="sequence" class="form-control" name="sequence" id="sequence"
                    v-bind:class="{ 'is-danger': errors.has('collection.sequence') }"
                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId" placeholder="Sequence">
                <p v-show="errors.has('collection.sequence')" class="help is-danger"> {{ errors.first('collection.sequence') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('learningPathForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';
export default {
    data() {
        return {
            object_identifier : null,
            business_code : null,
            learningpath : null,
            curriculum : null,
            sequence: null,
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.learningPath.detail) this.getData()
        this.getParam()
        this.$store.dispatch('company/getAll')
    },
    computed: {
        ...mapState({
            learningPath : state => state.learningPath,
            curriculums : state => state.curriculum.list,
            LPTID: state => state.LPTID,
        })
    },
    methods: {
        getParam(){
            this.$store.dispatch('CURID/getAll', {business_code:['*', this.LPTID.detail.business_code.business_code]})
        },
        getData() {
            this.object_identifier = this.learningPath.detail.object_identifier
            this.learningpath =  this.learningPath.detail.learningpath.id
            this.curriculum =  this.learningPath.detail.curriculum.id
            this.sequence =  this.learningPath.detail.sequence
            this.business_code =  this.learningPath.detail.business_code.business_code
            this.begin_date = this.learningPath.detail.begin_date
            this.end_date = this.learningPath.detail.end_date
        },
        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/learningpath', {
                learningpath : this.LPTID.detail.id,
                curriculum : this.curriculum,
                business_code : this.LPTID.detail.business_code.business_code,
                sequence : this.sequence,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('learningPathForm')
                this.$store.dispatch('learningPath/getAll',{learningpath:[this.LPTID.detail.id]});
            })
            .catch(err => {
                console.log(err.response);
            })
        },
        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/learningpath', {
                object_identifier: this.object_identifier,
                learningpath : this.learningpath,
                curriculum : this.curriculum,
                business_code : this.business_code,
                sequence : this.sequence,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('learningPathForm')
                this.$store.dispatch('learningPath/getAll',{learningpath:[this.LPTID.detail.id]});
            })
            .catch(err => {
                console.log(err.response);
            })
        },
        resetForm() {
            this.object_identifier = null
            this.business_code = null
            this.curriculum = null
            this.learningpath = null
            this.sequence = null
            this.begin_date = null
            this.end_date = null
            this.$validator.reset('collection')
        },
    },
}
</script>