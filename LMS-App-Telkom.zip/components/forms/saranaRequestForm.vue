<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Sarana Request </h4>
        </div>
        <div class='card-body p-4'>

            <!-- <div class="form-group">
                <label for="batch_name">Batch</label>
                <select v-model="batch_name" class="form-control" name="batch_name" id="batch_name"
                    :class="{ 'is-danger': errors.has('collection.batch') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <option v-for="(item, index) in batch.list" :key="index" :value="item.batch_id">{{item.batch_name}}
                    </option>
                </select>
                <p v-show="errors.has('collection.batch')" class="help is-danger">
                    {{ errors.first('collection.batch') }}</p>
            </div> -->

            <div class="form-group">
                <label for="facility">Facility</label>
                <select v-model="facility" class="form-control" name="facility" id="facility"
                    :class="{ 'is-danger': errors.has('collection.facility') }" v-validate="'required'"
                    data-vv-scope="collection">
                    <option v-for="(item, index) in FACCD.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.facility')" class="help is-danger">
                    {{ errors.first('collection.facility') }}</p>
            </div>

            <div class="form-group">
                <label for="quantity">Quantity</label>
                <input v-model="quantity" type="text" @keypress="onlyNumber" class="form-control" name="quantity"
                    id="quantity" placeholder="Quantity ..." :class="{ 'is-danger': errors.has('collection.quantity') }"
                    v-validate="'required'" data-vv-scope="collection" />
                <p v-show="errors.has('collection.quantity')" class="help is-danger">
                    {{ errors.first('collection.quantity') }}</p>
            </div>

            <div class="form-group">
                <label for="description">Description</label>
                <input v-model="description" type="text" class="form-control" name="description" id="description"
                    placeholder="Description ..." :class="{ 'is-danger': errors.has('collection.description') }"
                    v-validate="'required'" data-vv-scope="collection" />
                <p v-show="errors.has('collection.description')" class="help is-danger">
                    {{ errors.first('collection.description') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Begin Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('saranaRequestForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
    import {
        mapState
    } from 'vuex';

    export default {
        data() {
            return {
                object_identifier: null,

                begin_date: null,
                end_date: null,
                business_code: null,

                facility: null,
                quantity: null,
                description: null,
            }
        },
        created() {
            if (this.saranaRequest.detail) this.getData()

            // this.$store.dispatch('batch/getAll');
            this.$store.dispatch('FACCD/getAll');
        },
        computed: {
            ...mapState({
                saranaRequest: state => state.saranaRequest,
                batch: state => state.batch.detail,
                FACCD: state => state.FACCD,
            })
        },
        methods: {

            getData() {
                this.object_identifier = this.saranaRequest.detail.object_identifier
                this.facility = this.saranaRequest.detail.facility.id
                this.quantity = this.saranaRequest.detail.quantity
                this.description = this.saranaRequest.detail.description
                this.business_code = this.saranaRequest.detail.business_code.business_code
                this.begin_date = this.saranaRequest.detail.begin_date
                this.end_date = this.saranaRequest.detail.end_date
            },

            async storeData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.post('lms/api/requestsarana', {
                        batch: this.batch.batch_id,
                        facility: this.facility,
                        quantity: this.quantity,
                        description: this.description,
                        business_code: this.batch.business_code.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('saranaRequestForm')
                        this.$store.dispatch('saranaRequest/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            async updateData() {
                let isValid = await this.$validator.validateAll('collection')
                if (!isValid) return false
                this.$axios.put('lms/api/requestsarana', {
                        object_identifier: this.object_identifier,
                        batch: this.batch.batch_id,
                        facility: this.facility,
                        quantity: this.quantity,
                        description: this.description,
                        business_code: this.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Updated!',
                            'Successfully update data.',
                            'success'
                        )
                        this.resetForm()
                        this.$bvModal.hide('saranaRequestForm')
                        this.$store.dispatch('saranaRequest/getAll');
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            resetForm() {
                this.object_identifier = null

                this.description = null
                this.facility = null
                this.quantity = null
                this.business_code = null
                this.begin_date = null
                this.end_date = null

                this.$validator.reset('collection')
            },

            onlyNumber($event) {
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
                    $event.preventDefault();
                }
            },
        },
    }

</script>
