<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Forum </h4>
        </div>
        <div class='card-body p-4'>

            <!-- <div class="form-group">
                <label for="business_code">Company</label>
                <select
                    v-model="business_code" class="form-control" name="business_code" id="business_code"
                    :class="{ 'is-danger': errors.has('collection.business_code') }"
                    v-validate="'required'" data-vv-scope="collection"
                    @change="syncCompanyParams()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.business_code')" class="help is-danger"> {{ errors.first('collection.business_code') }}</p>
            </div>

            <div class="form-group">
                <label for="batch">Batch</label>
                <select v-model="batch" class="form-control" name="batch"
                    id="batch" v-bind:class="{ 'is-danger': errors.has('collection.batch') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in batch_list" :key="index" :value="item.batch_id">
                        {{item.batch_name}}</option>
                </select>
                <p v-show="errors.has('collection.batch')" class="help is-danger">{{ errors.first('collection.batch') }}</p>
            </div> -->

            <div class="form-group">
                <label for="forum_title">Title</label>
                <input v-model="forum_title" type="text" name="text"
                    id="forum_title" class="form-control" placeholder="forum_title"
                    aria-describedby="forum_title" v-bind:class="{ 'is-danger': errors.has('collection.forum_title')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.forum_title')" class="help is-danger"> {{ errors.first('collection.forum_title') }}</p>
            </div>

            <div class="form-group">
                <label for="forum_text" class="form-label">Content</label>
                <textarea v-model="forum_text" class="form-control" name="forum_text" id="forum_text" rows="3" placeholder="Content  ..."
                    v-bind:class="{ 'is-danger': errors.has('collection.forum_text')}"
                    v-validate="'required'" data-vv-scope="collection"
                ></textarea>
                <p v-show="errors.has('collection.forum_text')" class="help is-danger">{{ errors.first('collection.forum_text') }}</p>
            </div>


            <div class="form-group">
                <label for="forum_image">Image</label>
                <b-form-file
                    accept="image/*"
                    v-model="forum_image"
                    :state="Boolean(forum_image)"
                    placeholder="Choose a file..."
                    drop-placeholder="Drop file here..."
                ></b-form-file>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('forumForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            business_code : null,
            batch_id : null,
            owner : null,
            forum_title : null,
            forum_text : null,
            forum_type : null,
            forum_image : null,
            forum_time : null,
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.forum.detail) {
            this.getData()
            // this.syncCompanyParams()
        }

        // this.$store.dispatch('company/getAll')
    },
    computed: {
        ...mapState({
            forum : state => state.forum,
            company : state => state.company,
            batch : state => state.batch,
        })
    },
    methods: {

        syncCompanyParams() {
            this.$store.dispatch('batch/getAll')
        },

        getData() {
            this.object_identifier = this.forum.detail.object_identifier

            this.business_code = this.forum.detail.business_code.business_code
            this.batch_id = this.forum.detail.batch.batch_id
            this.owner = this.forum.detail.owner
            this.forum_title = this.forum.detail.forum_title
            this.forum_text = this.forum.detail.forum_text
            this.forum_type = this.forum.detail.forum_type.id
            this.forum_image = this.forum.detail.forum_image
            this.forum_time = this.forum.detail.forum_time
            this.begin_date = this.forum.detail.begin_date
            this.end_date = this.forum.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            let data = new FormData();

            data.append('business_code', this.batch.detail.business_code.business_code)
            data.append('batch', this.batch.detail.batch_id)
            data.append('owner', this.$auth.user.username)
            data.append('forum_title', this.forum_title)
            data.append('forum_text', this.forum_text)
            data.append('forum_type', 1)
            data.append('forum_image', this.forum_image)
            data.append('forum_time', moment(new Date).format("HH:mm"))
            data.append('begin_date', this.begin_date)
            data.append('end_date', this.end_date)

            this.$axios.post('lms/api/forum', data)
            .then((res) => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('forumForm')
                this.$store.dispatch('forum/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            let data = new FormData();

            data.append('object_identifier', this.object_identifier)
            data.append('business_code', this.business_code)
            data.append('batch', this.batch_id)
            data.append('owner', this.$auth.user.username)
            data.append('forum_title', this.forum_title)
            data.append('forum_text', this.forum_text)
            data.append('forum_type', 1)
            data.append('forum_image', this.forum_image)
            data.append('forum_time', moment(new Date).format("HH:mm"))
            data.append('begin_date', this.begin_date)
            data.append('end_date', this.end_date)

            this.$axios.post('lms/api/forum', data)
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('forumForm')
                this.$store.dispatch('forum/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            
            this.owner = null
            this.forum_title = null
            this.forum_text = null
            this.forum_type = null
            this.forum_image = null
            this.forum_time = null
            this.begin_date = null
            this.end_date = null

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
