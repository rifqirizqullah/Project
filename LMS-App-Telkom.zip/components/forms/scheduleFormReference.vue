<template>
    <div class="">
            <div class="card">
                <div class="">
                    <table class="table table-responsive table-flush table-hover">
                        <thead class="">
                            <tr>
                                <th>No</th>
                                <th>Time</th>
                                <th>Title</th>
                                <th>Topic</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in scheduleReferenceList" :key="index">
                                <td> {{ index+1 }} </td>
                                <td> {{ item.begin_time }} - {{ item.end_time }} </td>
                                <td> {{ item.schedule_name }} </td>
                                <td> {{ item.topic }} </td>
                                <td>
                                    <button type="button" class="btn btn-success btn-sm" @click="submit(item)">
                                        + Add
                                    </button>
                                </td>
                            </tr>
                            <tr v-if="schedule.isLoadingR">
                                <td colspan="10">
                                    <div class="row">
                                        <div class="col d-flex justify-content-center">
                                            <div class="loader loader-accent text-center"></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <paginationBarR :state='schedule' :storeModuleName="'schedule'" />
                </div>
            </div>

    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';
import paginationBarR from '@@/components/paginationBar'

export default {
    components : { paginationBarR },
    created() {        
        this.$store.dispatch('schedule/getReference');
        
    },
    data() {
        return {
            type : this.$route.query.type
        }
    },
    computed: {
        ...mapState({
            currentEvent : state => state.event.detail,
            session : state => state.session.detail,
            schedule : state => state.schedule,
        }),
        scheduleReferenceList(){
            return this.schedule.listReference.filter((scheduleRef, index) => {
                return this.schedule.list.find(schedule => schedule.reference.schedule_id == scheduleRef.schedule_id ) === undefined
            })
        }
    },
    methods: {
        submit(plannedSchedule){
            this.$axios.post('lms/api/schedule', {
                business_code : this.currentEvent.business_code.business_code,
                session : this.session.session_id,
                schedule_name : plannedSchedule.schedule_name,
                schedule_date : plannedSchedule.schedule_date,
                begin_time : plannedSchedule.begin_time,
                day_number : plannedSchedule.day_number,
                end_time : plannedSchedule.end_time,
                topic : plannedSchedule.topic,
                reference  : plannedSchedule.schedule_id,
                begin_date : plannedSchedule.begin_date,
                end_date : plannedSchedule.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.$store.dispatch('schedule/getAll',{'type':this.type});
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
