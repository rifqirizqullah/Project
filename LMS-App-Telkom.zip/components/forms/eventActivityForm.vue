<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Event Activity </h4>
        </div>
        <div class='card-body p-4'>


            <div class="form-group">
                <label for="learning_plan">Learning Plan</label>
                <select
                    v-model="learning_plan" class="form-control" name="learning_plan" id="learning_plan"
                    :class="{ 'is-danger': errors.has('collection.learning_plan') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in masterLearningPlan.list" :key="index" :value="item.learning_plan">{{item.title}}</option>
                </select>
                <p v-show="errors.has('collection.learning_plan')" class="help is-danger">{{ errors.first('collection.learning_plan') }}</p>
            </div>

            <div class="form-group">
                <label for="learning_activity">Learning Activity</label>
                <select
                    v-model="learning_activity" class="form-control" name="learning_activity" id="learning_activity"
                    :class="{ 'is-danger': errors.has('collection.learning_activity') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in learningActivity.list" :key="index" :value="item.activity_id">{{item.activity_name}}</option>
                </select>
                <p v-show="errors.has('collection.learning_activity')" class="help is-danger">{{ errors.first('collection.learning_activity') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>



        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('eventActivityForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,
            event_activity_id : null,

            business_code : null,
            learning_plan : null,
            learning_activity : null,
            begin_date : null,
            end_date : null,

        }
    },
    created() {
        if(this.eventActivity.detail) this.getData()

        this.$store.dispatch('masterLearningPlan/getAll');
        this.$store.dispatch('learningActivity/getAll');
    },
    computed: {
        ...mapState({
            event_id: state => state.event.detail.event_id,
            current_event: state => state.event.detail,
            eventActivity: state => state.eventActivity,

            masterLearningPlan: state => state.masterLearningPlan,
            learningActivity: state => state.learningActivity,
        })
    },
    methods: {

        getData() {
            this.object_identifier = this.eventActivity.detail.object_identifier
            this.event_activity_id = this.eventActivity.detail.event_activity_id

            this.business_code = this.eventActivity.detail.business_code.business_code
            this.learning_plan = this.eventActivity.detail.learning_plan.learning_plan
            this.learning_activity = this.eventActivity.detail.learning_activity.activity_id
            this.begin_date = this.eventActivity.detail.begin_date
            this.end_date = this.eventActivity.detail.end_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/eventactivity', {
                event : this.event_id ,
                business_code : this.current_event.business_code.business_code,
                learning_plan : this.learning_plan,
                learning_activity : this.learning_activity,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventActivityForm')
                this.$store.dispatch('eventActivity/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/eventactivity', {
                object_identifier : this.object_identifier,
                event : this.event_id ,
                business_code : this.business_code,
                learning_plan : this.learning_plan,
                learning_activity : this.learning_activity,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('eventActivityForm')
                this.$store.dispatch('eventActivity/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.event_activity_id = null

            this.business_code = null
            this.learning_plan = null
            this.learning_activity = null
            this.begin_date = null
            this.end_date = null

            this.$validator.reset('collection')
        },


    },
}

</script>
