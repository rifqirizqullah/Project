<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Wage </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="company">Company</label>
                <select
                    v-model="business_code" class="form-control" name="company" id="company"
                    :class="{ 'is-danger': errors.has('collection.company') }"
                    v-validate="'required'" data-vv-scope="collection" @change="getObject()"
                >
                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                </select>
                <p v-show="errors.has('collection.company')" class="help is-danger">{{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="wage_type">Wage Type</label>
                <input
                    v-model="wage_type" type="text" class="form-control" name="wage_type" id="wage_type" placeholder="Wage Type .."
                    :class="{ 'is-danger': errors.has('collection.wage_type') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                <p v-show="errors.has('collection.wage_type')" class="help is-danger">{{ errors.first('collection.wage_type') }}</p>
            </div>

             <div class="form-group">
                <label for="wage_name">Wage Name</label>
                <input
                    v-model="wage_name" type="text" class="form-control" name="wage_name" id="wage_name" placeholder="Wage Name .."
                    :class="{ 'is-danger': errors.has('collection.wage_name') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                <p v-show="errors.has('collection.wage_name')" class="help is-danger">{{ errors.first('collection.wage_name') }}</p>
            </div>

            <div class="form-group">
                <label for="reference_table">Reference Table</label>
                <select
                    v-model="reference_table" class="form-control" name="reference_table" id="reference_table"
                    :class="{ 'is-danger': errors.has('collection.reference_table') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in WGERF.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.reference_table')" class="help is-danger">{{ errors.first('collection.reference_table') }}</p>
            </div>

            <div class="form-group">
                <label for="tax_type">Taxt Type</label>
                <select
                    v-model="tax_type" class="form-control" name="tax_type" id="tax_type"
                    :class="{ 'is-danger': errors.has('collection.tax_type') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in TAXTY.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.tax_type')" class="help is-danger">{{ errors.first('collection.tax_type') }}</p>
            </div>

            <div class="form-row form-group">
                <div class="col">
                    <label class="form-label" for="flag_taxable">Taxable</label><br>
                    <div class="custom-control custom-checkbox-toggle custom-control-inline mr-1">
                        <input
                            v-model="flag_taxable" checked="" type="checkbox" name="flag_taxable" id="flag_taxable" class="custom-control-input"
                            true-value="y" false-value="n"
                            :class="{ 'is-danger': errors.has('collection.flag_taxable') }"
                            v-validate="'required'" data-vv-scope="collection"
                        >
                        <label class="custom-control-label" for="flag_taxable">{{flag_taxable}}</label>
                    </div>
                </div>
                <div class="col">
                    <label class="form-label" for="flag_deductible">Deductible</label><br>
                    <div class="custom-control custom-checkbox-toggle custom-control-inline mr-1">
                        <input
                            v-model="flag_deductible" checked="" type="checkbox" name="flag_deductible" id="flag_deductible" class="custom-control-input"
                            true-value="y" false-value="n"
                            :class="{ 'is-danger': errors.has('collection.flag_deductible') }"
                            v-validate="'required'" data-vv-scope="collection"
                        >
                        <label class="custom-control-label" for="flag_deductible">{{flag_deductible}}</label>
                    </div>
                </div>
                <div class="col">
                    <label class="form-label" for="flag_proportional">Proportional</label><br>
                    <div class="custom-control custom-checkbox-toggle custom-control-inline mr-1">
                        <input
                            v-model="flag_proportional" checked="" type="checkbox" name="flag_proportional" id="flag_proportional" class="custom-control-input"
                            true-value="y" false-value="n"
                            :class="{ 'is-danger': errors.has('collection.flag_proportional') }"
                            v-validate="'required'" data-vv-scope="collection"
                        >
                        <label class="custom-control-label" for="flag_proportional">{{flag_proportional}}</label>
                    </div>
                </div>
            </div>

            <div class="form-row form-group mt-4">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="my-1 btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="my-1 btn btn-info" @click="end_date = '2999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('wageForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            wage_type : null,
            wage_name : null,
            reference_table : null,
            tax_type : null,
            flag_taxable : "y",
            flag_deductible : 'y',
            flag_proportional : 'y',
            business_code : null,
            end_date : null,
            begin_date : null,
        }
    },
    created() {
        if(this.wage.detail) this.getData()

        this.$store.dispatch('company/getAll');
        this.getObject();
    },
    computed: {
        ...mapState(['wage','TAXTY','WGERF','company'])
    },
    methods: {
        getObject(){

            this.$store.dispatch('WGERF/getAll',{business_code:['*', this.business_code]});
            this.$store.dispatch('TAXTY/getAll',{business_code:['*', this.business_code]});

        },

        getData() {
            this.object_identifier = this.wage.detail.object_identifier

            this.wage_type = this.wage.detail.wage_type
            this.wage_name = this.wage.detail.wage_name
            this.business_code = this.wage.detail.business_code.business_code
            this.reference_table = this.wage.detail.reference_table
            this.tax_type = this.wage.detail.tax_type.id
            this.flag_taxable = this.wage.detail.flag_taxable
            this.flag_deductible = this.wage.detail.flag_deductible
            this.flag_proportional = this.wage.detail.flag_proportional
            this.end_date = this.wage.detail.end_date
            this.begin_date = this.wage.detail.begin_date
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('hcis/api/wage', {
                wage_type : this.wage_type ,
                wage_name : this.wage_name ,
                business_code : this.business_code ,
                reference_table : this.reference_table ,
                tax_type : this.tax_type ,
                flag_taxable : this.flag_taxable ,
                flag_deductible : this.flag_deductible ,
                flag_proportional : this.flag_proportional ,
                end_date : this.end_date ,
                begin_date : this.begin_date ,

            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('wageForm')
                this.$store.dispatch('wage/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('hcis/api/wage', {
                object_identifier: this.object_identifier,

                wage_type : this.wage_type ,
                wage_name : this.wage_name ,
                business_code : this.business_code ,
                reference_table : this.reference_table ,
                tax_type : this.tax_type ,
                flag_taxable : this.flag_taxable ,
                flag_deductible : this.flag_deductible ,
                flag_proportional : this.flag_proportional ,
                end_date : this.end_date ,
                begin_date : this.begin_date ,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('wageForm')
                this.$store.dispatch('wage/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null

            this.wage_type = null,
            this.wage_name = null,
            this.business_code = null,
            this.reference_table = null,
            this.tax_type = null,
            this.flag_taxable = null,
            this.flag_deductible = null,
            this.flag_proportional = null,
            this.end_date = null,
            this.begin_date = null,


            this.$validator.reset('collection')
        },


    },
}

</script>
