<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Mentoring </h4>
        </div>
        <div class='card-body p-4'>
            <div class="form-group">
                <label for="title">Title</label>
                <input
                    v-model="title" type="text" class="form-control" name="title" id="title" placeholder="Title ..."
                    :class="{ 'is-danger': errors.has('collection.title') }"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <p v-show="errors.has('collection.title')" class="help is-danger">{{ errors.first('collection.title') }}</p>
            </div>
            <div class="form-group">
                <label for="topic">Topic</label>
                <input
                    v-model="topic" type="text" class="form-control" name="topic" id="topic" placeholder="Topic ..."
                    :class="{ 'is-danger': errors.has('collection.topic') }"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <p v-show="errors.has('collection.topic')" class="help is-danger">{{ errors.first('collection.topic') }}</p>
            </div>
            <div class="form-group">
                <label for="description">Description</label>
                <input
                    v-model="description" type="text" class="form-control" name="description" id="description" placeholder="description ..."
                    :class="{ 'is-danger': errors.has('collection.description') }"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <p v-show="errors.has('collection.description')" class="help is-danger">{{ errors.first('collection.description') }}</p>
            </div>
            <div class="form-group">
                <label for="duration">Duration</label>
                <input
                    v-model="duration" type="number" class="form-control" name="duration" id="duration" placeholder="duration ..."
                    :class="{ 'is-danger': errors.has('collection.duration') }"
                    v-validate="'required'" data-vv-scope="collection"
                /> Minutes
                <p v-show="errors.has('collection.duration')" class="help is-danger">{{ errors.first('collection.duration') }}</p>
            </div>


            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Begin Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('mentoringForm')">Cancel</b-button>
            <!-- <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button> -->
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,
            
            title : null,
            topic : null,
            duration : null,
            description : null,            
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.mentoring.detail) this.getData()
    },
    computed: {
        ...mapState({
            mentoring : state => state.mentoring,
            session: state => state.session.detail,
        })
    },
    methods: {

        getData() {
            this.object_identifier = this.mentoring.detail.object_identifier
            this.title = this.mentoring.detail.title
            this.topic = this.mentoring.detail.topic
            this.reference = this.mentoring.detail.reference_mentoring
            this.begin_date = this.mentoring.detail.begin_date
            this.end_date = this.mentoring.detail.end_date
            this.business_code = this.mentoring.detail.business_code
            this.duration = this.mentoring.detail.duration            
            this.description = this.mentoring.detail.description
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/mentoring', {
                session : this.session.session_id,
                title : this.title,
                topic : this.topic,
                duration : this.duration,                
                description : this.description,
                reference_mentoring  : 0,
                business_code : this.session.business_code.business_code,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('mentoringForm')
                this.$store.dispatch('mentoring/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/mentoring', {
                object_identifier : this.object_identifier,
                session : this.session.session_id,
                title : this.title,
                topic : this.topic,
                duration : this.duration,                
                description : this.description,
                reference_mentoring  : this.reference,
                business_code : this.session.business_code.business_code,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('mentoringForm')
                this.$store.dispatch('mentoring/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.student_name = null
            this.mentoring_name = null
            this.begin_time = null
            this.end_time = null
            this.topic = null
            this.reference = null
            this.business_code = null
            this.begin_date = null
            this.end_date = null

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }

    },
}

</script>
