<template>
    <div class="">
        <div class="card-header bg-info">
            <h4> {{object_identifier ? 'Update' : 'Create'}} Schedule </h4>
        </div>
        <div class='card-body p-4'>

            <div class="form-group">
                <label for="schedule_name">Schedule Name</label>
                <input
                    v-model="schedule_name" type="text" class="form-control" name="schedule_name" id="schedule_name" placeholder="Schedule Name ..."
                    :class="{ 'is-danger': errors.has('collection.schedule_name') }"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <p v-show="errors.has('collection.schedule_name')" class="help is-danger">{{ errors.first('collection.schedule_name') }}</p>
            </div>

            <div class="form-group">
                <label for="day_number">Day</label>
                <input v-model.number="day_number" type="number" name="Title"
                    id="day_number" class="form-control" placeholder="Day 1..."
                    aria-describedby="day_number" v-bind:class="{ 'is-danger': errors.has('collection.day_number')}"
                    v-validate="'required'" data-vv-scope="collection">
                <p v-show="errors.has('collection.day_number')" class="help is-danger"> {{ errors.first('collection.day_number') }}</p>
            </div>

            <div class="form-group">
                <label for="schedule_date">Schedule Date</label>
                <div class="">
                    <flat-pickr
                        v-model="schedule_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                        placeholder="Select end date" name="schedule_date" id="schedule_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.schedule_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <!-- <button type="button" class="btn btn-info" @click="schedule_date = new Date() ">Today</button> -->
                    <p v-show="errors.has('collection.schedule_date')" class="help is-danger"> {{ errors.first('collection.schedule_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="topic">Topic</label>
                <input
                    v-model="topic" type="text" class="form-control" name="topic" id="topic" placeholder="Topic ..."
                    :class="{ 'is-danger': errors.has('collection.topic') }"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <p v-show="errors.has('collection.topic')" class="help is-danger">{{ errors.first('collection.topic') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_time">Start Time</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_time" :config="{enableTime: true, noCalendar: true, dateFormat: 'H:i', time_24hr: true}" class="form-control"
                                placeholder="Select start date" name="begin_time" id="begin_time"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_time')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <p v-show="errors.has('collection.begin_time')" class="help is-danger"> {{ errors.first('collection.begin_time') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_time" class="form-group">
                        <label for="end_time">End Time</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_time" :config="{enableTime: true, noCalendar: true, dateFormat: 'H:i', time_24hr: true, minDate: begin_time}" class="form-control"
                                placeholder="Select end date" name="end_time" id="end_time"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_time')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <p v-show="errors.has('collection.end_time')" class="help is-danger"> {{ errors.first('collection.end_time') }}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="col-6 ">
                    <div class="form-group">
                        <label for="begin_date">Begin Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr
                                v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                                placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                v-validate="'required'" data-vv-scope="collection"
                            />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('scheduleForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';

export default {
    data() {
        return {
            object_identifier : null,

            business_code : null,
            schedule_name : null,
            day_number : null,
            schedule_date : null,
            begin_time : null,
            end_time : null,
            topic : null,
            begin_date : null,
            end_date : null,
        }
    },
    created() {
        if(this.schedule.detail) this.getData()
    },
    computed: {
        ...mapState({
            schedule : state => state.schedule,
            session: state => state.session.detail,
        })
    },
    methods: {

        getData() {
            this.object_identifier = this.schedule.detail.object_identifier
            this.schedule_name = this.schedule.detail.schedule_name
            this.day_number = this.schedule.detail.day_number
            this.schedule_date = this.schedule.detail.schedule_date
            this.reference = this.schedule.detail.reference.schedule_id || 0
            this.begin_date = this.schedule.detail.begin_date
            this.end_date = this.schedule.detail.end_date
            this.business_code = this.schedule.detail.business_code.business_code
            this.begin_time = this.schedule.detail.begin_time
            this.end_time = this.schedule.detail.end_time
            this.topic = this.schedule.detail.topic
        },

        async storeData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/schedule', {
                session : this.session.session_id,
                schedule_name : this.schedule_name,
                day_number : this.day_number,
                schedule_date : this.schedule_date,
                begin_time : this.begin_time,
                end_time : this.end_time,
                topic : this.topic,
                reference  : 0,
                business_code : this.session.business_code.business_code,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('scheduleForm')
                this.$store.dispatch('schedule/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.put('lms/api/schedule', {
                object_identifier : this.object_identifier,
                session : this.session.session_id,
                schedule_name : this.schedule_name,
                day_number : this.day_number,
                schedule_date : this.schedule_date,
                begin_time : this.begin_time,
                end_time : this.end_time,
                topic : this.topic,
                reference  : this.reference,
                business_code : this.session.business_code.business_code,
                begin_date : this.begin_date,
                end_date : this.end_date,
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('scheduleForm')
                this.$store.dispatch('schedule/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.object_identifier = null
            this.schedule_name = null
            this.begin_time = null
            this.end_time = null
            this.topic = null
            this.reference = null
            this.business_code = null
            this.begin_date = null
            this.end_date = null
            this.day_number = null
            this.schedule_date = null

            this.$validator.reset('collection')
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }

    },
}

</script>
