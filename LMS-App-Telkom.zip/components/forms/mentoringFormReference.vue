<template>
    <div class="">
            <div class="card">
                <div class="">
                    <table class="table table-responsive table-flush table-hover">
                        <thead class="">
                            <tr>
                                <th>No</th>                                
                                <th>Title</th>
                                <th>Topic</th>
                                <th>Description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in mentoringReferenceList" :key="index">
                                <td> {{ index+1 }} </td>
                                <td> {{ item.title }}</td>
                                <td> {{ item.topic }} </td>
                                <td> {{ item.description }} </td>
                                <td>
                                    <button type="button" class="btn btn-success btn-sm" @click="submit(item)">
                                        + Add
                                    </button>
                                </td>
                            </tr>
                            <tr v-if="mentoring.isLoadingR">
                                <td colspan="10">
                                    <div class="row">
                                        <div class="col d-flex justify-content-center">
                                            <div class="loader loader-accent text-center"></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <paginationBarR :state='mentoring' :storeModuleName="'mentoring'" />
                </div>
            </div>

    </div>

</template>

<script>
import moment from 'moment'
import { mapState } from 'vuex';
import paginationBarR from '@@/components/paginationBarR'

export default {
    components : { paginationBarR },
    created() {        
        this.$store.dispatch('mentoring/getReference');
        
    },
    data() {
        return {
            type : this.$route.query.type
        }
    },
    computed: {
        ...mapState({
            currentEvent : state => state.event.detail,
            session : state => state.session.detail,
            mentoring : state => state.mentoring,
        }),
        mentoringReferenceList(){
            //console.log(this.mentoring)
            return this.mentoring.listReference.filter((mentoringRef, index) => {
                return this.mentoring.list.find(mentoring => mentoring.reference_mentoring.mentoring_id == mentoringRef.mentoring_id ) === undefined
            })
        }
    },
    methods: {
        submit(plannedMentoring){
            this.$axios.post('lms/api/mentoring', {
                business_code : this.currentEvent.business_code.business_code,
                session : this.session.session_id,
                title : plannedMentoring.title,
                topic : plannedMentoring.topic,
                description : plannedMentoring.description,
                duration : plannedMentoring.duration,
                reference_mentoring  : plannedMentoring.mentoring_id,
                begin_date : plannedMentoring.begin_date,
                end_date : plannedMentoring.end_date,
            })
            .then(() => {
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.$store.dispatch('mentoring/getAll',{'type':this.type});
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }


    },
}

</script>
