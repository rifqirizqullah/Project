<template>
    <div class>
        <div class="card-header bg-info">
            <h4>{{object_identifier ? 'Update' : 'Create'}} Trainer Communication</h4>
        </div>
        <div class="card-body p-4">
            <div class="form-group">
                <label for="company">Company</label>
                <input v-model="business_code" type="text" name="company" id="company" class="form-control"
                    :placeholder="trainer.business_code.company_name" aria-describedby="company"
                    v-bind:class="{ 'is-danger': errors.has('collection.company')}" v-validate="'required'"
                    data-vv-scope="collection" disabled />
                <p v-show="errors.has('collection.company')" class="help is-danger">
                    {{ errors.first('collection.company') }}</p>
            </div>

            <div class="form-group">
                <label for="communication_type">Communication Type</label>
                <select v-model="communication_type" class="form-control" name="communication_type"
                    id="communication_type" v-bind:class="{ 'is-danger': errors.has('collection.communication_type') }"
                    v-validate="'required'" data-vv-scope="collection">
                    <option v-for="(item, index) in COMTY.list" :key="index" :value="item.id">{{item.value}}
                    </option>
                </select>
                <p v-show="errors.has('collection.communication_type')" class="help is-danger">
                    {{ errors.first('collection.communication_type') }}</p>
            </div>

            <div class="form-group">
                <label for="communication_text">Communication Text</label>
                <input v-model="communication_text" type="text" name="communication_text" id="communication_text"
                    class="form-control" placeholder="Communication Text" aria-describedby="communication_text"
                    v-bind:class="{ 'is-danger': errors.has('collection.communication_text')}" v-validate="'required'"
                    data-vv-scope="collection" />
                <p v-show="errors.has('collection.communication_text')" class="help is-danger">
                    {{ errors.first('collection.communication_text') }}</p>
            </div>

            <div class="form-row">
                <div class="col-6">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                placeholder="Select start date" name="begin_date" id="begin_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                v-validate="'required'" data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                            <p v-show="errors.has('collection.begin_date')" class="help is-danger">
                                {{ errors.first('collection.begin_date') }}</p>
                        </div>
                    </div>
                </div>
                <div class="col-6">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <div class="form-inline">
                            <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                                data-vv-scope="collection" />
                            <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                            <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                {{ errors.first('collection.end_date') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-footer text-right">
            <b-button variant="secondary" @click="$bvModal.hide('trainerCommunicationForm')">Cancel</b-button>
            <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
            <b-button v-if="!object_identifier" variant="success" @click="storeData">Save</b-button>
            <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
        </div>
    </div>
</template>

<script>
    import {
        mapState
    } from "vuex";

    export default {
        data() {
            return {
                object_identifier: null,
                business_code: null,
                begin_date: null,
                end_date: null,
                trainer_id: null,
                communication_type: null,
                communication_text: ""
            };
        },
        created() {
            if (this.trainerCommunication.detail) this.getData();
            this.$store.dispatch("company/getAll");
            this.$store.dispatch("COMTY/getAll", {
                'business_code': ['*', this.trainer.business_code.business_code]
            });
        },
        computed: {
            ...mapState({
                trainer: state => state.trainer.detail,
                trainerCommunication: state => state.trainerCommunication,
                company: state => state.company,
                COMTY: state => state.COMTY,
            })
        },
        methods: {
            getData() {
                this.object_identifier = this.trainerCommunication.detail.object_identifier;
                this.business_code = this.trainerCommunication.detail.business_code.company_name;
                this.begin_date = this.trainerCommunication.detail.begin_date;
                this.end_date = this.trainerCommunication.detail.end_date;
                this.trainer_id = this.trainerCommunication.detail.trainer.trainer_id;
                this.communication_type = this.trainerCommunication.detail.communication_type.id;
                this.communication_text = this.trainerCommunication.detail.communication_text;
            },

            async storeData() {
                let isValid = await this.$validator.validateAll("collection");
                if (!isValid) return false;
                this.$axios
                    .post("lms/api/trainercommunication", {
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.trainer.business_code.business_code,
                        trainer: this.trainer.trainer_id,
                        communication_type: this.communication_type,
                        communication_text: this.communication_text
                    })
                    .then(() => {
                        this.$swal("Saved!", "Successfully saved data.", "success");
                        this.resetForm();
                        this.$bvModal.hide("trainerCommunicationForm");
                        this.$store.dispatch("trainerCommunication/getAll");
                    })
                    .catch(err => {
                        console.log(err.response);
                    });
            },

            async updateData() {
                let isValid = await this.$validator.validateAll("collection");
                if (!isValid) return false;
                this.$axios
                    .put("lms/api/trainercommunication", {
                        object_identifier: this.object_identifier,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        business_code: this.trainer.business_code.business_code,
                        trainer: this.trainer.trainer_id,
                        communication_type: this.communication_type,
                        communication_text: this.communication_text
                    })
                    .then(() => {
                        this.$swal("Updated!", "Successfully update data.", "success");
                        this.resetForm();
                        this.$bvModal.hide("trainerCommunicationForm");
                        this.$store.dispatch("trainerCommunication/getAll");
                    })
                    .catch(err => {
                        console.log(err.response);
                    });
            },

            resetForm() {
                this.object_identifier = this.trainerCommunication.detail.object_identifier;
                this.business_code = this.trainerCommunication.detail.business_code.company_name;
                this.begin_date = this.trainerCommunication.detail.begin_date;
                this.end_date = this.trainerCommunication.detail.end_date;
                this.trainer_id = this.trainerCommunication.detail.trainer.trainer_id;
                this.communication_type = this.trainerCommunication.detail.communication_type.id;
                this.communication_text = this.trainerCommunication.detail.communication_text;

                this.$validator.reset("collection");
            }
        }
    };

</script>
