<template>
    <div class="modal fade" id="courses" tabindex="-1" role="dialog">
        <div class="modal-dialog" style="margin-left:0 ; max-width:350px" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col bg-body pr-0">
                            <div class=" menu">
                                <ul class="nav flex-column">
                                    <li v-for="(layar, index) in layars" :key="index" class="nav-item">
                                        <nuxt-link class="nav-link" data-dismiss='modal' :to="layar.link" >{{index+1}} - {{layar.label}}</nuxt-link>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                    <button type="button" class="close" data-dismiss="modal">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
  data() {
    return {

        layars : [
            {link : '/',  label : 'Landing'},
            {link : '/login',  label : 'Login'},
            {link : '/organization-strategy',  label : 'Manage Organization Strategy'},
            {link : '/organization-strategy/add',  label : 'Create Organization Strategy'},
            {link : '/learning-plan',  label : 'Learning Plan'},
            {link : '/learning-plan/add',  label : 'Add Learning Plan'},
            {link : '/learning-plan/participant',  label : 'Manage Participant'},
            {link : '/learning-plan/participant/add',  label : 'Add Participant'},
            {link : '/learning-plan/budget',  label : 'Manage Budget'},
            {link : '/learning-plan/budget/add',  label : 'Add Budget (pop up)'},
            {link : '/curriculum',  label : 'Curriculum Management'},
            {link : '/curriculum/add',  label : 'Create Curriculum'},
            {link : '/learning-activity',  label : 'Manage Learning Activity'},
            {link : '/curriculum/add',  label : 'POP UP Choose Learning Activity'},
            {link : '/learning-activity/add',  label : 'Add Learning Activity'},
            {link : '/learning-activity/set-add-material',  label : 'Add Learning Activity Set (Material)'},
            {link : '/learning-activity/set-add-quiz',  label : 'Add Learning Activity Set (Quiz)'},
            {link : '/learning-activity/set-add-quiz',  label : 'POP UP Choose Question'},
            {link : '/',  label : 'Add Learning Activity Set (Assignment)'},
            {link : '/learning-activity/set-add-feedback',  label : 'Add Learning Activity Set (Feedback)'},
            {link : '/',  label : 'POP UP Choose Feedback '},
            {link : '/learning-activity/set-add-schedule',  label : 'Add Learning Activity Set (Schedule)'},
            {link : '/event',  label : 'Event Management (Event List)'},
            {link : '/event/event-plan',  label : 'Event Management (Plan List)'},
            {link : '/event/event-plan-add',  label : 'Add New Event'},
            {link : '/event/event-plan-add',  label : 'Pop Up Create new planned'},
            {link : '/learning-plan/event/add-c1',  label : 'Cycle 1 event'},
            {link : '/learning-plan/event/add-c2',  label : 'Cycle 2 event'},
            {link : '/learning-plan/event/add-c3',  label : 'Cycle 3 event'},
            {link : '/learning-plan/event/add-c4',  label : 'Cycle 4 event dan Pop up search Person'},
            {link : '/',  label : 'Cycle 5 Event dan Pop Up search Person'},
            {link : '/learning-plan/event/add-c6',  label : 'Cycle 6 Event dan Pop UP search Person'},
            {link : '/learning-plan/event/add-c3-classroom',  label : 'Learning Plan add Classroom'},
            {link : '/learning-plan/budget',  label : 'Learning Plan Manage Budget dan Pop up Add budget'},
            {link : '/learning-plan/budget/add',  label : 'Learning Plan add Expert'},
            {link : '/expert-assignment/',  label : '3. Manage Assign Expert'},
            {link : '/expert-assignment/edit',  label : '3. Update Assign Expert'},
            {link : '/learning-plan/event/add-c3-work',  label : 'Learning Plan add Work'},
            {link : '/learning-plan/event/add-c3-delivery',  label : 'Learning Plan add Delivery dan Pop Up'},
            {link : '/learning-activity/add-feedback-supervisor',  label : 'Feedback Supervisor'},
            {link : '/',  label : 'Even List (Peserta)'},
            {link : '/',  label : 'Insight List/artikel'},
            {link : '/student/learning-activity/cycle-1',  label : 'Cycle 1 Peserta'},
            {link : '/student/learning-activity/cycle-2',  label : 'Cycle 2 Peserta'},
            {link : '/student/learning-activity/cycle-3',  label : 'Cycle 3 Peserta'},
            {link : '/student/learning-activity/cycle-4',  label : 'Cycle 4 Peserta'},
            {link : '/student/learning-activity/cycle-5',  label : 'Cycle 5 Peserta'},
            {link : '/student/learning-activity/cycle-6',  label : 'Cycle 6 Peserta'},
            {link : '/',  label : 'Feedback Penyelenggara'},
            {link : '/',  label : 'Feedback Materi'},
            {link : '/',  label : 'Feedback Trainer'},
            {link : '/',  label : 'Quiz'},
            {link : '/',  label : 'Layar Mentor'},

        ],

    }
  },

}
</script>

<style scoped>

</style>
