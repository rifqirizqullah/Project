<template>
    <div v-if="session" class="">
        <div class="card mt-2">
            <div class="">
                <div class="card-header bg-primary ">
                    <h3 class="card-title text-light">{{session.session_name}}</h3>
                </div>
                <div class="card-body">
                    <div class="row" v-if="event.event_type.id == '01'">
                        <div class="col-lg-2">
                            <small>Learning Activity</small>
                            <p> {{session.learning_activity && session.learning_activity.activity_name}}</p>
                        </div>
                        <div class="col-lg-2">
                            <small>Cycle</small>
                            <p>{{session.learning_activity && session.learning_activity.cycle.value}}</p>
                        </div>
                        <div class="col-lg-2">
                            <small>Type</small>
                            <p>{{session.learning_activity && session.learning_activity.activity_type.value}}</p>
                        </div>
                        <div v-if="session.learning_activity" class="col-lg-2">
                            <small>Flag Online</small>
                            <p v-if="session.learning_activity.flag_online === true">Online</p>
                            <p v-else>Offline</p>
                        </div>
                        <div class="col-lg-3">
                            <small>Begin/End Date</small>
                            <p>{{formatDate(session.begin_date)}} - {{formatDate(session.end_date)}}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'

export default {
    data() {
        return {
            type : this.$route.query.type
        }
    },
    computed: {
        session(){
            return this.$store.state.session.detail
        },
        event(){
            if (this.type == 'event') {
                return this.$store.state.event.detail
            } else {
                return this.$store.state.eventPlan.detail
            }
        },
    },
    methods: {
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>

<style>

</style>
