<template>
        <div class="border-bottom-white py-32pt" style="background-image: url(/img/bg-05.jpg);" >

            <div class="container d-flex flex-column flex-md-row align-items-center text-center text-md-left">
                <!-- <img src="assets/images/illustration/student/128/white.svg" width="104" class="mr-md-32pt mb-32pt mb-md-0" alt="student"> -->
                <div class="avatar-xxl">
                    <span class="avatar-title h1 bg-white text-info shadow rounded-circle">
                        {{headerTitle ? headerTitle.slice(0,2).toUpperCase() : ''}}
                    </span>
                </div>
                <div class="flex mb-32pt mb-md-0">
                    <h1 class="text-white ml-16pt"> {{headerTitle}} </h1>
                    <span class="text-white ml-16pt d-flex align-items-center">
                        {{headerDescription}}
                    </span>
                    <span class="text-white ml-16pt d-flex align-items-center">
                        {{headerSubDescription}}
                    </span>
                </div>
            </div>

        </div>
</template>

<script>
export default {
    props : ['headerTitle', 'headerDescription', 'headerSubDescription']

}
</script>

<style>

</style>
