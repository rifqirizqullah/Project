<template>
    <div class="card mb-0">
        <img src="~static/img/bg-City.png" alt="bg_city" class="card-img" style="min-height: 250px; width: initial;">
        <div class="fullbleed bg-primary" style="opacity: .5;"></div>
        <div class="d-flex align-items-center justify-content-center fullbleed">
            <div v-if="event" class="m-3">
                <h1 class="text-white h1 mb-16pt mt-1 text-center">{{event.event_name}}</h1>
                <p class="flex text-white-70 text-center mb-4">{{event.event_id}} {{event.description}}</p>
                <div class="d-flex align-items-center mb-16pt justify-content-center">
                    <div class="d-flex align-items-center mr-16pt">
                        <span class="material-icons icon-16pt text-success mx-4pt">access_time</span>
                        <p class="flex text-white-50 lh-1 mb-0">{{formatDate(event.begin_date)}}</p>
                    </div>
                    <div class="d-flex align-items-center mr-16pt">
                        <span class="material-icons icon-16pt text-danger mx-4pt">access_time</span>
                        <p class="flex text-white-50 lh-1 mb-0">{{formatDate(event.end_date)}}</p>
                    </div>
                </div>
                <div class="d-flex align-items-center justify-content-center">
                    <h3 class="text-white">{{event.event_type.value}} Event</h3>
                </div>
                <div class="d-flex align-items-center mt-3 mb-16pt justify-content-center">
                    <div class="d-flex align-items-center">
                        <p class="flex text-white lh-1 mb-0">
                            {{event.business_code.company_name}} - {{event.organization.organization_name}}
                        </p>
                    </div>
                </div>
            </div>
            <div v-else>
                <div class="row">
                    <div class="col d-flex justify-content-center">
                        <div class="loader loader-accent text-center"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'
export default {
    data() {
        return {
            type : this.$route.query.type
        }
    },
    computed: {
        event(){
            if (this.type == 'event') {
                return this.$store.state.event.detail
            } else {
                return this.$store.state.eventPlan.detail
            }
        },
    },
    methods: {
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>

<style>

</style>
