<template>
    <section>
        <div class="bg-white border-top-2">
            <!-- <div class="container page-section py-lg-48pt">
                <div class="row">
                    <div class="col-md-8">
                        <div class="row">
                            <div class="col-6 col-md-4 mb-24pt mb-md-0">
                                <h4 class="text-70">Learn</h4>
                                <nav class="nav nav-links nav--flush flex-column">
                                    <a class="nav-link" href="#">Library</a>
                                    <a class="nav-link" href="#">Featured</a>
                                    <a class="nav-link" href="#">Explore</a>
                                    <a class="nav-link" href="#">Learning Paths</a>
                                </nav>
                            </div>
                            <div class="col-6 col-md-4 mb-24pt mb-md-0">
                                <h4 class="text-70">Join us</h4>
                                <nav class="nav nav-links nav--flush flex-column">
                                    <a class="nav-link" href="#">Pricing</a>
                                    <a class="nav-link" href="#">Login</a>
                                    <a class="nav-link" href="#">Sign Up</a>
                                    <a class="nav-link" href="#">Payment</a>
                                </nav>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-4 text-md-right">
                        <p class="text-70 brand justify-content-md-end my-2">
                            <img class="brand-icon" src="/img/Corpu.png" width="30" alt="Corpu"> Corpu
                        </p>
                        <p class="text-muted mb-0 mb-lg-16pt">Corpu is an online learning platform that helps anyone achieve their personal and professional goals.</p>
                    </div>
                </div>
            </div> -->
            <div class="bg-footer page-section py-3">
                <div class="container">
                    <div class="row">
                        <div class="col text-center">
                            <p class="text-white-50 mb-0" style="margin-bottom:10px">Copyright 2019 © All rights reserved.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {

}
</script>

<style>

</style>
