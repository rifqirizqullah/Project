import pkg from './package'
require('dotenv').config()
// import $ from 'jquery'

export default {
  mode: 'spa',

  /*
  ** Headers of the page
  */
 auth: {
    strategies: {
      local: {
        endpoints: {
          login: { url: 'ldap/api/auth/login', method: 'post', propertyName: 'access_token' },
          user: { url: 'ldap/api/auth/account', method: 'get', propertyName: 'data'},
          logout: false
        }
      }
    }
  },
  head: {
    title: pkg.name,
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: pkg.description }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
    ],
    script: [
      { src : 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'}
    ]

  },

  /*
  ** Customize the progress-bar color
  */
  loading: { color: '#fff' },

  /*
  ** Global CSS
  */
  css: [
    '@/assets/css/add.css',
    '@/assets/css/app.css',
    '@/assets/css/animate.css',
    '@/assets/css/bootstrap-touchspin.css',
    '@/assets/css/flatpickr.css',
    '@/assets/css/flatpickr-airbnb.css',
    '@/assets/css/fontawesome.css',
    '@/assets/css/input-spinner.css',
    '@/assets/css/main.css',
    '@/assets/css/material-icons.css',
    '@/assets/css/quill.css',
    '@/assets/css/select2.css',
    '@/assets/css/slider-input.css',
    '@/assets/css/tab.css',
    '@/assets/css/tabs.css',
    '@/assets/css/theme.css',
    '@/assets/css/tree-view.css',
    '@/assets/css/util.css',
    '@/assets/css/prettyJSON.css',
  ],

  /*
  ** Plugins to load before mounting the App
  */
  plugins: [
    '~plugins/bootstrap.js',
    '~plugins/flatpickr.js',
    '~/plugins/axios.js',
    '~/plugins/sweetalert.js',
    '~/plugins/vee-validate.js',
  ],

  /*
  ** Nuxt.js modules
  */
  modules: [
    // Doc: https://axios.nuxtjs.org/usage
    '@nuxtjs/axios',
    // Doc: https://bootstrap-vue.js.org/docs/
    'bootstrap-vue/nuxt',
    '@nuxtjs/pwa',
    '@nuxtjs/auth',
    '@nuxtjs/dotenv',
    'vue-sweetalert2/nuxt',

  ],
  /*
  ** Axios module configuration
  */
  axios: {
    // See https://github.com/nuxt-community/axios-module#options
    baseURL: process.env.API_BASE_URL
  },

  /*
  ** Environtment Variable
  */
  // env: {
  //   API_LDAP_URL : 'https://ldapmain.digitalevent.id',
  //   API_TMS_URL : 'https://tmsmain.digitalevent.id',
  //   API_HCIS_URL : 'https://hcismain.digitalevent.id',
  //   API_LMS_URL : 'https://lmsmain.digitalevent.id'
  // },

  /*
  ** Build configuration
  */
  build: {
    /*
    ** You can extend webpack config here
    */

    extend(config, ctx) {

    },
    server: {
      host: process.env.APP_URL,
      port: process.env.PORT
    },
  }
}
