<template>
    <div class="mdk-header-layout__content page-content">

         <div class="mdk-box" style="background-image: url(/img/bg-05.jpg);">

                <div class="mdk-box__content">
                    <div class="container page__container py-64pt py-md-112pt">
                        <div class="row align-items-center text-center text-md-left">
                            <div class="col-md-6 col-lg-5 order-1 order-md-0" >
                               <div class="col-md-12">
                                <h1 class="text-white">Learning Management <span class="text-scramble js-text-scramble">System</span></h1>
                                <br>
                                <p class="lead mb-48pt text-white">An Application to manage all competency development activities of Telkom Group's Employee</p>
                                <!-- <a href="library.html" class="btn btn-lg btn-white btn--raised mb-16pt">Browse Menu</a> -->


                               </div>
                            </div>
                            <div class="col-md-6 col-lg-7 order-0 order-md-1 text-center mb-32pt mb-md-0">
                                <img src="/img/macbook.png" alt="macbook" class="home-macbook" style="height:100%;width:60%">
                            </div>
                        </div>
                    </div>
                    <!-- <div class="hero container text-center py-112pt">
      <h1 class="text-white">Learn to Code</h1>
      <p class="lead measure-hero-lead mx-auto mb-48pt text-white">Business, Technology and Creative Skills taught by industry experts. Explore a wide range of skills with our professional tutorials.</p>
      <a href="library.html" class="btn btn-lg btn-outline-white">Browse Courses</a>
    </div> -->
                </div>
            </div>

        <div class="container">
           <br>
            <div class="row">
                <!-- Strategy -->
                <div class="adminlms col-xs-12 col-sm-6 col-md-3 d-none"
                    style="cursor : pointer;" @click="$router.push('/learning-strategy')" >
                    <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/strategy.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Learning Strategy</h4>
                                        <p class="card-text">This is basic card with image on top, title,
                                            description and button.</p>
                                            <br>
                                       <nuxt-link to="/learning-strategy" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></nuxt-link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Curriculumn -->
                <div class="adminlms col-xs-12 col-sm-6 col-md-3 d-none"
                    style="cursor : pointer;" @click="$router.push('/curriculum')">
                <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/curriculum.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Curriculum</h4>
                                        <p class="card-text">This is basic card with image on top, title,
                                            description and button.</p>
                                            <br>
                                        <nuxt-link to="/curriculum" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></nuxt-link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Activity -->
                <div class="adminlms col-xs-12 col-sm-6 col-md-3 d-none"  style="cursor : pointer;" @click="$router.push('/learning-activity')">
                    <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/activity.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Learning Activity</h4>
                                        <p class="card-text">This is basic card with image on top, title,
                                            description and button.</p>
                                            <br>
                                          <nuxt-link to="/learning-activity" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></nuxt-link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Event -->
                <div class="adminlms col-xs-12 col-sm-6 col-md-3 d-none"
                    style="cursor : pointer;" @click="$router.push('/event/event')">
                    <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/event.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Event</h4>
                                        <p class="card-text">This is basic card with image on top, title,
                                            description and button.</p>
                                            <br>
                                        <nuxt-link to="/event" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></nuxt-link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Resource -->
                <div class="adminlms col-xs-12 col-sm-6 col-md-3 d-none"
                    style="cursor : pointer;" @click="$router.push('/resource')">
                    <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/target.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Manage Parameters</h4>
                                        <p class="card-text">This is basic card with image on top, title,
                                            description and button.</p>
                                            <br>
                                        <nuxt-link to="/resource" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></nuxt-link>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Peserta -->
                <div class="adminlms participant col-xs-12 col-sm-6 col-md-3 d-none" style="cursor : pointer;" @click="$router.push('/peserta')">
                    <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/plan.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Student</h4>
                                        <p class="card-text">This is basic card with image on top, title,
                                            description and button.</p>
                                            <br>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- Peserta -->
                <div class="adminlms admexpert expert col-xs-12 col-sm-6 col-md-3 d-none"
                    style="cursor : pointer;" @click="$router.push('/expert')">
                    <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/activity.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Expert</h4>
                                        <p class="card-text">
                                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum, nulla?
                                        </p>
                                            <br>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="adminlms admexpert col-xs-12 col-sm-6 col-md-3 d-none"
                    style="cursor : pointer;" @click="$router.push('/admin-trainer')">
                    <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/manager.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Admin Expert</h4>
                                        <p class="card-text">
                                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum, nulla?
                                        </p>
                                            <br>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

            <!-- Peserta -->
                <div class="adminlms mentor col-xs-12 col-sm-6 col-md-3 d-none" style="cursor : pointer;" @click="$router.push('/mentor')">
                    <div >
                        <div class="mainflip">
                            <div class="frontside">
                                <div class="card">
                                    <div class="card-body text-center">
                                        <p><img class=" img-fluid" style="height:100px;width:100px"
                                                src="/img/network.png"
                                                alt="card image"></p>
                                        <br>
                                        <h4 class="card-title">Mentor</h4>
                                        <p class="card-text">
                                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nostrum, nulla?
                                        </p>
                                            <br>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
</template>

<script>
    import backgroundUrl from 'static/img/HC.png'
    export default {
        layout: 'home',
        data() {
            return {
                backgroundUrl
            }
        },
        methods: {
			
			callmenu() {
                   
				     this.$axios.get('lms/api/getrole', {
                        // object_identifier: this.schedule_trainer.detail.object_identifier,
                        //otype_parent : "SCHDL",
                        
                    }) 					
                    .then(response => {
						var  list = new Array();
							for (const item of response.data.data) {
							  list.push(item.rolecode)
							}
						let unique = [...new Set(list)];
							for (const vv of unique) {
								for(var i = 0 ; i <= vv.length; i++){
									document.querySelectorAll('.'+vv.toLowerCase())[i].classList.remove('d-none')
								}
							
								}
                      }).catch(e => {
                                console.log(e);
                      });
				   
				   
					}
         },
		mounted: function () {
			this.callmenu();
			 //console.log(storage); 
		},
    }

</script>

<style scoped>
    .card {
        transition: .2s !important;
    }

    .card:hover {
        box-shadow: 0 .4rem .8rem rgba(0, 0, 0, .15) !important;
    }

    .navigation {
        display: flex;
    }

    .col {
        width: 33%;
    }

    .navigation {
        flex-wrap: wrap;
    }

    .h64 .w64 {
        height: 64px !important;
        width: 64px !important;
    }

    @media all and (max-width: 1310px) {
        .col {
            width: 50%;
        }
    }

    @media all and (max-width: 1000px) {
        .col {
            width: 100%;
        }
    }

    #team {
        background: #eee !important;
    }

    .btn-primary:hover,
    .btn-primary:focus {
        background-color: #17A2B8;
        border-color: #17A2B8;
        box-shadow: none;
        outline: none;
    }

    .btn-primary {
        color: #fff;
        background-color: #17A2B8;
        border-color: #17A2B8;
    }

    section .section-title {
        text-align: center;
        color:#17A2B8;
        margin-bottom: 50px;
        text-transform: uppercase;
    }

    #team .card {
        border: none;
        background: #ffffff;
    }

    .image-flip:hover .backside,
    .image-flip.hover .backside {
        -webkit-transform: rotateY(0deg);
        -moz-transform: rotateY(0deg);
        -o-transform: rotateY(0deg);
        -ms-transform: rotateY(0deg);
        transform: rotateY(0deg);
        border-radius: .25rem;
    }

    .image-flip:hover .frontside,
    .image-flip.hover .frontside {
        -webkit-transform: rotateY(180deg);
        -moz-transform: rotateY(180deg);
        -o-transform: rotateY(180deg);
        transform: rotateY(180deg);
    }

    .mainflip {
        -webkit-transition: 1s;
        -webkit-transform-style: preserve-3d;
        -ms-transition: 1s;
        -moz-transition: 1s;
        /* -moz-transform: perspective(1000px); */
        -moz-transform-style: preserve-3d;
        -ms-transform-style: preserve-3d;
        transition: 1s;
        transform-style: preserve-3d;
        position: relative;
    }

    .frontside {
        position: relative;
        /* -webkit-transform: rotateY(0deg);
        -ms-transform: rotateY(0deg); */
        z-index: 2;
        margin-bottom: 30px;
    }

    .backside {
        position: absolute;
        top: 0;
        left: 0;
        -webkit-transform: rotateY(-180deg);
        -moz-transform: rotateY(-180deg);
        -o-transform: rotateY(-180deg);
        -ms-transform: rotateY(-180deg);
        transform: rotateY(-180deg);
        /* -webkit-box-shadow: 5px 7px 9px -4px rgb(158, 158, 158);*/
        /* -moz-box-shadow: 5px 7px 9px -4px rgb(158, 158, 158); */
        /* box-shadow: 5px 7px 9px -4px rgb(158, 158, 158); */
    }

    .frontside,
    .backside {
        -webkit-backface-visibility: hidden;
        -moz-backface-visibility: hidden;
        -ms-backface-visibility: hidden;
        backface-visibility: hidden;
        -webkit-transition: 1s;
        -webkit-transform-style: preserve-3d;
        -moz-transition: 1s;
        -moz-transform-style: preserve-3d;
        -o-transition: 1s;
        -o-transform-style: preserve-3d;
        -ms-transition: 1s;
        -ms-transform-style: preserve-3d;
        transition: 1s;
        transform-style: preserve-3d;
    }

    .frontside .card,
    .backside .card {
        min-height: 312px;
    }

    .backside .card a {
        font-size: 18px;
        color: #17A2B8!important;
    }

    .frontside .card .card-title,
    .backside .card .card-title {
        color: #17A2B8 !important;
    }

    .frontside .card .card-body img {
        width: 120px;
        height: 120px;
        border-radius: 50%;
    }

</style>