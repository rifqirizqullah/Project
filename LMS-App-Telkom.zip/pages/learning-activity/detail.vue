<template>
    <div class="container page-section">

        <h1 class="display-4">Learning Activity Detail</h1>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{learningActivity.detail.activity_name}}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Company</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningActivity.detail.business_code.company_name }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Cycle</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningActivity.detail.cycle.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Begin/End Date</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>{{formatDate(learningActivity.detail.begin_date)}} - {{formatDate(learningActivity.detail.end_date)}}</p>
                            </div>
                        </div>
                    </div> 
                    
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Activity Type</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningActivity.detail.activity_type.value}}</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Status</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p v-if="learningActivity.detail.flag_online == true" class="text-success">Online</p>
                                 <p v-else class="text-accent">Offline</p>
                            </div>
                        </div>
                    </div>

                    
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <span>
                    <h4 class="card-title">Competence Activity</h4>
                    <p class="card-subtitle">List of Competence Activity</p>
                </span>
                <span>
                    <button @click="clearDetail(); $bvModal.show('competenceActivityForm')" class="btn btn-success btn-sm">+ Add Competence Activity</button>                    
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                        <i class="fa fa-search"></i> Search
                    </b-button>
                </span>
            </div>            
        </div>    

        <div class>
     <div class>
         <div class>
          <div class="text-right">
            <div class="bg-white">
              <b-collapse id="collapse-a" class="mt-2">
                <form class="p-2">
                  <div class="row">
                    
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select
                          v-model="filters.plcode"
                          class="form-control"
                          name="plcode"
                          id="plcode"
                        >
                          <option
                            v-for="(item, index) in PLCOD.list"
                            :key="index"
                            :value="item.id"
                          >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Procifiency Level</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select
                          v-model="filters.competence"
                          class="form-control"
                          name="competence"
                          id="competence"
                        >
                          <option
                            v-for="(item, index) in CMPTY.list"
                            :key="index"
                            :value="item.id"
                          >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Competence</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select start date" name="begin_date" id="begin_date"
                        />
                        <small class="form-text text-muted">Begin Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select end date" name="end_date" id="end_date"
                        />
                        <small class="form-text text-muted">End Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group text-right">
                        <b-button
                          @click="filters = {}; runFilter()"
                          variant="secondary"
                        >Clear Filter</b-button>

                        <b-button @click="runFilter" variant="info">
                          <span class="btn-label">
                            <i class="fa fa-search"></i> Filter
                          </span>
                        </b-button>
                      </div>
                    </div>
                  </div>
                </form>
              </b-collapse>
            </div>
          </div>
        </div>
         <div class="card">
            <table class="table table-responsive table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Procifiency Level</th> 
                        <th>Competence</th>
                        <th>Begin Date</th>
                        <th>End Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in competence_activity.list" :key="index">
                        <td> {{index+1}} </td>
                        <td>
                            {{ item.object1.value }}
                        </td>
                        <td>{{ item.object2.value }}</td>
                        <td>{{ formatDate(item.begin_date) }}</td>
                        <td>{{ formatDate(item.end_date) }}</td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>                                    
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="competence_activity.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>
            <div class="card-footer">
                <paginationBar :state='competence_activity' :storeModuleName="'competence_activity'" />
            </div>
         </div>
       </div>
     </div>   
        <b-modal v-model="modalShow" ref="competenceActivityForm" @hide="clearDetail" hide-footer hide-header id="competenceActivityForm" size="lg">
            <competenceActivityForm v-if="modalShow"/>
        </b-modal>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import competenceActivityForm from '@@/components/forms/competenceActivityForm'
import paginationBar from '@@/components/paginationBar'
import {mapState, mapActions} from 'vuex'

export default {
    layout : 'learning-activity',
    components : { competenceActivityForm, paginationBar },
    middleware: ({ store, redirect }) => {
        if (!store.state.learningActivity.detail) return redirect('/learning-activity')
    },
    created() {
        this.$store.dispatch('competence_activity/clearAll');
        this.$store.dispatch('competence_activity/getAll',{id:[this.learningActivity.detail.activity_id]});           
    },
     data() {
        return {        
            modalDelimitShow:false,
            modalShow: false,    
            begin_date : null,
            end_date : null,
            page_number: null,
        filters: {
            plcode: null,
            competence: null,
            begin_date: null,
            end_date: null
        }  
        };
    },
    computed: {
        ...mapState(["learningActivity", "competence_activity", "PLCOD", 'CMPTY']),
        
    },
    methods: {
        getParam(){
            this.$store.dispatch("PLCOD/getAll");
            this.$store.dispatch("CMPTY/getAll");
        },
        ...mapActions({
            getDetail: 'competence_activity/getDetail',
            clearDetail: 'competence_activity/clearDetail',            
            deleteOne: 'competence_activity/deleteOne',
            getAll: 'competence_activity/getAll',
        }),   
        runFilter() {
        let params = {};
        if (this.filters.plcode){
            params["otype1"] = ["PLCOD"];
            params["object1"] = [this.filters.plcode];
        }
        if (this.filters.competence){
            params["otype2"] = ["CMPTY"];
            params["object2"] = [this.filters.competence];
        }
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;

        this.$router.push({ path : this.$route.path , query : params})
        this.getAll(params);
    },

    clearFilters() {
      this.filters = {
       
        plcode: null,
        competence:null,
      };
    },
        
        async showUpdateForm(object_identifier) {
            
            await this.getDetail(object_identifier)
            
            this.$bvModal.show('competenceActivityForm')
        },
        
        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.competence_activity.detail.begin_date
            this.end_date = this.competence_activity.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/lmsrelation2object?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/lmsrelation2object', {}, {
                    params : {
                        object_identifier : this.competence_activity.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('competence_activity/getAll',{id:[this.learningActivity.detail.activity_id]});  
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
