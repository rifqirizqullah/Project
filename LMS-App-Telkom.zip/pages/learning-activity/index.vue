<template>
    <div class="container page-section">

            <div class="mb-heading d-flex align-items-end px-3">
                <div class="flex">
                    <p class="card-title" style="font-size:25px;color:black">Learning Activity Management</p>
                    <p  style="font-size:15px;margin-top:-15px">List of Available Learning Activity</p>
                </div>
                <button @click="clearDetail(); $bvModal.show('learningActivityForm')" class="btn btn-success btn-sm">+
                    Create Learning Activity</button>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
            </div>
            <div class="card-body p-0">

            <div class="">
                <div class="text-right">
                    <div class="bg-white">
                        <!-- Elements to collapse -->
                        <b-collapse id="collapse-a" class="mt-2 p-4">
                            <form action="">
                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters.company" class="form-control" name="company" id="company">
                                            <option
                                                v-for="(item, index) in company.list"
                                                :key="index"
                                                :value="item.business_code"
                                            >{{item.company_name}}</option>
                                            </select>
                                            <small class="form-text text-muted">Company</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <input v-model="filters.activity_name" type="text" class="form-control" id="name" placeholder="Name">
                                            <small>Activity Name</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <select v-model="filters.cycle" class="form-control" name="cycle" id="cycle">
                                                <option v-for="(item, index) in CYCLE.list" :key="index" :value="item.id">{{item.value}}</option>
                                            </select>
                                            <small>Cycle</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <select v-model="filters.activity_type" class="form-control" name="activity_type" id="activity_type">
                                                <option v-for="(item, index) in ACTTY.list" :key="index" :value="item.id">{{item.value}}</option>
                                            </select>
                                            <small>Activity Type</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <select v-model="filters.flag_online" class="form-control" name="flag_online" id="flag_online">
                                                <option :value="true">Online</option>
                                                <option :value="false">Offline</option>
                                            </select>
                                            <small>Flag Online</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters = {}; runFilter()" variant="secondary" >Clear Filter</b-button>
                                            <b-button @click="runFilter" variant="info" >
                                                <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                            </b-button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </b-collapse>
                    </div>
                </div>
            </div>

                <div class="card">
                   <div class="" >
                        <table class="table table-flush table-hover table-responsive">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Company</th>
                                <th>Name</th>
                                <th>Cycle</th>
                                <th>Type</th>
                                <th>Flag Online</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody class="list ">
                            <tr v-for="(item, index) in learningActivity.list" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.business_code.company_name }}</td>
                                <td @click="getDetail(item.object_identifier); $router.push('/learning-activity/detail')">
                                    <b style="cursor:pointer">{{ item.activity_name }}</b>
                                </td>
                                <td>{{ item.cycle.value }}</td>
                                <td>{{ item.activity_type.value }}</td>
                                <td v-if="item.flag_online == true" class="text-success">Online</td>
                                <td v-else class="text-accent">Offline</td>
                                <td>{{ formatDate(item.begin_date) }}</td>
                                <td>{{ formatDate(item.end_date) }}</td>
                                <td>

                                    <div class="dropdown d-sm-flex">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>

                                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                            <button class="dropdown-item"
                                                @click="showUpdateForm(item.object_identifier)">Update</button>
                                            <button class="dropdown-item"
                                                @click="deleteData(item.object_identifier, index)">Delete</button>
                                            <button class="dropdown-item"
                                                @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                            <button class="dropdown-item"
                                                @click="getDetail(item.object_identifier); $router.push('/learning-activity/detail')">Detail</button>
                                            <!-- <button class="dropdown-item"
                                                @click="getCompetencyActivity(item.object_identifier); $router.push('/learning-activity/competency-activity')">Competency Activity</button> -->
                                        </div>
                                    </div>
                                </td>
                            </tr>
                             <tr v-if="learningActivity.isLoading" >
                                <td colspan="10">
                                    <div class="row">
                                        <div class="col d-flex justify-content-center">
                                            <div class="loader loader-accent text-center"></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                   </div>
                    <div class="card-footer">
                        <paginationBar :state='learningActivity' :storeModuleName="'learningActivity'" />
                    </div>
                </div>
            </div>


        <b-modal v-model="modalShow" ref="learningActivityForm" hide-footer hide-header id="learningActivityForm"
            size="lg">
            <learningActivityForm v-if="modalShow" />
        </b-modal>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

    </div>
</template>

<script>
    import moment from 'moment'
    import { mapState, mapActions } from 'vuex'

    import learningActivityForm from '@@/components/forms/learningActivityForm'
    import paginationBar from '@@/components/paginationBar'

    export default {
        layout: 'learning-activity',
        components: {
            learningActivityForm,
            paginationBar
        },
        created() {
            this.$store.dispatch('learningActivity/getAll');            
            this.$store.dispatch("company/getAll");
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                begin_date:null,
                end_date: null,

                filters : {
                    activity_name : null,
                    cycle : null,
                    activity_type : null,
                    flag_online : null,
                    company:null,
                    begin_date: null,
                    end_date: null
                }
            }
        },
        computed: {
            ...mapState(['learningActivity', 'CYCLE', 'ACTTY','company'])
        },
        methods: {
            getParam(){
                this.$store.dispatch('CYCLE/getAll');
                this.$store.dispatch('ACTTY/getAll');
                
            },
            ...mapActions({
                getDetail: 'learningActivity/getDetail',
                clearDetail: 'learningActivity/clearDetail',
                deleteOne: 'learningActivity/deleteOne',
                getAll: 'learningActivity/getAll',
                getCompetencyActivity: 'learningActivity/getCompetencyActivity',
            }),

            runFilter(){
                let params = {}
                if (this.filters.company)
                    params["business_code"] = [this.filters.company];
                if (this.filters.activity_name)
                    params["activity_name[]"] = this.filters.activity_name
                if (this.filters.cycle)
                    params["cycle[]"] = this.filters.cycle
                if (this.filters.flag_online !== null)
                    params["flag_online[]"] = this.filters.flag_online
                if (this.filters.begin_date)
                    params["begin_date_lte"] = this.filters.begin_date;
                if (this.filters.end_date)
                    params["end_date_gte"] = this.filters.end_date;

                this.$router.push({ path : this.$route.path , query : params})
                this.getAll(params)

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearFilters(){
                this.filters = {
                    activity_name : null,
                    cycle : null,
                    flag_online : null,
                }

            },
            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('learningActivityForm')
            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.learningActivity.detail.begin_date
                this.end_date = this.learningActivity.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/learningactivity?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/learningactivity', {}, {
                            params: {
                                object_identifier: this.learningActivity.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('learningActivity/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });

            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
