<template>
    <div class="container page-section">

        <b><p style="font-size:20px">Competency Activity Detail</p></b>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{learningActivity.activity_name}}</h3>
                    <b><p>
                        ID <code> {{learningActivity.activity_id}} </code>
                        Identifier <code> {{learningActivity.object_identifier}} </code>
                    </p></b>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Company</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningActivity.business_code.company_name }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Type</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningActivity.activity_type.value }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Cycle</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningActivity.cycle.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Flag Online</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>{{learningActivity.flag_online}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Begin/End Date</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>{{formatDate(learningActivity.begin_date)}} - {{formatDate(learningActivity.end_date)}}</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="card shadow-sm mt-4">
            <div class="card-header bg-info">
                <h4 class="text-light">Competency Activity Set</h4>
            </div>
            <div class="card-body bg-light">

                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Competency Activity</h4>
                        <!-- <nuxt-link class="btn btn-success btn-sm"
                            :to="{path : '/learning-activity/detail/add-activity-set', query: {type :'Material'}}">+ Add
                        </nuxt-link> -->
                    </div>
                    <div class="card-body">
                        <div class="">
                            <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>Activity Name</th>
                                    <th>Activity Type</th>
                                    <th>Proficiency Level</th>
                                    <th>Competemcy Type</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(data, index) in activities" :key="index">
                                    <td>{{ data.competency_activity_name }}</td>
                                    <td>{{ data.competency_activity_type }}</td>
                                    <td>{{ data.proficiency_level }}</td>
                                    <td>{{ data.competency_type }}</td>
                                    <td>{{ formatDate(data.begin_date) }}</td>
                                    <td>{{ formatDate(data.end_date) }}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="editData(data.object_identifier)">Edit</button>
                                                <button class="dropdown-item"
                                                    @click="delimitData(data.object_identifier)">Delimit</button>
                                                <button class="dropdown-item"
                                                    @click="deleteData(data.object_identifier, index)">Delete</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table></div>
                    </div>

                    <!-- <b-modal ref="my-modal" title="Material Data" size="lg" hide-footer no-close-on-backdrop>

                        <div class="modal-body">

                            <div class="form-group">
                                <label for="materialName">Material Name</label>
                                <input v-model="materialName" type="text" name="materialName" id="materialName"
                                    class="form-control" placeholder="Material Name" aria-describedby="materialName"
                                    v-bind:class="{ 'is-danger': errors.has('collection.materialName')}"
                                    v-validate="'required'" data-vv-scope="collection">
                                <p v-show="errors.has('collection.materialName')" class="help is-danger">
                                    {{ errors.first('collection.materialName') }}</p>
                            </div>

                            <div class="form-group">
                                <label for="materialType">Materi Type</label>
                                <select v-model="materialType" class="form-control" name="materialType"
                                    id="materialType"
                                    v-bind:class="{ 'is-danger': errors.has('collection.materialType') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <option v-for="(material, index) in MATTY" :key="index" :value="material.id">
                                        {{material.value}}
                                    </option>
                                </select>
                                <p v-show="errors.has('collection.materialType')" class="help is-danger">
                                    {{ errors.first('collection.materialType') }}</p>
                            </div>

                            <div class="form-group">
                                <label for="file">File</label>
                                <input v-on:change="file()" type="file" name="file" id="file" class="custom-file-input"
                                    placeholder="file" aria-describedby="file"
                                    v-bind:class="{ 'is-danger': errors.has('collection.file')}" v-validate="'required'"
                                    data-vv-scope="collection">
                                <p v-show="errors.has('collection.file')" class="help is-danger">
                                    {{ errors.first('collection.file') }}</p>
                            </div>

                            <div class="form-group">
                                <label for="description">Description</label>
                                <input v-model="description" type="text" name="description" id="description"
                                    class="form-control" placeholder="Description" aria-describedby="description"
                                    v-bind:class="{ 'is-danger': errors.has('collection.description')}"
                                    v-validate="'required'" data-vv-scope="collection">
                                <p v-show="errors.has('collection.description')" class="help is-danger">
                                    {{ errors.first('collection.description') }}</p>
                            </div>

                            <div class="form-group">
                                <label for="competence">Main Competency</label>
                                <select v-model="competence" class="form-control" name="competence" id="competence"
                                    v-bind:class="{ 'is-danger': errors.has('collection.competence') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <option v-for="(competencies, index) in CMPTY" :key="index"
                                        :value="competencies.id">
                                        {{competencies.value}}
                                    </option>
                                </select>
                                <p v-show="errors.has('collection.competence')" class="help is-danger">
                                    {{ errors.first('collection.competence') }}</p>
                            </div>

                            <div class="form-group">
                                <label for="plCode">Proficiency Level</label>
                                <select v-model="plCode" class="form-control" name="plCode" id="plCode"
                                    v-bind:class="{ 'is-danger': errors.has('collection.plCode') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <option v-for="(plCode, index) in PLCOD" :key="index" :value="plCode.id">
                                        {{plCode.value}}</option>
                                </select>
                                <p v-show="errors.has('collection.plCode')" class="help is-danger">
                                    {{ errors.first('collection.plCode') }}</p>
                            </div>

                            <div class="form-row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label for="beginDate">Start Date</label>
                                        <div class="form-inline">
                                            <flat-pickr v-model="beginDate" :config="{dateFormat: 'Y-m-d'}"
                                                class="form-control" placeholder="Select start date" name="beginDate"
                                                id="beginDate"
                                                v-bind:class="{ 'is-danger': errors.has('collection.beginDate')}"
                                                v-validate="'required'" data-vv-scope="collection" />
                                            <button type="button" class="btn btn-info"
                                                @click="beginDate = new Date()">Today</button>
                                            <p v-show="errors.has('collection.beginDate')" class="help is-danger">
                                                {{ errors.first('collection.beginDate') }}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div v-show="beginDate" class="form-group">
                                        <label for="endDate">End Date</label>
                                        <div class="form-inline">
                                            <flat-pickr v-model="endDate"
                                                :config="{dateFormat: 'Y-m-d', minDate: beginDate}" class="form-control"
                                                placeholder="Select end date" name="endDate" id="endDate"
                                                v-bind:class="{ 'is-danger': errors.has('collection.endDate')}"
                                                v-validate="'required'" data-vv-scope="collection" />
                                            <button type="button" class="btn btn-info"
                                                @click="endDate = '2999-12-31' ">Max</button>
                                            <p v-show="errors.has('collection.endDate')" class="help is-danger">
                                                {{ errors.first('collection.endDate') }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" @click="closeFormModal">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="saveData">Save</button>
                        </div>
                    </b-modal>

                    <b-modal ref="my-modal-delimit" title="Delimit Data" size="sm" centered hide-footer
                        no-close-on-backdrop>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="beginDate">Begin Date</label>
                                <flat-pickr v-model="beginDate" :config="flatPickerConfig" class="form-control"
                                    placeholder="Select begin date" name="date"
                                    v-bind:class="{ 'is-danger': errors.has('delimit.beginDate')}"
                                    v-validate="'required'" data-vv-scope="delimit" disabled> </flat-pickr>
                                <p v-show="errors.has('delimit.beginDate')" class="help is-danger">
                                    {{ errors.first('delimit.beginDate') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="endDate">End Date</label>
                                <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                    placeholder="Select end date" name="date"
                                    v-bind:class="{ 'is-danger': errors.has('delimit.endDate')}" v-validate="'required'"
                                    data-vv-scope="delimit"> </flat-pickr>
                                <p v-show="errors.has('delimit.endDate')" class="help is-danger">
                                    {{ errors.first('delimit.endDate') }}</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary"
                                @click="closeFormModalDelimit">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="delimitDataSave()">Save</button>
                        </div>
                    </b-modal> -->

                </div>

                <!-- <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Quiz</h4>
                        <nuxt-link class="btn btn-success btn-sm"
                            :to="{path : '/learning-activity/detail/add-activity-set', query: {type :'Quiz'}}">+ Add
                        </nuxt-link>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                             <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th>Quiz Name</th>
                                    <th>Quiz Type</th>
                                    <th>Total Question</th>
                                    <th>File</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Assignment</h4>
                        <nuxt-link class="btn btn-success btn-sm"
                            :to="{path : '/learning-activity/detail/add-activity-set', query: {type :'Assignment'}}">+
                            Add</nuxt-link>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th>Assignment Name</th>
                                    <th>Assignment Type</th>
                                    <th>Total Assignment</th>
                                    <th>File</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>

                <div class="card ">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Feedback</h4>
                        <nuxt-link class="btn btn-success btn-sm"
                            :to="{path : '/learning-activity/detail/add-activity-set', query: {type :'Feedback'}}">+ Add
                        </nuxt-link>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                        <table class="table">
                            <thead class="thead-light">
                                <tr>
                                    <th>Feedback Name</th>
                                    <th>Feedback Type</th>
                                    <th>Total Question</th>
                                    <th>File</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                </tr>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div> -->

            </div>
        </div>

    </div>

</template>
<script>
    import moment from 'moment'
    import { mapState, mapActions } from 'vuex'

export default {
        layout: 'learning-activity',
        middleware: ({ store, redirect }) => {
            if (!store.state.learningActivity.competencyActivity) return redirect('/learning-activity')
        },
        data() {
            return {
                today: null,
                competency_activities: [],
                id: null,
                objectIdentifier: null,
                competencyActivityName: '',
                competencyActivityType: null,
                proficiencyLevel: null,
                competencyType: null,
                beginDate: null,
                endDate: null,

                buscd: this.$auth.user,

                flatPickerConfig: {
                    dateFormat: 'Y-m-d',
                },
            }
        },
        created() {
            this.getToday();
            this.getCompetencyActivity();

            this.$store.dispatch('learningActivity/getAll')
            this.$store.dispatch('CMPTY/getAll')
            this.$store.dispatch('PLCOD/getAll')
        },
        computed: {
            ...mapState({
                learningActivity: state => state.learningActivity.competencyActivity,

                learningActivity: state => state.learningActivity.list,
                CMPTY: state => state.CMPTY.list,
                PLCOD: state => state.PLCOD.list,
            })
        },
        methods: {
            ...mapActions({
                getCompetencyActivity: 'learningActivity/getCompetencyActivity',
                clearCompetencyActivity: 'learningActivity/clearCompetencyActivity',
            }),
            getToday() {
                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth() + 1;
                var yyyy = today.getFullYear();
                if (dd < 10) {
                    dd = '0' + dd;
                }
                if (mm < 10) {
                    mm = '0' + mm;
                }
                this.today = yyyy + '-' + mm + '-' + dd;
            },
            getCompetencyActivity() {
                this.$axios.get('lms/api/lmsrelation2object??table_code[]=LRACT&relation[]=L001&otype1[]=PLCOD&otype2[]=CMPTY&id[]=' + this.activity_id)
                    .then(res => {
                        this.datas = [];
                        res.data.data.forEach(async (data, key) => {
                            await this.competency_activities.push({
                                competency_activity_id: data.id.activity_id,
                                object_identifier: data.object_identifier,
                                competency_activity_name: data.id.activity_name,
                                competency_activity_type: data.id.activity_type.value,
                                proficiency_level:data.object1.value,
                                competency_type: data.object2.value,
                                begin_date: data.begin_date,
                                end_date: data.end_date
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
            },
            // async getActivityDetail(id) {
            //     let data = await this.activities.find(data => data.object_identifier == id);
            //     this.id = data.activity_id;
            //     this.objectIdentifier = data.object_identifier;
            //     this.activityName = data.activity_name;
            //     this.activityType = data.activity_type;
            //     this.proficiencyLevel = data.proficiency_level;
            //     this.competencyType = data.competency_type;
            //     this.beginDate = data.begin_date;
            //     this.endDate = data.end_date
            // },
            showModal() {
                this.$refs['my-modal'].show()
            },
            hideModal() {
                this.$refs['my-modal'].hide()
            },
            editData(id) {
                this.showModal();
                this.getActivityDetail(id);
            },
            closeFormModal() {
                this.hideModal()
                this.id = null
                this.objectIdentifier = null;
                this.competencyActivityName = '';
                this.competencyActivityType = null;
                this.proficiencyLevel = null;
                this.competencyType = null;
                this.beginDate = null;
                this.endDate = null;
                this.$nextTick(() => this.$validator.reset());
            },
            storeData() {
                this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                    this.$axios.post('lms/api/lmsrelation2object', {
                            begin_date: this.beginDate,
                            end_date: this.endDate,
                            business_code: "1000",
                            // materi_name: this.materialName,
                            // materi_type: this.materialType,
                            // address: "www.belajar.com",
                            // // address: this.file,
                            // description: this.description,
                            // competence: this.competence,
                            // pl_code: this.plCode
                        })
                        .then(response => {
                            this.getData();
                            this.closeFormModal();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            updateData() {
                this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                    this.$axios.put('lms/api/lmsrelation2object', {
                            object_identifier: this.objectIdentifier,
                            begin_date: this.beginDate,
                            end_date: this.endDate,
                            business_code: "1000",
                            // materi_name: this.materialName,
                            // materi_type: this.materialType,
                            // address: "www.belajar.com",
                            // // address: this.file,
                            // description: this.description,
                            // competence: this.competence,
                            // pl_code: this.plCode
                        })
                        .then(response => {
                            this.getData();
                            this.closeFormModal();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            saveData() {
                this.id ? this.updateData(this.id) : this.storeData();
            },
            showModalDelimit() {
                this.$refs['my-modal-delimit'].show()
            },
            hideModalDelimit() {
                this.$refs['my-modal-delimit'].hide()
            },
            delimitData(id) {
                this.showModalDelimit();
                // this.getMaterialDetail(id);
            },
            closeFormModalDelimit() {
                this.hideModalDelimit()
                this.id = null
                this.objectIdentifier = null;
                // this.materialName = '';
                // this.materialType = null;
                // this.description = '';
                // this.file = '';
                // this.competence = null;
                // this.plCode = null;
                this.beginDate = null;
                this.endDate = null;
                this.$nextTick(() => this.$validator.reset());
            },
            delimitDataSave() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/lmsrelation2object?end_date=' + this.endDate +
                            '&object_identifier=' + this.objectIdentifier)
                        .then(response => {
                            this.getMaterial();
                            this.closeFormModalDelimit();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            deleteData(id, key) {
                this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/lmsrelation2object?object_identifier=' + objectIdentifier)
                            .then(response => {
                                this.$swal(
                                    'Deleted!',
                                    response.data.message,
                                    'success'
                                )
                            })
                            .catch(e => {
                                console.log(e);
                            })
                            .then(() => {
                                this.removeData(key);
                            })
                    }
                });
            },
            removeData(key) {
                this.activities.splice(key, 1);
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },
    }

</script>
