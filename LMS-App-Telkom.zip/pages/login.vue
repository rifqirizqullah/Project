<template>
    <section style="background-color: #666666;fixed">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <div class="limiter ">
            <div class="container-login100">
                <div class="wrap-login100">
                    <div class="form-login">
                        <form class="login100-form validate-form" @submit.prevent="login">
                            <span class="login100-form-title p-b-43">
                                Login to continue
                            </span>
                            <div class="wrap-input100 validate-input" data-validate="Username is required">
                                <input class="input100" type="text" name="nik" placeholder="Username"
                                    v-bind:class="{ 'is-danger': errs.username }" v-model="nik">
                                <span class="focus-input100" style="padding-left:15px"> Username </span>
                                <span class="label-input100"></span>
                                <!-- <p v-if="errs.username" class="help is-danger">{{ errs.username[0] }}</p> -->
                            </div>
                            <div class="wrap-input100 validate-input" data-validate="Password is required">
                                <input class="input100" type="password" name="pass"
                                    v-bind:class="{ 'is-danger': errs.password }" v-model="password" placeholder="password">
                                <span class="focus-input100" style="padding-left:15px"> Password </span>
                                <span class="label-input100"></span>
                                <!-- <p v-if="errs.password" class="help is-danger">{{ errs.password[0] }}</p> -->
                            </div>
                            <p v-if="errs.username" class="help is-danger">{{ errs.username[0] }}</p>
                            <p v-if="errs.password" class="help is-danger">{{ errs.password[0] }}</p>

                            <div class="container-login100-form-btn">
                                <button type="submit" class="login100-form-btn">
                                    Login
                                </button>
                            </div>

                            <br>

                            <div class="login100-form-social flex-c-m">
                                <a href="#" class="login100-form-social-item">
                                    <img style="opacity:1; width:40px;height:40px;" src="/img/Corpu.png" alt="">
                                </a>
                            </div>

                        </form>
                    </div>

                    <div id="demo" class="login100-more carousel slide background" style="height: 100vh;"
                        data-ride="carousel">

                        <!-- Indicators -->
                        <!-- <ul class="carousel-indicators">
                            <li data-target="#demo" data-slide-to="0" class="active"></li>
                            <li data-target="#demo" data-slide-to="1"></li>
                            <li data-target="#demo" data-slide-to="2"></li>
                        </ul> -->

                        <!-- The slideshow -->
                        <!-- <div class="carousel-inner"> -->
                            <!-- <div class="carousel-item active"> -->
                                <img src="/img/bg-03.jpg" alt="" style="opacity: 0.3; height: auto\9;">
                                <div class="carousel-caption d-none d-md-block">
                                    <div class="banner-text">
                                        <h2>Learning Management System</h2>
                                        <br>
                                        <p>Learning Management System is an application to manage all competency 
                                            development activities of Telkom Group's Employee.</p>
                                    </div>
                                </div>
                            <!-- </div> -->
                            <!-- <div class="carousel-item ">
                                <img src="/img/bg-04.jpg" alt="">
                            </div> -->
                            <!-- <div class="carousel-item">
                                <img src="/img/bg-02.jpg" alt="">
                            </div> -->
                        <!-- </div> -->

                        <!-- Left and right controls -->
                        <!-- <a class="carousel-control-prev" href="#demo" data-slide="prev">
                            <span class="carousel-control-prev-icon"></span>
                        </a>
                        <a class="carousel-control-next" href="#demo" data-slide="next">
                            <span class="carousel-control-next-icon"></span>
                        </a> -->
                    </div>
                </div>
            </div>
        </div>

    </section>
</template>
<script>
    // import Vue from 'vue'
    // import Router from 'vue-router'

    // Vue.use(Router);
    
    // const router = new Router({ 
    //     routes: [
    //         {
    //             path: '/login',
    //             name: 'login',
    //         }

    //     ]
    // })
    // // export default router
    // const openRoutes=['Login'];

    // router.beforeEach((to, from, next) => {
    //     if(openRoutes.includes(to.name)){
    //         next()
    //     }else if(window.token){
    //         next()
    //     }else{
    //         next('/login')
    //     }
    // })

    export default {
        // router,
        layout: 'auth',
        // middleware: 'guest',
        data() {
            return {
                nik: '',
                password: '',
                errs: []
            }
        },
        created() {
            console.log(this.$auth)
        },
        methods: {
            async login() {
                try {
                    await this.$auth.loginWith('local', {
                        data: {
                            username: this.nik,
                            password: this.password,
                            application_id: '2'
                        }
                    });
                    // console.log(this.$auth.user.username)
                    this.$router.push('/');
                } catch (error) {
                    this.errs = error.response.data.errors
                }
            }
        }
        // async login() {
        // try {
        // await this.$auth.loginWith('local', {
        //     data: {
        //         username: this.nik,
        //         password: this.password
        //     }
        // });
        //this.$router.push('/');
        //console.log(this.$auth)
        // if (this.$auth.user) {
        //     this.errs = null
        //     this.$router.push('/home');
        // } else {
        //     //this.$router.push('/logout');
        //     this.errs = 'wrong username or password !'
        // }

        // } catch (error) {
        //   this.errs = 'username atau password falah !'
        // }
        //     console.log('ajax call ');

        //     this.$axios.post( process.env.API_LDAP_URL + '/api/auth/login', {
        //         username : this.nik,
        //         password : this.password,
        //         application_id : '2'
        //     })
        //     .then(res => {
        //         if(res.data.access_token) {
        //             localStorage.setItem('access_token',res.data.access_token)
        //             this.$router.push('/');
        //         }
        //     })
        //     .catch(err => {
        //         this.errs = err.response.data.message
        //     })
        // }

    }

</script>

<style src="~/assets/logincss/css/main.css" scoped></style>
<style src="~/assets/logincss/css/util.css" scoped></style>

<style>
    .background {

        background-size: cover;
        background-color: #000;
    }

    .image {
        max-width: 100%;
        /* height: auto; */
    }

    .carousel-inner img {
        width: 100%;
        /* height: 100%; */
    }

    .carousel-caption {
        text-align: left;
        /* left: 5%; */
        margin-left: auto;
        margin-right: auto;
        top: 40%;
        /* margin-bottom: 30%; */
    }

    .banner-text {
        /* width: 70%; */
        /* position: absolute; */
        /* bottom: 40px; */
        /* vertical-align: middle; */
        padding-left: 20px;
    }

    .banner-text h2 {
        color: #fff;
        font-weight: 400;
        display: block;
        font-family: Poppins-Regular;
        font-size: 25px;
    }

    .banner-text h2:after {
        content: " ";
        width: 100px;
        height: 5px;
        background: #FFF;
        display: block;
        margin-top: 20px;
        border-radius: 3px;
    }

    .banner-text p {
        color: #fff;
    }

    

</style>
