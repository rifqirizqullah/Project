<template>
    <div class="container">
        <div class="page-section">

            <div class="row">
                <div class="col-md-8">

                    <h1 class="h2 mb-2"> {{ forum_detail.forum_title }} </h1>
                    <p class="text-muted d-flex align-items-center mb-32pt mb-lg-48pt">
                        <nuxt-link to="/student/forum" class="mr-3">Back to Forum</nuxt-link>
                    </p>

                    <div class="card card-body">
                        <div class="d-flex">
                            <a href="" class=" mr-3">
                                <span class="material-icons">person</span>
                            </a>
                            <div class="flex">
                                <p class="d-flex align-items-center mb-2">
                                    <a href="student-profile.html" class="text-body mr-2"><strong>{{ forum_detail.owner }}</strong></a>
                                    <small class="text-muted">{{ momentSince(forum_detail.begin_date) }}</small>
                                </p>
                                <p>{{ forum_detail.forum_text }}</p>
                                <br>
                                <div class="d-flex align-items-center">
                                    <span class="text-50 d-flex align-items-center text-decoration-0">
                                        <span v-if="forum_like.isLoading">
                                            <div  class="loader loader-accent text-center m-1"></div>
                                        </span>
                                        <span v-else>
                                            <i v-if="!my_like_status" @click="toggleLike" class="material-icons text-secondary btn unliked" style="font-size: 24px;">thumb_up</i>
                                            <i v-if="my_like_status" @click="toggleLike" class="material-icons text-accent btn liked" style="font-size: 24px;">thumb_up</i>
                                            {{ forum_like.pagination && forum_like.pagination.total }}
                                            Likes
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="d-flex mb-4">
                        <a href="student-profile.html" class=" mr-3">
                                <span class="material-icons">person</span>
                        </a>
                        <div class="flex">
                            <div class="form-group">
                                <label for="comment" class="form-label">Your reply</label>
                                <textarea v-model="comment" class="form-control" name="comment" id="comment" rows="3" placeholder="Type here to reply  ..."
                                    v-bind:class="{ 'is-danger': errors.has('collection.comment')}"
                                    v-validate="'required'" data-vv-scope="collection"
                                ></textarea>
                                <p v-show="errors.has('collection.comment')" class="help is-danger">{{ errors.first('collection.comment') }}</p>
                            </div>
                            <b-button variant="accent" @click="postComment">Post Comment</b-button>
                        </div>
                    </div>


                    <div class="pt-3">
                        <h4>{{ forum_comment.pagination && forum_comment.pagination.total }} Comments</h4>
                        <br/>

                        <span v-if="forum_comment.isLoading">
                            <div  class="loader loader-accent text-center m-1"></div>
                        </span>
                        <span v-for="(item, index) in forum_comment.list" :key="index">
                            <div class="ml-sm-32pt mt-3 card p-3 mb-0">
                                <div class="d-flex">
                                    <a href="#" class=" mr-3">
                                        <span class="material-icons">person</span>
                                    </a>
                                    <div class="flex">
                                        <div class="d-flex align-items-center">
                                            <a href="profile.html" class="text-body"><strong>{{ item.owner }}</strong></a>
                                            <small class="ml-auto text-muted"> {{ momentSince(item.begin_date+' '+item.begin_time) }} </small>
                                        </div>
                                        <p class="mt-1 mb-0 text-70">{{ item.comment }}</p>
                                    </div>
                                </div>
                            </div>
                        </span>

                    </div>
                </div>
                <div class="col-md-4">
<!--
                    <h4 class="card-title">Top Contributors</h4>
                    <p class="card-subtitle mb-24pt">People who started the most discussions</p>

                    <div class="mb-4">

                        <div class="d-flex align-items-center mb-2">
                            <a href="student-profile.html" class=" mr-3">
                                <span class="material-icons">person</span>
                            </a>
                            <a href="student-profile.html" class="flex mr-2 text-body"><strong>Luci Bryant</strong></a>
                            <span class="text-70 mr-2">105</span>
                            <i class="text-muted material-icons font-size-16pt">forum</i>
                        </div>

                    </div> -->

                </div>
            </div>

        </div>
    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'

export default {
    layout : 'expert-detail',
    components : { paginationBar },
    middleware({store, redirect}){
        if(!store.state.forum.detail) redirect('/peserta/forum')
    },
    created() {
        this.$store.dispatch('forum_like/clearAll');
        this.$store.dispatch('forum_like/getAll', {'forum[]' : this.forum.detail.forum_id});
        this.$store.dispatch('forum_comment/clearAll');
        this.$store.dispatch('forum_comment/getAll', {'forum[]' : this.forum.detail.forum_id});
    },
    data() {
        return {
            type : this.$route.query.type,

            comment : null,
        }
    },
    computed: {
        ...mapState({
            forum : state => state.forum,
            forum_detail : state => state.forum.detail,
            forum_like : state => state.forum_like,
            forum_comment : state => state.forum_comment,
        }),

        my_like_status() {
            let isLiked = this.forum_like.list.findIndex(val => {
                return val.owner == this.$auth.user.username
            })
            return isLiked != -1
        }
    },
    methods: {
        ...mapActions({

        }),

        toggleLike() {
            this.$axios.post('lms/api/forumlike', {
                begin_date : moment(new Date).format("YYYY-MM-DD"),
                begin_time : moment(new Date).format("HH:mm"),
                business_code : this.forum.detail.business_code.business_code,
                otype_parent :"SCHDL",
                forum : this.forum.detail.forum_id,
                like : true,
                owner : this.$auth.user.username,
            })
            .then(() => {
                this.$store.dispatch('forum_like/getAll', {'forum[]' : this.forum.detail.forum_id});
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async postComment() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false
            this.$axios.post('lms/api/forumcomment', {
                begin_date : moment(new Date).format("YYYY-MM-DD"),
                begin_time : moment(new Date).format("HH:mm"),
                business_code : this.forum.detail.business_code.business_code,
                otype_parent :"SCHDL",
                forum : this.forum.detail.forum_id,
                comment : this.comment,
                owner : this.$auth.user.username
            })
            .then(() => {
                this.comment = null
                this.$validator.reset('collection')
                this.$store.dispatch('forum_comment/getAll', {'forum[]' : this.forum.detail.forum_id});
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/forumcomment?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/forum', {}, {
                    params : {
                        object_identifier : this.forum.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('forum/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        momentSince(date) {
            return moment(date).fromNow()
        }
    },

}
</script>

<style scoped>
.list-group-item-action :hover {
    background-color: lavender;
    cursor: pointer;
}
.unliked:hover {
    color: #ed0b4c !important;
}
.liked:hover {
    color: #818181 !important;
}
</style>
