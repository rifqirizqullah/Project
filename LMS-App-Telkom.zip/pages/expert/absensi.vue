<template>
    <div class="">
        <div  class="container">
            <headerEventComponent/>
            <headerBatchComponent/>
            <headerSessionComponent/>
            <headerScheduleComponent/>
            <div class="page-section">

                <h3 class="m-4">Attendant</h3>

                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center" style="white-space: nowrap;">
                            <div class="col-lg-auto">
                                <form class="search-form search-form--light d-lg-inline-flex mb-8pt mb-lg-0">
                                    <input type="text" class="form-control w-lg-auto" placeholder="Search Participant">
                                    <button class="btn" type="submit" role="button"><i class="material-icons">search</i></button>
                                </form>
                            </div>
                            <div class="col-lg d-flex flex-wrap align-items-center">
                                <!-- <div class="ml-lg-auto dropdown">
                                    <a href="#" class="btn btn-link dropdown-toggle text-black-70" data-toggle="dropdown">Filter</a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <span  class="btn dropdown-item">All Topics</span>
                                        <span  class="btn dropdown-item">My Topics</span>
                                    </div>
                                </div> -->
                                <!-- <div  class="btn btn-accent">QR Code</div> -->
                            </div>
                        </div>
                    </div>

                
                    <div class="list-group list-group-flush">
                        <div v-for="(item, index) in participant_attendance_list" :key="index" class="list-group-item p-3">
                            <div class="row align-items-center">
                                <div class="col-md-3 mb-8pt mb-md-0">
                                    <div class="media">
                                        <div class="media-left mr-16pt">
                                            <i  class="material-icons m-2"
                                                :class="{
                                                    'text-accent' : item.participant.gender.id == 'P',
                                                    'text-primary' : item.participant.gender.id != 'P'
                                                }"
                                            >
                                                person
                                            </i>
                                            <!-- <img src="/img/guy-3.jpg" width="40" alt="avatar" class="rounded-circle"> -->
                                        </div>
                                        <div class="media-body media-middle">
                                            <p class="m-0 text-body">{{ item.participant.complete_name }}</p>
                                            <p class="text-muted m-0">{{ item.participant.gender.value }}</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5 mb-8pt mb-md-0">
                                    <p class="mb-8pt">{{ item.participant.business_code.company_name }}</p>
                                </div>
                                <div class="col-md-4 d-flex align-items-center justify-content-between">
                                    <span class="mx-4">
                                        <p class="m-0">{{ (item.status && item.status.value) || '-' }}</p>
                                    </span>
                                     <span>
                                        <p class="m-0">{{ item.time || '-' }}</p>
                                    </span>
                                    <span v-if="!item.status">
                                        <div class="ml-lg-auto dropdown">
                                            <a href="#" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown"></a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <span v-for="(status, index) in ATDST.list" :key="index">
                                                    <div @click="postAttendanceStatus(item, status.id)"  class="btn dropdown-item">{{ status.value }}</div>
                                                </span>
                                            </div>
                                        </div>
                                    </span>
                                    <span v-if="item.status && item.status">
                                        <span>
                                        <button v-if="item.check == false" class="btn btn-sm btn-accent" @click="check(item.attendance_identifier)" >Check</button>    
                                        </span>
                                        
                                        <span>
                                        <button @click="deleteAttendanceStatus(item.attendance_identifier)" type="button" class="btn btn-sm btn-danger">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        



                    </div>


                    <div class="card-body text-center">
                        <a href="" class="text-black-70 text-underline"> - </a>
                    </div>
                </div>

            </div>

        </div>
    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'
import headerScheduleComponent from '@@/components/headerScheduleComponent'
import paginationBar from '@@/components/paginationBar'

export default {
    layout : 'expert-detail',
    components : {
        paginationBar,headerEventComponent, headerBatchComponent, headerSessionComponent, headerScheduleComponent
    },
    middleware: ({ store, redirect }) => {
        if (!store.state.schedule.detail) return redirect('/expert')
    },
    async created() {
        await this.$store.dispatch('ATDST/getAll', { company : ['*',this.schedule.business_code.business_code] })
        await this.$store.dispatch('attendance/getAll', { 'parent[]' : this.schedule.schedule_id })   // schedule_id
        await this.$store.dispatch('batchParticipant/getAll', { 'batch[]' : this.schedule.session.batch.batch_id })  // batch_id
        console.log(this.participant_attendance_list)
    },
    data() {
        return {

        }
    },
    computed: {
        ...mapState({
            batchParticipant : state => state.batchParticipant,
            attendance : state => state.attendance,
            ATDST : state => state.ATDST,
            schedule : state => state.schedule.detail,
        }),

        participant_attendance_list() {
            let batchParticipant_list = [...this.batchParticipant.list]
            let attendance_list = [...this.attendance.list]

            attendance_list.forEach(attendance => {
                let index = batchParticipant_list.findIndex(batchParticipant => {
                    return batchParticipant.participant.participant_id == attendance.child.participant_id
                })
                if(index != -1) {
                    batchParticipant_list[index].status = attendance.status
                    batchParticipant_list[index].time = attendance.time
                    batchParticipant_list[index].attendance_identifier = attendance.object_identifier
                    batchParticipant_list[index].check = attendance.check
                }
            })

            return batchParticipant_list
        }
    },
    methods: {
        ...mapActions({
            deleteAttendance : 'attendance/deleteOne'
        }),

        async check(attendance_identifier){
            let attendanc = await this.participant_attendance_list.find(
            attendanc => attendanc.attendance_identifier == attendance_identifier
            );
            this.$axios.put('lms/api/attendance', {
                object_identifier : attendanc.attendance_identifier,
                business_code : attendanc.business_code.business_code,
                relation :  "AP04",
                otype_parent : "SCHDL",
                parent :  this.schedule.schedule_id,
                otype_child : "PARTI",
                child :  attendanc.participant.participant_id,
                begin_date : attendanc.begin_date,
                time : attendanc.time,
                status : attendanc.status.id,
                check: true,
            })
            .then(() => {
                this.$store.dispatch('attendance/getAll', { 'parent[]' : this.schedule.schedule_id })   // schedule_id
                this.$store.dispatch('batchParticipant/getAll', { 'batch[]' : this.schedule.session.batch.batch_id })  // batch_id
                this.$swal(
                        'Saved!',
                        'Successfully checked attendance.',
                        'success'
                    )
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        deleteAttendanceStatus(object_identifier) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
            this.$axios.delete("lms/api/attendance?object_identifier=" + object_identifier)
                .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                .then(result => {
                    let index = this.attendance.list.findIndex(item => {
                        return item.object_identifier == object_identifier
                    })
                    this.deleteAttendance(index)
                    this.$store.dispatch('attendance/getAll', { 'parent[]' : this.schedule.schedule_id })   // schedule_id
                    this.$store.dispatch('batchParticipant/getAll', { 'batch[]' : this.schedule.session.batch.batch_id })  // batch_id
                })
                .catch(e => {
                    console.log(e.response);
                })
                }
                });
        },

        postAttendanceStatus(batchParticipant ,status_id) {

            this.$axios.post('lms/api/attendance', {
                business_code : this.schedule.business_code.business_code,
                relation :  "AP04",
                otype_parent : "SCHDL",
                parent :  this.schedule.schedule_id,
                otype_child : "PARTI",
                child :  batchParticipant.participant.participant_id,
                begin_date : moment(new Date).format('YYYY-MM-DD'),
                time : moment(new Date).format('h:mm'),
                status : status_id,
                check: true,
            })
            .then(() => {
                this.$store.dispatch('attendance/getAll', { 'parent[]' : this.schedule.schedule_id })   // schedule_id
                this.$store.dispatch('batchParticipant/getAll', { 'batch[]' : this.schedule.session.batch.batch_id })  // batch_id
                this.$swal(
                        'Saved!',
                        'Successfully post attendance.',
                        'success'
                    )
            })
            .catch(err => {
                console.log(err.response);
            })
        
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },
    },

}
</script>
