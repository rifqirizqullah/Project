<template>
    <div class="container page-section">
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">On Going Events</h4>
                            <p class="card-subtitle text-light">happening now</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of ongoing Event <span class="badge badge-pill badge-success badge-lg ml-3">{{mySchedule.Ongoing && mySchedule.Ongoing}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '01'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Upcoming Events</h4>
                            <p class="card-subtitle text-light">Upcoming</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Upcoming Event <span class="badge badge-pill badge-accent badge-lg ml-3">{{mySchedule.Upcoming && mySchedule.Upcoming}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '02'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Events Complete</h4>
                            <p class="card-subtitle text-light">Completed event</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Event Complete <span class="badge badge-pill badge-secondary badge-lg ml-3">{{mySchedule.Done && mySchedule.Done}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '03'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h2>My Schedule</h2>
        <span>
            <b-button type="button" @click="getParam" class="text-right ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
            <i class="fa fa-search"></i> Search         
            </b-button>
        </span>
        </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.schedule_date"
                        config="{dateFormat: 'Y-m-d'}"
                        class="form-control"
                        name="schedule_date"
                        id="schedule_date"
                        placeholder="Select end date"
                        >
                        <small class="form-text text-muted">Schedule Date</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.topic"
                        type="text"
                        class="form-control"
                        name="topic"
                        id="topic"
                        placeholder="Topic"
                        >
                        <small class="form-text text-muted">Topic</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.schedule_name"
                        type="text"
                        class="form-control"
                        name="schedule_name"
                        id="schedule_name"
                        placeholder="Title"
                        >
                        <small class="form-text text-muted">Title</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.event_name"
                        type="text"
                        class="form-control"
                        name="event_name"
                        id="event_name"
                        placeholder="Event"
                        >
                        <small class="form-text text-muted">Event</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.batch_name"
                        type="text"
                        class="form-control"
                        name="batch_name"
                        id="batch_name"
                        placeholder="Batch"
                        >
                        <small class="form-text text-muted">Batch</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.session_name"
                        type="text"
                        class="form-control"
                        name="session_name"
                        id="session_name"
                        placeholder="Session"
                        >
                        <small class="form-text text-muted">Session</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; runFilter1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

        <div class="card">
            <div class="" style="">
            <table class="table table-flush table-responsive  table-hover">
                <thead class="">
                    <tr class="">
                        <th>Day Num</th>
                        <th>Schedule Date</th>
                        <th>Time</th>
                        <th>Topic</th>
                        <th>Title</th>
                        <th>Event</th>
                        <th>Batch</th>
                        <th>Session</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in mySchedule.list" :key="index">
                        <td> {{ item.day_number }} </td>
                        <td> {{ formatDay(item.schedule_date) }} </td>
                        <td> {{ item.begin_time }} - {{ item.end_time }} </td>
                        <td> {{ item.topic }} </td>
                        <td @click="detail(item.schedule_id,item.event_id,item.batch,item.session_id)" style="cursor:pointer;">
                            <strong>{{ item.schedule_name }}</strong>
                        </td>
                        <td>{{item.event_name}}</td>
                        <td>{{item.batch_name}}</td>
                        <td>{{item.session_name}}</td>
                      
                    </tr>
                    <tr v-if="mySchedule.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>
            <div class="card-footer">
                <paginationBar :state='mySchedule' :storeModuleName="'mySchedule'" />
            </div>
        </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'

export default {
    layout: 'expert',
    components: {
        paginationBar,
    },
    data() {
        return {
            filters : {
                status : '01',
            },

            filters1 : {
                schedule_date: null,
                topic: null,
                schedule_name: null,
                event_name: null,
                batch_name: null,
                session_name: null,
                begin_date: null,
                end_date: null
            
            },
        }
    },
    created() {
        this.$store.dispatch('mySchedule/getAll');
        this.$store.dispatch('mySchedule/getAllStatus');
    },
    computed: {
        ...mapState({
            mySchedule : state => state.mySchedule,
        }),
        
        // mySchedule() {
        //     let batch_list_copy = [...this.batchParticipant.list]
        //     let filter = batch_list_copy.filter(obj => {
        //         return obj.batch.batch_id !== undefined && (obj.batch.event.event_situation && obj.batch.event.event_situation.id == '2')
        //     })
        //     let batch = filter.map(item => {return item.batch})
        //     return batch
        // }
    },
    methods: {
        getParam(){
        
        },
        ...mapActions({
            getBatchDetail: 'batch/getOne',
            getEventDetail: 'event/getOne',
            getSessionDetail: 'session/getOne',
            getScheduleDetail: 'schedule/getOne',
            getAll: 'mySchedule/getAll',
            getAll1: 'mySchedule/getAll',
        }),
        runFilter1() {
        let params1 = {};
        if (this.filters1.schedule_date)
            params1["schedule_date[]"] = this.filters1.schedule_date;
        if (this.filters1.topic)
            params1["topic[]"] = this.filters1.topic
        if (this.filters1.schedule_name)
            params1["schedule_name[]"] = this.filters1.schedule_name
        if (this.filters1.event_name)
            params1["event_name[]"] = this.filters1.event_name
        if (this.filters1.batch_name)
            params1["batch_name[]"] = this.filters1.batch_name
        if (this.filters1.session_name)
            params1["session_name[]"] = this.filters1.session_name
        if (this.filters1.begin_date)
            params1["begin_date_lte"] = this.filters1.begin_date;
        if (this.filters1.end_date)
            params["end_date_gte"] = this.filters1.end_date;
            this.$router.push({ path : this.$route.path , query : params1})
            this.getAll1(params1);
        },
        clearFilters1() {
            this.filters1 = {
                schedule_date: null,
                topic: null,
                schedule_name: null,
                event_name: null,
                batch_name: null,
                session_name: null,
                begin_date: null,
                end_date: null
            };
            this.getAll1(params1);
            let params1 = {};
        },
        async detail(schedule,event,batch,session){
            await this.getScheduleDetail({schedule_id : [schedule]});
            await this.getEventDetail({event_id : [event]});
            await this.getBatchDetail({batch_id : [batch]});
            await this.getSessionDetail({session_id : [session]});
            this.$router.push('/expert/detail?type=event')
        },        
        runFilter(){
            let params = {}
            if (this.filters.status)
                params["event_status"] = this.filters.status
            this.getAll(params)
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }

    },
}

</script>

