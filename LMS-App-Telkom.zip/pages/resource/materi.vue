<template>
    <div class="container page-section">

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <p class="card-title"  style="font-size:25px;color:black">Materi Management</p>
                <p style="font-size:15px;margin-top:-15px">Manage All Learning Materi</p>
            </div>
            <button class="btn btn-sm btn-success" @click="$bvModal.show('materiForm');clearDetail();" >+ Create Materi</button>
            <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
            </b-button>
        </div>

        <div class="">
            <div class=" text-right">
                <div class="bg-white">
                    <b-collapse id="collapse-a" class="mt-2">
                        <form class="p-3">
                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                         <input v-model="filters.materi_name" type="text" name="matery_name"
                                            id="materi_name" class="form-control" placeholder="materi_name">
                                        <small class="form-text text-muted">Matri Name</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                        <select v-model="filters.matery_type" class="form-control" name="matery_type" id="matery_type">
                                            <option v-for="(item, index) in MATTY.list" :key="index" :value="item.id">{{item.value}}</option>
                                        </select>
                                        <small class="form-text text-muted">Type</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-2">
                                    <div class="form-group">
                                        <select v-model="filters.method" class="form-control" name="method" id="method">
                                            <option v-for="(item, index) in MATTY.list" :key="index" :value="item.id">{{item.value}}</option>
                                        </select>
                                        <small class="form-text text-muted">Method</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-2">
                                    <div class="form-group">
                                        <select v-model="filters.competence" class="form-control" name="competence" id="competence">
                                            <option v-for="(item, index) in CMPTY.list" :key="index" :value="item.id">{{item.value}}</option>
                                        </select>
                                        <small class="form-text text-muted">Competency</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-2">
                                    <div class="form-group">
                                        <select v-model="filters.pl_code" class="form-control" name="pl_code" id="pl_code">
                                            <option v-for="(item, index) in PLCOD.list" :key="index" :value="item.id">{{item.value}}</option>
                                        </select>
                                        <small class="form-text text-muted">Poriciency Level</small>
                                    </div>
                                </div>

                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group text-right">
                                        <b-button @click="filters = {}; runFilter()" variant="secondary" >Clear Filter</b-button>
                                        <b-button @click="runFilter" variant="info" >
                                            <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                        </b-button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </b-collapse>
                </div>
            </div>
        </div>

        <div class="card" style="">
            <div class="">
                <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr class="">
                    <th>No</th>
                    <th>Company</th>
                    <th>Materi Name</th>
                    <th>Type</th>
                    <th>Method</th>
                    <th>Competence</th>
                    <th>Proficiency Level</th>
                    <th>Selling Price</th>
                    <th>Purchase Price</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody v-if="materi">
                    <tr v-for="(item , index) in materi.list" :key="index">
                        <td>{{index +1}}</td>
                        <td>{{item.business_code.company_name}}</td>
                        <td>{{item.materi_name}}</td>
                        <td>{{item.materi_type.value}}</td>
                        <td>{{item.method.value}}</td>
                        <td>{{item.competence.value}}</td>
                        <td>{{item.pl_code.value}}</td>
                        <td>
                            {{getRpFormat(item.selling_price)}}
                        </td>
                        <td>
                            {{getRpFormat(item.purchase_price)}}
                        </td>
                        <td>
                            <div class="dropdown d-sm-flex">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/resource/materi-detail')">Detail</button>
                                </div>
                            </div>

                        </td>
                    </tr>
                    <tr v-if="materi.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='materi' :storeModuleName="'materi'" />
            </div>

        </div>

        <b-modal v-model="modalShow" ref="materiForm" hide-footer hide-header id="materiForm" size="lg">
            <materiForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr
                        v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import materiForm from '@@/components/forms/materiForm'
import paginationBar from '@@/components/paginationBar'

import { mapState, mapActions } from 'vuex'

export default {
    layout: 'learning-activity',
    components: {
        materiForm, paginationBar
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow: false,

            end_date: null,
            begin_date: null,

            filters : {
                materi_name : null,
                materi_type : null,
                method : null,
                address: null,
                competence : null,
                pl_code : null,
            }
        }
    },
    created() {
        this.$store.dispatch('materi/getAll');
        this.$store.dispatch('CMPTY/getAll');
        this.$store.dispatch('PLCOD/getAll');
        this.$store.dispatch('MATTY/getAll')
        this.$store.dispatch('TCMTD/getAll')
    },
    computed: {
        ...mapState({
            materi : state => state.materi,
            MATTY : state => state.MATTY,
            TCMTD : state => state.TCMTD,
            CMPTY : state => state.CMPTY,
            PLCOD : state => state.PLCOD,
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'materi/getDetail',
            clearDetail: 'materi/clearDetail',
            deleteOne: 'materi/deleteOne',
            getAll: 'materi/getAll',
        }),

        runFilter(){
            let params = {}
            if (this.filters.matery_name)
                params["matery_name[]"] = this.filters.matery_name
            if (this.filters.matery_type)
                params["matery_type[]"] = this.filters.matery_type
            if (this.filters.method)
                params["method[]"] = this.filters.method
            if (this.filters.competence)
                params["competence[]"] = this.filters.competence
            if (this.filters.pl_code)
                params["pl_code[]"] = this.filters.pl_code

            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params)
        },

        clearFilters(){
            this.filters = {
                competence : null,
                pl_code : null,
            }
        },

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('materiForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.materi.detail.begin_date
            this.end_date = this.materi.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                })
                .then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/materi?object_identifier=' + id)
                            .then(response => {
                                return this.$swal('Deleted!', response.data.message, 'success')
                            })
                            .then((result) => {
                                this.deleteOne(index)
                            })
                            .catch(e => {
                                console.log(e.response);
                            })
                    }
                });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/materi', {}, {
                        params: {
                            object_identifier: this.materi.detail.object_identifier,
                            end_date: this.end_date,
                        }
                    })
                    .then(response => {
                        this.$store.dispatch('materi/getAll');
                        this.$bvModal.hide('modalDelimit')
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                    })
                    .catch(e => {
                        console.log(e.response);
                    });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        getRpFormat(num) {
            // if(!num) return 0
            let rupiah = '';
            let numrev = num.toString().split('').reverse().join('');
            for(let i = 0; i < numrev.length; i++) if(i%3 == 0) rupiah += numrev.substr(i,3)+'.';
            return 'Rp '+rupiah.split('',rupiah.length-1).reverse().join('');
        },
    },

}

</script>
