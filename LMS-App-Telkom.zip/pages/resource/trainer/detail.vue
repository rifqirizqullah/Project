<template>
    <div class="container page-section">
        <div class="card shadow mt-4">
            <div class="card-header bg-info">
                <h4 class="text-light">Trainer Detail</h4>
            </div>
            <div class="card-body bg-light">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Job</h4>
                        <button type="button" class="btn btn-success btn-sm"
                            @click="clearDetailJob();$bvModal.show('trainerJobForm')">
                            + Add Job
                        </button>
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Company</th>
                                    <th>Unit</th>
                                    <th>Job</th>
                                    <th>Position</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(data , index) in trainerJob.list" :key="index">
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ item.company_name }}</td>
                                    <td>{{ item.unit_name }}</td>
                                    <td>{{ item.job_name }}</td>
                                    <td>{{ item.position_name }}</td>
                                    <td>{{ formatDate(item.begin_date) }}</td>
                                    <td>{{ formatDate(item.end_date) }}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="editDataJob(data.object_identifier)">Edit</button>
                                                <button class="dropdown-item"
                                                    @click="delimitDataJob(data.object_identifier)">Delimit</button>
                                                <button class="dropdown-item"
                                                    @click="deleteDataJob(data.object_identifier, index)">Delete</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <paginationBar :state='trainerJob' :storeModuleName="'trainerJob'" />
                    </div>
                </div>
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Address</h4>
                        <button type="button" class="btn btn-success btn-sm"
                            @click="clearDetailAddress();$bvModal.show('trainerAddressForm')">
                            + Add Address
                        </button>
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Address Type</th>
                                    <th>Street</th>
                                    <th>City</th>
                                    <th>Province</th>
                                    <th>Country</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item , index) in trainerAddress.list" :key="index">
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ item.address_type.value }}</td>
                                    <td>{{ item.street }}</td>
                                    <td>{{ item.city.value }}</td>
                                    <td>{{ item.province.value }}</td>
                                    <td>{{ item.country.value }}</td>
                                    <td>{{ formatDate(item.begin_date) }}</td>
                                    <td>{{ formatDate(item.end_date) }}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="showUpdateFormAddress(item.object_identifier)">Edit</button>
                                                <button class="dropdown-item"
                                                    @click="deleteDataAddress(item.object_identifier, index)">Delete</button>
                                                <button class="dropdown-item"
                                                    @click="showDelimitFormAddress(item.object_identifier, item.end_date)">Delimit</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <paginationBar :state='trainerAddress' :storeModuleName="'trainerAddress'" />
                    </div>
                </div>
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Communication</h4>
                        <button type="button" class="btn btn-success btn-sm"
                            @click="clearDetailCommunication();$bvModal.show('trainerCommunicationForm')">
                            + Add Communitcation
                        </button>
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Communication Type</th>
                                    <th>Communication Address</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item , index) in trainerCommunication.list" :key="index">
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ item.communication_type.value }}</td>
                                    <td>{{ item.communication_text }}</td>
                                    <td>{{ formatDate(item.begin_date) }}</td>
                                    <td>{{ formatDate(item.end_date) }}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="showUpdateFormCommunication(item.object_identifier)">Edit</button>
                                                <button class="dropdown-item"
                                                    @click="deleteDataCommunication(item.object_identifier, index)">Delete</button>
                                                <button class="dropdown-item"
                                                    @click="showDelimitFormCommunication(item.object_identifier, item.end_date)">Delimit</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <paginationBar :state='trainerCommunication' :storeModuleName="'trainerCommunication'" />
                    </div>
                </div>
            </div>
        </div>

        <!-- job modal -->
        <b-modal v-model="jobModalShow" ref="trainerJobForm" hide-footer hide-header id="trainerJobForm" size="lg"
            @hide='clearDetailJob'>
            <trainerJobForm v-if="jobModalShow" />
        </b-modal>

        <b-modal v-model="jobmodalDelimitShow" id="modalDelimitJob" centered title="Delimit Data"
            header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                        class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                        data-vv-scope="collection" />
                    <a class="btn text-info" @click="end_date = new Date() ">Set Today</a>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                        {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary"
                    @click="$bvModal.hide('modalDelimitJob')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataJob">Save</button>
            </div>
        </b-modal>
        <!-- job modal -->

        <!-- address modal -->
        <b-modal v-model="addressModalShow" ref="trainerAddressForm" hide-footer hide-header id="trainerAddressForm"
            size="lg" @hide='clearDetailAddress'>
            <trainerAddressForm v-if="addressModalShow" />
        </b-modal>

        <b-modal v-model="addressmodalDelimitShow" id="modalDelimitAddress" centered title="Delimit Data"
            header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                        class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                        data-vv-scope="collection" />
                    <a class="btn text-info" @click="end_date = new Date() ">Set Today</a>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                        {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary"
                    @click="$bvModal.hide('modalDelimitAddress')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataAddress">Save</button>
            </div>
        </b-modal>
        <!-- address modal -->

        <!-- communication modal -->
        <b-modal v-model="communicationModalShow" ref="trainerCommunicationForm" hide-footer hide-header
            id="trainerCommunicationForm" size="lg" @hide='clearDetailCommunication'>
            <trainerCommunicationForm v-if="communicationModalShow" />
        </b-modal>

        <b-modal v-model="communicationmodalDelimitShow" id="modalDelimitCommunication" centered title="Delimit Data"
            header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                        class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                        data-vv-scope="collection" />
                    <a class="btn text-info" @click="end_date = new Date() ">Set Today</a>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                        {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary"
                    @click="$bvModal.hide('modalDelimitCommunication')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataCommunication">Save</button>
            </div>
        </b-modal>
        <!-- communication modal -->

    </div>
</template>

<script>
    import moment from 'moment'
    import {
        mapState,
        mapActions
    } from 'vuex'
    import trainerAddressForm from '@@/components/forms/trainerAddressForm'
    import trainerCommunicationForm from '@@/components/forms/trainerCommunicationForm'
    import trainerJobForm from '@@/components/forms/trainerJobForm'
    import paginationBar from '@@/components/paginationBar'

    export default {
        layout: 'noouter',
        components: {
            trainerAddressForm,
            trainerCommunicationForm,
            trainerJobForm,
            paginationBar
        },
        data() {
            return {
                end_date: null,
                begin_date: null,

                addressModalShow: false,
                communicationModalShow: false,
                jobModalShow: false,

                addressmodalDelimitShow: false,
                communicationmodalDelimitShow: false,
                jobmodalDelimitShow: false,
            }
        },
        created() {
            this.$store.dispatch("trainer/getAll");
            this.$store.dispatch('trainerAddress/getAll')
            this.$store.dispatch('trainerCommunication/getAll')
            this.$store.dispatch('trainerJob/getAll')
        },
        computed: {
            ...mapState({
                trainer: state => state.trainer.detail,
                trainerAddress: state => state.trainerAddress,
                trainerCommunication: state => state.trainerCommunication,
                trainerJob: state => state.trainerJob,
            })
        },
        methods: {
            ...mapActions({
                getAllAddress: 'trainerAddress/getAll',
                getDetailAddress: 'trainerAddress/getDetail',
                clearDetailAddress: 'trainerAddress/clearDetail',
                deleteOneAddress: 'trainerAddress/deleteOne',

                getAllJob: 'trainerJob/getAll',
                getDetailJob: 'trainerJob/getDetail',
                clearDetailJob: 'trainerJob/clearDetail',
                deleteOneJob: 'trainerJob/deleteOne',

                getAllCommunication: 'trainerCommunication/getAll',
                getDetailCommunication: 'trainerCommunication/getDetail',
                clearDetailCommunication: 'trainerCommunication/clearDetail',
                deleteOneCommunication: 'trainerCommunication/deleteOne',
            }),

            showUpdateFormAddress(object_identifier) {
                this.getDetailAddress(object_identifier)
                this.$bvModal.show('trainerAddressForm')
            },
            async showDelimitFormAddress(object_identifier) {
                await this.getDetailAddress(object_identifier)
                this.begin_date = this.trainerAddress.detail.begin_date
                this.end_date = this.trainerAddress.detail.end_date
                this.$bvModal.show('modalDelimitAddress')
            },
            delimitDataAddress() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/traineraddress', {}, {
                            params: {
                                object_identifier: this.trainerAddress.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('trainerAddress/getAll');
                            this.$bvModal.hide('modalDelimitAddress')
                            this.$swal(
                                'Saved!',
                                'Successfully delimit data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            deleteDataAddress(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/traineraddress?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOneAddress(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            showUpdateFormCommunication(object_identifier) {
                this.getDetailCommunication(object_identifier)
                this.$bvModal.show('trainerCommunicationForm')
            },
            async showDelimitFormCommunication(object_identifier) {
                await this.getDetailCommunication(object_identifier)
                this.begin_date = this.trainerCommunication.detail.begin_date
                this.end_date = this.trainerCommunication.detail.end_date
                this.$bvModal.show('modalDelimitCommunication')
            },
            delimitDataCommunication() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/trainercommunication', {}, {
                            params: {
                                object_identifier: this.trainerCommunication.detail
                                    .object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('trainerCommunication/getAll');
                            this.$bvModal.hide('modalDelimitCommunication')
                            this.$swal(
                                'Saved!',
                                'Successfully delimit data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            deleteDataCommunication(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/trainercommunication?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOneCommunication(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            showUpdateFormJob(object_identifier) {
                this.getDetailCommunication(object_identifier)
                this.$bvModal.show('trainerJobForm')
            },
            async showDelimitFormJob(object_identifier) {
                await this.getDetailCommunication(object_identifier)
                this.begin_date = this.trainerJob.detail.begin_date
                this.end_date = this.trainerJob.detail.end_date
                this.$bvModal.show('modalDelimitJob')
            },
            delimitDataJob() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/trainerjob', {}, {
                            params: {
                                object_identifier: this.trainerJob.detail
                                    .object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('trainerJob/getAll');
                            this.$bvModal.hide('modalDelimitJob')
                            this.$swal(
                                'Saved!',
                                'Successfully delimit data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            deleteDataJob(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/trainerjob?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOneJob(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },
    }

</script>

<style scoped>
</style>
