<template>
    <div>

        <div class="container page-section">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <span>
                        <h4 class="card-title">Trainer List</h4>
                        <p class="card-subtitle text-secondary">List of available training</p>
                    </span>
                    <button @click="clearDetail();$bvModal.show('trainerForm')" class="btn btn-success btn-sm">+ Add
                        Trainer</button>
                </div>

                <div class="card-body p-0">
                    <div class="table ">
                        <table class="table table-flush table-hover table-responsive">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Company</th>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th>Trainer's Company</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody class="list bg-white">
                                <tr v-for="(item, index) in trainer.list" :key="index">
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ item.business_code.company_name }}</td>
                                    <td>{{ item.trainer_name }}</td>
                                    <td>{{ item.trainer_status.value }}</td>
                                    <td>{{ item.company.company_name }}</td>
                                    <td>{{ formatDate(item.begin_date) }}</td>
                                    <td>{{ formatDate(item.end_date) }}</td>
                                    <td>
                                        <div class="btn-group">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="showUpdateForm(item.object_identifier)">Edit</button>
                                                <button class="dropdown-item"
                                                    @click="deleteData(item.object_identifier, index)">Delete</button>
                                                <button class="dropdown-item"
                                                    @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                                <button class="dropdown-item"
                                                    @click="getDetail(item.object_identifier);$router.push('/resource/trainer/detail')">Detail</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr v-if="trainer.isLoading">
                                    <td colspan="10">
                                        <div class="row">
                                            <div class="col d-flex justify-content-center">
                                                <div class="loader loader-accent text-center"></div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <paginationBar :state='trainer' :storeModuleName="'trainer'" />
                </div>
            </div>

            <b-modal v-model="modalShow" ref="trainerForm" hide-footer hide-header id="trainerForm" size="lg"
                @hide='clearDetail'>
                <trainerForm v-if="modalShow" />
            </b-modal>

            <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data"
                header-bg-variant="light" size="sm">
                <div class="col-12">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-control">
                            <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                        </div>
                    </div>
                </div>
                <hr>
                <div class="col-12">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <flat-pickr v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                            class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                            v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                            data-vv-scope="collection" />
                        <a class="btn text-info" @click="end_date = new Date() ">Set Today</a>
                        <p v-show="errors.has('collection.end_date')" class="help is-danger">
                            {{ errors.first('collection.end_date') }}</p>
                    </div>
                </div>
                <div slot="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        @click="$bvModal.hide('modalDelimit')">Cancel</button>
                    <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
                </div>
            </b-modal>

        </div>

    </div>

</template>

<script>
    import moment from 'moment'
    import {
        mapState,
        mapActions
    } from 'vuex'
    import trainerForm from '@@/components/forms/trainerForm'
    import paginationBar from '@@/components/paginationBar'

    export default {
        layout: 'noouter',
        components: {
            trainerForm,
            paginationBar
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                per_page: null,

                end_date: null,
                begin_date: null,
            }
        },
        created() {
            this.$store.dispatch('trainer/getAll')
        },
        computed: {
            ...mapState(['trainer'])
        },
        methods: {
            ...mapActions({
                getAll: 'trainer/getAll',
                getDetail: 'trainer/getDetail',
                clearDetail: 'trainer/clearDetail',
                deleteOne: 'trainer/deleteOne'
            }),

            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('trainerForm')
            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.trainer.detail.begin_date
                this.end_date = this.trainer.detail.end_date
                this.$bvModal.show('modalDelimit')
            },
            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/trainer', {}, {
                            params: {
                                object_identifier: this.trainer.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('trainer/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully delimit data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });

            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/trainer?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
