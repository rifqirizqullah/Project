<template>
    <div class="container page-section">

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h4 class="card-title"  style="font-size:25px;color:black">Questioner Management</h4>
                <p style="font-size:15px;margin-top:-15px">Manage All Questioner</p>
            </div>
            <button class="btn btn-sm btn-success" @click="$bvModal.show('questionerForm');clearDetail();" >+ Create Questioner</button>
            <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
            </b-button>
        </div>

        <div class="">
            <div class=" text-right">
                <div class="bg-white">
                    <b-collapse id="collapse-a" class="mt-2">
                        <form class="p-3">
                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                         <input v-model="filters.quesioner_name" type="text" name="matery_name"
                                            id="quesioner_name" class="form-control" placeholder="quesioner_name">
                                        <small class="form-text text-muted">Questioner Name</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-2">
                                    <div class="form-group">
                                        <select v-model="filters.quesioner_type" class="form-control" name="quesioner_type" id="quesioner_type">
                                            <option v-for="(item, index) in QSNTY.list" :key="index" :value="item.id">{{item.value}}</option>
                                        </select>
                                        <small class="form-text text-muted">Type</small>
                                    </div>
                                </div>

                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group text-right">
                                        <b-button @click="filters = {}; runFilter()" variant="secondary" >Clear Filter</b-button>
                                        <b-button @click="runFilter" variant="info" >
                                            <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                        </b-button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </b-collapse>
                </div>
            </div>
        </div>

        <div class="card">
            <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr>
                    <th>No</th>
                    <th>Company</th>
                    <th>Title</th>
                    <th>Text</th>
                    <th>Type</th>
                    <th>Category</th>
                    <th>Purpose</th>
                    <th>Choices</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody v-if="questioner">
                <tr v-for="(item , index) in questioner.list" :key="index">
                    <td>{{index +1}}</td>
                    <td>{{item.business_code.company_name}}</td>
                    <td>{{item.quesioner_title}}</td>
                    <td>{{item.quesioner_text}}</td>
                    <td>{{item.quesioner_type.value}}</td>
                    <td>{{item.quesioner_category.value}}</td>
                    <td>{{item.quesioner_purpose.value}}</td>
                    <td>{{item.number_of_choice}}</td>
                    <td>
                        <div class="dropdown d-sm-flex">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/resource/questioner-detail')">Detail</button>
                            </div>
                        </div>

                    </td>
                </tr>
                 <tr v-if="questioner.isLoading" >
                    <td colspan="10">
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </td>
                </tr>

            </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='questioner' :storeModuleName="'questioner'" />
            </div>

        </div>

        <b-modal v-model="modalShow" ref="questionerForm" hide-footer hide-header id="questionerForm" size="lg">
            <questionerForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr
                        v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import questionerForm from '@@/components/forms/questionerForm'
import paginationBar from '@@/components/paginationBar'

import { mapState, mapActions } from 'vuex'

export default {
    layout: 'learning-activity',
    components: {
        questionerForm, paginationBar
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow: false,

            end_date: null,
            begin_date: null,

            filters : {
                quesioner_name : null,
                quesioner_type : null,
            }
        }
    },
    created() {
        this.$store.dispatch('questioner/getAll');
        this.$store.dispatch('QSNTY/getAll');
    },
    computed: {
        ...mapState({
            questioner : state => state.questioner,
            QSNTY : state => state.QSNTY,
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'questioner/getDetail',
            clearDetail: 'questioner/clearDetail',
            deleteOne: 'questioner/deleteOne',
            getAll: 'questioner/getAll',
        }),

        runFilter(){
            let params = {}
            if (this.filters.questioner_name)
                params["questioner_name[]"] = this.filters.questioner_name
            if (this.filters.quesioner_type)
                params["quesioner_type[]"] = this.filters.quesioner_type

            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params)
        },

        clearFilters(){
            this.filters = {
                competence : null,
                pl_code : null,
            }
        },

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('questionerForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.questioner.detail.begin_date
            this.end_date = this.questioner.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                })
                .then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/quesioner?object_identifier=' + id)
                            .then(response => {
                                return this.$swal('Deleted!', response.data.message, 'success')
                            })
                            .then((result) => {
                                this.deleteOne(index)
                            })
                            .catch(e => {
                                console.log(e.response);
                            })
                    }
                });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/quesioner', {}, {
                        params: {
                            object_identifier: this.questioner.detail.object_identifier,
                            end_date: this.end_date,
                        }
                    })
                    .then(response => {
                        this.$store.dispatch('questioner/getAll');
                        this.$bvModal.hide('modalDelimit')
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                    })
                    .catch(e => {
                        console.log(e.response);
                    });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}

</script>
