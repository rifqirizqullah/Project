<template>
    <div class="container page-section">
        <div class="card shadow mt-4">
            <div class="card-header bg-info">
                <h4 class="text-light">Participant Detail</h4>
            </div>
            <div class="card-body bg-light">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Job</h4>
                    <span>     
                        <button type="button" class="btn btn-success btn-sm"
                            @click="clearDetailJob();$bvModal.show('participantJobForm')">
                            + Add Job
                        </button> 
                        <b-button type="button" @click="getParam1" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                        <i class="fa fa-search"></i> Search         
                        </b-button>      
                    </span>
                    </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters1.company" class="form-control" name="company" id="company">
                        <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                        >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.unit"
                        type="text"
                        class="form-control"
                        id="unit"
                        placeholder="Unit"
                        >
                        <small class="form-text text-muted">Unit</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.job"
                        type="text"
                        class="form-control"
                        id="job"
                        placeholder="Job"
                        >
                        <small class="form-text text-muted">Job</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.position"
                        type="text"
                        class="form-control"
                        id="position"
                        placeholder="Position"
                        >
                        <small class="form-text text-muted">Position</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Start Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; runFilter1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Company</th>
                                    <th>Unit</th>
                                    <th>Job</th>
                                    <th>Position</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item , index) in participantJob.list" :key="index">
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ item.company_name }}</td>
                                    <td>{{ item.unit_name }}</td>
                                    <td>{{ item.job_name }}</td>
                                    <td>{{ item.position_name }}</td>
                                    <td>{{ formatDate(item.begin_date) }}</td>
                                    <td>{{ formatDate(item.end_date) }}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="showUpdateFormJob(item.object_identifier)">Edit</button>
                                                <button class="dropdown-item"
                                                    @click="showDelimitFormJob(item.object_identifier)">Delimit</button>
                                                <button class="dropdown-item"
                                                    @click="deleteDataJob(item.object_identifier, index)">Delete</button>
                                                <button class="dropdown-item"
                                                    @click="roadmap(item.object_identifier); $router.push('/resource/participant/roadmap')">Roadmap</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <paginationBar :state='participantJob' :storeModuleName="'participantJob'" />
                    </div>
                </div>
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Address</h4>
                    <span>
                        <button type="button" class="btn btn-success btn-sm"
                            @click="clearDetailAddress();$bvModal.show('participantAddressForm')">
                            + Add Address
                        </button>  
                        <b-button type="button" @click="getParam2" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>  
                        <i class="fa fa-search"></i> Search         
                        </b-button>      
                    </span>    
                </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-b" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters2.address_type" class="form-control" name="address" id="address">
                        <option
                            v-for="(item, index) in ADDTY.list"
                            :key="index"
                            :value="item.id"
                        >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Address</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters2.street"
                        type="text"
                        class="form-control"
                        id="street"
                        placeholder="Street"
                        >
                        <small class="form-text text-muted">Street</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters2.city" class="form-control" name="city" id="city">
                        <option
                            v-for="(item, index) in PRVNC_CITY.list"
                            :key="index"
                            :value="item.child.id"
                        >{{item.child.value}}</option>
                        </select>
                        <small class="form-text text-muted">City</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters2.province" class="form-control" name="province" id="province">
                        <option
                            v-for="(item, index) in PRVNC.list"
                            :key="index"
                            :value="item.id"
                        >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Province</small>
                    </div>
                </div>
                
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters2.country" class="form-control" name="country" id="country">
                        <option
                            v-for="(item, index) in CONTR.list"
                            :key="index"
                            :value="item.id"
                        >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Country</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Start Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters2 = {}; runFilter2()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter2" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Address Type</th>
                                    <th>Street</th>
                                    <th>City</th>
                                    <th>Province</th>
                                    <th>Country</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item , index) in participantAddress.list" :key="index">
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ item.address_type.value }}</td>
                                    <td>{{ item.street }}</td>
                                    <td>{{ item.city.value }}</td>
                                    <td>{{ item.province.value }}</td>
                                    <td>{{ item.country.value }}</td>
                                    <td>{{ formatDate(item.begin_date) }}</td>
                                    <td>{{ formatDate(item.end_date) }}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="showUpdateFormAddress(item.object_identifier)">Edit</button>
                                                <button class="dropdown-item"
                                                    @click="deleteDataAddress(item.object_identifier, index)">Delete</button>
                                                <button class="dropdown-item"
                                                    @click="showDelimitFormAddress(item.object_identifier, item.end_date)">Delimit</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <paginationBar :state='participantAddress' :storeModuleName="'participantAddress'" />
                    </div>
                </div>
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Communication</h4>
                    <span> 
                        <button type="button" class="btn btn-success btn-sm"
                            @click="clearDetailCommunication();$bvModal.show('participantCommunicationForm')">
                            + Add Communitcation
                        </button> 
                        <b-button type="button" @click="getParam3" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-c>  
                        <i class="fa fa-search"></i> Search         
                        </b-button>      
                    </span>
                    </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-c" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters3.communication_type"
                      class="form-control"
                      name="communication_type"
                      id="communication_type"
                    >
                      <option
                        v-for="(item, index) in COMTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Communication Type</small>
                  </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters3.communication_text"
                        type="text"
                        class="form-control"
                        id="communication_text"
                        placeholder="Communication Text"
                        >
                        <small class="form-text text-muted">Communication Text</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters3.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters3.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters3 = {}; runFilter3()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter3" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Communication Type</th>
                                    <th>Communication Text</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item , index) in participantCommunication.list" :key="index">
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ item.communication_type.value }}</td>
                                    <td>{{ item.communication_text }}</td>
                                    <td>{{ formatDate(item.begin_date) }}</td>
                                    <td>{{ formatDate(item.end_date) }}</td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="showUpdateFormCommunication(item.object_identifier)">Edit</button>
                                                <button class="dropdown-item"
                                                    @click="deleteDataCommunication(item.object_identifier, index)">Delete</button>
                                                <button class="dropdown-item"
                                                    @click="showDelimitFormCommunication(item.object_identifier, item.end_date)">Delimit</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <paginationBar :state='participantCommunication'
                            :storeModuleName="'participantCommunication'" />
                    </div>
                </div>
            </div>
        </div>

        <!-- job modal -->
        <b-modal v-model="jobModalShow" ref="participantJobForm" hide-footer hide-header id="participantJobForm"
            size="lg" @hide='clearDetailJob'>
            <participantJobForm v-if="jobModalShow" />
        </b-modal>

        <b-modal v-model="jobmodalDelimitShow" id="modalDelimitJob" centered title="Delimit Data"
            header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                        class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                        data-vv-scope="collection" />
                    <a class="btn text-info" @click="end_date = new Date() ">Set Today</a>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                        {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary"
                    @click="$bvModal.hide('modalDelimitJob')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataJob">Save</button>
            </div>
        </b-modal>
        <!-- job modal -->

        <!-- address modal -->
        <b-modal v-model="addressModalShow" ref="participantAddressForm" hide-footer hide-header
            id="participantAddressForm" size="lg" @hide='clearDetailAddress'>
            <participantAddressForm v-if="addressModalShow" />
        </b-modal>

        <b-modal v-model="addressmodalDelimitShow" id="modalDelimitAddress" centered title="Delimit Data"
            header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                        class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                        data-vv-scope="collection" />
                    <a class="btn text-info" @click="end_date = new Date() ">Set Today</a>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                        {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary"
                    @click="$bvModal.hide('modalDelimitAddress')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataAddress">Save</button>
            </div>
        </b-modal>
        <!-- address modal -->

        <!-- communication modal -->
        <b-modal v-model="communicationModalShow" ref="participantCommunicationForm" hide-footer hide-header
            id="participantCommunicationForm" size="lg" @hide='clearDetailCommunication'>
            <participantCommunicationForm v-if="communicationModalShow" />
        </b-modal>

        <b-modal v-model="communicationmodalDelimitShow" id="modalDelimitCommunication" centered title="Delimit Data"
            header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                        class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                        data-vv-scope="collection" />
                    <a class="btn text-info" @click="end_date = new Date() ">Set Today</a>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                        {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary"
                    @click="$bvModal.hide('modalDelimitCommunication')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataCommunication">Save</button>
            </div>
        </b-modal>
        <!-- communication modal -->

    </div>
</template>

<script>
    import moment from 'moment'
    import {
        mapState,
        mapActions
    } from 'vuex'
    import participantAddressForm from '@@/components/forms/participantAddressForm'
    import participantCommunicationForm from '@@/components/forms/participantCommunicationForm'
    import participantJobForm from '@@/components/forms/participantJobForm'
    import paginationBar from '@@/components/paginationBar'

    export default {
        layout: 'participant',
        components: {
            participantAddressForm,
            participantCommunicationForm,
            participantJobForm,
            paginationBar
        },
        data() {
            return {
                filters1 : {
                    company : null,
                    unit : null,
                    job : null,
                    position : null,
                    begin_date: null,
                    end_date: null
            },
                filters2 : {
                    address_type : null,
                    street : null,
                    city : null,
                    province : null,
                    country : null,
                    begin_date: null,
                    end_date: null
            },
                filters3 : {
                    communication_type : null,
                    communication_text : null,
                    begin_date: null,
                    end_date: null
            },
                end_date: null,
                begin_date: null,

                addressModalShow: false,
                communicationModalShow: false,
                jobModalShow: false,

                addressmodalDelimitShow: false,
                communicationmodalDelimitShow: false,
                jobmodalDelimitShow: false,
            }
        },
        created() {
            this.$store.dispatch("participant/getAll");
            this.$store.dispatch('participantAddress/getAll');
            this.$store.dispatch('participantCommunication/getAll');
            this.$store.dispatch('participantJob/getAll');
            this.$store.dispatch('company/getAll');
        },
        computed: {
            ...mapState({
                participant: state => state.participant.detail,
                participantAddress: state => state.participantAddress,
                participantCommunication: state => state.participantCommunication,
                participantJob: state => state.participantJob,
                company : state => state.company,
                CONTR : state => state.CONTR,
                PRVNC_CITY : state => state.PRVNC_CITY,
                PRVNC : state => state.PRVNC,
                ADDTY : state => state.ADDTY,
                COMTY : state => state.COMTY,
            })
        },
        methods: {
            getParam1(){
        },
            getParam2(){
               this.$store.dispatch("CONTR/getAll");
               this.$store.dispatch("PRVNC/getAll");
               this.$store.dispatch("PRVNC_CITY/getAll"); 
               this.$store.dispatch("ADDTY/getAll");
        },
            getParam3(){
                this.$store.dispatch("COMTY/getAll");
        },
            ...mapActions({
                getAllAddress: 'participantAddress/getAll',
                getDetailAddress: 'participantAddress/getDetail',
                clearDetailAddress: 'participantAddress/clearDetail',
                deleteOneAddress: 'participantAddress/deleteOne',

                getAllJob: 'participantJob/getAll',
                getDetailJob: 'participantJob/getDetail',
                clearDetailJob: 'participantJob/clearDetail',
                deleteOneJob: 'participantJob/deleteOne',

                getAllCommunication: 'participantCommunication/getAll',
                getDetailCommunication: 'participantCommunication/getDetail',
                clearDetailCommunication: 'participantCommunication/clearDetail',
                deleteOneCommunication: 'participantCommunication/deleteOne',
                roadmap: 'participantJob/getDetail',
            }),

            runFilter1(){
                let params1 = {}
                if (this.filters1.company)
                    params1["business_code"] = [this.filters1.company];
                if (this.filters1.unit)
                    params1["unit[]"] = this.filters1.unit
                if (this.filters1.batch)
                    params1["job[]"] = this.filters1.job
                if (this.filters1.position)
                    params1["position[]"] = this.filters1.position
                if (this.filters1.begin_date)
                    params1["begin_date_lte"] = this.filters1.begin_date;
                if (this.filters1.end_date)
                    params1["end_date_gte"] = this.filters1.end_date;

                this.$router.push({ path : this.$route.path , query : params1})
                this.getAllJob(params1)

            },
            clearFilters1(){
                this.filters1 = {
                    company : null,
                    unit : null,
                    job : null,
                    position : null,
                }

            },

            runFilter2(){
                let params2 = {}
                if (this.filters2.address_type)
                    params2["address_type[]"] = [this.filters2.address_type];
                if (this.filters2.street)
                    params2["street[]"] = this.filters2.street
                if (this.filters2.city)
                    params2["city[]"] = this.filters2.city
                if (this.filters2.province)
                    params2["province[]"] = this.filters2.province
                if (this.filters2.country)
                    params2["country[]"] = this.filters2.country
                if (this.filters2.begin_date)
                    params2["begin_date_lte"] = this.filters2.begin_date;
                if (this.filters2.end_date)
                    params2["end_date_gte"] = this.filters2.end_date;

                this.$router.push({ path : this.$route.path , query : params2})
                this.getAllAddress(params2)

            },
            clearFilters2(){
                this.filters2 = {
                    address : null,
                    street : null,
                    city : null,
                    province : null,
                    country : null,
                }

            },

            runFilter3(){
                let params3 = {}
                if (this.filters3.communication_type)
                    params3["communication_type[]"] = [this.filters3.communication_type];
                if (this.filters3.communication_text)
                    params3["communication_text[]"] = this.filters3.communication_text
                if (this.filters3.begin_date)
                    params3["begin_date_lte"] = this.filters3.begin_date;
                if (this.filters3.end_date)
                    params3["end_date_gte"] = this.filters3.end_date;

                this.$router.push({ path : this.$route.path , query : params3})
                this.getAllCommunication(params3)

            },
            clearFilters3(){
                this.filters3 = {
                    communication_type : null,
                    communication_text : null,
                }

            },
            showUpdateFormAddress(object_identifier) {
                this.getDetailAddress(object_identifier)
                this.$bvModal.show('participantAddressForm')
            },
            async showDelimitFormAddress(object_identifier) {
                await this.getDetailAddress(object_identifier)
                this.begin_date = this.participantAddress.detail.begin_date
                this.end_date = this.participantAddress.detail.end_date
                this.$bvModal.show('modalDelimitAddress')
            },
            delimitDataAddress() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/participantaddress', {}, {
                            params: {
                                object_identifier: this.participantAddress.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('participantAddress/getAll');
                            this.$bvModal.hide('modalDelimitAddress')
                            this.$swal(
                                'Saved!',
                                'Successfully delimit data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            deleteDataAddress(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/participantaddress?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOneAddress(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            showUpdateFormCommunication(object_identifier) {
                this.getDetailCommunication(object_identifier)
                this.$bvModal.show('participantCommunicationForm')
            },
            async showDelimitFormCommunication(object_identifier) {
                await this.getDetailCommunication(object_identifier)
                this.begin_date = this.participantCommunication.detail.begin_date
                this.end_date = this.participantCommunication.detail.end_date
                this.$bvModal.show('modalDelimitCommunication')
            },
            delimitDataCommunication() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/participantcommunication', {}, {
                            params: {
                                object_identifier: this.participantCommunication.detail
                                    .object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('participantCommunication/getAll');
                            this.$bvModal.hide('modalDelimitCommunication')
                            this.$swal(
                                'Saved!',
                                'Successfully delimit data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            deleteDataCommunication(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/participantcommunication?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOneCommunication(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            showUpdateFormJob(object_identifier) {
                this.getDetailJob(object_identifier)
                this.$bvModal.show('participantJobForm')
            },
            async showDelimitFormJob(object_identifier) {
                await this.getDetailJob(object_identifier)
                this.begin_date = this.participantJob.detail.begin_date
                this.end_date = this.participantJob.detail.end_date
                this.$bvModal.show('modalDelimitJob')
            },
            delimitDataJob() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/participantjob', {}, {
                            params: {
                                object_identifier: this.participantJob.detail
                                    .object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('participantJob/getAll');
                            this.$bvModal.hide('modalDelimitJob')
                            this.$swal(
                                'Saved!',
                                'Successfully delimit data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            deleteDataJob(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/participantjob?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOneJob(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },
    }

</script>

<style scoped>
</style>
