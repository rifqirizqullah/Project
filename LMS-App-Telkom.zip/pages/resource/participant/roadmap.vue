<template>
    <div class="container page-section">
        <div class="page-headline text-center pb-3">
            <h2>My Learning Roadmap</h2>
        </div>
        <div class="card">
            <!-- <div class="text-center">
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select v-model="business_code" class="form-control" name="company" id="company" @change="getRoadmap">
                        <option>Choose Company</option>
                        <option v-for="(c, index) in company" :key="index" :value="c.business_code">
                        {{c.company_name}}
                    </option>
                    </select>
                  </div>
                </div>
            </div> -->
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Current Roadmap</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum</th>
                                <th>PL Code</th>
                                <th>Competence</th>
                                <!-- <th>Company</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in currents" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.curriculum && item.curriculum.curriculum.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.pl_code.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.competence.value }}</td>
                                <!-- <td>{{ item.curriculum && item.curriculum.business_code.company_name }}</td> -->
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Required Competencies: SUC</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum</th>
                                <th>PL Code</th>
                                <th>Competence</th>
                                <!-- <th>Company</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in SUC" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.curriculum && item.curriculum.curriculum.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.pl_code.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.competence.value }}</td>
                                <!-- <td>{{ item.curriculum && item.curriculum.business_code.company_name }}</td> -->
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Required Competencies: MCP</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum</th>
                                <th>PL Code</th>
                                <th>Competence</th>
                                <!-- <th>Company</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in MCP" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.curriculum && item.curriculum.curriculum.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.pl_code.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.competence.value }}</td>
                                <!-- <td>{{ item.curriculum && item.curriculum.business_code.company_name }}</td> -->
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Required Competencies: ECP</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum</th>
                                <th>PL Code</th>
                                <th>Competence</th>
                                <!-- <th>Company</th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in ECP" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.curriculum && item.curriculum.curriculum.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.pl_code.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.competence.value }}</td>
                                <!-- <td>{{ item.curriculum && item.curriculum.business_code.company_name }}</td> -->
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import moment from 'moment'
    import {
        mapState,
        mapActions
    } from 'vuex'
    import paginationBar from '@@/components/paginationBar'
    export default {
        layout: 'participant-roadmap',
        components: {
            paginationBar,
        },
        data() {
            return {
                currents: [],
                SUC: [],
                ECP: [],
                MCP: [],
                posisiSUC: null,
                posisiECP: null,
                posisiMCP: null,
                posisi: null,
                personal_number: null,
                business_code: this.$store.state.participantJob.detail.business_code.business_code,
                participant_id: this.$store.state.participantJob.detail.participant.participant_id
            }
        },
        async created() {
            await this.getJob();
            this.getSUC();
            this.getECP();
            this.getMCP();
        },
        computed: {
            ...mapState({}),
        },
        methods: {
            async getJob() {
                await this.$axios
                    .get(
                        'lms/api/participantjob?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&participant[]=' + this.participant_id +
                        '&business_code[]=' + this.business_code)
                    .then(response => {
                        this.posisi = response.data.data[0].position_code
                        this.personal_number = response.data.data[0].participant.personnel_number
                        // this.posisi = "PosisiA2f"
                        // this.personal_number = '10101010'
                        this.getRoadmmap();
                    }).catch(e => {
                        console.log(e);
                    });
            },

            async getSUC() {
                await this.$axios
                    .get(
                        'hcis/api/qualifications?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&personnel_number[]=' + this.personal_number +
                        '&parent_type[]=ASPTY&child_type[]=ASPTY&child[]=SUC&business_code[]=' + this
                        .business_code +
                        '&object_value_1[]=' + this.posisi)
                    .then(response => {
                        this.posisiSUC = response.data.data[0].object_value_2
                        this.$axios
                            .get(
                                '/lms/api/currentroadmap?begin_date=' + moment(new Date()).format(
                                    "YYYY-MM-DD") +
                                '&end_date=' + moment(new Date()).format("YYYY-MM-DD") +
                                '&personnel_number=' + this.personal_number +
                                '&organization_type=S&organization_id=' + this.posisiSUC +
                                '&business_code=' + this.business_code)
                            .then(response => {
                                this.SUC = [];
                                response.data.forEach(async (item, key) => {
                                    await this.SUC.push({
                                        OBJCH: item.OBJCH,
                                        OBVL2: item.OBVL2,
                                        curriculum: null
                                    });
                                    await this.$axios.get('lms/api/curriculum?pl_code[]=' + item
                                            .OBVL2 +
                                            '&competence[]=' + item.OBJCH)
                                        .then(response => {
                                            this.SUC[key].curriculum = response.data.data[0]
                                        }).catch(e => {
                                            console.log(e);
                                        });
                                })
                                // this.pagination = response.data.meta.pagination;
                            })
                    }).catch(e => {
                        console.log(e);
                    });
            },
            async getECP() {
                await this.$axios
                    .get(
                        'hcis/api/qualifications?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&personnel_number[]=' + this.personal_number +
                        '&parent_type[]=ASPTY&child_type[]=ASPTY&child[]=ECP&business_code[]=' +
                        this.business_code +
                        '&object_value_1[]=' + this.posisi)
                    .then(response => {
                        this.posisiECP = response.data.data[0].object_value_2
                        this.$axios.get(
                                '/lms/api/currentroadmap?begin_date=' + moment(new Date()).format(
                                    "YYYY-MM-DD") + '&end_date=' + moment(new Date()).format("YYYY-MM-DD") +
                                '&personnel_number=' + this.personal_number +
                                '&organization_type=S&organization_id=' + this.posisiECP +
                                '&business_code=' + this.business_code)
                            .then(response => {
                                this.ECP = [];
                                response.data.forEach(async (item, key) => {
                                    await this.ECP.push({
                                        OBJCH: item.OBJCH,
                                        OBVL2: item.OBVL2,
                                        curriculum: null
                                    });
                                    await this.$axios.get('lms/api/curriculum?pl_code[]=' + item
                                            .OBVL2 + '&competence[]=' + item.OBJCH)
                                        .then(response => {
                                            this.ECP[key].curriculum = response.data.data[0]
                                        }).catch(e => {
                                            console.log(e);
                                        });
                                })
                                // this.pagination = response.data.meta.pagination;
                            })

                    }).catch(e => {
                        console.log(e);
                    });
            },
            async getMCP() {
                await this.$axios.get('hcis/api/qualifications?begin_date_lte=' + moment(new Date()).format(
                            "YYYY-MM-DD") + '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&personnel_number[]=' + this.personal_number +
                        '&parent_type[]=ASPTY&child_type[]=ASPTY&child[]=MCP&business_code[]=' + this
                        .business_code + '&object_value_1[]=' + this.posisi)
                    .then(response => {
                        this.posisiMCP = response.data.data[0].object_value_2
                        this.$axios.get('/lms/api/currentroadmap?begin_date=' + moment(new Date()).format(
                                    "YYYY-MM-DD") + '&end_date=' + moment(new Date()).format("YYYY-MM-DD") +
                                '&personnel_number=' + this.personal_number +
                                '&organization_type=S&organization_id=' + this.posisiMCP +
                                '&business_code=' +
                                this.business_code)
                            .then(response => {
                                this.MCP = [];
                                response.data.forEach(async (item, key) => {
                                    await this.MCP.push({
                                        OBJCH: item.OBJCH,
                                        OBVL2: item.OBVL2,
                                        curriculum: null
                                    });
                                    await this.$axios.get('lms/api/curriculum?pl_code[]=' + item
                                            .OBVL2 + '&competence[]=' + item.OBJCH)
                                        .then(response => {
                                            this.MCP[key].curriculum = response.data.data[0]
                                        }).catch(e => {
                                            console.log(e);
                                        });
                                })
                                // this.pagination = response.data.meta.pagination;
                            })

                    }).catch(e => {
                        console.log(e);
                    });
            },
            getRoadmmap() {
                this.$axios.get('/lms/api/currentroadmap?begin_date=' + moment(new Date()).format("YYYY-MM-DD") +
                        '&end_date=' + moment(new Date()).format("YYYY-MM-DD") + '&personnel_number=' + this
                        .personal_number + '&organization_type=S&organization_id=' + this.posisi + '&business_code=' +
                        this.business_code)
                    .then(response => {
                        this.currents = [];
                        response.data.forEach(async (item, key) => {
                            await this.currents.push({
                                OBJCH: item.OBJCH,
                                OBVL2: item.OBVL2,
                                curriculum: null
                            });
                            await this.$axios.get('lms/api/curriculum?pl_code[]=' + item.OBVL2 +
                                    '&competence[]=' + item.OBJCH)
                                .then(response => {
                                    this.currents[key].curriculum = response.data.data[0]
                                }).catch(e => {
                                    console.log(e);
                                });
                        })
                        // this.pagination = response.data.meta.pagination;
                    })
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            },
        },
    }

</script>
