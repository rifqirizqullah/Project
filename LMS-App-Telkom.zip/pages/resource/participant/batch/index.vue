<template>
    <div class="container page-section">

        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <span>
                    <h4 class="card-title">Batch Participant</h4>
                    <p class="card-subtitle">List of Batch Participant</p>
                </span>
                <button @click="clearDetail(); $bvModal.show('batchParticipantForm')" class="btn btn-success btn-sm">+
                    Create Batch Participant</button>
            </div>

            <table class="table table-flush table-responsive table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Batch</th>
                        <th>Participant</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in batchParticipant.list" :key="index">
                        <td> {{ index + 1 }} </td>
                        <td> {{ item.batch.batch_name }} </td>
                        <td> {{ item.participant.complete_name }} </td>
                        <td> {{ formatDate(item.begin_date) }} </td>
                        <td> {{ formatDate(item.end_date) }} </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                    style="padding:6px;"></button>
                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                    <button class="dropdown-item"
                                        @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item"
                                        @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item"
                                        @click="showDelimitForm(item.object_identifier, item.begin_date, item.end_date)">Delimit</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="batchParticipant.isLoading">
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>

        </div>

        <b-modal v-model="modalShow" ref="batchParticipantForm" hide-footer hide-header id="batchParticipantForm"
            size="lg">
            <batchParticipantForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <flat-pickr v-model="begin_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date"
                    v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}" v-validate="'required'"
                    data-vv-scope="delimit" disabled> </flat-pickr>
                <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                    {{ errors.first('delimit.begin_date') }}</p>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date"
                    v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}" v-validate="'required'"
                    data-vv-scope="delimit"> </flat-pickr>
                <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                    {{ errors.first('delimit.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>
</template>

<script>
    import moment from 'moment'
    import batchParticipantForm from '@@/components/forms/batchParticipantForm'

    import {
        mapState,
        mapActions
    } from 'vuex'

    export default {
        layout: 'participant',
        components: {
            batchParticipantForm
        },
        fetch({
            store,
            params
        }) {
            store.dispatch('batchParticipant/getAll');
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,

                begin_date: null,
                end_date: null,
            }
        },
        computed: {
            ...mapState(['batchParticipant'])
        },
        methods: {
            ...mapActions({
                getDetail: 'batchParticipant/getDetail',
                clearDetail: 'batchParticipant/clearDetail',
                deleteOne: 'batchParticipant/deleteOne'
            }),

            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('batchParticipantForm')
            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.batchParticipant.detail.begin_date
                this.end_date = this.batchParticipant.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/batchparticipant?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/batchparticipant', {}, {
                            params: {
                                object_identifier: this.batchParticipant.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('batchParticipant/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
