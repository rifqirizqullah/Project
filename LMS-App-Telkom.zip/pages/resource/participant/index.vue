<template>

    <div class="container page-section">

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h4 class="card-title">Participant List</h4>
                <p class="card-subtitle text-secondary">List of available participant</p>
            </div>
            <button class="btn btn-sm btn-success" @click="clearDetail();$bvModal.show('participantForm')">+ Create
                Participant</button>
            <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>Search</span>
            </b-button>
        </div>

        <div class="">
            <div class=" text-right">
                <div class="bg-white">
                    <b-collapse id="collapse-a" class="mt-2">
                        <form class="p-3">
                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                        <input v-model="filters.complete_name" type="text" name="complete_name"
                                            id="complete_name" class="form-control" placeholder="Participant Name">
                                        <small class="form-text text-muted">Participant Name</small>
                                    </div>
                                </div>

                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group text-right">
                                        <b-button @click="filters = {}; runFilter()" variant="secondary">
                                            Clear
                                            Filter</b-button>
                                        <b-button @click="runFilter" variant="info">
                                            <span class="btn-label"><i class="fa fa-search"></i>
                                                Filter</span>
                                        </b-button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </b-collapse>
                </div>
            </div>
        </div>


        <div class="card-body p-0 border-top">
            <div class="table">
                <table class="table table-flush table-hover table-responsive">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Personal Number</th>
                            <th>Complete Name</th>
                            <th>Company</th>
                            <th>Participant Type</th>
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="list bg-white">
                        <tr v-for="(item, index) in participant.list" :key="index">
                            <td>{{ index + 1 }}</td>
                            <td>{{ item.personnel_number }}</td>
                            <td>{{ item.complete_name }}</td>
                            <td>{{ item.business_code.company_name }}</td>
                            <td>{{ item.participant_type.value }}</td>
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                        <button class="dropdown-item" v-if="item.participant_type.id == '02'"
                                            @click="showUpdateForm(item.object_identifier)">Edit</button>
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                        <button class="dropdown-item"
                                            @click="getDetail(item.object_identifier);$router.push('/resource/participant/detail')">Detail</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="participant.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="card-footer">
            <paginationBar :state='participant' :storeModuleName="'participant'" />
        </div>

        <b-modal v-model="modalShow" ref="participantForm" hide-footer hide-header id="participantForm" size="lg">
            <participantForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" header-bg-variant="light"
            size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}"
                        class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                        data-vv-scope="collection" />
                    <a class="btn text-info" @click="end_date = new Date() ">Set Today</a>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                        {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>

</template>

<script>
    import moment from 'moment'
    import {
        mapState,
        mapActions
    } from 'vuex'
    import participantForm from '@@/components/forms/participantForm'
    import paginationBar from '@@/components/paginationBar'

    export default {
        layout: 'participant',
        components: {
            participantForm,
            paginationBar
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,

                end_date: null,
                begin_date: null,

                filters: {
                    complete_name: null,
                }
            }
        },
        created() {
            this.$store.dispatch('participant/getAll')
            this.$store.dispatch('company/getAll')
        },
        computed: {
            ...mapState(['participant', 'company'])
        },
        methods: {
            ...mapActions({
                getAll: 'participant/getAll',
                getDetail: 'participant/getDetail',
                clearDetail: 'participant/clearDetail',
                deleteOne: 'participant/deleteOne'
            }),

            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('participantForm')
            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.participant.detail.begin_date
                this.end_date = this.participant.detail.end_date
                this.$bvModal.show('modalDelimit')
            },
            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/participant', {}, {
                            params: {
                                object_identifier: this.participant.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('participant/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully delimit data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });

            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/participant?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            runFilter() {
                let params = {}
                if (this.filters.complete_name)
                    params["complete_name"] = this.filters.complete_name

                this.$router.push({
                    path: this.$route.path,
                    query: params
                })
                this.getAll(params)
            },

            clearFilters() {
                this.filters = {
                    complete_name: null,
                }
            },

            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },
    }

</script>

<style scoped>
</style>
