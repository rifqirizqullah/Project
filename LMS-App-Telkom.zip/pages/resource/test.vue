<template>
    <div class="container page-section">

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h3 class="card-title" >Test Management</h3>
                <p class="card-subtitle">Manage All Learning Test</p>
            </div>
            <button class="btn btn-sm btn-success" @click="$bvModal.show('testquestionbankForm');clearDetail();" >+ Create Test</button>
            <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
            </b-button>
        </div>

        <div class="">
            <div class=" text-right">
                <div class="bg-white">
                    <b-collapse id="collapse-a" class="mt-2">
                        <form class="p-3">
                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                         <input v-model="filters.question_name" type="text" name="matery_name"
                                            id="question_name" class="form-control" placeholder="question_name">
                                        <small class="form-text text-muted">Matri Name</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-2">
                                    <div class="form-group">
                                        <select v-model="filters.question_type" class="form-control" name="question_type" id="question_type">
                                            <option v-for="(item, index) in QSTTY.list" :key="index" :value="item.id">{{item.value}}</option>
                                        </select>
                                        <small class="form-text text-muted">Type</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-2">
                                    <div class="form-group">
                                        <select v-model="filters.competence" class="form-control" name="competence" id="competence">
                                            <option v-for="(item, index) in CMPTY.list" :key="index" :value="item.id">{{item.value}}</option>
                                        </select>
                                        <small class="form-text text-muted">Competency</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-2">
                                    <div class="form-group">
                                        <select v-model="filters.pl_code" class="form-control" name="pl_code" id="pl_code">
                                            <option v-for="(item, index) in PLCOD.list" :key="index" :value="item.id">{{item.value}}</option>
                                        </select>
                                        <small class="form-text text-muted">Poriciency Level</small>
                                    </div>
                                </div>

                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group text-right">
                                        <b-button @click="filters = {}; runFilter()" variant="secondary" >Clear Filter</b-button>
                                        <b-button @click="runFilter" variant="info" >
                                            <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                        </b-button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </b-collapse>
                </div>
            </div>
        </div>


        <div class="card table-responsive" style="">
            <table class="table table-hover table-flush">
                <thead class="thead">
                <tr>
                    <th>No</th>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Text</th>
                    <th>Image</th>
                    <th>Score</th>
                    <th>Competency</th>
                    <th>Proficiency Level</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody v-if="testquestionbank">
                    <tr v-for="(item , index) in testquestionbank.list" :key="index">
                        <td>{{index +1}}</td>
                        <td>{{item.question_name}}</td>
                        <td>{{item.question_type.value}}</td>
                        <td>{{item.question_text}}</td>
                        <td>{{item.question_image}}</td>
                        <td>{{item.score}}</td>
                        <td>{{item.competence.value}}</td>
                        <td>{{item.pl_code.value}}</td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/resource/test-detail')">Detail</button>
                                </div>
                            </div>

                        </td>
                    </tr>
                    <tr v-if="testquestionbank.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>

                </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='testquestionbank' :storeModuleName="'testquestionbank'" />
            </div>

        </div>

        <b-modal v-model="modalShow" ref="testquestionbankForm" hide-footer hide-header id="testquestionbankForm" size="lg">
            <testquestionbankForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" header-bg-variant="light" size="sm">
            <div class="col-12">
                <div class="form-group">
                    <label for="begin_date">Start Date</label>
                    <div class="form-control">
                        <input v-model="begin_date" disabled type="date" name="begin_date" id="begin_date">
                    </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr
                        v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true}" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
                    <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <b-button type="button" variant="secondary" @click="$bvModal.hide('modalDelimit')">Cancel</b-button>
                <b-button variant="warning" @click="resetForm">Reset</b-button>
                <b-button type="button" variant="success" @click="delimitData">Save</b-button>
            </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import testquestionbankForm from '@@/components/forms/testquestionbankForm'
import paginationBar from '@@/components/paginationBar'

import { mapState, mapActions } from 'vuex'

export default {
    layout: 'learning-activity',
    components: {
        testquestionbankForm, paginationBar
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow: false,

            end_date: null,
            begin_date: null,

            filters : {
                question_name : null,
                question_type : null,
                competence : null,
                pl_code : null,
            }
        }
    },
    created() {
        this.$store.dispatch('testquestionbank/getAll');
        this.$store.dispatch('CMPTY/getAll');
        this.$store.dispatch('PLCOD/getAll');
        this.$store.dispatch('QSTTY/getAll');
    },
    computed: {
        ...mapState({
            testquestionbank : state => state.testquestionbank,
            CMPTY : state => state.CMPTY,
            PLCOD : state => state.PLCOD,
            QSTTY : state => state.QSTTY,
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'testquestionbank/getDetail',
            clearDetail: 'testquestionbank/clearDetail',
            deleteOne: 'testquestionbank/deleteOne',
            getAll: 'testquestionbank/getAll',
        }),

        runFilter(){
            let params = {}
            if (this.filters.competence)
                params["competence[]"] = this.filters.competence
            if (this.filters.pl_code)
                params["pl_code[]"] = this.filters.pl_code
            if (this.filters.question_type)
                params["question_type[]"] = this.filters.question_type


            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params)
        },

        clearFilters(){
            this.filters = {
                competence : null,
                pl_code : null,
            }
        },

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('testquestionbankForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.testquestionbank.detail.begin_date
            this.end_date = this.testquestionbank.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                })
                .then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/testquestionbank?object_identifier=' + id)
                            .then(response => {
                                return this.$swal('Deleted!', response.data.message, 'success')
                            })
                            .then((result) => {
                                this.deleteOne(index)
                            })
                            .catch(e => {
                                console.log(e.response);
                            })
                    }
                });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/testquestionbank', {}, {
                        params: {
                            object_identifier: this.testquestionbank.detail.object_identifier,
                            end_date: this.end_date,
                        }
                    })
                    .then(response => {
                        this.$store.dispatch('testquestionbank/getAll');
                        this.$bvModal.hide('modalDelimit')
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                    })
                    .catch(e => {
                        console.log(e.response);
                    });
            });
        },
        resetForm(){
            
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}

</script>
