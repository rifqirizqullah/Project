<template>
    <div class="container page-section">

        <div class="card">
            <div class="mb-heading card-header bg-light d-flex align-items-end px-3">
                <div class="flex">
                    <h4 class="card-title">Cost Component</h4>
                    <p class="card-subtitle">Manage Cost Component</p>
                </div>
                <button class="btn btn-sm btn-success" @click="$bvModal.show('wageForm')" >+ Add Cost Component</button>
                <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                     <span class="btn-label"><i class="fa fa-search"></i>Search</span>
                </b-button>
            </div>
            <div class="">
            <div class=" text-right">
                <div class="bg-white">
                    <b-collapse id="collapse-a" class="mt-2">
                        <form class="p-3">
                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                        <input v-model="filters.wage_name" type="text" name="matery_name"
                                            id="wage_name" class="form-control" placeholder="wage_name">
                                        <small class="form-text text-muted">Wage Name</small>
                                    </div>
                                </div>

                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group text-right">
                                        <b-button @click="filters = {}; runFilter()" variant="secondary" >Clear Filter</b-button>
                                        <b-button @click="runFilter" variant="info" >
                                            <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                        </b-button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </b-collapse>
                </div>
            </div>
        </div>
            <table class="table table-flush table-nowrap table-responsive">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Company</th>
                        <th>Name</th>
                        <th>Reference</th>
                        <th>Tax Type</th>
                        <th>Taxable</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in wage.list" :key="index" >
                        <td> {{ index+1 }} </td>
                        <td> {{ item.business_code.company_name }} </td>
                        <td> {{ item.wage_name }} </td>
                        <td> {{ item["reference-table"].value }} </td>
                        <td> {{ item.tax_type.value }} </td>
                        <td> <i v-if="item.flag_taxable == 'y'" class="material-icons">check </i> </td>
                        <td> {{ formatDate(item.begin_date) }} </td>
                        <td> {{ formatDate(item.end_date) }} </td>
                        <td>
                            <div class="btn-group">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr v-if="wage.isLoading" >
                        <td colspan="20">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tfoot>
            </table>
            <div class="card-footer">
                <paginationBar :state='wage' :storeModuleName="'wage'" />
            </div>
        </div>



        <b-modal v-model="modalShow" ref="wageForm" hide-footer hide-header id="wageForm" size="lg" @hide='clearDetail'>
            <wageForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                    v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                    <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>


    </div>
</template>

<script>
import moment from 'moment'

import wageForm from '@@/components/forms/wageForm'
import paginationBar from '@@/components/paginationBar'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'noouter',
    components : {
        wageForm , paginationBar
    },
    created() {
        this.$store.dispatch('wage/getAll')
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            end_date: null,
            begin_date: null,

            filters : {
                wage_name : null,
            }
        }
    },
    computed: {
        ...mapState({
            wage : state => state.wage,
        }),
    },
    methods: {
        ...mapActions({
            getDetail: 'wage/getDetail',
            clearDetail: 'wage/clearDetail',
            deleteOne: 'wage/deleteOne',
            getAll: 'wage/getAll',
        }),

        runFilter(){
            let params = {}
            if (this.filters.wage_name)
                params["wage_name[]"] = this.filters.wage_name

            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params)
        },

        clearFilters(){
            this.filters = {
                wage_name : null,
            }
        },
        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('wageForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.end_date = this.wage.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/wage?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/wage', {}, {
                    params : {
                        object_identifier : this.wage.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('wage/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });

        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
