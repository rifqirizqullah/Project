<template>
    <div>
        <div class="container">
            <div class="row p-3 text-right">
                <div class="col-md-9"></div>
                <div class="card card-body px-4 col-md-3 col-sm-12">
                    <div class="form-group">
                        <label for="view">Select Master</label>
                        <select v-model="viewMode" class="custom-select" name="view" id="view">
                            <option v-for="(item, index) in tables" :key="index" :value="item.value">{{item.title}}</option>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <section style="margin-top: -50px">
            <trainer v-if="viewMode == 'trainer'" />
            <wage v-if="viewMode == 'wage'" />
            <participant v-if="viewMode == 'participant'" />
            <room v-if="viewMode == 'room'" />
            <questioner v-if="viewMode == 'questioner'" />
            <materi v-if="viewMode == 'materi'" />
            <test v-if="viewMode == 'test'" />
            <mentor v-if="viewMode == 'mentor'" />
        </section>
    </div>

</template>

<script>
import participant from './participant'
import trainer from './trainer'
import wage from './wage'
import room from './room'
import questioner from './questioner'
import materi from './materi'
import test from './test'
import mentor from './mentor.vue'

export default {
    layout : 'resources',
    components : {
        trainer ,
        wage,
        participant,
        room,
        questioner,
        materi,
        test,
        mentor
    },
    data() {
        return {
            viewMode : 'room',

            tables : [
                {title : 'Trainer', value : 'trainer'},
                {title : 'Wage', value : 'wage'},
                {title : 'Participant', value : 'participant'},
                {title : 'Room', value : 'room'},
                {title : 'Questioner', value : 'questioner'},
                {title : 'Materi', value : 'materi'},
                {title : 'Test', value : 'test'},
                {title : 'Mentor', value : 'mentor'},
            ]
        }
    },


}
</script>
