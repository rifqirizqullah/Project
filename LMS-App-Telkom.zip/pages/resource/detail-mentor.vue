<template>
    <div class="container page-section">
        <div class="card shadow mt-4">
            <div class="card-header bg-info">
                <h4 class="text-light">Mentor Detail</h4>
            </div>
            <div class="card-body bg-light">
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Job</h4>
                        <span>
                        <button type="button" class="btn btn-success btn-sm" @click="showModalJob">
                            + Add Job
                        </button>
                        <b-button type="button" @click="getParamJob" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                        <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                        </b-button>
                        </span>
                    </div>
                    <div class="">
                        <div class="text-right">
                            <div class="bg-white">
                                <!-- Elements to collapse -->
                                <b-collapse id="collapse-a" class="mt-2 p-4">
                                    <form action="">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <select v-model="filtersJob.company" class="form-control" name="company" id="company">
                                                    <option
                                                        v-for="(item, index) in companies"
                                                        :key="index"
                                                        :value="item.id"
                                                    >{{item.value}}</option>
                                                    </select>
                                                    <small class="form-text text-muted">Company</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersJob.unit_name"
                                                    type="text"
                                                    class="form-control"
                                                    id="unit_name"
                                                    placeholder="Unit"
                                                    >
                                                    <small class="form-text text-muted">Unit</small>
                                                </div>
                                            </div> 
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersJob.job_name"
                                                    type="text"
                                                    class="form-control"
                                                    id="job_name"
                                                    placeholder="Job"
                                                    >
                                                    <small class="form-text text-muted">Job</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersJob.position_name"
                                                    type="text"
                                                    class="form-control"
                                                    id="position_name"
                                                    placeholder="Position"
                                                    >
                                                    <small class="form-text text-muted">Position</small>
                                                </div>
                                            </div>       
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersJob.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select start date" name="begin_date" id="begin_date"
                                                    />
                                                    <small class="form-text text-muted">Begin Date</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersJob.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select end date" name="end_date" id="end_date"
                                                    />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group text-right">
                                                    <b-button @click="filtersJob = {}; clearFiltersJob()" variant="secondary" >Clear Filter</b-button>
                                                    <b-button @click="runFilterJob" variant="info" >
                                                        <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>Company</th>
                                    <th>Unit</th>
                                    <th>Job</th>
                                    <th>Position</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(data , index) in jobse.list" :key="index">
                                    <td>{{data.company_name}}</td>
                                    <td>{{data.unit_name}}</td>
                                    <td>{{data.job_name}}</td>
                                    <td>{{data.position_name}}</td>
                                    <td>{{moment(data.begin_date)}}</td>
                                    <td>{{moment(data.end_date)}}</td>                            
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                                <button class="dropdown-item" @click="editDataJob(data.object_identifier)">Edit</button>
                                                <button class="dropdown-item" @click="delimitDataJob(data.object_identifier)">Delimit</button>
                                                <button class="dropdown-item" @click="deleteDataJob(data.object_identifier, index)">Delete</button>                                                
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            
                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Address</h4>
                        <span>
                        <button type="button" class="btn btn-success btn-sm" @click="showModalAddress">
                            + Add Address
                        </button>
                        <b-button type="button" @click="getParamAdd" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>
                        <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                        </b-button>
                        </span>
                    </div>
                    <div class="">
                        <div class="text-right">
                            <div class="bg-white">
                                <!-- Elements to collapse -->
                                <b-collapse id="collapse-b" class="mt-2 p-4">
                                    <form action="">
                                        <div class="row">
                                            
                                            <div class="col-sm-12 col-md-3">
                                                        <div class="form-group">
                                                            <select v-model="filtersAdd.address_type" class="form-control" name="address_type" id="address_type">
                                                            <option
                                                                v-for="(item, index) in addressTypes"
                                                                :key="index"
                                                                :value="item.id"
                                                            >{{item.value}} </option>
                                                            </select>
                                                            <small class="form-text text-muted">Address Type</small>
                                                        </div>
                                                    </div>
                                                    <!-- <div class="col-sm-12 col-md-3">
                                                        <div class="form-group">
                                                            <input
                                                            v-model="filtersAdd.street"
                                                            type="text"
                                                            class="form-control"
                                                            id="street"
                                                            placeholder="Street"
                                                            >
                                                            <small class="form-text text-muted">Street</small>
                                                        </div>
                                                    </div>  -->
                                                    <div class="col-sm-12 col-md-3">
                                                        <div class="form-group">
                                                            <select v-model="filtersAdd.city" class="form-control" name="city" id="city">
                                                            <option
                                                                v-for="(item, index) in cities"
                                                                :key="index"
                                                                :value="item.id"
                                                            >{{item.value}}</option>
                                                            </select>
                                                            <small class="form-text text-muted">City</small>
                                                        </div>
                                                    </div>  

                                                    <div class="col-sm-12 col-md-3">
                                                        <div class="form-group">
                                                            <select v-model="filtersAdd.province" class="form-control" name="province" id="province">
                                                            <option
                                                                v-for="(item, index) in provinces"
                                                                :key="index"
                                                                :value="item.id"
                                                            >{{item.value}}</option>
                                                            </select>
                                                            <small class="form-text text-muted">Province</small>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-sm-12 col-md-3">
                                                        <div class="form-group">
                                                            <select v-model="filtersAdd.country" class="form-control" name="country" id="country">
                                                            <option
                                                                v-for="(item, index) in countries"
                                                                :key="index"
                                                                :value="item.id"
                                                            >{{item.value}}</option>
                                                            </select>
                                                            <small class="form-text text-muted">Country</small>
                                                        </div>
                                                    </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersAdd.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select start date" name="begin_date" id="begin_date"
                                                    />
                                                    <small class="form-text text-muted">Begin Date</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersAdd.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select end date" name="end_date" id="end_date"
                                                    />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group text-right">
                                                    <b-button @click="filtersAdd = {}; clearFiltersAdd()" variant="secondary" >Clear Filter</b-button>
                                                    <b-button @click="runFilterAdd" variant="info" >
                                                        <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>Address Type</th>
                                    <th>Street</th>
                                    <th>City</th>
                                    <th>Province</th>
                                    <th>Country</th>                                    
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(data , index) in addresse.list" :key="index">
                                    <td>{{data.address_type.value}}</td>
                                    <td>{{data.business_code.street}}</td>
                                    <td>{{data.city.value}}</td>
                                    <td>{{data.province.value}}</td>
                                    <td>{{data.country.value}}</td>
                                    <td>{{moment(data.begin_date)}}</td>
                                    <td>{{moment(data.end_date)}}</td>                            
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                                <button class="dropdown-item" @click="editDataAddress(data.object_identifier)">Edit</button>
                                                <button class="dropdown-item" @click="delimitDataAddress(data.object_identifier)">Delimit</button>
                                                <button class="dropdown-item" @click="deleteDataAddress(data.object_identifier, index)">Delete</button>                                                
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header d-flex justify-content-between">
                        <h4>Communication</h4>
                        <span>
                        <button type="button" class="btn btn-success btn-sm" @click="showModalCommunication">
                            + Add Communication
                        </button>
                        <b-button type="button" @click="getParamCom" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-c>
                        <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                        </b-button>
                        </span>
                    </div>
                    <div class="">
                        <div class="text-right">
                            <div class="bg-white">
                                <!-- Elements to collapse -->
                                <b-collapse id="collapse-c" class="mt-2 p-4">
                                    <form action="">
                                        <div class="row">
                                            
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <select
                                                    v-model="filtersCom.communication_type"
                                                    class="form-control"
                                                    name="communication_type"
                                                    id="communication_type"
                                                    >
                                                    <option
                                                        v-for="(item, index) in communicationTypes"
                                                        :key="index"
                                                        :value="item.id"
                                                    >{{item.value}}</option>
                                                    </select>
                                                    <small class="form-text text-muted">Communication Type</small>
                                                </div>
                                                </div>  

                                                <div class="col-sm-12 col-md-3">
                                                    <div class="form-group">
                                                        <input
                                                        v-model="filtersCom.communication_text"
                                                        type="text"
                                                        class="form-control"
                                                        id="communication_text"
                                                        placeholder="Communication Text"
                                                        >
                                                        <small class="form-text text-muted">Communication Text</small>
                                                    </div>
                                                </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersCom.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select start date" name="begin_date" id="begin_date"
                                                    />
                                                    <small class="form-text text-muted">Begin Date</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersCom.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select end date" name="end_date" id="end_date"
                                                    />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group text-right">
                                                    <b-button @click="filtersCom = {}; clearFiltersCom()" variant="secondary" >Clear Filter</b-button>
                                                    <b-button @click="runFilterCom" variant="info" >
                                                        <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>Communication Type</th>
                                    <th>Communication Address</th>                                    
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(data , index) in communicationse.list" :key="index">
                                    <td>{{data.communication_type.value}}</td>
                                    <td>{{data.communication_text}}</td>                                    
                                    <td>{{moment(data.begin_date)}}</td>
                                    <td>{{moment(data.end_date)}}</td>                            
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                                <button class="dropdown-item" @click="editDataCommunication(data.object_identifier)">Edit</button>
                                                <button class="dropdown-item" @click="delimitDataCommunication(data.object_identifier)">Delimit</button>
                                                <button class="dropdown-item" @click="deleteDataCommunication(data.object_identifier, index)">Delete</button>                                                
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- modal job -->
        <b-modal ref="my-modal-job" size="lg" hide-footer hide-header no-close-on-backdrop title="Create Curriculum">
            <div class="modal-body">                
                <div class="form-group">
                    <label for="startDate">Start Date</label>
                    <flat-pickr v-model="startDate_job" :config="flatPickerConfig" class="form-control"
                        placeholder="Select start date" name="startDate" v-bind:class="{ 'is-danger': errors.has('collection_job.startDate')}"
                        v-validate="'required'" data-vv-scope="collection_job"> </flat-pickr>
                    <p v-show="errors.has('collection_job.startDate')" class="help is-danger"> {{ errors.first('collection_job.startDate') }}</p>
                </div>
                <div class="form-group">
                    <label for="endDate">End Date</label>
                    <flat-pickr v-model="endDate_job" :config="flatPickerConfig" class="form-control"
                        placeholder="Select end date" name="endDate" v-bind:class="{ 'is-danger': errors.has('collection_job.endDate')}"
                        v-validate="'required'" data-vv-scope="collection_job"> </flat-pickr>
                        <p v-show="errors.has('collection_job.endDate')" class="help is-danger"> {{ errors.first('collection_job.endDate') }}</p>
                </div>
                <div class="form-group">
                    <label>Company</label>
                    <select v-model="buscd_job" class="form-control" name="buscd_job"
                        id="buscd_job" v-bind:class="{ 'is-danger': errors.has('collection_job.buscd_address') }"
                        v-validate="'required'" data-vv-scope="collection_job">                        
                        <option v-for="(data, index) in companies" :key="index" :value="data">
                            {{data.value}}
                        </option>
                    </select>
                    <p v-show="errors.has('collection_job.buscd_job')" class="help is-danger">{{ errors.first('collection_job.buscd_job') }}</p>
                </div>                
                <div class="form-group" v-if="mentorList.detail.mentor_status.id == 1">
                    <label for="gender">Unit</label>
                    <select v-model="unit" class="form-control" name="unit"
                        id="unit" v-bind:class="{ 'is-danger': errors.has('collection_job.unit') }"
                        v-validate="'required'" data-vv-scope="collection_job">
                        <!-- <option disabled value="">-</option> -->
                        <option v-for="(data, index) in unitMaster" :key="index" :value="data">
                            {{data.value}}</option>
                    </select>
                    <p v-show="errors.has('collection_job.unit')" class="help is-danger">{{ errors.first('collection_job.unit') }}</p>
                </div>
                <div class="form-group" v-else>
                    <label for="religion">Unit</label>
                    <input v-model="unit" type="text" name="unit"
                        id="bornCity" class="form-control" placeholder="unit"
                        aria-describedby="bornCity" v-bind:class="{ 'is-danger': errors.has('collection_job.unit')}"
                        v-validate="'required'" data-vv-scope="collection_job">
                    <p v-show="errors.has('collection_job.unit')" class="help is-danger"> {{ errors.first('collection_job.unit') }}</p>
                </div>
                <div class="form-group" v-if="mentorList.detail.mentor_status.id == 1">
                    <label for="religion">Job</label>
                    <select v-model="job" class="form-control" name="job"
                        id="job" v-bind:class="{ 'is-danger': errors.has('collection_job.job') }"
                        v-validate="'required'" data-vv-scope="collection_job">
                        <!-- <option disabled value="">-</option> -->
                        <option v-for="(data, index) in jobMaster" :key="index" :value="data">
                            {{data.value}}</option>
                    </select>
                    <p v-show="errors.has('collection_job.job')" class="help is-danger">{{ errors.first('collection_job.job') }}</p>
                </div>
                <div class="form-group" v-else>
                    <label for="religion">Job</label>
                    <input v-model="job" type="text" name="job"
                        id="bornCity" class="form-control" placeholder="job"
                        aria-describedby="bornCity" v-bind:class="{ 'is-danger': errors.has('collection_job.job')}"
                        v-validate="'required'" data-vv-scope="collection_job">
                    <p v-show="errors.has('collection_job.job')" class="help is-danger"> {{ errors.first('collection_job.job') }}</p>
                </div>                
                <div class="form-group" v-if="mentorList.detail.mentor_status.id == 1">
                    <label for="language">Position</label>
                    <select v-model="position" class="form-control" name="position"
                        id="position" v-bind:class="{ 'is-danger': errors.has('collection_job.position') }"
                        v-validate="'required'" data-vv-scope="collection_job">
                        <!-- <option disabled value="">-</option> -->
                        <option v-for="(data, index) in positionMaster" :key="index" :value="data">
                            {{data.value}}</option>
                    </select>
                    <p v-show="errors.has('collection_job.position')" class="help is-danger">{{ errors.first('collection_job.position') }}</p>
                </div>                                
                <div class="form-group" v-else>
                    <label for="religion">Position</label>
                    <input v-model="position" type="text" name="position"
                        id="bornCity" class="form-control" placeholder="position"
                        aria-describedby="bornCity" v-bind:class="{ 'is-danger': errors.has('collection_job.position')}"
                        v-validate="'required'" data-vv-scope="collection_job">
                    <p v-show="errors.has('collection_job.position')" class="help is-danger"> {{ errors.first('collection_job.position') }}</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" @click="closeFormModalJob">Cancel</button>
                <button type="button" class="btn btn-primary" @click="saveDataJob">Save</button>
            </div>
        </b-modal>
        <b-modal ref="my-modal-delimit-job" centered hide-header hide-footer no-close-on-backdrop>            
            <div class="modal-body">
                <div class="form-group">
                    <label for="endDate">End Date</label>
                    <flat-pickr v-model="endDate_job" :config="flatPickerConfig" class="form-control"
                        placeholder="Select end date" name="endDate_job" v-bind:class="{ 'is-danger': errors.has('delimit_job.endDate_job')}"
                        v-validate="'required'" data-vv-scope="delimit_job"> </flat-pickr>
                        <p v-show="errors.has('delimit_job.endDate_job')" class="help is-danger"> {{ errors.first('delimit_job.endDate_job') }}</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" @click="closeFormModalDelimitJob">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataSaveJob()">Save</button>
            </div>
        </b-modal>
        <!-- end modal job -->

        <!-- modal address -->
        <b-modal ref="my-modal-address" size="lg" hide-footer hide-header no-close-on-backdrop title="Create Curriculum">
            <div class="modal-body">                
                <div class="form-group">
                    <label for="startDate">Start Date</label>
                    <flat-pickr v-model="startDate_address" :config="flatPickerConfig" class="form-control"
                        placeholder="Select start date" name="startDate" v-bind:class="{ 'is-danger': errors.has('collection_address.startDate')}"
                        v-validate="'required'" data-vv-scope="collection_address"> </flat-pickr>
                    <p v-show="errors.has('collection_address.startDate')" class="help is-danger"> {{ errors.first('collection_address.startDate') }}</p>
                </div>
                <div class="form-group">
                    <label for="endDate">End Date</label>
                    <flat-pickr v-model="endDate_address" :config="flatPickerConfig" class="form-control"
                        placeholder="Select end date" name="endDate_address" v-bind:class="{ 'is-danger': errors.has('collection_address.endDate_address')}"
                        v-validate="'required'" data-vv-scope="collection_address"> </flat-pickr>
                        <p v-show="errors.has('collection_address.endDate_address')" class="help is-danger"> {{ errors.first('collection_address.endDate_address') }}</p>
                </div>
                <!-- <div class="form-group">
                    <label for="mentorList.detail.mentor_status.id">Company</label>
                    <select v-model="buscd_address" class="form-control" name="buscd_address"
                        id="buscd_address" v-bind:class="{ 'is-danger': errors.has('collection_address.buscd_address') }"
                        v-validate="'required'" data-vv-scope="collection_address">                        
                        <option v-for="(data, index) in companies" :key="index" :value="data.id">
                            {{data.value}}
                        </option>
                    </select>
                    <p v-show="errors.has('collection_address.buscd_address')" class="help is-danger">{{ errors.first('collection_address.buscd_address') }}</p>
                </div>                 -->
                <div class="form-group">
                    <label for="gender">Address Type</label>
                    <select v-model="addressType" class="form-control" name="addressType"
                        id="unit" v-bind:class="{ 'is-danger': errors.has('collection_address.addressType') }"
                        v-validate="'required'" data-vv-scope="collection_address">
                        <!-- <option disabled value="">-</option> -->
                        <option v-for="(data, index) in addressTypes" :key="index" :value="data.id">
                            {{data.value}}</option>
                    </select>
                    <p v-show="errors.has('collection_address.addressType')" class="help is-danger">{{ errors.first('collection_address.addressType') }}</p>
                </div>
                <div class="form-group">
                    <label for="religion">Street</label>
                    <input v-model="street" type="text" name="street"
                        id="bornCity" class="form-control" placeholder="street"
                        aria-describedby="bornCity" v-bind:class="{ 'is-danger': errors.has('collection_address.street')}"
                        v-validate="'required'" data-vv-scope="collection_address">
                    <p v-show="errors.has('collection_address.street')" class="help is-danger"> {{ errors.first('collection_address.street') }}</p>
                </div>                
                <div class="form-group">
                    <label for="language">Postal Code</label>
                    <input v-model="postalCode" type="number" name="postalCode"
                        id="bornCity" class="form-control" placeholder="postalCode"
                        aria-describedby="bornCity" v-bind:class="{ 'is-danger': errors.has('collection_address.postalCode')}"
                        v-validate="'required'" data-vv-scope="collection_address">
                    <p v-show="errors.has('collection_address.postalCode')" class="help is-danger"> {{ errors.first('collection_address.postalCode') }}</p>
                </div>   
                <div class="form-group">
                    <label for="gender">City</label>
                    <select v-model="city" class="form-control" name="city"
                        id="unit" v-bind:class="{ 'is-danger': errors.has('collection_address.city') }"
                        v-validate="'required'" data-vv-scope="collection_address">
                        <!-- <option disabled value="">-</option> -->
                        <option v-for="(data, index) in cities" :key="index" :value="data.id">
                            {{data.value}}</option>
                    </select>
                    <p v-show="errors.has('collection_address.city')" class="help is-danger">{{ errors.first('collection_address.city') }}</p>
                </div>
                <div class="form-group">
                    <label for="gender">Province</label>
                    <select v-model="province" class="form-control" name="province"
                        id="unit" v-bind:class="{ 'is-danger': errors.has('collection_address.province') }"
                        v-validate="'required'" data-vv-scope="collection_address">
                        <!-- <option disabled value="">-</option> -->
                        <option v-for="(data, index) in provinces" :key="index" :value="data.id">
                            {{data.value}}</option>
                    </select>
                    <p v-show="errors.has('collection_address.province')" class="help is-danger">{{ errors.first('collection_address.province') }}</p>
                </div>
                <div class="form-group">
                    <label for="gender">Country</label>
                    <select v-model="country" class="form-control" name="country"
                        id="unit" v-bind:class="{ 'is-danger': errors.has('collection_address.country') }"
                        v-validate="'required'" data-vv-scope="collection_address">
                        <!-- <option disabled value="">-</option> -->
                        <option v-for="(data, index) in countries" :key="index" :value="data.id">
                            {{data.value}}</option>
                    </select>
                    <p v-show="errors.has('collection_address.country')" class="help is-danger">{{ errors.first('collection_address.country') }}</p>
                </div>                             
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" @click="closeFormModalAddress">Cancel</button>
                <button type="button" class="btn btn-primary" @click="saveDataAddress">Save</button>
            </div>
        </b-modal>
        <b-modal ref="my-modal-delimit-address" centered hide-header hide-footer no-close-on-backdrop>            
            <div class="modal-body">
                <div class="form-group">
                    <label for="endDate">End Date</label>
                    <flat-pickr v-model="endDate_address" :config="flatPickerConfig" class="form-control"
                        placeholder="Select end date" name="endDate_job" v-bind:class="{ 'is-danger': errors.has('delimit_address.endDate_job')}"
                        v-validate="'required'" data-vv-scope="delimit_address"> </flat-pickr>
                        <p v-show="errors.has('delimit_address.endDate_job')" class="help is-danger"> {{ errors.first('delimit_address.endDate_job') }}</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" @click="closeFormModalDelimitAddress">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataSaveAddress()">Save</button>
            </div>
        </b-modal>
        <!-- end modal address -->

        <!-- modal communication -->
        <b-modal ref="my-modal-communication" size="lg" hide-footer hide-header no-close-on-backdrop title="Create Curriculum">
            <div class="modal-body">                
                <div class="form-group">
                    <label for="startDate">Start Date</label>
                    <flat-pickr v-model="startDate_communication" :config="flatPickerConfig" class="form-control"
                        placeholder="Select start date" name="startDate" v-bind:class="{ 'is-danger': errors.has('collection_communication.startDate')}"
                        v-validate="'required'" data-vv-scope="collection_communication"> </flat-pickr>
                    <p v-show="errors.has('collection_communication.startDate')" class="help is-danger"> {{ errors.first('collection_communication.startDate') }}</p>
                </div>
                <div class="form-group">
                    <label for="endDate">End Date</label>
                    <flat-pickr v-model="endDate_communication" :config="flatPickerConfig" class="form-control"
                        placeholder="Select end date" name="endDate_address" v-bind:class="{ 'is-danger': errors.has('collection_communication.endDate_address')}"
                        v-validate="'required'" data-vv-scope="collection_communication"> </flat-pickr>
                        <p v-show="errors.has('collection_communication.endDate_address')" class="help is-danger"> {{ errors.first('collection_communication.endDate_address') }}</p>
                </div>
                <!-- <div class="form-group">
                    <label for="mentorList.detail.mentor_status.id">Company</label>
                    <select v-model="buscd_communication" class="form-control" name="buscd_address"
                        id="buscd_address" v-bind:class="{ 'is-danger': errors.has('collection_communication.buscd_address') }"
                        v-validate="'required'" data-vv-scope="collection_communication">                        
                        <option v-for="(data, index) in companies" :key="index" :value="data.id">
                            {{data.value}}
                        </option>
                    </select>
                    <p v-show="errors.has('collection_communication.buscd_address')" class="help is-danger">{{ errors.first('collection_communication.buscd_address') }}</p>
                </div>                 -->
                <div class="form-group">
                    <label for="mentorList.detail.mentor_status.id">Communication Type</label>
                    <select v-model="communicationType" class="form-control" name="communicationType"
                        id="buscd_address" v-bind:class="{ 'is-danger': errors.has('collection_communication.communicationType') }"
                        v-validate="'required'" data-vv-scope="collection_communication">                        
                        <option v-for="(data, index) in communicationTypes" :key="index" :value="data.id">
                            {{data.value}}
                        </option>
                    </select>
                    <p v-show="errors.has('collection_communication.communicationType')" class="help is-danger">{{ errors.first('collection_communication.communicationType') }}</p>
                </div>                
                <div class="form-group">
                    <label for="religion">Communication Text</label>
                    <input v-model="communicationText" type="text" name="communicationText"
                        id="bornCity" class="form-control" placeholder="communication text"
                        aria-describedby="bornCity" v-bind:class="{ 'is-danger': errors.has('collection_communication.communicationText')}"
                        v-validate="'required'" data-vv-scope="collection_communication">
                    <p v-show="errors.has('collection_communication.communicationText')" class="help is-danger"> {{ errors.first('collection_communication.communicationText') }}</p>
                </div>                                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" @click="closeFormModalCommunication">Cancel</button>
                <button type="button" class="btn btn-primary" @click="saveDataCommunication">Save</button>
            </div>
        </b-modal>
        <b-modal ref="my-modal-delimit-communication" centered hide-header hide-footer no-close-on-backdrop>            
            <div class="modal-body">
                <div class="form-group">
                    <label for="endDate">End Date</label>
                    <flat-pickr v-model="endDate_communication" :config="flatPickerConfig" class="form-control"
                        placeholder="Select end date" name="endDate_job" v-bind:class="{ 'is-danger': errors.has('delimit_communication.endDate_job')}"
                        v-validate="'required'" data-vv-scope="delimit_communication"> </flat-pickr>
                        <p v-show="errors.has('delimit_communication.endDate_job')" class="help is-danger"> {{ errors.first('delimit_communication.endDate_job') }}</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" @click="closeFormModalDelimitCommunication">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitDataSaveCommunication()">Save</button>
            </div>
        </b-modal>
        <!-- end modal address -->
    </div>
</template>

<script>
    import moment from 'moment'
    import Vue from 'vue';
    import VeeValidate from 'vee-validate';
    import VueSweetalert2 from 'vue-sweetalert2';
    import { mapState, mapActions } from 'vuex'
    Vue.use(VueSweetalert2);
    Vue.use(VeeValidate);
    export default {
        layout: 'mentor',

        data() {
            return {
                jobs: [],
                addresses: [],
                communications: [],
                id_job: null,
                id_address: null,
                id_communication: null,
                object_id_job: null,                
                object_id_address: null,                
                object_id_communication: null,                
                startDate_job: null,
                endDate_job: null,
                startDate_address: null,
                endDate_address: null,
                startDate_communication: null,
                endDate_communication: null,              
                filtersJob : {
                    company: '',
                    begin_date: null,
                    end_date: null,
                    job_name: '',
                    unit_name: '',
                    position_name: '',
                },
                filtersAdd : {
                    begin_date: null,
                    end_date: null,
                    address_type : '',
                    street : '',
                    city : '',
                    province : '',
                    country : '',

                },
                filtersCom : {
                    begin_date: null,
                    end_date: null,
                    communication_type : '',
                    communication_text : '',

                },
                unit: null,
                job: null,
                position:null,
                addressType:null,
                street:'',
                postalCode:null,
                city:null,
                province:null,
                country:null,
                communicationType:null,
                communicationText: '',
                flatPickerConfig: {
                    dateFormat: 'Y-m-d',
                },
                jobMaster: [],
                positionMaster: [],
                unitMaster: [],                                
                cities:[],
                provinces:[],
                countries:[],
                addressTypes:[],                
                communicationTypes:[],    
                companies:[],            
                buscd_job: null,
                buscd_address: null,
                buscd_communication: null
            }
        },
        created() {
            this.$store.dispatch('mentorAddress/getAll');
            this.$store.dispatch('mentorJob/getAll');   
            this.$store.dispatch('mentorCommunication/getAll');               
            
            this.getToday();
            this.getJob()
            this.getAddress();
            this.getCommunication();
            this.getCommunicationType();
            this.getAddressType();
            this.getJobMaster();
            this.getPositionMaster();
            this.getUnitMaster();
            this.getCity();
            this.getProvince();
            this.getCountry();            
            this.getCompany();
        },
        computed: {
            ...mapState({
                mentorList : state => state.mentor,
                addresse: state => state.mentorAddress,
                jobse: state => state.mentorJob,   
                communicationse: state => state.mentorCommunication,   

            }),
        },
        methods: {
            getParamJob(){
            this.getCompany();
            },
            getParamCom(){
            this.getCommunicationType();
            },
            getParamAdd(){
            this.getCountry();
            this.getProvince();
            this.getCity();
            this.getAddressType();
            },
            ...mapActions({
                getAllAddress: 'mentorAddress/getAll',
                getAllCommunication: 'mentorCommunication/getAll',
                getAllJob: 'mentorJob/getAll',
            }),

            
            clearFiltersJob(){
                this.filtersJob = {
                    company: '',
                    job_name: '',
                    unit_name: '',
                    position_name: '',   
                }
                this.getAllJob()
            },
            
            clearFiltersAdd(){
                this.filtersAdd = {
                    address_type:'',
                    street: '',
                    city: '',
                    province: '',
                    country: '',
                }
                this.getAllAddress()
            },
            
            clearFiltersCom(){
                this.filtersCom = {
                    communication_type: '',
                    communication_text: '',
                }
                this.getAllCommunication()
                },

            getJob() {
                this.$axios.get('lms/api/mentorjob?begin_date_lte='+this.today+'&end_date_gte='+this.today+'&mentor[]='+this.mentorList.detail.mentor_id)
                    .then(res => {
                        this.jobs = res.data.data;                        
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },
            runFilterJob() {
                let paramsjob = {}
                if (this.filtersJob.company)
                    paramsjob["business_code[]"] = this.filtersJob.company
                if (this.filtersJob.position_name)
                    paramsjob["position_name[]"] = this.filtersJob.position_name
                if (this.filtersJob.job_name)
                    paramsjob["job_name[]"] = this.filtersJob.job_name
                if (this.filtersJob.unit_name)
                    paramsjob["unit_name[]"] = this.filtersJob.unit_name
                if (this.filtersJob.job_name)
                    paramsjob["job_name[]"] = this.filtersJob.job_name
                if (this.filtersJob.begin_date)
                    paramsjob["begin_date_lte"] = this.filtersJob.begin_date;
                if (this.filtersJob.end_date)
                    paramsjob["end_date_gte"] = this.filtersJob.end_date;

                this.$router.push({ path : this.$route.path , query : paramsjob})
                this.getAllJob(paramsjob)
            },
            getAddress() {
                this.$axios.get('lms/api/mentoraddress?begin_date_lte='+this.today+'&end_date_gte='+this.today+'&mentor[]='+this.mentorList.detail.mentor_id)
                    .then(res => {
                        this.addresses = res.data.data;                        
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },
            runFilterAdd() {
                let paramsadd = {}
                if (this.filtersAdd.address_type)
                    paramsadd["address_type[]"] = this.filtersAdd.address_type
                // if (this.filtersAdd.street)
                //     paramsadd["street[]"] = this.filtersAdd.street
                if (this.filtersAdd.city)
                    paramsadd["city[]"] = this.filtersAdd.city
                if (this.filtersAdd.province)
                    paramsadd["province[]"] = this.filtersAdd.province
                if (this.filtersAdd.country)
                    paramsadd["country[]"] = this.filtersAdd.country
                if (this.filtersAdd.begin_date)
                    paramsadd["begin_date_lte"] = this.filtersAdd.begin_date;
                if (this.filtersAdd.end_date)
                    paramsadd["end_date_gte"] = this.filtersAdd.end_date;

                this.$router.push({ path : this.$route.path , query : paramsadd})
                this.getAllAddress(paramsadd)
            },
            
            getCommunication() {
                this.$axios.get('lms/api/mentorcommunication?begin_date_lte='+this.today+'&end_date_gte='+this.today+'&mentor[]='+this.mentorList.detail.mentor_id)
                    .then(res => {
                        this.communications = res.data.data;                        
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },
            runFilterCom() {
                let paramscom = {}
                if (this.filtersCom.communication_type)
                    paramscom["communication_type[]"] = this.filtersCom.communication_type
                if (this.filtersCom.communication_text)
                    paramscom["communication_text[]"] = this.filtersCom.communication_text
                if (this.filtersCom.begin_date)
                    paramscom["begin_date_lte"] = this.filtersCom.begin_date;
                if (this.filtersCom.end_date)
                    paramscom["end_date_gte"] = this.filtersCom.end_date;

                this.$router.push({ path : this.$route.path , query : paramscom})
                this.getAllCommunication(paramscom)
            },
            getCommunicationType(){
                this.$axios.get('ldap/api/objects?object_type[]=COMTY&business_code[]='+this.mentorList.detail.business_code.business_code)
                    .then(response => {
                        this.communicationTypes = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.communicationTypes.push({
                                id: data.id,
                                value: data.value,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getAddressType(){
                this.$axios.get('ldap/api/objects?object_type[]=ADDTY&business_code[]='+this.mentorList.detail.business_code.business_code)
                    .then(response => {
                        this.addressTypes = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.addressTypes.push({
                                id: data.id,
                                value: data.value,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getJobMaster(){
                this.$axios.get('hcis/api/organization-data?organization_type[]=C&business_code[]='+this.mentorList.detail.business_code.business_code)
                    .then(response => {
                        this.jobMaster = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.jobMaster.push({
                                id: data.organization_code,
                                value: data.organization_name,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getPositionMaster(){
                this.$axios.get('hcis/api/organization-data?organization_type[]=S&business_code[]='+this.mentorList.detail.business_code.business_code)
                    .then(response => {
                        this.positionMaster = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.positionMaster.push({
                                id: data.organization_code,
                                value: data.organization_name,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getUnitMaster(){
                this.$axios.get('hcis/api/organization-data?organization_type[]=O&business_code[]='+this.mentorList.detail.business_code.business_code)
                    .then(response => {
                        this.unitMaster = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.unitMaster.push({
                                id: data.organization_code,
                                value: data.organization_name,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getCity(){
                this.$axios.get('ldap/api/objects?object_type[]=CITY&business_code[]=*&business_code[]='+this.mentorList.detail.business_code.business_code)
                    .then(response => {
                        this.cities = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.cities.push({
                                id: data.id,
                                value: data.value,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getProvince(){
                this.$axios.get('ldap/api/objects?object_type[]=PRVNC&business_code[]=*&business_code[]='+this.mentorList.detail.business_code.business_code)
                    .then(response => {
                        this.provinces = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.provinces.push({
                                id: data.id,
                                value: data.value,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getCountry(){
                this.$axios.get('ldap/api/objects?object_type[]=CONTR&business_code[]=*&business_code[]='+this.mentorList.detail.business_code.business_code)
                    .then(response => {
                        this.countries = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.countries.push({
                                id: data.id,
                                value: data.value,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            }, 
            getCompany(){
                this.$axios.get('hcis/api/company')
                    .then(response => {
                        this.companies = [];
                        response.data.data.forEach(async (data, key) => {
                            await this.companies.push({
                                id: data.business_code,
                                value: data.company_name,
                            })
                        });
                    })
                    .catch(e => {
                        console.log(e);
                    });
            },
            getToday() {
                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth() + 1;
                var yyyy = today.getFullYear();
                if (dd < 10) {
                    dd = '0' + dd;
                }
                if (mm < 10) {
                    mm = '0' + mm;
                }
                this.today = yyyy + '-' + mm + '-' + dd;
            },
            editDataJob(id) {
                this.showModalJob();
                this.getDataDetailJob(id);
            },
            async getDataDetailJob(id) {
                let data = await this.jobs.find(data => data.object_identifier == id);                
                if (this.mentorList.detail.mentor_status.id == 1) {
                    
                    var unit = {id : data.unit_code, value: data.unit_name}
                    var job = {id :data.job_code, value: data.job_name}
                    var position = {id: data.position_code, value: data.position_name}
                } else {
                    
                    var unit = data.unit_name
                    var job = data.job_name
                    var position = data.position_name
                }
                this.object_id_job = data.object_identifier;
                this.buscd_job = {id : data.company_code, value: data.company_name};
                this.unit = unit;
                this.job = job;
                this.position = position;                
                this.startDate_job = data.begin_date;
                this.endDate_job = data.end_date;                
            },
            delimitDataJob(id) {
                this.showModalDelimitJob();
                this.getDataDetailJob(id);
            },
            saveDataJob() {
                this.object_id_job ? this.updateDataJob() : this.storeDataJob();
            },
            storeDataJob() {
                this.$validator.validateAll('collection_job').then(async result => {
                    if (!result) return;
                    if(this.mentorList.detail.mentor_status.id == 2){
                        var unit_code = ' ';
                        var unit_value = this.unit;
                        var job_code = ' ';
                        var job_value = this.job;
                        var position_code = ' ';
                        var position_value = this.position;
                    }else{
                        var unit_code = this.unit.id;
                        var unit_value = this.unit.value
                        var job_code = this.job.id;
                        var job_value = this.job.value;
                        var position_code = this.position.id;
                        var position_value = this.position.value;
                    }
                    this.$axios.post('lms/api/mentorjob', {
                            begin_date: this.startDate_job,
                            end_date: this.endDate_job,
                            mentor: this.mentorList.detail.mentor_id,
                            company_code: this.buscd_job.id,
                            company_name:this.buscd_job.value,
                            unit_code:unit_code,
                            unit_name:unit_value,
                            job_name: job_value,
                            job_code: job_code,
                            position_code:position_code,
                            position_name:position_value,
                            business_code: this.mentorList.detail.business_code.business_code,
                        })
                        .then(response => {
                            this.getJob();
                            this.closeFormModalJob();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            updateDataJob() {
                this.$validator.validateAll('collection_job').then(async result => {
                    if (!result) return;
                    if(this.mentorList.detail.mentor_status.id == 2){
                        var unit_code = ' ';
                        var unit_value = this.unit;
                        var job_code = ' ';
                        var job_value = this.job;
                        var position_code = ' ';
                        var position_value = this.position;
                    }else{
                        var unit_code = this.unit.id;
                        var unit_value = this.unit.value
                        var job_code = this.job.id;
                        var job_value = this.job.value;
                        var position_code = this.position.id;
                        var position_value = this.position.value;
                    }
                    this.$axios.put('lms/api/mentorjob', {
                            object_identifier: this.object_id_job,
                            begin_date: this.startDate_job,
                            end_date: this.endDate_job,
                            mentor: this.mentorList.detail.mentor_id,
                            company_code: this.buscd_job.id,
                            company_name:this.buscd_job.value,
                            unit_code:unit_code,
                            unit_name:unit_value,
                            job_name: job_value,
                            job_code: job_code,
                            position_code:position_code,
                            position_name:position_value,
                            business_code: this.mentorList.detail.business_code.business_code,
                        })
                        .then(response => {
                            this.getJob();
                            this.closeFormModalJob();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            delimitDataSaveJob() {
                this.$validator.validateAll('delimit_job').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/mentorjob?end_date=' + this.endDate_job +
                            '&object_identifier=' + this.object_id_job)
                        .then(response => {
                            this.getJob();
                            this.closeFormModalDelimitJob();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            deleteDataJob(id, key) {
                this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/mentorjob?object_identifier=' + id)
                            .then(response => {
                                this.$swal(
                                    'Deleted!',
                                    response.data.message,
                                    'success'
                                )
                            })
                            .catch(e => {
                                console.log(e);
                            })
                            .then(() => {
                                this.removeDataJob(key);
                            })
                    }
                });
            },
            removeDataJob(key) {
                this.jobs.splice(key, 1);
            },
            showModalJob() {
                this.$refs['my-modal-job'].show()
            },
            hideModalJob() {
                this.$refs['my-modal-job'].hide()
            },
            showModalDelimitJob() {
                this.$refs['my-modal-delimit-job'].show()
            },
            hideModalDelimitJob() {
                this.$refs['my-modal-delimit-job'].hide()
            },
            closeFormModalJob() {
                this.hideModalJob()
                this.object_id_job = null;
                this.buscd_job = null;
                this.unit = null;
                this.job = null;
                this.position = null;                
                this.startDate_job = null;
                this.endDate_job = null;                
                this.$nextTick(() => this.$validator.reset());
            },
            closeFormModalDelimitJob() {
                this.hideModalDelimitJob()
                this.object_id_job = null;
                this.buscd_job = null;
                this.unit = null;
                this.job = null;
                this.position = null;                
                this.startDate_job = null;
                this.endDate_job = null;
                this.$nextTick(() => this.$validator.reset());
            },

            editDataAddress(id) {
                this.showModalAddress();
                this.getDataDetailAddress(id);
            },
            async getDataDetailAddress(id) {
                let data = await this.addresses.find(data => data.object_identifier == id);                
                this.object_id_address = data.object_identifier;
                this.buscd_address = data.business_code.business_code;
                this.addressType = data.address_type.id;
                this.street = data.street;
                this.postalCode = data.postal_code;                
                this.city = data.city.id;
                this.province = data.province.id;
                this.country = data.country.id;
                this.startDate_address = data.begin_date
                this.endDate_address = data.end_date;                
            },
            delimitDataAddress(id) {
                this.showModalDelimitAddress();
                this.getDataDetailAddress(id);
            },
            saveDataAddress() {
                this.object_id_address ? this.updateDataAddress() : this.storeDataAddress();
            },
            storeDataAddress() {
                this.$validator.validateAll('collection_address').then(async result => {
                    if (!result) return;
                    this.$axios.post('lms/api/mentoraddress', {
                            begin_date: this.startDate_address,
                            end_date: this.endDate_address,
                            business_code:this.mentorList.detail.business_code.business_code,
                            mentor:this.mentorList.detail.mentor_id,
                            address_type: this.addressType,
                            street: this.street,
                            postal_code: this.postalCode,
                            city: this.city,
                            province: this.province,
                            country: this.country
                        })
                        .then(response => {
                            this.getAddress();
                            this.closeFormModalAddress();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            updateDataAddress() {
                this.$validator.validateAll('collection_address').then(async result => {
                    if (!result) return;
                    this.$axios.put('lms/api/mentoraddress', {
                            object_identifier: this.object_id_address,
                            begin_date: this.startDate_address,
                            end_date: this.endDate_address,
                            business_code:this.mentorList.detail.business_code.business_code,
                            mentor:this.mentorList.detail.mentor_id,
                            address_type: this.addressType,
                            street: this.street,
                            postal_code: this.postalCode,
                            city: this.city,
                            province: this.province,
                            country: this.country
                        })
                        .then(response => {
                            this.getAddress();
                            this.closeFormModalAddress();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            delimitDataSaveAddress() {
                this.$validator.validateAll('delimit_address').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/mentoraddress?end_date=' + this.endDate_address +
                            '&object_identifier=' + this.object_id_address)
                        .then(response => {
                            this.getAddress();
                            this.closeFormModalDelimitAddress();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            deleteDataAddress(id, key) {
                this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/mentoraddress?object_identifier=' + id)
                            .then(response => {
                                this.$swal(
                                    'Deleted!',
                                    response.data.message,
                                    'success'
                                )
                            })
                            .catch(e => {
                                console.log(e);
                            })
                            .then(() => {
                                this.removeDataAddress(key);
                            })
                    }
                });
            },
            removeDataAddress(key) {
                this.addresses.splice(key, 1);
            },
            showModalAddress() {
                this.$refs['my-modal-address'].show()
            },
            hideModalAddress() {
                this.$refs['my-modal-address'].hide()
            },
            showModalDelimitAddress() {
                this.$refs['my-modal-delimit-address'].show()
            },
            hideModalDelimitAddress() {
                this.$refs['my-modal-delimit-address'].hide()
            },
            closeFormModalAddress() {
                this.hideModalAddress()
                this.object_id_address = null;
                this.buscd_address = null;
                this.addressType = null;
                this.street = null;
                this.postalCode = null;                
                this.city = null;
                this.province = null;
                this.country = null;
                this.startDate_address = null;
                this.endDate_address = null;                
                this.$nextTick(() => this.$validator.reset());
            },
            closeFormModalDelimitAddress() {
                this.hideModalDelimitAddress()
                this.object_id_address = null;
                this.buscd_address = null;
                this.addressType = null;
                this.street = null;
                this.postalCode = null;                
                this.city = null;
                this.province = null;
                this.country = null;
                this.startDate_address = null;
                this.endDate_address = null;
                this.$nextTick(() => this.$validator.reset());
            },
           
            editDataCommunication(id) {
                this.showModalCommunication();
                this.getDataDetailCommunication(id);
            },
            async getDataDetailCommunication(id) {
                let data = await this.communications.find(data => data.object_identifier == id);                
                this.object_id_communication = data.object_identifier;
                this.buscd_communication = data.business_code.business_code;
                this.communicationType = data.communication_type.id;
                this.communicationText = data.communication_text;                
                this.startDate_communication = data.begin_date;
                this.endDate_communication = data.end_date;
            },
            delimitDataCommunication(id) {
                this.showModalDelimitCommunication();
                this.getDataDetailCommunication(id);
            },
            saveDataCommunication() {
                this.object_id_communication ? this.updateDataCommunication() : this.storeDataCommunication();
            },
            storeDataCommunication() {
                this.$validator.validateAll('collection_communication').then(async result => {
                    if (!result) return;
                    this.$axios.post('lms/api/mentorcommunication', {
                            begin_date: this.startDate_communication,
                            end_date: this.endDate_communication,
                            business_code:this.mentorList.detail.business_code.business_code,
                            mentor:this.mentorList.detail.mentor_id,                            
                            communication_type: this.communicationType,
                            communication_text: this.communicationText
                        })
                        .then(response => {
                            this.getCommunication();
                            this.closeFormModalCommunication();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            updateDataCommunication() {
                this.$validator.validateAll('collection_communication').then(async result => {
                    if (!result) return;
                    this.$axios.put('lms/api/mentorcommunication', {
                            object_identifier: this.object_id_communication,
                            begin_date: this.startDate_communication,
                            end_date: this.endDate_communication,
                            business_code:this.mentorList.detail.business_code.business_code,
                            mentor:this.mentorList.detail.mentor_id,                            
                            communication_type: this.communicationType,
                            communication_text: this.communicationText
                        })
                        .then(response => {
                            this.getCommunication();
                            this.closeFormModalCommunication();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            delimitDataSaveCommunication() {
                this.$validator.validateAll('delimit_communication').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/mentorcommunication?end_date=' + this.endDate_communication +
                            '&object_identifier=' + this.object_id_communication)
                        .then(response => {
                            this.getCommunication();
                            this.closeFormModalDelimitCommunication();
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e);
                        });
                });
            },
            deleteDataCommunication(id, key) {
                this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/mentorcommunication?object_identifier=' + id)
                            .then(response => {
                                this.$swal(
                                    'Deleted!',
                                    response.data.message,
                                    'success'
                                )
                            })
                            .catch(e => {
                                console.log(e);
                            })
                            .then(() => {
                                this.removeDataCommunication(key);
                            })
                    }
                });
            },
            removeDataCommunication(key) {
                this.communications.splice(key, 1);
            },
            showModalCommunication() {
                this.$refs['my-modal-communication'].show()
            },
            hideModalCommunication() {
                this.$refs['my-modal-communication'].hide()
            },
            showModalDelimitCommunication() {
                this.$refs['my-modal-delimit-communication'].show()
            },
            hideModalDelimitCommunication() {
                this.$refs['my-modal-delimit-communication'].hide()
            },
            closeFormModalCommunication() {
                this.hideModalCommunication()
                this.object_id_communication = null;
                this.buscd_communication = null;
                this.communicationType = null;
                this.communicationText = '';                
                this.startDate_communication = null;
                this.endDate_communication = null;
                this.$nextTick(() => this.$validator.reset());
            },
            closeFormModalDelimitCommunication() {
                this.hideModalDelimitCommunication()
                this.object_id_communication = null;
                this.buscd_communication = null;
                this.communicationType = null;
                this.communicationText = '';                
                this.startDate_communication = null;
                this.endDate_communication = null;
                this.$nextTick(() => this.$validator.reset());
            },
            moment(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },
    }

</script>

<style scoped>
</style>