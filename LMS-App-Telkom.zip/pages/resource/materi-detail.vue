<template>

    <div class="container page-section">

        <b>
            <p style="font-size:20px">Materi Detail</p>
        </b>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{ materi.materi_name }}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Type</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.materi_type.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Method</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.method.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Competence</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.competence.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Proficiency Level</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.pl_code.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Selling Price</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>Rp {{materi.selling_price}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Purchase Price</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>Rp {{materi.purchase_price}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Link</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.address}} <i class="fa fa-download"></i></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Description</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.description}}</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</template>
<script>
    import {mapState, mapActions} from 'vuex'
    export default {
        layout: 'home',
        components: {

        },
        middleware: ({ store, redirect }) => {
        if (!store.state.materi.detail) return redirect('/resource')
    },
        data() {
            return {
                materi_name: '',
                materi_type: '',
                method: '',
                competence: '',
                pl_code: '',
                selling_price: '',
                purchase_price: '',
                address: '',
                description: '',
                materi_id : null
            };

        },
        computed: {
        ...mapState({
            materi : state => state.materi.detail,
        })
    },
        methods: {
            // panggilapi() {

            //     this.$store.dispatch('materi/getAll', {
            //         'materi_id[]' : this.materi_id,
            //         asdasd : 'asdsad'
            //     })
            // }
            // getMateriDetail() {
            //     this.$axios
            //         .get(
            //             "lms/api/materi?materi_id[]="+this.materi_id
            //         )
            //         .then(res => {
            //             this.materi_name    = res.data.data.materi_name;
            //             this.materi_type    = res.data.data.materi_type.value;
            //             this.method         = res.data.data.method.value;
            //             this.competence     = res.data.data.competence.value;
            //             this.pl_code        = res.data.data.pl_code.value;
            //             this.selling_price  = res.data.data.selling_price;
            //             this.purchase_price = res.data.data.purchase_price;
            //             this.address        = res.data.data.address;
            //             this.description    = res.data.data.description;
            //         })
            //         .catch(e => {
            //             console.log(e);
            //         });
            // },
        }

    };
</script>