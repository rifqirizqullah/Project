<template>
    <div class="container page-section">

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{ bank.question_name }} -
                        {{ bank.question_type.value }}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-lg-3">
                        <small>Text - Score</small>
                        <p>{{ bank.question_text }} - {{bank.score}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Competence</small>
                        <p>{{ bank.competence.value }}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>PL Code</small>
                        <p>{{ bank.pl_code.value }}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Begin/End Date</small>
                        <p>{{ formatDate(bank.begin_date) }} - {{ formatDate(bank.end_date) }}</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-info d-flex justify-content-between align-items-center">
                <h4 class="card-title">List Choice Test</h4>
                <span>
                <button @click="clearDetail(); $bvModal.show('choiceTestForm')" class="btn btn-success btn-sm">
                    + Create New
                </button>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span>
            </div>
            <div class="">
                <div class="text-right">
                    <div class="bg-white">
                        <!-- Elements to collapse -->
                        <b-collapse id="collapse-a" class="mt-2 p-4">
                            <form action="">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <input v-model="filters.text_choice" type="text" class="form-control" id="Text Choice" placeholder="Text Choice">
                                            <small>Text Choice</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <input v-model="filters.sequence_no" type="text" class="form-control" id="Sequence Number" placeholder="Sequence Number">
                                            <small>Sequence Number</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <input v-model="filters.score" type="text" class="form-control" id="score" placeholder="Score">
                                            <small>Score</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <select v-model="filters.flag_true" class="form-control" name="flag_true" id="flag_true">
                                                <option :value="true">true</option>
                                                <option :value="false">false</option>
                                            </select>
                                            <small>Flag</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters = {}; runFilter()" variant="secondary" >Clear Filter</b-button>
                                            <b-button @click="runFilter" variant="info" >
                                                <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                            </b-button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </b-collapse>
                    </div>
                </div>
            </div>
            <div class="">
                <table class="table table-hover table-flush table-responsive">
                    <thead class="">
                        <tr>
                            <th>No</th>
                            <th>Text Choice</th>
                            <th>Sequence Number</th>
                            <th>Score</th>                            
                            <th>Flag</th>                            
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item , index) in choice.list" :key="index">
                            <td>{{ index + 1 }}</td>                            
                            <td>{{ item.text_choice }}</td>
                            <td>{{ item.sequence_no }}</td>
                            <td>{{ item.score }}</td>
                            <td>{{ item.flag_true }}</td>
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                        <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier)">Delimit</button>                                        
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="choice.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <b-modal v-model="modalShow" ref="choiceTestForm" hide-footer hide-header id="choiceTestForm" size="lg">
                <choiceTestForm v-if="modalShow" />
            </b-modal>

            <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
                <div class="form-group">
                    <label for="begin_date">Begin Date</label>
                    <flat-pickr v-model="begin_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                        placeholder="Select end date" name="date"
                        v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}" v-validate="'required'"
                        data-vv-scope="delimit" disabled> </flat-pickr>
                    <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                </div>

                <div class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                        placeholder="Select end date" name="date"
                        v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}" v-validate="'required'"
                        data-vv-scope="delimit"> </flat-pickr>
                    <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                        {{ errors.first('delimit.end_date') }}</p>
                </div>
                <div slot="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        @click="$bvModal.hide('modalDelimit')">Cancel</button>
                    <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
                </div>
            </b-modal>

            <div class="card-footer">
                <paginationBar :state='choice' :storeModuleName="'choice'" />
            </div>
        </div>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import choiceTestForm from '@@/components/forms/choiceTestForm'
    import { mapState, mapActions } from 'vuex'

    export default {
        layout: 'resources',
        components: { choiceTestForm, paginationBar },
        middleware: ({ store, redirect }) => {
            if (!store.state.testquestionbank.detail) return redirect('/resource')
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,

                begin_date: null,
                end_date: null,    
                page_number: null,
                filters : {
                    text_choice : null,
                    sequence_no: null,
                    begin_date: null,
                    end_date: null,
                    flag_true: null,
                    score: null,

                }
            }
        },
        async created() {
            this.$store.dispatch('test_question_choice/getAll', { 'question[]' : this.bank.question_id });
        },
        computed: {
            ...mapState({
                bank: state => state.testquestionbank.detail,
                choice: state => state.test_question_choice,
            })
        },
        methods: {
            getParam(){
                
            },
            ...mapActions({
                getDetail: 'test_question_choice/getDetail',
                clearDetail: 'test_question_choice/clearDetail',
                deleteOne: 'test_question_choice/deleteOne',
                getAll: 'test_question_choice/getAll',
            }),
            runFilter(){
                let params = {'question[]' : this.bank.question_id}
                if (this.filters.text_choice)
                    params["text_choice[]"] = this.filters.text_choice
                if (this.filters.sequence_no)
                    params["sequence_no[]"] = this.filters.sequence_no
                if (this.filters.score)
                    params["score[]"] = this.filters.score
                if (this.filters.flag_true !== null)
                    params["flag_true[]"] = this.filters.flag_true
                
                if (this.filters.begin_date)
                    params["begin_date_lte"] = this.filters.begin_date;
                if (this.filters.end_date)
                    params["end_date_gte"] = this.filters.end_date;

                this.$router.push({ path : this.$route.path , query : params})
                this.getAll(params)

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearFilters(){
                this.filters = {
                    text_choice: null,
                    sequence_no: null,
                    score: null,
                    flag_true: null,
                }

            },
            
            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('choiceTestForm')
            },
            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.choice.detail.begin_date
                this.end_date = moment(new Date()).format("YYYY-MM-DD")
                this.$bvModal.show('modalDelimit')
            },
            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/testquestionchoice?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },
            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/testquestionchoice', {}, {
                            params: {
                                object_identifier: this.choice.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('test_question_choice/getAll', { 'question[]' : this.bank.question_id });
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
