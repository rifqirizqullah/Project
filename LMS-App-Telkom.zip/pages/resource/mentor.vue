<template>
    <div class="container page-section">

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h4 class="card-title"  style="font-size:25px;color:black">Mentor Management</h4>
                <p style="font-size:15px;margin-top:-15px">Manage All Mentor</p>
            </div>
            <button class="btn btn-sm btn-success" @click="$bvModal.show('mentorForm')" >+ Create Mentor</button>
            <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
            </b-button>
        </div>

        <div class="">
            <div class=" text-right">
                <div class="bg-white">
                    <b-collapse id="collapse-a" class="mt-2">
                        <form class="p-3">
                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                        <input v-model="filters.mentor_name" type="text" name="mentor_name"
                                            id="mentor_name" class="form-control" placeholder="mentor_name">
                                        <small class="form-text text-muted">Mentor Name</small>
                                    </div>
                                </div>

                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group text-right">
                                        <b-button @click="filters = {}; runFilter()" variant="secondary" >Clear Filter</b-button>
                                        <b-button @click="runFilter" variant="info" >
                                            <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                        </b-button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </b-collapse>
                </div>
            </div>
        </div>

        <div class="card">
            <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr>
                    <th>Personal Number</th>
                    <th>Name</th>
                    <th>Company</th>
                    <th>Mentor Status</th>                            
                    <th>Begin Date</th>
                    <th>End Date</th>                                                        
                    <th>Action</th>
                </tr>
            </thead>
            <tbody v-if="mentor">
                <tr v-for="(data , index) in mentor.list" :key="index">
                    <td>{{data.personnel_number}}</td>
                    <td>{{data.mentor_name}}</td>
                    <td>{{data.company.company_name}}</td>
                    <td>{{data.mentor_status.value}}</td>
                    <td>{{formatDate(data.begin_date)}}</td>
                    <td>{{formatDate(data.end_date)}}</td> 
                    <td>
                        <div class="btn-group">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                <button v-if="data.mentor_status.id == '02'" class="dropdown-item" @click="showUpdateForm(data.object_identifier)">Update</button>
                                <button class="dropdown-item" @click="deleteData(data.object_identifier, index)">Delete</button>
                                <button class="dropdown-item" @click="showDelimitForm(data.object_identifier)">Delimit</button>
                                <button
                      class="dropdown-item"
                      @click="getDetail(data.object_identifier); $router.push('/resource/detail-mentor')"
                    >Detail</button>
                            </div>
                        </div>
                    </td>
                </tr>
                 <tr v-if="mentor.isLoading" >
                    <td colspan="10">
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </td>
                </tr>

            </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='mentor' :storeModuleName="'mentor'" />
            </div>

        </div>

        <b-modal v-model="modalShow" ref="mentorForm" hide-footer hide-header id="mentorForm" size="lg">
            <mentorForm v-if="modalShow" />
        </b-modal>

        <b-modal
            v-model="modalDelimitShow"
            id="modalDelimit"
            centered
            title="Delimit Data"
            header-bg-variant="light"
            size="sm"
            >
            <div class="col-12">
                <div class="form-group">
                <label for="begin_date">Start Date</label>
                <div class="form-control">
                    <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
                </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date"
                    :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                    class="form-control"
                    placeholder="Select end date"
                    name="end_date"
                    id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'"
                    data-vv-scope="collection"
                />
                <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
                <p
                    v-show="errors.has('collection.end_date')"
                    class="help is-danger"
                >{{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button
                type="button"
                class="btn btn-secondary"
                @click="$bvModal.hide('modalDelimit')"
                >Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import mentorForm from '@@/components/forms/mentorForm'
import paginationBar from '@@/components/paginationBar'

import { mapState, mapActions } from 'vuex'

export default {
    
    components: {
        mentorForm, paginationBar
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow: false,

            end_date: null,
            begin_date: null,

            filters : {
                mentor_name : null,
            },
            // orgAsg:[]
        }
    },
    created() {
        this.$store.dispatch('mentor/getAll');        
    },
    computed: {
        ...mapState({
            mentor : state => state.mentor,            
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'mentor/getDetail',
            clearDetail: 'mentor/clearDetail',
            deleteOne: 'mentor/deleteOne',
            getAll: 'mentor/getAll',
        }),

        getJobComAdd(){
            if(this.mentor.detail.mentor_status.id == '01'){                    
                 this.$axios
                    .get(
                        "hcis/api/organization-assignment?begin_date_lte=" +
                        moment(new Date()).format("YYYY-MM-DD") +
                        "&end_date_gte=" +
                        moment(new Date()).format("YYYY-MM-DD") +
                        "&personnel_number[]=" +
                        this.mentor.detail.personnel_number + "&business_code[]=" +this.mentor.detail.business_code.business_code
                        )
                        .then(async response => {       
                        this.orgAsg = []             
                        this.orgAsg = response.data.data
                    })
                        .catch(e => {
                        console.log(e);
                    });
                    this.orgAsg.forEach(async (item, key) => {                        
                        this.$axios.post('lms/api/mentorjob', {
                            business_code : this.business_code,                
                            begin_date : item.begin_date,
                            end_date : item.end_date,                        
                            mentor: this.mentor.detail.mentor_id,
                            company_code: item.business_code.business_code,
                            company_name:item.business_code.company_name,
                            unit_code: item.unit.organization_code,
                            unit_name:item.unit.organization_name,
                            job_name: item.job.organization_code,
                            job_code: item.job.organization_name,
                            position_code:item.position.organization_code,
                            position_name:item.position.organization_name
                        })
                    })
                    
                }
        },
        runFilter(){
            let params = {}
            if (this.filters.mentor_name)
                params["mentor_name[]"] = this.filters.mentor_name

            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params)
        },

        clearFilters(){
            this.filters = {
                mentor_name : null,
            }
        },

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('mentorForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.mentor.detail.begin_date
            this.end_date = this.mentor.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                })
                .then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/mentor?object_identifier=' + id)
                            .then(response => {
                                return this.$swal('Deleted!', response.data.message, 'success')
                            })
                            .then((result) => {
                                this.deleteOne(index)
                            })
                            .catch(e => {
                                console.log(e.response);
                            })
                    }
                });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/mentor', {}, {
                        params: {
                            object_identifier: this.mentor.detail.object_identifier,
                            end_date: this.end_date,
                        }
                    })
                    .then(response => {
                        this.$store.dispatch('mentor/getAll');
                        this.$bvModal.hide('modalDelimit')
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                    })
                    .catch(e => {
                        console.log(e.response);
                    });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}

</script>
