<template>
    <div class="container page-section">
        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{object.value}}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-lg-3">
                        <small>Object Identifier</small>
                        <p>{{object.object_identifier}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Begin/End Date</small>
                        <p>{{formatDate(object.begin_date)}} - {{formatDate(object.end_date)}}</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Template Quesioner</h4>
            </div>
            <div class="card-body">
                        <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr>
                    <th>No</th>
                    <th>Company</th>
                    <th>Title</th>
                    <th>Text</th>
                    <!-- <th>Type</th> -->
                    <th>Category</th>
                    <th>Purpose</th>
                    <th>Choices</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(item , index) in templateQuestioner.list" :key="index">
                   <td>{{index +1}}</td>
                    <td>{{item.business_code.company_name}}</td>
                    <td>{{item.id.quesioner_title}}</td>
                    <td>{{item.id.quesioner_text}}</td>
                    <td>{{item.id.quesioner_type.value}}</td>
                    <td>{{item.id.quesioner_category.value}}</td>
                    <td>{{item.id.quesioner_purpose.value}}</td>
                    <td>{{item.id.number_of_choice}}</td>
                    <td>
                        <div class="dropdown d-sm-flex">
                            <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                <!-- <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button> -->
                                <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                            </div>
                        </div>
                    </td>
                </tr>
                 <tr v-if="templateQuestioner.isLoading" >
                    <td colspan="10">
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </td>
                </tr>

            </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='templateQuestioner' :storeModuleName="'templateQuestioner'" />
            </div>

            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">All Template Questioner</h4>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                    <tr>
                    <th>No</th>
                    <th>Company</th>
                    <th>Title</th>
                    <th>Text</th>
                    <th>Type</th>
                    <th>Category</th>
                    <th>Purpose</th>
                    <th>Choices</th>
                    <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in questioner.list" :key="index">
                            <td>{{index +1}}</td>
                            <td>{{item.business_code.company_name}}</td>
                            <td>{{item.quesioner_title}}</td>
                            <td>{{item.quesioner_text}}</td>
                            <td>{{item.quesioner_type.value}}</td>
                            <td>{{item.quesioner_category.value}}</td>
                            <td>{{item.quesioner_purpose.value}}</td>
                            <td>{{item.number_of_choice}}</td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.quesioner_id)">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="questioner.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='questioner' :storeModuleName="'questioner'" />
            </div>
        </div>
    <b-modal id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <flat-pickr v-model="begin_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date"
                    v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}" v-validate="'required'"
                    data-vv-scope="delimit" disabled> </flat-pickr>
                <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                    {{ errors.first('delimit.begin_date') }}</p>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date"
                    v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}" v-validate="'required'"
                    data-vv-scope="delimit"> </flat-pickr>
                <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                    {{ errors.first('delimit.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

        <b-modal id="modalAll" centered title="Add Schedule Questioner" size="md">           

            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalAll')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addQuestioner">Save</button>
            </div>
        </b-modal>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import {
        mapState,
        mapActions
    } from 'vuex'

    export default {
        layout: 'resources',
        components: {
            paginationBar
        },
        async created() {
            await this.$store.dispatch('templateQuestioner/getAll', { 'object' : [this.object.id] });
            await this.$store.dispatch('questioner/getAll');
            // await this.$store.dispatch('TPLCD/getAll')
            // await this.$store.dispatch('TPLTY/getAll')

        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                business_code: null,
                begin_date: null,
                end_date: null,
                test:null,

                type:this.$route.query.type
            }
        },
        computed: {
            object(){
                return this.$store.state.object.detail
            },
            ...mapState(['templateQuestioner', 'questioner', 'TPLCD', 'TPLTY'])
        },
        methods: {
            ...mapActions({
                getDetail: 'templateQuestioner/getDetail',

                deleteOne: 'templateQuestioner/deleteOne',
            }),
            addQuestioner() {
                this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/lmsrelationobject', {                            
                            table_code : "QUESN",
                            id : this.test,
                            relation : "Q001",
                            otype : "TPLCD",
                            object : this.object.id,
                            business_code: this.object.business_code.business_code,
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                        })
                        .then(() => {
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('templateQuestioner/getAll', {'object[]' : this.object.id});
                            this.$bvModal.hide('modalAll')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },
            async submit(object_identifier) {
                    this.end_date = null
                    this.begin_date = null
                    this.$validator.reset('collection')
                    this.test= object_identifier
                    this.$bvModal.show('modalAll')
            },


             async showDelimitForm(object_identifier,begin) {
                await this.getDetail(object_identifier)
                this.begin_date = this.templateQuestioner.detail.begin_date
                this.end_date = moment(new Date()).format("YYYY-MM-DD")
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/lmsrelationobject?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/lmsrelationobject', {}, {
                            params: {
                                object_identifier: this.templateQuestioner.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('templateQuestioner/getAll',{'object[]':this.object.id});
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
