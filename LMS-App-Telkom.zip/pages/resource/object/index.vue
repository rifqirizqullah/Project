<template>
    <div class="container page-section">

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h3 class="card-title">Object Management</h3>
                <p style="font-size:15px;margin-top:-15px">Manage All Object</p>
            </div>
            <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i> Search</span>
            </b-button>
        </div>

        <div class="">
            <div class=" text-right">
                <div class="bg-white">
                    <b-collapse id="collapse-a" class="mt-2">
                        <form class="p-2">
                            <div class="row">
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                        <select v-model="filters.object_type" class="form-control" name="object_type" id="object_type">
                                            <option v-for="(item, index) in otype.list" :key="index"
                                                :value="item.object_type.object_type">
                                                {{ item.object_type.object_type }}</option>
                                        </select>
                                        <small class="form-text text-muted">Object Type</small>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-3">
                                    <div class="form-group">
                                        <input v-model="filters.object_type" type="text" name="object_type2" id="object_type2" class="form-control">
                                        <small class="form-text text-muted">Object Type</small>
                                    </div>
                                </div>

                                <div class="col-sm-12 col-md-12">
                                    <div class="form-group text-right">
                                        <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter
                                        </b-button>
                                        <b-button @click="runFilter" variant="info">
                                            <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                        </b-button>
                                    </div>
                                </div>

                            </div>
                        </form>
                    </b-collapse>
                </div>
            </div>
        </div>

        <div class="card">
          <table class="table table-hover table-flush table-responsive">
            <thead>
              <tr>
                <th>No</th>
                <th>Company</th>
                <th>Type</th>
                <th>Name</th>
                <th>Begin Date</th>
                <th>End Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody class="list">
              <tr v-for="(item, index) in otype.list" :key="index">
                <td>{{index+1}}</td>
                <td>{{item.business_code.company_name}}</td>
                <td>{{item.object_type.object_type}}</td>
                <td>{{item.object_type.object_name}}</td>
                <td>{{formatDate(item.begin_date)}}</td>
                <td>{{formatDate(item.end_date)}}</td>
                <td>
                    <button class="btn btn-info btn-sm" @click="getDetail(item.object_identifier); $router.push('/resource/object/detail?otype='+item.object_type.object_type)">Detail</button>
                </td>
              </tr>
              <tr v-if="otype.isLoading">
                <td colspan="10">
                  <div class="row">
                    <div class="col d-flex justify-content-center">
                      <div class="loader loader-accent text-center"></div>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="card-footer">
            <paginationBar :state="otype" :storeModuleName="'otype'"/>
          </div>
        </div>

    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import { mapState, mapActions } from 'vuex'

    export default {
        layout: 'resources',
        components: {
            paginationBar
        },
        fetch({ store, params }) {
            store.dispatch('otype/getAll')
        },
        data() {
            return {
                end_date: null,
                begin_date: null,

                filters: {
                    object_type: null,
                    per_page: 20,
                }
            }
        },
        computed: {
            ...mapState({
                otype: state => state.otype,
            })
        },
        methods: {
            ...mapActions({
                getDetail: 'otype/getDetail',
                clearDetail: 'otype/clearDetail',
                deleteOne: 'otype/deleteOne',
                getAll: 'otype/getAll',
            }),

            runFilter() {
                let params = {}
                if (this.filters.object_type)
                    params["object_type[]"] = this.filters.object_type
                this.getAll(params)
            },

            clearFilters() {
                this.filters = {
                    object_type: null
                }
            },

            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            },
        },

    }

</script>
