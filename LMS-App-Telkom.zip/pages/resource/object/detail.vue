<template>
    <div class="container page-section">

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{ otype.object_type.object_type }} -
                        {{ otype.object_type.object_name }}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-lg-3">
                        <small>Company</small>
                        <p>{{ otype.business_code.company_name }}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Object Type</small>
                        <p>{{ otype.object_type.object_type }}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Object Name</small>
                        <p>{{ otype.object_type.object_name }}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Begin/End Date</small>
                        <p>{{ formatDate(otype.begin_date) }} - {{ formatDate(otype.end_date) }}</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-info d-flex justify-content-between align-items-center">
                <h4 class="card-title">List Object</h4>
            <span>
                <button @click="clearDetail(); $bvModal.show('objectForm')" class="btn btn-success btn-sm">
                    + Create New {{ otype.object_type.object_name }}
                </button>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                <i class="fa fa-search"></i> Search         
                </b-button>
            </span>
            </div>

            <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
		
		<div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.short_text"
                        type="text"
                        class="form-control"
                        id="short_text"
                        placeholder="ID..."
                        >
                        <small class="form-text text-muted">ID</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.long_text"
                        type="text"
                        class="form-control"
                        id="long_text"
                        name="long_text"
                        placeholder="Name"
                        >
                        <small class="form-text text-muted">Name</small>
                    </div>
                </div>
                
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters.company" class="form-control" name="company" id="company">
                        <option
                          v-for="(item, index) in company.list"
                          :key="index"
                          :value="item.business_code"
                        >{{item.company_name}}</option>
                    </select>
                    <small class="form-text text-muted">Company</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.object_description"
                        type="text"
                        class="form-control"
                        id="object_description"
                        name="object_description"
                        placeholder="Object Description"
                        >
                        <small class="form-text text-muted">Object Description</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

            <div class="">
                <table class="table table-hover table-flush table-responsive">
                    <thead class="">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Company Name</th>
                            <th>Description</th>
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item , index) in object.list" :key="index">
                            <td>{{ item.id }}</td>
                            <td>{{ item.value }}</td>
                            <td>{{ item.business_code.company_name }}</td>
                            <td>{{ item.object_description }}</td>
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                        <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                        <button v-if="otype_param =='TSTCD'" class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/resource/object/template-test')">Detail</button>
                                        <button v-if="otype_param =='TPLCD'" class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/resource/object/template-quesioner')">Detail</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="object.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <b-modal v-model="modalShow" ref="objectForm" hide-footer hide-header id="objectForm" size="lg">
                <objectForm v-if="modalShow" />
            </b-modal>

            <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
                <div class="form-group">
                    <label for="begin_date">Begin Date</label>
                    <flat-pickr v-model="begin_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                        placeholder="Select end date" name="date"
                        v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}" v-validate="'required'"
                        data-vv-scope="delimit" disabled> </flat-pickr>
                    <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                </div>

                <div class="form-group">
                    <label for="end_date">End Date</label>
                    <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                        placeholder="Select end date" name="date"
                        v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}" v-validate="'required'"
                        data-vv-scope="delimit"> </flat-pickr>
                    <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                        {{ errors.first('delimit.end_date') }}</p>
                </div>
                <div slot="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        @click="$bvModal.hide('modalDelimit')">Cancel</button>
                    <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
                </div>
            </b-modal>

            <div class="card-footer">
                <paginationBar :state='object' :storeModuleName="'object'" />
            </div>
        </div>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import objectForm from '@@/components/forms/objectForm'
    import { mapState, mapActions } from 'vuex'

    export default {
        layout: 'resources',
        components: { objectForm, paginationBar },
        middleware: ({ store, redirect }) => {
            if (!store.state.object) return redirect('/object')
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,

                begin_date: null,
                end_date: null,
                otype_param:this.$route.query.otype,
                filters: {
		    short_text: null,
                    long_text: null,
                    company: null,
                    object_description: null,
                    begin_date: null,
                    end_date: null
                }
            };
        },
        async created() {
            this.$store.dispatch('object/getAll');
            this.$store.dispatch('company/getAll');
            //this.$store.dispatch('object/clearAll');
        },
        computed: {
            ...mapState({
                otype: state => state.otype.detail,
                object: state => state.object,
                company : state => state.company,
            })
        },
        methods: {
            getParam(){

            },
            ...mapActions({
                getDetail: 'object/getDetail',
                clearDetail: 'object/clearDetail',
                deleteOne: 'object/deleteOne',
                getAll: 'object/getAll',
            }),
            runFilter() {
            let params = {};
            if (this.filters.company)
                params["business_code"] = [this.filters.company];
	    if (this.filters.short_text)
            	params["short_text[]"] = this.filters.short_text
            if (this.filters.long_text)
                params["long_text[]"] = this.filters.long_text;
            if (this.filters.object_description)
                params["object_description[]"] = this.filters.object_description;
            if (this.filters.begin_date)
                params["begin_date_lte"] = this.filters.begin_date;
            if (this.filters.end_date)
                params["end_date_gte"] = this.filters.end_date;
                this.$router.push({ path : this.$route.path , query : params})
                this.getAll(params);
            },
            clearFilters() {
                this.filters = {
                    company: null,
                    long_text: null,
		    short_text : null,
                    object_description: null,
                };
            },
            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('objectForm')
            },
            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.object.detail.begin_date
                this.end_date = this.object.detail.end_date
                this.$bvModal.show('modalDelimit')
            },
            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('ldap/api/objects?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },
            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('ldap/api/objects', {}, {
                            params: {
                                object_identifier: this.object.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('object/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
