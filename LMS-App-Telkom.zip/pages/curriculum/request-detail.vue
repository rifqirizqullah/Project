<template>
    <div class="container page-section">

        <h1 class="display-4">Request Detail</h1>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{curriculumRequest.request_name}}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Company</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{curriculumRequest.business_code.company_name }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Request Type</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{curriculumRequest.request_type.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Begin/End Date</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>{{formatDate(curriculumRequest.begin_date)}} - {{formatDate(curriculumRequest.end_date)}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Proficiency Level</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{curriculumRequest.pl_code.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Competence</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{curriculumRequest.competence.value}}</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Description</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{curriculumRequest.request_description}}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        

    </div>
</template>

<script>
import moment from 'moment'
import paginationBar from '@@/components/paginationBar'
import {mapState, mapActions} from 'vuex'

export default {
    layout : 'curriculum',
    components : { paginationBar },
    middleware: ({ store, redirect }) => {
        if (!store.state.curriculumRequest.detail) return redirect('/curriculum/request')
    },
    created() {     
        // this.$store.dispatch('curriculumRequest/getAll',{learningpath:[this.LPTID.id]});           
    },
     data() {
        return {        
            modalShow: false,    
            begin_date : null,
            end_date : null,
            
        }
    },
    computed: {
        ...mapState({
            curriculumRequest: state => state.curriculumRequest.detail
        })
    },
    methods: {
        
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
