<template>
    <div class="container page-section">

        <h1 class="display-4">Learning Path Detail</h1>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{LPTID.value}}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Company</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{LPTID.business_code.company_name }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Object Code</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{LPTID.id}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Begin/End Date</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>{{formatDate(LPTID.begin_date)}} - {{formatDate(LPTID.end_date)}}</p>
                            </div>
                        </div>
                    </div> 
                    
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Description</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{LPTID.object_description}}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <span>
                    <h4 class="card-title">Learning Path</h4>
                    <p class="card-subtitle">List of Available Activity</p>
                </span>
                <span>
                    <button @click="clearDetail(); $bvModal.show('learningPathForm')" class="btn btn-success btn-sm">+ Create Curriculum</button>  
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>      
                </span>  
            </div>     

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.curriculum"
                      class="form-control"
                      name="curriculum"
                      id="curriculum"
                    >
                      <option
                        v-for="(item, index) in CURID.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Curriculum</small>
                  </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.sequence"
                        type="text"
                        class="form-control"
                        id="sequence"
                        placeholder="sequence"
                        >
                        <small class="form-text text-muted">Sequence</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>       
            <table class="table table-responsive table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Curriculum</th>
                        <th>Sequence</th>
                        <th>Begin Date</th>
                        <th>End Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in learningPath.list" :key="index">
                        <td> {{index+1}} </td>
                        <td>
                         <strong> {{ item.curriculum.value }}</strong>
                        </td>
                        <td>{{ item.sequence }}</td>
                        <td>{{ formatDate(item.begin_date) }}</td>
                        <td>{{ formatDate(item.end_date) }}</td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>                                    
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="learningPath.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>
            <div class="card-footer">
                <paginationBar :state='learningPath' :storeModuleName="'learningPath'" />
            </div>

        </div>
        <b-modal v-model="modalShow" ref="learningPathForm" @hide="clearDetail" hide-footer hide-header id="learningPathForm" size="lg">
            <learningPathForm v-if="modalShow"/>
        </b-modal>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import learningPathForm from '@@/components/forms/learningPathForm'
import paginationBar from '@@/components/paginationBar'
import {mapState, mapActions} from 'vuex'
export default {
    layout : 'curriculum',
    components : { learningPathForm, paginationBar },
    middleware: ({ store, redirect }) => {
        if (!store.state.LPTID.detail) return redirect('/curriculum/learning-path')
    },
    created() {     
        this.$store.dispatch('learningPath/getAll');   
        this.$store.dispatch("curriculum/getAll");        
    },
     data() {
        return {        
            modalShow: false,    
            modalDelimitShow: false,
            begin_date : null,
            end_date : null,
            filters: {
                curriculum: null,
                sequence: null,
                begin_date: null,
                end_date: null
            }
        };
    },
    computed: {
        ...mapState({
            LPTID: state => state.LPTID.detail,
            learningPath: state=>state.learningPath,
            curriculum: state => state.curriculum,
            CURID: state => state.CURID,
            
        })
    },
    methods: {
        getParam(){
        this.$store.dispatch("CURID/getAll");
        
        },
        ...mapActions({
            getDetail: 'learningPath/getDetail',
            clearDetail: 'learningPath/clearDetail',            
            deleteOne: 'learningPath/deleteOne',
            getAll: "learningPath/getAll"
        }),
        runFilter() {
        let params = {};
        if (this.filters.curriculum)
            params["curriculum"] = [this.filters.curriculum];
        if (this.filters.sequence)
            params["sequence"] = [this.filters.sequence];
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;
            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params);
        },
        clearFilters() {
            this.filters = {
                curriculum: null,
                sequence: null,
            };
        },
        async showUpdateForm(object_identifier) {
            
            await this.getDetail(object_identifier)
            
            this.$bvModal.show('learningPathForm')
        },
        
        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.learningPath.detail.begin_date
            this.end_date = this.learningPath.detail.end_date
            this.$bvModal.show('modalDelimit')
        },
        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/learningpath?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },
        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/learningpath', {}, {
                    params : {
                        object_identifier : this.learningPath.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('learningPath/getAll',{learningpath:[this.LPTID.id]});
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>