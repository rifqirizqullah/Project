<template>
    <div v-if="curriculum" class="container page-section">

        <h1 class="display-4">Curriculum Detail</h1>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{curriculum.curriculum.value}}</h3>
                    <b><p>
                        ID <code> {{curriculum.curriculum.id}} </code>
                        Identifier <code> {{curriculum.object_identifier}} </code>
                    </p></b>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Company</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{curriculum.business_code.company_name }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Academic</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{curriculum.academic.value }}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Competency</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{curriculum.competence.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Begin/End Date</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>{{formatDate(curriculum.begin_date)}} - {{formatDate(curriculum.end_date)}}</p>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        </div>

        
        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <span>
                    <h4 class="card-title">Activity</h4>
                    <p class="card-subtitle">List of Available Activity</p>
                </span>
                <span>
                    <button @click="clearDetail(); $bvModal.show('compCurriForm')" class="btn btn-success btn-sm">+ Create Component Curriculum</button>                    
                    <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                        <i class="fa fa-search"></i> Search
                    </b-button>
                </span>
            </div>   
        </div>

    <div class>
     <div class>
         <div class>
          <div class="text-right">
            <div class="bg-white">
              <b-collapse id="collapse-a" class="mt-2">
                <form class="p-2">
                  <div class="row">
                    
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select start date" name="begin_date" id="begin_date"
                        />
                        <small class="form-text text-muted">Begin Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select end date" name="end_date" id="end_date"
                        />
                        <small class="form-text text-muted">End Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group text-right">
                        <b-button
                          @click="filters = {}; runFilter()"
                          variant="secondary"
                        >Clear Filter</b-button>

                        <b-button @click="runFilter" variant="info">
                          <span class="btn-label">
                            <i class="fa fa-search"></i> Filter
                          </span>
                        </b-button>
                      </div>
                    </div>
                  </div>
                </form>
              </b-collapse>
            </div>
          </div>
        </div>

         <div class="card">
            <table class="table table-responsive table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Learning Activity</th>
                        <th>Cycle</th>
                        <th>Activity Type</th>
                        <th>Begin Date</th>
                        <th>End Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in relation.list" :key="index">
                        <td> {{index+1}} </td>
                        <td>
                            <strong> {{ item.id.activity_name }}</strong>
                        </td>                        
                        <td>{{ item.id.cycle.value }}</td>
                        <td>{{ item.id.activity_type.value }}</td>
                        <td>{{ formatDate(item.begin_date) }}</td>
                        <td>{{ formatDate(item.end_date) }}</td>
                        <td>
                            <div class="btn-group">
                                <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    <!-- <button class="dropdown-item" @click="getDetailLA(item.id.object_identifier); $router.push('/learning-activity/detail')">Detail</button>                                     -->
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="relation.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>
            <div class="card-footer">
                <paginationBar :state='relation' :storeModuleName="'relation'" />
            </div>
          </div>
        </div>
     </div>
    

        <b-modal v-model="modalShow" ref="compCurriForm" @hide="clearDetail" hide-footer hide-header id="compCurriForm" size="lg">
            <compCurriForm v-if="modalShow"/>
        </b-modal>

        <b-modal        
            id="modalDelimit"
            centered
            title="Delimit Data"
            header-bg-variant="light"
            size="sm"
            >
            <div class="col-12">
                <div class="form-group">
                <label for="begin_date">Start Date</label>
                <div class="form-control">
                    <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
                </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date"
                    :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                    class="form-control"
                    placeholder="Select end date"
                    name="end_date"
                    id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'"
                    data-vv-scope="collection"
                />
                <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
                <p
                    v-show="errors.has('collection.end_date')"
                    class="help is-danger"
                >{{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button
                type="button"
                class="btn btn-secondary"
                @click="$bvModal.hide('modalDelimit')"
                >Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import compCurriForm from '@@/components/forms/compCurriForm'
import paginationBar from '@@/components/paginationBar'
import {mapState, mapActions} from 'vuex'

export default {
    layout : 'curriculum',
    components : { compCurriForm, paginationBar },
    middleware: ({ store, redirect }) => {
        if (!store.state.curriculum.detail) return redirect('/curriculum')
    },
    created() {                
        this.$store.dispatch('relation/getAll',{'object[]':this.curriculum.curriculum.id,'table_code[]':'LRACT','relation[]':'C001','otype[]':'CURID'})
        
    },
     data() {
        return {        
          modalShow: false,    
          begin_date : null,
          end_date : null,
          page_number: null,

        filters: {
           
            begin_date: null,
            end_date: null
        }  
        };
    },
    computed: {
        ...mapState({
            curriculum: state => state.curriculum.detail,
            relation: state=>state.relation,    
            learningActivity: state=> state.learningActivity,
        })
    },
    methods: {
        
    runFilter() {
        let params = {'object[]':this.curriculum.curriculum.id,'table_code[]':'LRACT','relation[]':'C001','otype[]':'CURID'};

        
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;

        this.$router.push({ path : this.$route.path , query : params})
        this.getAll(params);
    },

    clearFilters() {
      this.filters = {
        
      };
    },
        ...mapActions({
            getDetail: 'relation/getDetail',
            clearDetail: 'relation/clearDetail',            
            deleteOne: 'relation/deleteOne',
            getAll: "relation/getAll",

        }),
        
        
        async showUpdateForm(object_identifier) {
            
            await this.getDetail(object_identifier)
            
            this.$bvModal.show('compCurriForm')
        },
        
        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.relation.detail.begin_date
            this.end_date = this.relation.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/lmsrelationobject?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/lmsrelationobject', {}, {
                    params : {
                        object_identifier : this.session.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('relation/getAll',{'object[]':this.curriculum.curriculum.id,'table_code[]':'LRACT','relation[]':'C001','otype[]':'CURID'});
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
