<template>
    <div class="container page-section">

        <div class="card-header d-flex justify-content-between">
            <h2>My Mentoring</h2>
        <span> 
            <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
            <i class="fa fa-search"></i> Search         
            </b-button>      
        </span>
        </div>

        <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.title"
                        type="text"
                        class="form-control"
                        id="title"
                        placeholder="Title"
                        >
                        <small class="form-text text-muted">Title</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.topic"
                        type="text"
                        class="form-control"
                        id="topic"
                        placeholder="Topic"
                        >
                        <small class="form-text text-muted">Topic</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.description"
                        type="text"
                        class="form-control"
                        id="description"
                        placeholder="Description"
                        >
                        <small class="form-text text-muted">Description</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.duration"
                        type="number"
                        class="form-control"
                        id="duration"
                        placeholder="Duration"
                        >
                        <small class="form-text text-muted">Duration</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

        <div class="card">
            <table class="table table-responsive table-flush table-hover">
                <thead class="">
                    <tr class="">
                            <th>Title</th>
                            <th>Topic</th>
                            <th>Description</th>
                            <th>Duration</th>
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <!-- <th>Action</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in mentoringMentor.list" :key="index">
                            <td @click="getDetail(item.object_identifier); $router.push('/mentor/detail')" style="cursor:pointer;"> 
                               <strong> {{ item.mentoring.title }} </strong>
                            </td>
                            <td> {{ item.mentoring.topic }} </td>
                            <td> {{ item.mentoring.description }} </td>
                            <td>
                               {{ item.mentoring.duration }} minutes
                            </td>                            
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <!-- <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">                                        
                                        <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/peserta/activity/mentoring/detail?type='+type)">Detail</button>
                                    </div>
                                </div>
                            </td> -->
                        </tr>
                    <tr v-if="mentoringMentor.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>
            <div class="card-footer">
                    <paginationBar :state='mentoringMentor' :storeModuleName="'mentoringMentor'" />
            </div>
        </div>


    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'

export default {
    layout: 'mentor',
    components: {
        paginationBar,
    },
    data() {
        return {
            filters : {
                status : '01',
                title: null,
                topic: null,
                description: null,
                duration: null,
                begin_date: null,
                end_date: null,
            },
        }
    },
   created() {
        this.$store.dispatch('mentoringMentor/getAll',{'id[]':'2'});                
    },
    computed: {
        ...mapState({
            mentoringMentor : state => state.mentoringMentor,
        }),
    },
    methods: {
        getParam(){
        
        },
        ...mapActions({
            getDetail: 'mentoringMentor/getDetail',
            clearDetail: 'mentoringMentor/clearDetail',            
            deleteOne: 'mentoringMentor/deleteOne',
            getAll: "mentoringMentor/getAll"            
        }),
        runFilter() {
        let params = {};
        if (this.filters.title)
            params["title"] = [this.filters.title];
        if (this.filters.topic)
            params["topic"] = [this.filters.topic];
        if (this.filters.description)
            params["description"] = [this.filters.description];
        if (this.filters.duration)
            params["duration"] = [this.filters.duration];
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;
            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params);
        },
        clearFilters() {
            this.filters = {
                title: null,
                topic: null,
                description: null,
                duration: null,
            };
        },
       
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>

