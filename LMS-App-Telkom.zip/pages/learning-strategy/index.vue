<template>
  <div class="container page-section">
    <div class="mb-heading d-flex align-items-end px-3">
      <div class="flex">
        <!-- <h4 class="card-title">Learning Strategy</h4> -->
        <p class="card-title" style="font-size:25px;color:black">Learning Strategy</p>
        <p style="font-size:15px;margin-top:-15px">Manage All Learning Strategy</p>
      </div>
      <button class="btn btn-sm btn-success" @click="clearDetail();$bvModal.show('learningStrategyForm')">
        + Create Learning
        Strategy
      </button>
      <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
        <span class="btn-label">
          <i class="fa fa-search"></i> Search
        </span>
      </b-button>
    </div>

    <div class>
      <div class>
        <div class>
          <div class="text-right">
            <div class="bg-white">
              <b-collapse id="collapse-a" class="mt-2">
                <form class="p-2">
                  <div class="row">
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select v-model="filters.company" class="form-control" name="company" id="company">
                          <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                          >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select v-model="filters.year" class="form-control" name="year" id="year">
                          <option
                            v-for="(item, index) in 10"
                            :key="index"
                            :value="item+2015"
                          >{{item+2015}}</option>
                        </select>
                        <small class="form-text text-muted">Year</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <input
                          v-model="filters.organization_strategy_name"
                          type="text"
                          class="form-control"
                          id="organization_strategy_name"
                          placeholder="Strategy Name"
                        >
                        <small class="form-text text-muted">Strategy Name</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select
                          v-model="filters.organization_code"
                          class="form-control"
                          name="organization_code"
                          id="organization_code"
                        >
                          <option
                            v-for="(item, index) in organizationData.list"
                            :key="index"
                            :value="item.organization_code"
                          >{{item.organization_name}}</option>
                        </select>
                        <small class="form-text text-muted">Unit</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select
                          v-model="filters.startegy_inisiative"
                          class="form-control"
                          name="startegy_inisiative"
                          id="startegy_inisiative"
                        >
                          <option
                            v-for="(item, index) in LOSID.list"
                            :key="index"
                            :value="item.id"
                          >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Strategic Initiative</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select start date" name="begin_date" id="begin_date"
                        />
                        <small class="form-text text-muted">Begin Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select end date" name="end_date" id="end_date"
                        />
                        <small class="form-text text-muted">End Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group text-right">
                        <b-button
                          @click="filters = {}; runFilter()"
                          variant="secondary"
                        >Clear Filter</b-button>

                        <b-button @click="runFilter" variant="info">
                          <span class="btn-label">
                            <i class="fa fa-search"></i> Filter
                          </span>
                        </b-button>
                      </div>
                    </div>
                  </div>
                </form>
              </b-collapse>
            </div>
          </div>
        </div>

        <div class="card">
          <table class="table table-hover table-flush table-responsive">
            <thead>
              <tr>
                <th>No</th>
                <th>Company</th>
                <th>Year</th>
                <th>Strategy Name</th>
                <th>Unit</th>
                <th>Strategic Initiative</th>
                <th>Begin Date</th>
                <th>End Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody class="list">
              <tr v-for="(item, index) in learningStrategy.list"  :key="index">
                <td>{{index+1}}</td>
                <td>{{item.business_code.company_name}}</td>
                <td>{{item.year}}</td>
                <td @click="getDetail(item.object_identifier); $router.push('/learning-strategy/detail')"
                ><b>{{item.organization_strategy_name}}</b></td>
                <td>{{item.organization_code.organization_name}}</td>
                <td>
                  {{item.object_parent.value}}
                  <br>
                </td>
                <td>{{ formatDate(item.begin_date) }}</td>
                <td>{{ formatDate(item.end_date) }}</td>
                <td>
                  <div class="dropdown d-sm-flex">
                    <button
                      class="btn btn-secondary dropdown-toggle"
                      type="button"
                      id="triggerId"
                      data-toggle="dropdown"
                    ></button>
                    <div class="dropdown-menu dropdown-menu-right">
                      <button
                        class="dropdown-item"
                        @click="showUpdateForm(item.object_identifier)"
                      >Update</button>
                      <button
                        class="dropdown-item"
                        @click="deleteData(item.object_identifier, index)"
                      >Delete</button>
                      <button
                        class="dropdown-item"
                        @click="showDelimitForm(item.object_identifier, item.end_date)"
                      >Delimit</button>
                      <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/learning-strategy/detail')">Detail</button>
                    </div>
                  </div>
                </td>
              </tr>
              <tr v-if="learningStrategy.isLoading">
                <td colspan="10">
                  <div class="row">
                    <div class="col d-flex justify-content-center">
                      <div class="loader loader-accent text-center"></div>
                    </div>
                  </div>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="card-footer">
            <paginationBar :state="learningStrategy" :storeModuleName="'learningStrategy'"/>
          </div>
        </div>
      </div>
    </div>

    <b-modal
      v-model="modalShow"
      ref="learningStrategyForm"
      hide-footer
      hide-header
      id="learningStrategyForm"
      size="lg"
    >
      <learningStrategyForm v-if="modalShow"/>
    </b-modal>

    <b-modal
      v-model="modalDelimitShow"
      id="modalDelimit"
      centered
      title="Delimit Data"
      header-bg-variant="light"
      size="sm"
    >
      <div class="col-12">
        <div class="form-group">
          <label for="begin_date">Start Date</label>
          <div class="form-control">
            <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
          </div>
        </div>
      </div>
      <hr>
      <div class="col-12">
        <div v-show="begin_date" class="form-group">
          <label for="end_date">End Date</label>
          <flat-pickr
            v-model="end_date"
            :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
            class="form-control"
            placeholder="Select end date"
            name="end_date"
            id="end_date"
            v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
            v-validate="'required'"
            data-vv-scope="collection"
          />
          <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
          <p
            v-show="errors.has('collection.end_date')"
            class="help is-danger"
          >{{ errors.first('collection.end_date') }}</p>
        </div>
      </div>
      <div slot="modal-footer">
        <button
          type="button"
          class="btn btn-secondary"
          @click="$bvModal.hide('modalDelimit')"
        >Cancel</button>
        <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
      </div>
    </b-modal>
  </div>
</template>

<script>
import moment from "moment";
import learningStrategyForm from "@@/components/forms/learningStrategyForm";
import paginationBar from "@@/components/paginationBar";

import { mapState, mapActions } from "vuex";

export default {
  layout: "learning-strategy",
  components: {
    learningStrategyForm,
    paginationBar
  },
  created() {
    this.$store.dispatch("learningStrategy/getAll");    
    this.$store.dispatch("company/getAll");
  },
  data() {
    return {
      modalShow: false,
      modalDelimitShow: false,
      begin_date:null,
      end_date: null,
      page_number: null,

      filters: {
        company: null,
        year: null,
        organization_strategy_name: null,
        organization_code: null,
        startegy_inisiative: null,
        begin_date: null,
        end_date: null
      }
    };
  },
  computed: {
    ...mapState(["learningStrategy", "organizationData", "LOSID", 'company']),
  },
  methods: {
    getParam(){
      this.$store.dispatch("organizationData/getAll");
      this.$store.dispatch("LOSID/getAll");
      
    },
    ...mapActions({
      getDetail: "learningStrategy/getDetail",
      clearDetail: "learningStrategy/clearDetail",
      deleteOne: "learningStrategy/deleteOne",
      getAll: "learningStrategy/getAll"
    }),

    runFilter() {
        let params = {};

        if (this.filters.company)
            params["business_code"] = [this.filters.company];
        if (this.filters.year)
            params["year"] = [this.filters.year];
        if (this.filters.organization_strategy_name)
            params[ "organization_strategy_name" ] = [this.filters.organization_strategy_name];
        if (this.filters.organization_code)
            params["organization_code"] = [this.filters.organization_code];
        if (this.filters.startegy_inisiative){
            params["otype_parent"] = ["LOSID"];
            params["object_parent"] = [this.filters.startegy_inisiative];
        };
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;

        this.$router.push({ path : this.$route.path , query : params})
        this.getAll(params);
    },

    clearFilters() {
      this.filters = {
        activity_name: null,
        cycle: null,
        flag_online: null
      };
    },

    showUpdateForm(object_identifier) {
      this.getDetail(object_identifier);
      this.$bvModal.show("learningStrategyForm");
    },

    async showDelimitForm(object_identifier) {
      await this.getDetail(object_identifier);
      this.begin_date = this.learningStrategy.detail.begin_date;
      this.end_date = this.learningStrategy.detail.end_date;
      this.$bvModal.show("modalDelimit");
    },

    deleteData(id, index) {
      this.$swal({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        type: "warning",
        showCancelButton: true
      }).then(result => {
        if (result.value) {
          this.$axios
            .delete("lms/api/organizationstrategy?object_identifier=" + id)
            .then(response => {
              return this.$swal("Deleted!", response.data.message, "success");
            })
            .then(result => {
              this.deleteOne(index);
            })
            .catch(e => {
              console.log(e.response);
            });
        }
      });
    },

    delimitData() {
      this.$validator.validateAll("delimit").then(async result => {
        if (!result) return;
        this.$axios
          .patch(
            "lms/api/organizationstrategy",
            {},
            {
              params: {
                object_identifier: this.learningStrategy.detail
                  .object_identifier,
                end_date: this.end_date
              }
            }
          )
          .then(response => {
            this.$store.dispatch("learningStrategy/getAll");
            this.$bvModal.hide("modalDelimit");
            this.$swal("Saved!", "Successfully saved data.", "success");
          })
          .catch(e => {
            console.log(e.response);
          });
      });
    },
    formatDate(date) {
        return moment(date).format('DD MMM YYYY')
    }
  }
};
</script>
<style>
.dropdown-item:focus,
.dropdown-item:hover {
  color: rgba(93, 86, 86, 0.9);
  text-decoration: none;
  background-color: #27202030;
}
</style>
