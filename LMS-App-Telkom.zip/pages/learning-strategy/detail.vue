<template>
    <div class="container page-section">

        <h1 class="display-4">Learning Strategy Detail</h1>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{learningStrategy.organization_strategy_name}}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Company</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningStrategy.business_code.company_name }}</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Year</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningStrategy.year}}</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Unit</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningStrategy.organization_code.organization_code}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Begin/End Date</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>{{formatDate(learningStrategy.begin_date)}} - {{formatDate(learningStrategy.end_date)}}</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Learning Focus</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningStrategy.learning_focus.value}}</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Strategic Initiative</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningStrategy.object_parent.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Issue</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningStrategy.object_child1.value}}</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Procifiency Level</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningStrategy.object_child2.value}}</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Employee Cluster</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>{{learningStrategy.employee_cluster.value}}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        

    </div>
</template>

<script>
import moment from 'moment'
import paginationBar from '@@/components/paginationBar'
import {mapState, mapActions} from 'vuex'

export default {
    layout : 'learning-strategy',
    components : { paginationBar },
    middleware: ({ store, redirect }) => {
        if (!store.state.learningStrategy.detail) return redirect('/learning-strategy')
    },
    created() {     
                  
    },
     data() {
        return {        
            modalShow: false,    
            begin_date : null,
            end_date : null,
            
        }
    },
    computed: {
        ...mapState({
            learningStrategy: state => state.learningStrategy.detail
        })
    },
    methods: {
        
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
