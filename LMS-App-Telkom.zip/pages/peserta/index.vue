<template>
    <div class="container page-section">
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">On Going Events</h4>
                            <p class="card-subtitle text-light">happening now</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of ongoing Event <span class="badge badge-pill badge-success badge-lg ml-3">{{myBatch.Ongoing && myBatch.Ongoing}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '01'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Upcoming Events</h4>
                            <p class="card-subtitle text-light">Upcoming</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Upcoming Event <span class="badge badge-pill badge-accent badge-lg ml-3">{{myBatch.Upcoming && myBatch.Upcoming}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '02'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Events Complete</h4>
                            <p class="card-subtitle text-light">Completed event</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Event Complete <span class="badge badge-pill badge-secondary badge-lg ml-3">{{myBatch.Done && myBatch.Done}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '03'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-header bg-light d-flex justify-content-between align-items-center">
            <h2>My Events</h2>
            <span>  
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                <i class="fa fa-search"></i> Search         
                </b-button>      
            </span> 
        </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters1.company" class="form-control" name="company" id="company">
                        <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                        >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.event"
                        type="text"
                        class="form-control"
                        id="event_name"
                        placeholder="Event"
                        >
                        <small class="form-text text-muted">Event</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.batch"
                        type="text"
                        class="form-control"
                        id="batch_name"
                        placeholder="Batch"
                        >
                        <small class="form-text text-muted">Batch</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.type"
                        type="text"
                        class="form-control"
                        id="event_type"
                        placeholder="Type"
                        >
                        <small class="form-text text-muted">Type</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.curriculum"
                        type="text"
                        class="form-control"
                        id="curriculum"
                        placeholder="Curriculum"
                        >
                        <small class="form-text text-muted">Curriculum</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Start Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; runFilter1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

        <div class="card">
            <div class="" style="">
                <table class="table table-flush table-responsive  table-hover">
                <thead class="">
                    <tr class="">                        
                        <th>Company</th>
                        <th>Event</th>
                        <th>Batch</th>
                        <th>Location</th>
                        <th>Type</th>
                        <th>Curriculum</th>
                        <th>Status</th>
                        <th>Start</th>
                        <th>End</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- <tr v-for="(item, index) in myBatch" :key="index"
                        @click="
                            getOne({data : item});
                            getEventDetail({data : item.event});
                            $router.push('/peserta/activity?type=event')"
                        style="cursor:pointer;"
                    > -->
                    <tr v-for="(item, index) in myBatch.list" :key="index">
                        <td> {{ item.company_name }} </td>
                        <td> {{ item.event_name }} </td>
                        <td @click="detail(item.event_id,item.batch)" style="cursor:pointer;"> 
                            <strong>{{ item.batch_name }}</strong> 
                        </td>
                        <td> {{ item.location }} </td>
                        <td> {{ item.event_type }} </td>
                        <td> {{ item.curriculum }} </td>
                        <td v-bind:class="{
                            'text-success': item.event_curr_stat == 'Ongoing',
                            'text-accent': item.event_curr_stat == 'Upcoming',
                            'text-secondary': item.event_curr_stat == 'Done',
                            'text-warning': item.event_curr_stat == undefined,
                            }" >
                            <b>{{ item.event_curr_stat || 'Planning' }}</b>
                        </td>
                        <td> {{formatDate(item.begin_date)}} </td>
                        <td> {{formatDate(item.end_date)}} </td>
                    </tr>
                    <tr v-if="myBatch.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
             <div class="card-footer">
                <paginationBar :state='myBatch' :storeModuleName="'myBatch'" />
            </div>

        </div>


        <div class="page-headline text-center pb-3">
            <h2>My Learning Roadmap</h2>
        </div>
        <div class="card">
            <div class="text-center">
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select v-model="business_code" class="form-control" name="company" id="company" @change="getRoadmap">
                        <option>Choose Company</option>
                        <option v-for="(c, index) in company.list" :key="index" :value="c.business_code">
                        {{c.company_name}}
                    </option>
                    </select>
                  </div>
                </div>
            </div>
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Current Roadmap</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum</th>
                                <th>PL Code</th>
                                <th>Competence</th>
                                <th>Company</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in currents" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.curriculum && item.curriculum.curriculum.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.pl_code.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.competence.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.business_code.company_name }}</td>
                            </tr>                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Required Competencies: SUC</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum</th>
                                <th>PL Code</th>
                                <th>Competence</th>
                                <th>Company</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in SUC" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.curriculum && item.curriculum.curriculum.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.pl_code.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.competence.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.business_code.company_name }}</td>
                            </tr>                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Required Competencies: MCP</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum</th>
                                <th>PL Code</th>
                                <th>Competence</th>
                                <th>Company</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in MCP" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.curriculum && item.curriculum.curriculum.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.pl_code.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.competence.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.business_code.company_name }}</td>
                            </tr>                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Required Competencies: ECP</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum</th>
                                <th>PL Code</th>
                                <th>Competence</th>
                                <th>Company</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item , index) in ECP" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>{{ item.curriculum && item.curriculum.curriculum.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.pl_code.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.competence.value }}</td>
                                <td>{{ item.curriculum && item.curriculum.business_code.company_name }}</td>
                            </tr>                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="page-headline text-center pb-0">
            <h2>Learning Proposal</h2>
        </div>
        <curriculumRequest/>


    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'
import curriculumRequest from '@@/pages/curriculum/request'
export default {
    layout: 'peserta',
    components: {
        paginationBar,
        curriculumRequest
    },
    data() {
        return {
            filters : {
                status : '01',
            },
            filters1 : {
                company : null,
                event : null,
                batch : null,
                type : null,
                curriculum:null,
                begin_date: null,
                end_date: null
            },
            currents:[],
            SUC:[],
            ECP:[],
            MCP:[],
            posisiSUC:[],
            posisiECP:[],
            posisiMCP:[],
            posisi:null,
            personal_number:null,
            business_code:null
        }
    },
    async created() {
        this.$store.dispatch('myBatch/getAll');
        this.$store.dispatch('myBatch/getAllStatus');
        this.$store.dispatch('company/getAll');
        // this.$store.dispatch('event/getAll');
        // this.$store.dispatch('batch/getAll');
        // this.$store.dispatch('batchParticipant/getAll', {
        //     'participant[]' : '2'
        //     //  // ini dengan participant id yang login !!!
        // });
        //await this.getJob();
        // this.getSUC();        
        // this.getECP();        
        // this.getMCP();        
        //console.log(this.$auth.user)
    },
    computed: {
        ...mapState({
            // event : state => state.event,
            // Ongoing : state => state.event.Ongoing,
            // Upcoming : state => state.event.Upcoming,
            // Done : state => state.event.Done,
            // batchParticipant : state => state.batchParticipant,
            myBatch : state => state.myBatch,
            company : state => state.company
        }),
        // myBatch() {
        //     let batch_list_copy = [...this.batchParticipant.list]
        //     let filter = batch_list_copy.filter(obj => {
        //         return obj.batch.batch_id !== undefined && (obj.batch.event.event_situation && obj.batch.event.event_situation.id == '2')
        //     })
        //     let batch = filter.map(item => {return item.batch})
        //     return batch
        // }
    },
    methods: {
        getParam(){
        // this.$store.dispatch("Batch/getAll");

        },
        ...mapActions({
            // getDetail: 'batch/getDetail',
            // clearDetail: 'batch/clearDetail',
            // deleteOne: 'batch/deleteOne',
            // getAll: 'batch/getAll',
            // getOne: 'batch/getOne',
            getEventDetail: 'event/getOne',
            getBatchDetail: 'batch/getOne',            
            getAll: 'myBatch/getAll',
            getAll1: 'myBatch/getAll',
        }),

        runFilter1(){
                let params1 = {}
                if (this.filters1.company)
                    params1["business_code"] = [this.filters1.company];
                if (this.filters1.event)
                    params1["event_name[]"] = this.filters1.event
                if (this.filters1.batch)
                    params1["batch_name[]"] = this.filters1.batch
                if (this.filters1.type)
                    params1["event_type[]"] = this.filters1.type
                if (this.filters1.curriculum)
                    params1["curriculum[]"] = this.filters1.curriculum
                if (this.filters1.begin_date)
                    params1["begin_date_lte"] = this.filters1.begin_date;
                if (this.filters1.end_date)
                    params1["end_date_gte"] = this.filters1.end_date;

                this.$router.push({ path : this.$route.path , query : params1})
                this.getAll1(params1)

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearFilters1(){
                this.filters1 = {
                    company : null,
                    event : null,
                    batch : null,
                    type : null,
                    curriculum : null,
                }

            },
        async detail(event,batch){            
            await this.getEventDetail({event_id : [event]});
            await this.getBatchDetail({batch_id : [batch]});
           
            this.$router.push('/peserta/activity?type=event')
        },        
        runFilter(){
            let params = {}
            if (this.filters.status)
                params["curr_stat"] = this.filters.status
            this.getAll(params)
        },
        async getRoadmap(){
            await this.getJob();
            this.getSUC();        
            this.getECP();        
            this.getMCP();        
        },
        async getSUC() {
            await this.$axios
                .get(
                    'hcis/api/qualifications?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                    '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                    '&personnel_number[]=' + this.personal_number +
                    '&parent_type[]=ASPTY&child_type[]=ASPTY&child[]=SUC&business_code[]=' + this
                    .business_code +
                    '&object_value_1[]=' + this.posisi)
                .then(response => {
                    this.posisiSUC = response.data.data[0].object_value_2
                    this.$axios
                        .get(
                            '/lms/api/currentroadmap?begin_date=' + moment(new Date()).format(
                                "YYYY-MM-DD") +
                            '&end_date=' + moment(new Date()).format("YYYY-MM-DD") +
                            '&personnel_number=' + this.personal_number +
                            '&organization_type=S&organization_id=' + this.posisiSUC +
                            '&business_code=' + this.business_code)
                        .then(response => {
                            this.SUC = [];
                            response.data.forEach(async (item, key) => {
                                await this.SUC.push({
                                    OBJCH: item.OBJCH,
                                    OBVL2: item.OBVL2,
                                    curriculum: null
                                });
                                await this.$axios.get('lms/api/curriculum?pl_code[]=' + item
                                        .OBVL2 +
                                        '&competence[]=' + item.OBJCH)
                                    .then(response => {
                                        this.SUC[key].curriculum = response.data.data[0]
                                    }).catch(e => {
                                        console.log(e);
                                    });
                            })
                            // this.pagination = response.data.meta.pagination;
                        })
                }).catch(e => {
                    console.log(e);
                });
        },
        async getECP() {
            await this.$axios
                .get(
                    'hcis/api/qualifications?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
                    '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                    '&personnel_number[]=' + this.personal_number +
                    '&parent_type[]=ASPTY&child_type[]=ASPTY&child[]=ECP&business_code[]=' +
                    this.business_code +
                    '&object_value_1[]=' + this.posisi)
                .then(response => {
                    this.posisiECP = response.data.data[0].object_value_2
                    this.$axios.get(
                            '/lms/api/currentroadmap?begin_date=' + moment(new Date()).format(
                                "YYYY-MM-DD") + '&end_date=' + moment(new Date()).format("YYYY-MM-DD") +
                            '&personnel_number=' + this.personal_number +
                            '&organization_type=S&organization_id=' + this.posisiECP +
                            '&business_code=' + this.business_code)
                        .then(response => {
                            this.ECP = [];
                            response.data.forEach(async (item, key) => {
                                await this.ECP.push({
                                    OBJCH: item.OBJCH,
                                    OBVL2: item.OBVL2,
                                    curriculum: null
                                });
                                await this.$axios.get('lms/api/curriculum?pl_code[]=' + item
                                        .OBVL2 + '&competence[]=' + item.OBJCH)
                                    .then(response => {
                                        this.ECP[key].curriculum = response.data.data[0]
                                    }).catch(e => {
                                        console.log(e);
                                    });
                            })
                            // this.pagination = response.data.meta.pagination;
                        })

                }).catch(e => {
                    console.log(e);
                });
        },
        async getMCP() {
            await this.$axios.get('hcis/api/qualifications?begin_date_lte=' + moment(new Date()).format(
                        "YYYY-MM-DD") + '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") +
                    '&personnel_number[]=' + this.personal_number +
                    '&parent_type[]=ASPTY&child_type[]=ASPTY&child[]=MCP&business_code[]=' + this
                    .business_code + '&object_value_1[]=' + this.posisi)
                .then(response => {
                    this.posisiMCP = response.data.data[0].object_value_2
                    this.$axios.get('/lms/api/currentroadmap?begin_date=' + moment(new Date()).format(
                                "YYYY-MM-DD") + '&end_date=' + moment(new Date()).format("YYYY-MM-DD") +
                            '&personnel_number=' + this.personal_number +
                            '&organization_type=S&organization_id=' + this.posisiMCP +
                            '&business_code=' +
                            this.business_code)
                        .then(response => {
                            this.MCP = [];
                            response.data.forEach(async (item, key) => {
                                await this.MCP.push({
                                    OBJCH: item.OBJCH,
                                    OBVL2: item.OBVL2,
                                    curriculum: null
                                });
                                await this.$axios.get('lms/api/curriculum?pl_code[]=' + item
                                        .OBVL2 + '&competence[]=' + item.OBJCH)
                                    .then(response => {
                                        this.MCP[key].curriculum = response.data.data[0]
                                    }).catch(e => {
                                        console.log(e);
                                    });
                            })
                            // this.pagination = response.data.meta.pagination;
                        })

                }).catch(e => {
                    console.log(e);
                });
        },
        async getJob(){            
            await this.$axios.get('lms/api/participantjob?begin_date_lte='+moment(new Date()).format("YYYY-MM-DD")+'&end_date_gte='+moment(new Date()).format("YYYY-MM-DD")+'&participant[]=2&business_code[]='+this.business_code)
            .then(response => {
                this.posisi = response.data.data[0].position_code
                this.personal_number = response.data.data[0].participant.personnel_number                
                this.getCurrent();
            }).catch(e => {
                console.log(e);
            });                                                  
        },
        getCurrent() {
            this.$axios.get('/lms/api/currentroadmap?begin_date='+moment(new Date()).format("YYYY-MM-DD")+'&end_date='+moment(new Date()).format("YYYY-MM-DD")+'&personnel_number='+this.personal_number+'&organization_type=S&organization_id='+this.posisi+'&business_code='+this.business_code)
            .then(response => {
                this.currents = [];
                response.data.forEach(async (item, key) => {
                    await this.currents.push({
                        OBJCH: item.OBJCH,
                        OBVL2: item.OBVL2,                
                        curriculum:null
                    });
                    await this.$axios.get('lms/api/curriculum?pl_code[]='+item.OBVL2+'&competence[]=' + item.OBJCH)
                    .then(response => {
                        this.currents[key].curriculum = response.data.data[0]                 
                    }).catch(e => {
                        console.log(e);
                    });                                      
                })
            // this.pagination = response.data.meta.pagination;
            })
        },      
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },


    },
}
</script>

