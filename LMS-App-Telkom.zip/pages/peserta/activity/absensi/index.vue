<template>
    <div>
        <div class="container">
            <headerEventComponent/>
        </div>
        <div class="container">
            <headerBatchComponent/>
        </div>
        <div class="container">
            <headerSessionComponent/>
        </div>
        <div class="container page-section pt-0">

            <span class="d-flex justify-content-between align-items-center">
                <h2 class="m-3"> <i class="material-icons text-info">person</i> Qr Code</h2>                
            </span>

            <div class="card">

                <table class="table table-responsive table-flush table-hover">
                    <thead class="">
                        <tr class="">
                            <th align="center">Absensi</th>                            
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td align="center"><img :src="'data:image/jpeg;base64,'+qrCode"/>
                                
                            </td>                            
                        </tr>                        
                    </tbody>

                </table>
            </div>            
        </div>


    </div>
</template>

<script>
import moment from 'moment'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'schedule_peserta',
    components : { headerEventComponent, headerBatchComponent, headerSessionComponent },
    
    data() {
        return {            
            type : this.$route.query.type,
            qrCode: null
        }
    },
    created() {
        this.getQRCode()        
    },
    computed: {
        ...mapState({
            session : state => state.session.detail,            
        }),
    },
    methods: {
        ...mapActions({            
        }),

        getQRCode() {           
            let data = new FormData();
            data.append('parid', '1')
            data.append('sesid', this.session.session_id)            
            this.$axios.post('lms/api/attendance/qr', data)
            .then((response) => {
                this.qrCode = response.data.data
                console.log(response.data.data)
            })
            .catch(err => {
                console.log(err.response);
            })
        },
       
    },

}
</script>