<template>
    <div>
        <div class="container">
            <headerEventComponent/>
            <headerBatchComponent/>
           
        </div>

        <div class="container page-section">

            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h2>Activity</h2>
                <span>  
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>      
                </span> 
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.session_name"
                        type="text"
                        class="form-control"
                        id="session_name"
                        name="session_name"
                        placeholder="Name"
                        >
                        <small class="form-text text-muted">Name</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-6 col-lg-3">
                    <div class="form-group">
                        <input v-model="filters.activity_name" type="text" class="form-control" id="name" placeholder="Activity Name">
                        <small>Activity Name</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

            <div class="card">

                <table class="table table-responsive table-flush table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Name</th>
                            <th v-if="batch.curriculum.id">Learning Activity</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in session.list" :key="index">
                            <td> {{index+1}} </td>
                            <td @click="getDetail(item.object_identifier); $router.push('/peserta/activity/schedule?type=event')" style="cursor:pointer;">
                               <strong> {{ item.session_name }}</strong>
                            </td>
                            <td v-if="batch.curriculum.id">{{ item.learning_activity.activity_name }}</td>
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>

                        </tr>
                        <tr v-if="session.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
                <div class="card-footer">
                    <paginationBar :state='session' :storeModuleName="'session'" />
                </div>

            </div>

            <b-modal v-model="modalShow" ref="sessionForm" hide-footer hide-header id="sessionForm" size="lg">
                <sessionForm v-if="modalShow" />
            </b-modal>
            <b-modal v-model="modalReferenceShow" ref="sessionFormReference" hide-footer title="Add Planned Activity" id="sessionFormReference" size="lg">
                <sessionFormReference v-if="modalReferenceShow" />
            </b-modal>

            <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="endDate">Begin Date</label>
                        <flat-pickr disabled v-model="begin_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                            placeholder="Select end date" name="begin_date" v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}"
                            v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                            <p v-show="errors.has('delimit.begin_date')" class="help is-danger"> {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                    <div class="form-group">
                        <label for="endDate">End Date</label>
                        <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                            placeholder="Select end date" name="end_date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                            v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                            <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
                    </div>
                </div>
                <div slot="modal-footer">
                    <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                    <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
                </div>
            </b-modal>

        </div>
    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'
import sessionForm from '@@/components/forms/sessionForm'
import sessionFormReference from '@@/components/forms/sessionFormReference'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'

export default {
    layout : 'peserta-batch',
    components : { sessionForm, paginationBar, headerEventComponent, headerBatchComponent, sessionFormReference },
    middleware({store,redirect}) {      
        if (!store.state.batch.detail) redirect('/peserta')      
    },
    created() {
        // if (route.query.type == 'event') {
        //     if (!store.state.batch.detail) redirect('/event/event')
        // } else {
        //     if (!store.state.batch.detail) redirect('/event/event-plan')
        // }
        this.$store.dispatch('session/clearAll');
        this.$store.dispatch('session/getAll');
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            modalReferenceShow : false,

            begin_date : null,
            end_date : null,

            type : this.$route.query.type,
            filters: {
                session_name: null,
                activity_name: null,
                begin_date: null,
                end_date: null
            }
        };
    },
    computed: {
        ...mapState({
            batch : state => state.batch.detail,
            session : state => state.session,
        }),
    },
    methods: {
        getParam(){
                // this.$store.dispatch('ACTTY/getAll');
                
        },
        ...mapActions({
            getDetail: 'session/getDetail',
            clearDetail: 'session/clearDetail',
            deleteOne: 'session/deleteOne',
            getAll: 'session/getAll',
        }),

        runFilter(){
                let params = {};
                if (this.filters.session_name)
                    params["session_name[]"] = this.filters.session_name;
                if (this.filters.activity_name)
                    params["activity_name[]"] = this.filters.activity_name;
                if (this.filters.begin_date)
                    params["begin_date_lte"] = this.filters.begin_date;
                if (this.filters.end_date)
                    params["end_date_gte"] = this.filters.end_date;
                    this.$router.push({ path : this.$route.path , query : params})
                    this.getAll(params);

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearFilters(){
                this.filters = {
                    activity_name : null,
                    session_name : null,
                };

            },
        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('sessionForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.batch.detail.begin_date
            this.end_date = moment(new Date()).format("YYYY-MM-DD")
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/session?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/session', {}, {
                    params : {
                        object_identifier : this.session.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('session/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
