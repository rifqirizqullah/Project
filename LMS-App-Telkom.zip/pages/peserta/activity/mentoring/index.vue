<template>
    <div>
        <div class="container">
            <headerEventComponent/>
        </div>
        <div class="container">
            <headerBatchComponent/>
        </div>
        <div class="container">
            <headerSessionComponent/>
        </div>
        <div class="container page-section pt-0">

            <span class="d-flex justify-content-between align-items-center">
                <h2 class="m-3"> <i class="material-icons text-info">person</i> Mentoring</h2>               
            </span>

            <div class="card">

                <table class="table table-responsive table-flush table-hover">
                    <thead class="">
                        <tr class="">
                            <th>Title</th>
                            <th>Topic</th>
                            <th>Description</th>
                            <th>Duration</th>
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <!-- <th>Action</th> -->
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in mentoringParticipant.list" :key="index">
                            <td @click="getDetail(item.object_identifier); $router.push('/peserta/activity/mentoring/detail?type='+type)" style="cursor:pointer;"> 
                               <strong> {{ item.title }} </strong>
                            </td>
                            <td> {{ item.topic }} </td>
                            <td> {{ item.description }} </td>
                            <td>
                               {{ item.duration }}
                            </td>                            
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <!-- <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">                                        
                                        <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/peserta/activity/mentoring/detail?type='+type)">Detail</button>
                                    </div>
                                </div>
                            </td> -->
                        </tr>
                        <tr v-if="mentoringParticipant.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'
import paginationBar from '@@/components/paginationBar'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'schedule_peserta',
    components : {paginationBar, headerEventComponent, headerBatchComponent, headerSessionComponent },
    
    data() {
        return {
            type : this.$route.query.type
        }
    },
    created() {
        this.$store.dispatch('mentoringParticipant/getAll',{'otype':'PARTI','id':'1'});                
    },
    computed: {
        ...mapState({
            mentoringParticipant : state => state.mentoringParticipant,
        }),
    },
    methods: {
        ...mapActions({
            getDetail: 'mentoringParticipant/getDetail',            
        }),
       
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>