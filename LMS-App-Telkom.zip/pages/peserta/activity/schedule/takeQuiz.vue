<template>
    <div>
        <div class="container">

            <div class="bg-gradient-primary pb-lg-64pt py-32pt">
                <div class="container">
                    <nav v-if="relation.pagination" class="course-nav">
                        <a v-for="(item, index) in relation.pagination.total" :key="index">
                            <span v-if="index+1 < data_index" class="material-icons text-primary">check_circle</span>
                            <span v-if="index+1 == data_index" class="material-icons text-accent">play_circle_filled</span>
                            <span v-if="index+1 > data_index" class="material-icons text-primary">check_circle_outline</span>
                        </a>
                    </nav>
                    <span class="">
                        <div class="d-flex flex-wrap align-items-end justify-content-end mb-16pt">
                            <h3 class="text-white-50 flex m-0">Test {{data_index}} of {{relation.list.length}}</h3>
                            <p class="h5 text-white-50 font-weight-light mr-2">{{current_quiz.quesioner_type && current_quiz.quesioner_type.value}}</p>
                        </div>
                        <!-- <h1 class="text-light"> {{current_test.question_name}}</h1> -->
                        <p class="mt-4 hero__lead measure-hero-lead text-white">
                            <span class="material-icons">contact_support</span> {{current_quiz.quesioner_title}} ?
                        </p>
                        <div class="text-light" >
                            <span class="material-icons">attach_file</span>  {{current_quiz.quesioner_text}}
                        </div>
                    </span>
                </div>
            </div>

            <div class="navbar navbar-expand-md navbar-list navbar-submenu navbar-light " style="white-space: nowrap;">
                <div class="container page__container">
                    <ul class="nav navbar-nav flex navbar-list__item">
                        <li class="nav-item">
                            <i class="material-icons text-50 mr-8pt">tune</i>
                            Choose the correct answer below:
                        </li>
                    </ul>
                </div>
            </div>

            <div class="bg-light  container" v-if="current_quiz.quesioner_type && current_quiz.quesioner_type.id">
                <div class="page-section py-3">
                    <h3 class="text-black-50">Your Answer:</h3> <br/>

                    <div  v-for="(item, index) in quesioner_choice.list" :key="index" class="form-group" >
                        <div class="custom-control custom-checkbox" v-if="current_quiz.quesioner_type.id == '01'">
                            <input v-model="checkedChoice" type="checkbox" :id="'choice'+index" class="custom-control-input" :value="item.text_choice">
                            <label :for="'choice'+index" class="custom-control-label">{{item.text_choice}}</label>
                        </div>
                    </div>

                    <div class="form-group" v-if="current_quiz.quesioner_type.id == '02'">
                        <b-form-group label="Individual radios">
                            <b-form-radio v-model="answerBool" name="some-radios" value="Benar">True</b-form-radio>
                            <b-form-radio v-model="answerBool" name="some-radios" value="Salah">False</b-form-radio>
                        </b-form-group>
                    </div>

                    <div class="form-group" style="max-width:600px;" v-if="current_quiz.quesioner_type.id == '03'">
                      <input v-model="answerText" type="text" class="form-control" name="answerText" id="answerText" placeholder="Your text answer ...">
                    </div>

                    <br/>
                    <p class="text-50 mb-0">Note: There can be multiple correct answers to this question.</p>
                </div>
            </div>

             <div class="navbar navbar-expand-md navbar-list bg-light " style="white-space: nowrap;">
                <div class="container">
                    <div v-if="relation.pagination" class="nav navbar-nav ml-sm-auto navbar-list__item">
                        <div class="nav-item d-flex flex-column flex-sm-row ml-sm-16pt">
                            <p v-if="!checkedChoice.length && answerText.trim() == '' && answerBool.trim() == ''" class="mr-3 text-warning">Please select or fill your answer</p>
                            <button
                                v-if="relation.list.length > data_index"
                                :disabled="!checkedChoice.length && answerText == '' && answerBool == ''"
                                class="btn btn-accent"
                                @click=" submitAnswer() ; data_index+=1 ; fetch_quesioner_choice() "
                            >
                                Next Question <i class="material-icons icon--right">play_arrow</i>
                            </button>

                            <button
                                v-else
                                :disabled="!checkedChoice.length && answerText == '' && answerBool == ''"
                                class="btn btn-accent"
                                @click=" submitAnswer() ; $router.push('/peserta/activity/schedule/detail?type=event') "
                            >
                                Finish <i class="material-icons icon--right">play_arrow</i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'

import scheduleForm from '@@/components/forms/scheduleForm'
import scheduleFormReference from '@@/components/forms/scheduleFormReference'
import paginationBar from '@@/components/paginationBar'

export default {
    layout : 'peserta-batch',
    components : {
        scheduleForm,
        paginationBar,
    },
    data() {
        return {
            data_index : 1,
            type : this.$route.query.type,
            checkedChoice : [],
            answerText : '',
            answerBool : '',
            participant_id : '1',
        }
    },
    middleware: ({ store, redirect }) => {
        if (!store.state.schedule_templateQuestioner.detail) return redirect('/peserta')
    },
    async created() {
        await this.$store.dispatch('relation/getAll',{'object[]':this.schedule_templateQuestioner.template_code.id,'table_code[]':'QUESN','relation[]':'Q001','otype[]':'TPLCD'})
        this.fetch_quesioner_choice()
        //console.log(this.current_quiz)
    },
    computed: {
        ...mapState({
            relation : state => state.relation,
            schedule_templateQuestioner : state => state.schedule_templateQuestioner.detail,
            quesioner_choice : state => state.quesioner_choice,
        }),

        current_quiz() {
            return this.relation.list.length ? this.relation.list[this.data_index-1].id : {}
        }
    },
    methods: {
        ...mapActions({

        }),         
        triggerNext() {

        },

        fetch_quesioner_choice(){
            this.$store.dispatch('quesioner_choice/clearAll');
            this.$store.dispatch('quesioner_choice/getAll', { 'quesioner[]' : this.current_quiz.quesioner_id });
            this.checkedChoice = []
            this.answerText = ''
            this.answerBool = ''
        },

        submitAnswer() {
            if (this.answerText.length) this.checkedChoice.push(this.answerText)
            if (this.answerBool.length) this.checkedChoice.push(this.answerBool)
            this.$axios.post('lms/api/quesionerparticipantchoice', {
                business_code : this.current_quiz.business_code.business_code,
                quesioner :  this.current_quiz.quesioner_id,
                participant :  this.participant_id,
                relation_quesioner : this.schedule_templateQuestioner.relation_quesioner_id,
                text_choice : this.checkedChoice.join(' , '),
                begin_date : moment(new Date).format('YYYY-MM-DD'),
                end_date : "9999-12-30",
            })
            .then((res) => {
                console.log(res.data);
            })
            .catch(err => {
                console.log(err.response);
            })
        },


        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>
