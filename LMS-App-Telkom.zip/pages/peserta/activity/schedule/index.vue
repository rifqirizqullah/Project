<template>
    <div>
        <div class="container">
            <headerEventComponent/>
            <headerBatchComponent/>
            <headerSessionComponent/>
            
        </div>
        <div class="container page-section pt-0">

            <span class="d-flex justify-content-between align-items-center">
                <h2 class="m-3"> <i class="material-icons text-info">access_time</i> Schedule</h2>
                <span>
                </span>
            </span>

            <div class="card">

                <table class="table table-responsive table-flush table-hover">
                    <thead class="">
                        <tr class="">
                            <th>Day Num</th>
                            <th>Schedule Date</th>
                            <th>Time</th>
                            <th>Title</th>
                            <th>Topic</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule.list" :key="index">
                            <td> {{ item.day_number }} </td>
                            <td> {{ formatDay(item.schedle_date) }} </td>
                            <td> {{ item.begin_time }} - {{ item.end_time }} </td>
                            <td @click="getOne({data : item}); $router.push('/peserta/activity/schedule/detail?type=event')" style="cursor:pointer;">
                               <strong>{{ item.schedule_name }}</strong>
                            </td>
                            <td> {{ item.topic }} </td>
                        </tr>
                        <tr v-if="schedule.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
            </div>

        </div>


    </div>
</template>

<script>
import moment from 'moment'
import scheduleForm from '@@/components/forms/scheduleForm'
import scheduleFormReference from '@@/components/forms/scheduleFormReference'
import paginationBar from '@@/components/paginationBar'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'schedule_peserta',
    components : { scheduleForm, paginationBar, headerEventComponent, headerBatchComponent, scheduleFormReference, headerSessionComponent },
    middleware: ({ store, redirect }) => {
        if (!store.state.session.detail) return redirect('/peserta')
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            modalReferenceShow : false,

            begin_date : null,
            end_date : null,

            type : this.$route.query.type
        }
    },
    created() {
        this.$store.dispatch('schedule/getAll');
        //this.$store.dispatch('schedule/getReference');
        this.business_code = this.session.business_code.business_code
    },
    computed: {
        ...mapState({
            session : state => state.session.detail,
            schedule : state => state.schedule,
        }),
    },
    methods: {
        ...mapActions({
            getDetail: 'schedule/getDetail',
            getOne: 'schedule/getOne',
            getDetailReference: 'schedule/getDetailReference',
            clearDetail: 'schedule/clearDetail',
            deleteOne: 'schedule/deleteOne'
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('scheduleForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.schedule.detail.begin_date
            this.end_date = moment(new Date()).format("YYYY-MM-DD")
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/schedule?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/schedule', {}, {
                    params : {
                        object_identifier : this.schedule.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('schedule/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>
