<template>
    <div class="">
        <div  class="container">

            <div class="bg-gradient-primary pb-4 pt-32pt">
                <div class="container">
                    <nav v-if="test_templateTest.pagination" class="course-nav">
                        <a v-for="(item, index) in test_templateTest.pagination.total" :key="index">
                            <span v-if="index+1 < data_index" class="material-icons text-primary">check_circle</span>
                            <span v-if="index+1 == data_index" class="material-icons text-accent">play_circle_filled</span>
                            <span v-if="index+1 > data_index" class="material-icons text-primary">check_circle_outline</span>
                        </a>
                    </nav>
                    <span class="">
                        <div class="d-flex flex-wrap align-items-end justify-content-end mb-16pt">
                            <h3 class="text-white-50 flex m-0">Test {{data_index}} of {{test_templateTest.pagination && test_templateTest.pagination.total}}</h3>
                            <p class="h5 text-white-50 font-weight-light mr-2">{{current_test.question_type && current_test.question_type.value}}</p>
                        </div>
                        <!-- <h1 class="text-light"> {{current_test.question_name}}</h1> -->
                        <p class="mt-4 hero__lead measure-hero-lead text-white">
                            <span class="material-icons">contact_support</span> {{current_test.question_text}} ?
                        </p>
                        <div class="text-light" >
                            <span class="material-icons">attach_file</span>  {{current_test.question_image}}
                        </div>
                    </span>
                </div>
            </div>

            <div class="navbar navbar-expand-md navbar-list navbar-submenu navbar-light " style="white-space: nowrap;">
                <div class="container page__container">
                    <ul class="nav navbar-nav flex navbar-list__item">
                        <li class="nav-item">
                            <i class="material-icons text-50 mr-8pt">tune</i>
                            Choose the correct answer below:
                        </li>
                    </ul>
                </div>
            </div>

            <div class="bg-light  container" v-if="current_test.question_type && current_test.question_type.id">
                <div class="page-section py-3">
                    <h3 class="text-black-50">Your Answer:</h3> <br/>

                    <div v-for="(item, index) in test_question_choice.list" :key="index" class="form-group">
                        <div class="custom-control custom-checkbox" v-if="current_test.question_type.id == '04'">
                            <input v-model="checkedChoice" type="checkbox" :id="'choice'+index" class="custom-control-input" :value="item">
                            <label :for="'choice'+index" class="custom-control-label">{{item.text_choice}}</label>
                        </div>
                    </div>
                    
                    <div class="custom-control custom-checkbox" v-if="current_test.question_type.id == '01'">
                        <b-form-group label="Individual radios" >
                            <b-form-radio v-for="(item, index) in test_question_choice.list" :key="index" v-model="answer" name="some-radios" :value="item" >{{item.text_choice}}</b-form-radio>                            
                        </b-form-group>                        
                    </div>                    

                    <div class="form-group" v-if="current_test.question_type.id == '02'">
                        <b-form-group label="Individual radios">
                            <b-form-radio v-for="(item, index) in test_question_choice.list" :key="index" v-model="answer" name="some-radios" :value="item">{{item.text_choice}}</b-form-radio>                            
                        </b-form-group>
                    </div>

                    <div class="form-group" style="max-width:600px;" v-if="current_test.question_type.id == '03'">
                      <input v-model="answer" type="text" class="form-control" name="answerText" id="answerText" placeholder="Your text answer ...">
                    </div>

                    <br/>
                    <p class="text-50 mb-0">Note: There can be multiple correct answers to this question.</p>
                </div>
            </div>

             <div class="navbar navbar-expand-md navbar-list bg-light " style="white-space: nowrap;">
                <div class="container">
                    <div v-if="test_templateTest.pagination" class="nav navbar-nav ml-sm-auto navbar-list__item">
                        <div class="nav-item d-flex flex-column flex-sm-row ml-sm-16pt">
                            <p v-if="!checkedChoice.length && answer" class="mr-3 text-warning">Please select or fill your answer</p>
                            <button
                                v-if="test_templateTest.pagination.total > data_index"
                                :disabled="!checkedChoice.length && !answer"
                                class="btn btn-accent"
                                @click=" submitAnswer() ; data_index+=1 ; fetch_test_question_choice() "
                            >
                                Next Question <i class="material-icons icon--right">play_arrow</i>
                            </button>

                            <button
                                v-else
                                :disabled="!checkedChoice.length && !answer"
                                class="btn btn-accent"
                                @click=" submitAnswer() ; $router.push('/peserta') "
                            >
                                Finish <i class="material-icons icon--right">play_arrow</i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'

import paginationBar from '@@/components/paginationBar'

export default {
    layout : 'peserta',
    components : {
        paginationBar,
    },
    middleware: ({ store, redirect }) => {
        if (!store.state.schedule_templateTest.detail) return redirect('/peserta')
    },
    data() {
        return {            
            participant_id : '1',            
            data_index : 1,
            type : this.$route.query.type,
            checkedChoice : [],
            answer : null,            

        }
    },
    async created() {
        await this.$store.dispatch('test_templateTest/getAll', {'object[]':this.schedule_templateTest.test_code.id})
        this.fetch_test_question_choice()
    },
    computed: {
        ...mapState({
            test_templateTest : state => state.test_templateTest,
            schedule_templateTest : state => state.schedule_templateTest.detail,
            test_question_choice : state => state.test_question_choice,
        }),

        current_test() {
            return this.test_templateTest.list.length ? this.test_templateTest.list[this.data_index-1].id : {}
        }
    },
    methods: {

        triggerNext() {

        },

        showAlert(){
            
        },

        fetch_test_question_choice(){
            this.$store.dispatch('test_question_choice/clearAll');
            this.$store.dispatch('test_question_choice/getAll', { 'question[]' : this.current_test.question_id });
            this.checkedChoice = []
            this.answer = null            
        },

        submitAnswer() {
            //console.log(this.answer)
            // if (this.answerText.length) this.checkedChoice.push(this.answerText)
            if(this.current_test.question_type.id =='02' && this.current_test.question_type.id =='01'){
                this.$axios.post('lms/api/testquestionparticipantchoice', {
                    business_code : this.current_test.business_code.business_code,
                    question :  this.current_test.question_id,
                    participant :  this.participant_id,
                    relation_question : this.schedule_templateTest.relation_question_id,
                    sequence_no: this.answer.sequence_no,
                    text_choice : this.answer.text_choice,
                    begin_date : moment(new Date).format('YYYY-MM-DD'),
                    end_date : "9999-12-30",
                })
                .then((res) => {
                    console.log(res.data);
                })
                .catch(err => {
                    console.log(err.response);
                })
            }else if(this.current_test.question_type.id =='03'){
                this.$axios.post('lms/api/testquestionparticipantchoice', {
                    business_code : this.current_test.business_code.business_code,
                    question :  this.current_test.question_id,
                    participant :  this.participant_id,
                    relation_question : this.schedule_templateTest.relation_question_id,
                    sequence_no: 1,
                    text_choice : this.answer,
                    begin_date : moment(new Date).format('YYYY-MM-DD'),
                    end_date : "9999-12-30",
                })
                .then((res) => {
                    console.log(res.data);
                })
                .catch(err => {
                    console.log(err.response);
                })
            }            
                
            
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>
