<template>

    <!-- <div v-if="materi" class="container page-section">

        <b>
            <p style="font-size:20px">Materi Detail</p>
        </b>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{ materi.materi_name }}</h3>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Type</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.materi_type.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Method</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.method.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Competence</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.competence.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Proficiency Level</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.pl_code.value}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Selling Price</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>Rp {{materi.selling_price}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Purchase Price</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>Rp {{materi.purchase_price}}</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Link</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.address}} <i class="fa fa-download"></i></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b>
                                    <p>Description</p>
                                </b>
                            </div>
                            <div class="col-sm-8">
                                <p>{{materi.description}}</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div> -->
    <div class="container">
    <div v-if="schedule_materi" class="bg-gradient-primary pb-lg-64pt py-32pt">
                <div class="container">
                    <div v-if="schedule_materi.child.address && schedule_materi.child.address.substr(schedule_materi.child.address.length-4)==='.jpg'">
                        <img :src="schedule_materi.child.address"/>
                    </div>
                    <div v-if="schedule_materi.child.address &&schedule_materi.child.address.substr(schedule_materi.child.address.length-4)==='.pdf'">
                        <embed :src="schedule_materi.child.address" width="550" height="600"/>
                    </div>
                    <!-- <div class="js-player embed-responsive embed-responsive-16by9 mb-32pt" data-domfactory-upgraded="player">
                        <div class="player embed-responsive-item">
                            <div class="player__content">
                                <div class="player__image" style="--player-image: url(assets/images/illustration/player.svg)"></div>
                                <a href="" class="player__play">
                                    <span class="material-icons">play_arrow</span>
                                </a>
                            </div>
                            <div>
                               <img :src="materi.address"/>
                            </div>

                            <div class="player__embed d-none">
                                <iframe class="embed-responsive-item" src="https://player.vimeo.com/video/97243285?title=0&amp;byline=0&amp;portrait=0" allowfullscreen=""></iframe>
                            </div>
                        </div>
                    </div> -->

                    <div class="d-flex flex-wrap align-items-end mb-2pt">
                        <h1 class="text-white flex m-0">{{schedule_materi.child.materi_name}}</h1>
                    </div>

                    <p class="lead text-white-50 d-flex align-items-center">{{schedule_materi.child.materi_type.value}} 
                        <span class="ml-16pt d-flex align-items-center">
                            <i class="material-icons icon-16pt mr-4pt">opacity</i> 
                            {{schedule_materi.child.method.value}}    
                        </span>
                        <span class="ml-16pt d-flex align-items-center">
                            <i class="material-icons icon-16pt mr-4pt">opacity</i> 
                            {{schedule_materi.child.competence.value}}   
                        </span>
                        <span class="ml-16pt d-flex align-items-center"><i class="material-icons icon-16pt mr-4pt">opacity</i> 
                            {{schedule_materi.child.pl_code.value}}</span>

                    </p>
                    <br>
                    <p class="lead text-white-50 measure-lead-max">{{schedule_materi.child.description}}</p>
                    <br>
                    <!-- <div v-if="materi.address.substr(materi.address.length-4)==='.jpg'" class="d-flex flex-column flex-sm-row align-items-center justify-content-start">
                        <a :href="materi.address" download class="btn btn-outline-white mb-16pt mb-sm-0 mr-sm-16pt">Download Materi 
                            <i class="material-icons icon--right">play_circle_outline</i>
                        </a>
                    </div> -->
                    <div v-if="schedule_materi.child.address && schedule_materi.child.address.substr(schedule_materi.child.address.length-4)==='.pdf'" class="d-flex flex-column flex-sm-row align-items-center justify-content-start">
                        <a :href="schedule_materi.child.address" download class="btn btn-outline-white mb-16pt mb-sm-0 mr-sm-16pt">Download PDF   
                            <i class="fa fa-download">  </i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
</template>
<script>
    import {mapState, mapActions} from 'vuex';
    export default {
        layout: 'peserta',
        components: {

        },
        middleware: ({ store, redirect }) => {
            if (!store.state.schedule_materi.detail) return redirect('/peserta')
        },
        data() {
            return {
      
            };

        },
        computed: {
        ...mapState({
            schedule_materi : state => state.schedule_materi.detail,
        })
    },
        methods: {
            
        }

    };
</script>