<template>
    <div class="container">
        <headerEventComponent/>
        <headerBatchComponent/>
        <headerSessionComponent/>
        <headerScheduleComponent/>
        <div class="page-section">

            <div class="page-headline text-center">
                <h2>Forum</h2>
            </div>

            <div class="page-section">

                <h3 class="m-4">Discussions</h3>

                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center" style="white-space: nowrap;">
                            <div class="col-lg-auto">
                                <form class="search-form search-form--light d-lg-inline-flex mb-8pt mb-lg-0">
                                    <input type="text" class="form-control w-lg-auto" placeholder="Search Discussion">
                                    <button class="btn" type="submit" role="button"><i class="material-icons">search</i></button>
                                </form>
                            </div>
                            <div class="col-lg d-flex flex-wrap align-items-center">
                                <div class="ml-lg-auto dropdown">
                                    <button @click="showMyForum" type="button" class="btn btn-link text-black-70">My Forum</button>
                                    <!-- <a href="#" class="btn btn-link dropdown-toggle text-black-70" data-toggle="dropdown">Filter</a>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <span  class="btn dropdown-item">All Topics</span>
                                        <span  class="btn dropdown-item">My Topics</span>
                                    </div> -->
                                </div>
                                <div @click="clearDetail(); $bvModal.show('forumForm')" class="btn btn-accent">New Discussion</div>
                            </div>
                        </div>
                    </div>


                    <div class="list-group list-group-flush list-group-item-action">

                        <div v-for="(item, index) in forum.list" :key="index" class="list-group-item p-3"

                        >
                            <div class="row align-items-center">
                                <div class="col-md-3 mb-8pt mb-md-0">
                                    <div class="media">
                                        <div class="media-left mr-16pt">
                                            <i  class="material-icons m-2">
                                                forum
                                            </i>
                                            <!-- <img src="/img/guy-3.jpg" width="40" alt="avatar" class="rounded-circle"> -->
                                        </div>
                                        <div class="media-body media-middle">
                                            <p class="m-0 text-body">{{ item.owner }}</p>
                                            <p class="text-muted m-0">{{ momentSince(item.begin_date) }}</p>
                                        </div>
                                    </div>
                                </div>
                                <div @click="getDetail(item.object_identifier) ; $router.push('/peserta/forum/detail?type=event')"
                                    class="col-md-6 mb-8pt mb-md-0"
                                    style="cursor:pointer;"
                                >
                                    <p class="mb-8pt"> <strong> {{ item.forum_title }} </strong></p>
                                    <span class="chip chip-outline-secondary">{{ item.batch.batch_name }}</span>
                                </div>
                                <div v-if="$auth.user.username == item.owner" class="col-md-3 d-flex align-items-center justify-content-end">
                                    <span class="mx-4">
                                        <button @click="showUpdateForm(item.object_identifier)"
                                            type="button" class="btn text-warning btn-sm">
                                            <i class="fa fa-edit" aria-hidden="true"></i>
                                        </button>
                                        <button @click="deleteData(item.object_identifier, index)"
                                            type="button" class="btn text-danger btn-sm">
                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                        </button>
                                    </span>
                                </div>
                            </div>
                        </div>



                    </div>


                    <div v-if="forum.isLoading" class="card-body text-center d-flex justify-content-center">
                        <div class="loader loader-accent text-center"></div>
                    </div>
                    <div class="card-body text-center d-flex justify-content-center">
                        <paginationBar :state="forum" :storeModuleName="'forum'"/>
                    </div>
                </div>

            </div>
        </div>


        <b-modal v-model="modalShow" ref="forumForm" hide-footer hide-header id="forumForm" size="lg">
            <forumForm v-if="modalShow" />
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'
import forumForm from '@@/components/forms/forumForm'

export default {
    layout : 'peserta-batch',
    components : { paginationBar, forumForm },
    middleware({store,redirect}) {      
        if (!store.state.batch.detail) redirect('/peserta')      
    },
    created() {
        this.$store.dispatch('forum/getAll');
    },
    data() {
        return {
            type : this.$route.query.type,

            modalShow: false,
            modalDelimitShow : false,
            filters : {
                status : null,
            },
            begin_date:null,
            end_date: null,
        }
    },
    computed: {
        ...mapState({
            forum : state => state.forum,
        }),
    },
    methods: {
        ...mapActions({
            getDetail: 'forum/getDetail',
            clearDetail: 'forum/clearDetail',
            deleteOne: 'forum/deleteOne',
            getAll: 'forum/getAll',
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('forumForm')
        },

        showMyForum() {
            this.$store.dispatch('forum/getAll', {
                'owner[]' : this.$auth.user.username ,
                begin_date_lte : null,
                end_date_gte : null,
            });

        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.batch.detail.begin_date
            this.end_date = moment(new Date()).format("YYYY-MM-DD")
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/forum?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/forum', {}, {
                    params : {
                        object_identifier : this.forum.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('forum/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        momentSince(date) {
            return moment(date).fromNow()
        }
    },

}
</script>

<style scoped>
.list-group-item-action :hover {
    background-color: lavender;
}
</style>
