<template>
    <div class="container page-section">
        <div>
            <div class="text-center mt-5 mb-4">
                <h2>DIY & HOW TO EVERYTHING</h2>
            </div>
            <div class="card">
                <div class="card-header">
                    <div class="row align-items-center" style="white-space: nowrap;">
                        <div class="col-lg-auto">
                            <form class="search-form search-form--light d-lg-inline-flex mb-8pt mb-lg-0">
                                <input type="text" class="form-control w-lg-auto" placeholder="Search Discussion">
                                <button class="btn" type="submit" role="button"><i class="material-icons">search</i></button>
                            </form>
                        </div>
                        <div class="col-lg d-flex flex-wrap align-items-center">
                            <div class="ml-lg-auto dropdown">
                                <button @click="showMyForum" type="button" class="btn btn-link text-black-70">My Insight</button>
                                <!-- <a href="#" class="btn btn-link dropdown-toggle text-black-70" data-toggle="dropdown">Filter</a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <span  class="btn dropdown-item">All Topics</span>
                                    <span  class="btn dropdown-item">My Topics</span>
                                </div> -->
                            </div>
                            <div @click="clearDetail(); $bvModal.show('insightForm')" class="btn btn-accent">New Insight</div>
                        </div>
                    </div>
                </div>
            </div>
            <b-card-group deck>
                <div class="row">
                    <div class="col-sm-6 col-md-3 has-margin" v-for="(item, index) in insight_list" :key="index">

                        <b-card :img-src="item.forum_image" img-alt="Card image" img-top>
                            <h4>{{item.forum_title}}</h4>
                            <b-card-text>
                                {{item.forum_text}}
                                <br>
                                <div class="text-center mt-3">
                                    {{item.owner}} - {{item.forum_time}}
                                </div>
                            </b-card-text>
                            <div class="d-flex align-items-center">
                                <span class="text-50 d-flex align-items-center text-decoration-0">
                                    <!-- <span>
                                        <div  class="loader loader-accent text-center m-1"></div>
                                    </span> -->
                                    <span>

                                        <i class="material-icons text-secondary btn unliked" v-if="!item.like_status" @click="toggleLike(item.forum_id,item.business_code.business_code)" style="font-size: 20px;">thumb_up</i>

                                        <i class="material-icons text-accent btn liked" v-else @click="toggleLike(item.forum_id,item.business_code.business_code)" style="font-size: 20px;">thumb_up</i>
                                        {{item.likes.length}} Likes
                                    </span>
                                    <span v-if="$auth.user.username == item.owner">
                                        <button @click="showUpdateForm(item.object_identifier)"
                                            type="button" class="btn text-warning btn-sm">
                                            <i class="fa fa-edit" aria-hidden="true"></i>
                                        </button>
                                    </span>
                                    <span v-if="$auth.user.username == item.owner">
                                        <button @click="deleteData(item.object_identifier, index)"
                                            type="button" class="btn text-danger btn-sm">
                                            <i class="fa fa-trash" aria-hidden="true"></i>
                                        </button>
                                    </span>
                                </span>
                            </div>
                        </b-card>

                    </div>
                </div>
            </b-card-group>

        </div>
        <b-modal v-model="modalShow" ref="insightForm" hide-footer hide-header id="insightForm" size="lg">
            <insightForm v-if="modalShow" :getAllContent='getAllContent' />
        </b-modal>



    </div>
</template>
<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'
import insightForm from '@@/components/forms/insightForm'

export default {
    layout : 'peserta-batch',
    components : { paginationBar, insightForm },
    middleware({store,redirect}) {      
        if (!store.state.batch.detail) redirect('/peserta')      
    },
    async created() {
        await this.$store.dispatch('insight/clearAll');
        await this.$store.dispatch('insight/getAll');
        this.getAllContent();

    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            filters : {
                status : null,
            },
            insight_list:[],
            begin_date:null,
            end_date: null,
            like_status:false,
        }
    },
    computed: {
        ...mapState({
            insight : state => state.insight,
        }),
    },
    methods: {
         ...mapActions({
            getDetail: 'insight/getDetail',
            clearDetail: 'insight/clearDetail',
            deleteOne: 'insight/deleteOne',
            getAll: 'insight/getAll',
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('insightForm')
        },
        getAllContent(){
            //console.log('masuk paekoooooooooooooooooooooooooooo');
            this.insight_list = [],
            this.insight.list.forEach(async (item, key) => {
              await this.insight_list.push({
                object_identifier: item.object_identifier,
                begin_date: item.begin_date,
                end_date: item.end_date,
                business_code: item.business_code,
                batch: item.batch,
                forum_id : item.forum_id,
                forum_title: item.forum_title,
                forum_text: item.forum_text,
                forum_image: item.forum_image,
                forum_time: item.forum_time,
                owner: item.owner,
                like_status: this.like_status,
                likes: []
              });

              await this.$axios.get('lms/api/forumlike?forum[]=' + item.forum_id)
                .then(response => {
                  response.data.data.forEach(async (like, index) => {
                    await this.insight_list[key].likes.push({
                      key: index,
                      owner: like.owner,
                    });
                  });
                }).catch(e => {
                  console.log(e);
                });
                var auth = this.$auth.user.username
                var found = this.insight_list[key].likes.some(function (el) {
                    return el.owner === auth;
                });
                if (found) {
                    this.like_status= true
                    this.insight_list[key].like_status = this.like_status
                }else{
                    this.like_status= false
                    this.insight_list[key].like_status = this.like_status
                }

            })
        },
        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/forum?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        toggleLike(id,buscd) {
            this.$axios.post('lms/api/forumlike', {
                begin_date : moment(new Date).format("YYYY-MM-DD"),
                begin_time : moment(new Date).format("HH:mm"),
                business_code : buscd,
                otype_parent :"SCHDL",
                forum : id,
                like : true,
                owner : this.$auth.user.username,
            })
            .then(() => {
                this.getAllContent();
                console.log(this.insight_list)
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        showMyForum() {
            this.$store.dispatch('insight/getAll', {
                'owner[]' : this.$auth.user.username ,
                begin_date_lte : null,
                end_date_gte : null,
            });

        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        momentSince(date) {
            return moment(date).fromNow()
        }
    },

}
</script>

<style scoped>
    .has-margin {
        margin-bottom: 15px;
    }
    .list-group-item-action :hover {
        background-color: lavender;
        cursor: pointer;
    }
    .unliked:hover {
        color: #ed0b4c !important;
    }
    .liked:hover {
        color: #818181 !important;
    }
</style>
