<template>
    <div class="container page-section">
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">On Going Events</h4>
                            <p class="card-subtitle text-light">happening now</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of ongoing Event <span class="badge badge-pill badge-success badge-lg ml-3">{{Ongoing && Ongoing.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '01'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Upcoming Events</h4>
                            <p class="card-subtitle text-light">Upcoming</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Upcoming Event <span class="badge badge-pill badge-accent badge-lg ml-3">{{Upcoming && Upcoming.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '02'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Events Complete</h4>
                            <p class="card-subtitle text-light">Completed event</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Event Complete <span class="badge badge-pill badge-secondary badge-lg ml-3">{{Done && Done.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '03'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">On Going Events</h4>
                            <p class="card-subtitle text-light">happening now</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of ongoing Event <span class="badge badge-pill badge-success badge-lg ml-3">{{Ongoing && Ongoing.total}}</span></p>
                        <div class="text-right">
                            <button class="btn-outline-accent btn" :disabled="filters.status == '01'" @click="filters.status = '01'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Upcoming Events</h4>
                            <p class="card-subtitle text-light">Upcoming</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Upcoming Event <span class="badge badge-pill badge-accent badge-lg ml-3">{{Upcoming && Upcoming.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-outline-accent" :disabled="filters.status == '02'" @click="filters.status = '02'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Events Complete</h4>
                            <p class="card-subtitle text-light">Completed event</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Event Complete <span class="badge badge-pill badge-secondary badge-lg ml-3">{{Done && Done.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-outline-accent" :disabled="filters.status == '03'" @click="filters.status = '03'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->

        <!-- <div class="page-headline text-center pb-3">
            <h2>My Events</h2>
        </div>
        <div class="card">
            <div class="" style="">
                <table class="table table-flush table-responsive  table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Company</th>
                        <th>Event Name</th>
                        <th>Type</th>
                        <th>Unit</th>
                        <th>Status</th>
                        <th>Vendor</th>
                        <th>Start</th>
                        <th>End</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in event.list" :key="index"
                        @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')" style="cursor:pointer;">
                        <td> {{ index+1 }} </td>
                        <td> {{ item.business_code.company_name }} </td>
                        <td>
                            <b> <i v-if="item.reference.event_id" class="material-icons text-warning">bookmark</i> {{ item.event_name }}</b>
                        </td>
                        <td> {{ item.event_type.value }} </td>
                        <td> {{ item.organization.organization_type.value }} {{item.organization.organization_name}}</td>
                        <td v-bind:class="{
                            'text-success': item.event_status.value == 'Ongoing',
                            'text-accent': item.event_status.value == 'Upcoming',
                            'text-secondary': item.event_status.value == 'Done',
                            }" >
                            <b>{{ item.event_status.value }}</b>
                        </td>
                        <td> {{ item.vendor.company_name }} </td>
                        <td> {{formatDate(item.begin_date)}} </td>
                        <td> {{formatDate(item.end_date)}} </td>
                    </tr>
                    <tr v-if="event.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
             <div class="card-footer">
                <paginationBar :state='event' :storeModuleName="'event'" />
            </div>

        </div> -->

         <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <p class="card-title" style="font-size:30px;color:black">Event List - Ongoing</p>
            </div>
        </div>

        <!-- <div class="card">
            <div class="" style="">
                <table class="table table-flush table-responsive  table-hover">
                <thead class="">
                    <tr class="">
                        <th>Company</th>
                        <th>Event</th>
                        <th>Batch</th>
                        <th>Type</th>
                        <th>Curriculum</th>
                        <th>Status</th>
                        <th>Start</th>
                        <th>End</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in myBatch" :key="index"
                        @click="
                            getOne({data : item});
                            getEventDetail({data : item.event});
                            $router.push('/peserta/activity?type=event')"
                        style="cursor:pointer;"
                    >
                        <td> {{ item.business_code.company_name }} </td>
                        <td> {{ item.event.event_name }} </td>
                        <td> {{ item.batch_name }} </td>
                        <td> {{ item.event.event_type.value }} </td>
                        <td> {{ item.curriculum.value }} </td>
                        <td v-bind:class="{
                            'text-success': item.event.event_status.value == 'Ongoing',
                            'text-accent': item.event.event_status.value == 'Upcoming',
                            'text-secondary': item.event.event_status.value == 'Done',
                            'text-warning': item.event.event_status.value == undefined,
                            }" >
                            <b>{{ item.event.event_status.value || 'Planning' }}</b>
                        </td>
                        <td> {{formatDate(item.begin_date)}} </td>
                        <td> {{formatDate(item.end_date)}} </td>
                    </tr>
                    <tr v-if="batchParticipant.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
             <div class="card-footer">
                <paginationBar :state='batchParticipant' :storeModuleName="'batchParticipant'" />
            </div>

        </div> -->

        <div class="card">
            <div class="" style="">
                <table class="table table-flush table-responsive  table-hover">
                <thead class="">
                    <tr class="">
                        <th>Curriculum Name</th>
                        <th>Event Title</th>
                        <th>Cycle</th>
                        <th>Event Type</th>
                        <th>Location</th>
                        <th>Academy</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Onsite / Online</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in myBatch" :key="index"
                        @click="
                            getOne({data : item});
                            getEventDetail({data : item.event});
                            $router.push('/peserta/activity?type=event')"
                        style="cursor:pointer;"
                    >
                        <th>Curriculum Name</th>
                        <th>Event Title</th>
                        <th>Cycle</th>
                        <th>Event Type</th>
                        <th>Location</th>
                        <th>Academy</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Onsite / Online</th>
                        <th>Status</th>
                    </tr>
                    <tr v-if="batchParticipant.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
             <div class="card-footer">
                <paginationBar :state='batchParticipant' :storeModuleName="'batchParticipant'" />
            </div>

        </div>


        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <p class="card-title" style="font-size:30px;color:black">Learning Roadmap</p>
            </div>
        </div>


        <div class="card">

            <div class="text-center">
                <b-button-group class="mt-2">
                    <b-button variant="info">Current Roadmap</b-button>
                    <b-button variant="info">Future Roadmap</b-button>
                </b-button-group>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Basic</th>
                                <th>Intermediate</th>
                                <th>Advance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Fundamental of Cisco Router</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td></td>
                                <td>GPMP V</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td></td>
                                <td></td>
                                <td>Coaching for Supervisor</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <p class="card-title" style="font-size:25px;color:black">My Learning Proposal</p>
            </div>
            <b-button class="btn btn-sm" variant="success">Proposed Learning</b-button>
        </div>
       
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum Name</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item, index) in 3" :key="index">
                                <td>{{ index+1 }}</td>
                                <td>Advance HTML Programming</td>
                                <td>Planned</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- <curriculumRequest/> -->


    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'
import curriculumRequest from '@@/pages/curriculum/request'

export default {
    layout: 'peserta',
    components: {
        paginationBar,
        curriculumRequest
    },
    data() {
        return {
            filters : {
                status : '01',
            },
        }
    },
    created() {
        // this.$store.dispatch('event/getAll');
        this.$store.dispatch('batch/getAll');
        this.$store.dispatch('batchParticipant/getAll', {
            'participant[]' : '1'
            //  // ini dengan participant id yang login !!!
        });
    },
    computed: {
        ...mapState({
            event : state => state.event,
            Ongoing : state => state.event.Ongoing,
            Upcoming : state => state.event.Upcoming,
            Done : state => state.event.Done,
            batchParticipant : state => state.batchParticipant
        }),

        myBatch() {
            let batch_list_copy = [...this.batchParticipant.list]
            let filter = batch_list_copy.filter(obj => {
                // return obj.batch.batch_id !== undefined && obj.batch.event.event_situation.id == '2'
            })
            let batch = filter.map(item => {return item.batch})
            return batch
        }
    },
    methods: {
        ...mapActions({
            getDetail: 'batch/getDetail',
            clearDetail: 'batch/clearDetail',
            deleteOne: 'batch/deleteOne',
            getAll: 'batch/getAll',
            getOne: 'batch/getOne',

            getEventDetail: 'event/getOne',
        }),
        runFilter(){
            let params = {}
            if (this.filters.status)
                params["event_status[]"] = this.filters.status
            this.getAll(params)
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },


    },

}

</script>