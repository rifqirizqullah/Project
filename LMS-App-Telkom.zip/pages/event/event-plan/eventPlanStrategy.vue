<template>
    <div class="container page-section">

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{event.event_name}}</h3>
                    <p class="card-subtitle text-dark">
                        ID <code> {{event.event_id}} </code>
                        Identifier <code> {{event.object_identifier}} </code>
                    </p>
                </div>
                <div class="row card-body">
                    <div class="col-lg-3">
                        <small>Type</small>
                        <p>{{event.event_type.value}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Begin/End Date</small>
                        <p>{{formatDate(event.begin_date)}} - {{formatDate(event.end_date)}}</p>
                    </div>
                    <div class="col-lg-2">
                        <small>Description</small>
                        <p>{{event.description}}</p>
                    </div>
                    <div class="col-lg-2">
                        <small>Organization</small>
                        <p>{{event.organization.organization_name}}</p>
                    </div>
                    <div class="col-lg-2">
                        <small>Vendor</small>
                        <p>{{event.vendor.company_name}}</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h4 class="card-title">Learning Strategy</h4>
                <p class="card-subtitle">Strategy of This Event</p>
            </div>
            <button class="btn btn-sm btn-success" @click="$bvModal.show('eventPlanStrategyForm')" >+ Add Learning Strategy</button>
        </div>

        <div class="card">
            <table class="table table-flush table-responsive">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Year</th>
                        <th>Strategy Name</th>
                        <th>Unit</th>
                        <th>Business Issue</th>
                        <th>Performance Issue</th>
                        <th>Competency Issue</th>
                        <th>Learning Focus</th>
                        <th>E Cluster</th>
                        <th>Acttion</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in eventPlanStrategy.list" :key="index" >
                        <td> {{index+1}} </td>
                        <td>{{item.child.year}}</td>
                        <td>{{item.child.organization_strategy_name}}</td>
                        <td>{{item.child.organization_code.organization_name}}</td>
                        <td>{{item.child.object_parent.value}} <br/> <small>{{item.child.object_parent.object_type}}</small> </td>
                        <td>{{item.child.object_child1.value}} <br/> <small>{{item.child.object_child1.object_type}}</small> </td>
                        <td>{{item.child.object_child2.value}} <br/> <small>{{item.child.object_child2.object_type}}</small> </td>
                        <td>{{item.child.learning_focus.value}}</td>
                        <td>{{item.child.employee_cluster.value}}</td>
                        <td>
                            <button class="dropdown-item" @click="deleteData(item.object_identifier, index)"> <i class="fa fa-trash"></i></button>

                        </td>
                    </tr>
                    <tr v-if="eventPlanStrategy.isLoading" >
                        <td colspan="15">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>


            </table>
        </div>

        <b-modal v-model="modalShow" ref="eventPlanStrategyForm" hide-footer hide-header id="eventPlanStrategyForm" size="lg" @hide='clearDetail'>
            <eventPlanStrategyForm v-if="modalShow" />
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import eventPlanStrategyForm from '@@/components/forms/eventPlanStrategyForm'
import paginationBar from '@@/components/paginationBar'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'event',
    components : {
        eventPlanStrategyForm ,
        paginationBar
    },
    async created() {
        await this.$store.dispatch('eventPlanStrategy/clearAll')
        this.$store.dispatch('eventPlanStrategy/getAll')
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            end_date: null,
        }
    },
    computed: {
        ...mapState({
            eventPlanStrategy : state => state.eventPlanStrategy,
            event : state => state.eventPlan.detail,
        }),
    },
    methods: {
        ...mapActions({
            getDetail: 'eventPlanStrategy/getDetail',
            clearDetail: 'eventPlanStrategy/clearDetail',
            deleteOne: 'eventPlanStrategy/deleteOne'
        }),


        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.end_date = this.eventPlanStrategy.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/lmsrelation?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },


        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
