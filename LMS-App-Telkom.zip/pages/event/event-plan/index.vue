<template>
    <div>
        <div class="container page-section">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <div class="flex">
                        <p class="card-title" style="font-size:25px;color:black">Manage Event Plan</p>
                        <p style="font-size:15px;margin-top:-15px">List of Available event Plan</p>
                    </div>
                   <button @click="clearDetail(); $bvModal.show('eventPlanForm')" class="btn btn-success btn-sm">+ Create Event Plan</button>  
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button> 
                </div>
    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select v-model="filters.company" class="form-control" name="company" id="company">
                      <option
                        v-for="(item, index) in company.list"
                        :key="index"
                        :value="item.business_code"
                      >{{item.company_name}}</option>
                    </select>
                    <small class="form-text text-muted">Company</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.event_name"
                        type="text"
                        class="form-control"
                        id="event_name"
                        placeholder="Event Name..."
                        >
                        <small class="form-text text-muted">Event Name</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.event_type"
                      class="form-control"
                      name="event_type"
                      id="event_type"
                    >
                      <option
                        v-for="(item, index) in EVNTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Event Type</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.unit"
                      class="form-control"
                      name="unit"
                      id="unit"
                    >
                      <option
                        v-for="(item, index) in unit.list"
                        :key="index"
                        :value="item.organization_code"
                      >{{item.organization_name}}</option>
                    </select>
                    <small class="form-text text-muted">Unit</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.vendor"
                      class="form-control"
                      name="vendor"
                      id="vendor"
                    >
                      <option
                        v-for="(item, index) in companyRelation.list"
                        :key="index"
                        :value="item.child_company.business_code"
                      >{{item.child_company.company_name}}</option>
                    </select>
                    <small class="form-text text-muted">Vendor</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>   
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Company</th>
                            <th>Event Name</th>
                            <th>Type</th>
                            <th>Unit</th>
                            <th>Vendor</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in eventPlan.list" :key="index">
                            <td> {{index+1}} </td>
                            <td> {{ item.business_code.company_name }} </td>
                            <td @click="getDetail(item.object_identifier); $router.push('/event/batch')" style="cursor:pointer;">
                               <strong> {{ item.event_name }}</strong>
                            </td>
                            <td> {{ item.event_type.value }} </td>
                            <td> {{ item.organization.organization_name }} </td>
                            <td> {{ item.vendor.company_name }} </td>
                            <td> {{formatDate(item.begin_date)}} </td>
                            <td> {{formatDate(item.end_date)}} </td>
                            <td>
                                <div class="btn-group">
                                <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                    aria-haspopup="true" aria-expanded="false">
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/event-plan/detail')">Learning Strategy</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch')">Batch</button>
                                </div>
                            </div>
                            </td>
                        </tr>
                        <tr v-if="eventPlan.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
                <div class="card-footer">
                    <paginationBar :state='eventPlan' :storeModuleName="'eventPlan'" />
                </div>

            </div>

            <b-modal v-model="modalShow" ref="eventPlanForm" hide-footer hide-header id="eventPlanForm" size="lg">
                <eventPlanForm v-if="modalShow" />
            </b-modal>

            <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>
        </div>
    </div>
</template>

<script>
import moment from 'moment'
import eventPlanForm from '@@/components/forms/eventPlanForm'
import paginationBar from '@@/components/paginationBar'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'event',
    components : { eventPlanForm, paginationBar },
    created() {
        this.$store.dispatch('eventPlan/getAll');        
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            begin_date:null,
            end_date: null,
            filters: {                
                company: null,
                event_name: null,
                event_type: null,
                vendor: null,
                begin_date: null,
                end_date: null,              
                unit:null
            }
        }
    },
    computed: {
        ...mapState({            
            eventPlan : state => state.eventPlan,
            EVNTY : state => state.EVNTY,
            LEVST : state => state.LEVST,
            unit : state => state.unit,
            companyRelation : state => state.companyRelation,
            company : state => state.company,
        })
    },
    methods: {
        getParam(){
        this.$store.dispatch("company/getAll");
        this.$store.dispatch("EVNTY/getAll");
        this.$store.dispatch("unit/getAll");
        this.$store.dispatch("companyRelation/getAll");
        
        },
        ...mapActions({
            getDetail: 'eventPlan/getDetail',
            clearDetail: 'eventPlan/clearDetail',
            deleteOne: 'eventPlan/deleteOne',
            getAll: 'eventPlan/getAll'
        }),
        runFilter() {
        let params = {};
        if (this.filters.company)
            params["business_code"] = [this.filters.company];
        if (this.filters.event_name)
            params["event_name"] = [this.filters.event_name];
        if (this.filters.event_type)
            params["event_type"] = [this.filters.event_type];
        if (this.filters.unit)
            params["organization"] = [this.filters.unit];
        if (this.filters.vendor)
            params["vendor"] = [this.filters.vendor];
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;
            this.$router.push({ path : this.$route.path , query : params})
            
            this.getAll(params);
        },
        clearFilters() {
            this.filters = {
                company: null,
                event_name: null,
                event_type: null,
                vendor: null,
                begin_date: null,
                end_date: null,              
                unit:null
            };
        },
        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('eventPlanForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.eventPlan.detail.begin_date
            this.end_date = this.eventPlan.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/event?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/event', {}, {
                    params : {
                        object_identifier : this.eventPlan.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('eventPlan/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
