<template>
    <div class="container page-section">

        <h1 class="display-4">Event Planning Detail</h1>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{eventPlan.event_name}}</h3>
                    <p class="card-subtitle text-dark">
                        ID <code> {{eventPlan.event_id}} </code>
                        Identifier <code> {{eventPlan.object_identifier}} </code>
                    </p>
                </div>
                <div class="row card-body">
                    <div class="col-lg-3">
                        <small>Description</small>
                        <p>{{eventPlan.description}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Event Type</small>
                        <p>{{eventPlan.event_type.value}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Begin/End Date</small>
                        <p>{{formatDate(eventPlan.begin_date)}} - {{formatDate(eventPlan.end_date)}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Company</small>
                        <p>{{eventPlan.business_code.company_name}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Organization</small>
                        <p>{{eventPlan.organization.organization_name}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Vendor</small>
                        <p>{{eventPlan.vendor.company_name}}</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-8pt">
            <div class="col-12">
                <eventPlanStrategy/>
            </div>
            <!-- <div class="col-12">
                <eventPlanBatch/>
            </div> -->

        </div>

    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import eventPlanStrategy from './eventPlanStrategy'
import eventPlanBatch from './eventPlanBatch'

export default {
    layout : 'event',
    components : { eventPlanStrategy, eventPlanBatch },
    middleware: ({ store, redirect }) => {
        if (!store.state.eventPlan.detail) return redirect('/event/event-plan')
    },
    computed: {
        ...mapState({
            eventPlan: state => state.eventPlan.detail,
            eventPlan_id: state=> state.eventPlan.detail.event_id
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'eventPlan/getDetail',
            clearDetail: 'eventPlan/clearDetail',
        }),

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
