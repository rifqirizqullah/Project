<template>
    <div>
        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h4 class="card-title">Batch Planning</h4>
                <p class="card-subtitle">Batch for This Event Planning</p>
            </div>
            <button class="btn btn-sm btn-success" @click="$bvModal.show('batchForm')" >+ Add Batch</button>
        </div>

        <div class="card">
            <table class="table table-flush table-responsive">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Batch Name</th>
                        <th>Location</th>
                        <th>Curriculum</th>
                        <th>Vendor</th>
                        <th>Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in batch.list" :key="index" >
                        <td> {{index+1}} </td>
                        <td> {{item.batch_name}} </td>
                        <td> {{item.location.value}} </td>
                        <td> {{item.curriculum.value}} </td>
                        <td> {{item.vendor.company_name}} </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batchDetail')">Detail</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>


            </table>
        </div>

        <b-modal v-model="modalShow" ref="batchForm" hide-footer hide-header id="batchForm" size="lg" @hide='clearDetail'>
            <batchForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                    v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                    <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>


    </div>
</template>

<script>
import moment from 'moment'
import batchForm from '@@/components/forms/batchForm'

import {mapState, mapActions} from 'vuex'

export default {
    components : {
        batchForm ,
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            end_date: null,
        }
    },
    async created() {
        this.$store.dispatch('batch/getAll')
    },
    computed: {
        ...mapState({
            batch : state => state.batch,
        }),
    },
    methods: {
        ...mapActions({
            getDetail: 'batch/getDetail',
            clearDetail: 'batch/clearDetail',
            deleteOne: 'batch/deleteOne'
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('batchForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.end_date = this.batch.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/batch?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/batch', {}, {
                    params : {
                        object_identifier : this.batch.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('batch/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });

        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
