<template>
    <section>
        <div class="container">
            <headerEventComponent/>
        </div>

        <div class="container page-section">
            <div class="page-headline text-center">
                <h2>Batch</h2>
            </div>
            <div class="card">
                <div class="card-header bg-info d-flex justify-content-between align-items-center">
                    <h4 class="h4">Available Batch</h4>
                    <span>
                        <button @click="clearDetail(); $bvModal.show('batchForm')" class="btn btn-sm btn-success">
                        + Create Batch</button>
                        <button v-if="$route.query.type == 'event' && event.reference.event_id"  @click="clearDetail(); $bvModal.show('batchFormReference')" class="btn btn-sm btn-success">
                        + Add Planned Batch</button>
                        <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a><i class="fa fa-search"></i> 
                        Search</b-button>
                    </span>
                </div>
        <div class>
          <div class="text-right">
            <div class="bg-white">
              <b-collapse id="collapse-a" class="mt-2">
                <form class="p-2">
                  <div class="row">
                    
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <input
                          v-model="filters.batch_name"
                          type="text"
                          class="form-control"
                          id="batch_name"
                          placeholder="Batch Name"
                        >
                        <small class="form-text text-muted">Batch Name</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select v-model="filters.location" class="form-control" name="location" id="location">
                          <option
                            v-for="(item, index) in LOCID.list"
                            :key="index"
                            :value="item.id"
                          >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">location</small>
                      </div>
                    </div>
                     <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select v-model="filters.curriculum" class="form-control" name="curriculum" id="curriculum">
                          <option
                            v-for="(item, index) in curriculum.list"
                            :key="index"
                            :value="item.curriculum.id"
                          >{{item.curriculum.value}}</option>
                        </select>
                        <small class="form-text text-muted">curriculum</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select v-model="filters.vendor" class="form-control" name="vendor" id="vendor">
                          <option
                            v-for="(item, index) in vendors.list"
                            :key="index"
                            :value="item.child_company.business_code"
                          >{{item.child_company.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">vendor</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select start date" name="begin_date" id="begin_date"
                        />
                        <small class="form-text text-muted">Begin Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select end date" name="end_date" id="end_date"
                        />
                        <small class="form-text text-muted">End Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group text-right">
                        <b-button
                          @click="filters = {}; runFilter()"
                          variant="secondary"
                        >Clear Filter</b-button>

                        <b-button @click="runFilter" variant="info">
                          <span class="btn-label">
                            <i class="fa fa-search"></i> Filter
                          </span>
                        </b-button>
                      </div>
                    </div>
                  </div>
                </form>
              </b-collapse>
            </div>
          </div>
        </div>
                <div class="" style="">
                    <table class="table table-responsive table-flush table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Batch</th>
                                <th>Location</th>
                                <th v-if="event && event.event_type.id == '01'">Curriculum</th>
                                <th>Vendor</th>
                                <th>Begin Date</th>
                                <th>End Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(batch , index) in batch.list" :key="index">
                                <td>{{index+1}}</td>
                                <td @click="goToDetail(batch.object_identifier)">
                                    <strong style="cursor:pointer">{{batch.batch_name}}</strong>
                                </td>
                                <td>{{batch.location.value}}</td>
                                <td v-if="event && event.event_type.id == '01'">{{batch.curriculum.value}}</td>
                                <td>{{batch.vendor && batch.vendor.company_name}}</td>
                                <td>{{formatDate(batch.begin_date)}}</td>
                                <td>{{formatDate(batch.end_date)}}</td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                            <button class="dropdown-item" @click="showUpdateForm(batch.object_identifier)">Update</button>
                                            <button class="dropdown-item" @click="deleteData(batch.object_identifier, index)">Delete</button>
                                            <button class="dropdown-item" @click="showDelimitForm(batch.object_identifier)">Delimit</button>
                                            <button class="dropdown-item" @click="goToDetail(batch.object_identifier)">Detail</button>
                                        </div>
                                    </div>

                                </td>
                            </tr>
                            <tr v-if="batch.isLoading">
                                <td colspan="10">
                                    <div class="row">
                                        <div class="col d-flex justify-content-center">
                                            <div class="loader loader-accent text-center"></div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <paginationBar :state='batch' :storeModuleName="'batch'" />
                </div>
            </div>
        </div>

        <b-modal v-model="modalShow" ref="batchForm" hide-footer hide-header id="batchForm" size="lg">
            <batchForm v-if="modalShow" />
        </b-modal>
        <b-modal v-model="modalReferenceShow" ref="batchFormReference" hide-footer title="Add Planned Batch" id="batchFormReference" size="lg">
            <batchFormReference v-if="modalReferenceShow" />
        </b-modal>
        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>




    </section>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'
import batchForm from '@@/components/forms/batchForm'
import batchFormReference from '@@/components/forms/batchFormReference'
import headerEventComponent from '@@/components/headerEventComponent'

export default {
    layout : 'event-detail',
    components : { batchForm , paginationBar, batchFormReference, headerEventComponent },
    middleware({store,redirect,route}) {
        if (route.query.type == 'event') {
            if (!store.state.event.detail) redirect('/event/event')
        } else {
            if (!store.state.eventPlan.detail) redirect('/event/event-plan')
        }
    },
    created() {
        this.$store.dispatch('batch/clearAll')
        this.$store.dispatch('batch/getAll', { 'type' : this.type })
        // this.$store.dispatch('batch/getReference', { 'type' : this.type });
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            modalReferenceShow : false,

            begin_date: null,
            end_date: null,            

            type:this.$route.query.type,
            
            filters: {
                begin_date: null,
                end_date: null,
                batch_name: null,
                location: null,
                curriculum: null,
                vendor: null,
        } 
        };
    },
    computed: {
        event(){
            
            if (this.type == 'event') {
                return this.$store.state.event.detail
            } else {
                return this.$store.state.eventPlan.detail
            }

        },
        ...mapState({
            batch: state => state.batch,
            LOCID: state => state.LOCID,
            curriculum: state => state.curriculum,
            vendors: state=> state.companyRelation,
        })
    },
    methods: {
        getParam(){  
          this.$store.dispatch("LOCID/getAll");
          this.$store.dispatch("curriculum/getAll");
          this.$store.dispatch("companyRelation/getAll");
          
        },
        ...mapActions({
            getDetail: 'batch/getDetail',
            clearDetail: 'batch/clearDetail',
            deleteOne: 'batch/deleteOne',
            getAll: 'batch/getAll', 
        }),
        runFilter() {
        let params = {'type' : this.type};
        if (this.filters.batch_name)
            params["batch_name"] = [this.filters.batch_name];
        if (this.filters.location)
            params["location"] = [this.filters.location];
        if (this.filters.curriculum)
            params["curriculum"] = [this.filters.curriculum];
        if (this.filters.vendor)
            params["vendor"] = [this.filters.vendor];
               
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;

        this.$router.push({ path : this.$route.path , query : params})
        this.getAll(params);
    },

    clearFilters() {
      this.filters = {
       batch_name: null,
       location: null,
       curriculum: null,
       vendor: null,
      };
    },
        goToDetail(object_identifier){
            this.getDetail(object_identifier)
            this.$router.push('/event/batch/detail/classroom?type='+this.type)
        },

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('batchForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.batch.detail.begin_date
            this.end_date = this.batch.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/batch?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/batch', {}, {
                    params : {
                        object_identifier : this.batch.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('batch/getAll',{'type':this.type});
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>

