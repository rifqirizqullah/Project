<template>
    <div>
        <div class="container">
            <headerEventComponent />
        </div>
        <div class="container">
            <headerBatchComponent />
        </div>
        <div class="container page-section">

            <div class="page-headline text-center">
                <h2>Activity</h2>
            </div>

            <div class="card">
                <div class="card-header bg-info d-flex justify-content-between align-items-center">
                    <span>
                        <h4 class="card-title">Activity</h4>
                        <p class="card-subtitle">List of Available Activity</p>
                    </span>
                    <span>
                        <button @click="clearDetail(); $bvModal.show('sessionForm')" class="btn btn-success btn-sm">+
                            Create Activity</button>
                        <button v-if="$route.query.type == 'event' && batch.reference.batch_id"
                            @click="clearDetail(); $bvModal.show('sessionFormReference')"
                            class="btn btn-sm btn-success">+ Add Planned Activity</button>
                        <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                            <span class="btn-label"><i class="fa fa-search"></i> Search</span>
                        </b-button>
                    </span>
                </div>

                <div class="bg-light">
                    <div class="text-right">
                        <div>
                            <b-collapse id="collapse-a" class="p-3">
                                <form class="p-2">
                                    <div class="row">
                                    <div class="col-sm-12 col-md-6 col-lg-3">
                                        <div class="form-group">
                                            <input v-model="filters.session_name" type="text" class="form-control" id="name" placeholder="Name">
                                            <small>Session Name</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters.learning_activity" class="form-control" name="learning_activity" id="learning_activity">
                                            <option
                                                v-for="(item, index) in learningActivity.list"
                                                :key="index"
                                                :value="item.id.activity_id"
                                            >{{item.id.activity_name}}</option>
                                            </select>
                                            <small class="form-text text-muted">Learning Activity</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                        <div class="col-sm-12 col-md-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters = {}; clearFilters()" variant="secondary">Clear Filter</b-button>
                                            <b-button @click="runFilter" variant="info">
                                            <span class="btn-label">
                                                <i class="fa fa-search"></i> Filter
                                            </span>
                                            </b-button>
                                        </div>
                                        </div>

                                    </div>
                                </form>
                            </b-collapse>
                        </div>
                    </div>
                </div>

                <table class="table table-responsive table-flush table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Name</th>
                            <th v-if="batch.curriculum.id">Learning Activity</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in session.list" :key="index">
                            <td> {{index+1}} </td>
                            <td @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/schedule?type='+type)"
                                style="cursor:pointer;">
                                <strong> {{ item.session_name }}</strong>
                            </td>
                            <td v-if="batch.curriculum.id">{{ item.learning_activity.activity_name }}</td>
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary dropdown-toggle"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                        <button class="dropdown-item"
                                            @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/schedule?type='+type)">Schedule</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="session.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
                <div class="card-footer">
                    <paginationBar :state='session' :storeModuleName="'session'" />
                </div>

            </div>

            <b-modal v-model="modalShow" ref="sessionForm" hide-footer hide-header id="sessionForm" size="lg">
                <sessionForm v-if="modalShow" />
            </b-modal>
            <b-modal v-model="modalReferenceShow" ref="sessionFormReference" hide-footer title="Add Planned Activity"
                id="sessionFormReference" size="lg">
                <sessionFormReference v-if="modalReferenceShow" />
            </b-modal>

            <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data"
                header-bg-variant="light" size="sm">
                <div class="col-12">
                    <div class="form-group">
                        <label for="begin_date">Start Date</label>
                        <div class="form-control">
                            <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled name="begin_date"
                                id="begin_date">
                        </div>
                    </div>
                </div>
                <hr>
                <div class="col-12">
                    <div v-show="begin_date" class="form-group">
                        <label for="end_date">End Date</label>
                        <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                            class="form-control" placeholder="Select end date" name="end_date" id="end_date"
                            v-bind:class="{ 'is-danger': errors.has('collection.end_date')}" v-validate="'required'"
                            data-vv-scope="collection" />
                        <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
                        <p v-show="errors.has('collection.end_date')" class="help is-danger">
                            {{ errors.first('collection.end_date') }}</p>
                    </div>
                </div>
                <div slot="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        @click="$bvModal.hide('modalDelimit')">Cancel</button>
                    <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
                </div>
            </b-modal>

        </div>
    </div>
</template>

<script>
    import moment from 'moment'
    import {
        mapState,
        mapActions
    } from 'vuex'
    import paginationBar from '@@/components/paginationBar'
    import sessionForm from '@@/components/forms/sessionForm'
    import sessionFormReference from '@@/components/forms/sessionFormReference'
    import headerEventComponent from '@@/components/headerEventComponent'
    import headerBatchComponent from '@@/components/headerBatchComponent'

    export default {
        layout: 'batch',
        components: {
            sessionForm,
            paginationBar,
            headerEventComponent,
            headerBatchComponent,
            sessionFormReference
        },
        middleware({
            store,
            redirect,
            route
        }) {
            if (route.query.type == 'event') {
                if (!store.state.batch.detail) redirect('/event/event')
            } else {
                if (!store.state.batch.detail) redirect('/event/event-plan')
            }            
            
        },
        created() {
            this.$store.dispatch('session/clearAll');
            this.$store.dispatch('session/getAll');
            // this.$store.dispatch('batch/getReference', { 'type' : this.type });
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                modalReferenceShow: false,

                begin_date: null,
                end_date: null,
                filters :{
                    session_name:null,
                    learning_activity:null,
                    begin_date: null,
                    end_date: null,
                },
                type: this.$route.query.type
            }
        },
        computed: {
            ...mapState({
                batch: state => state.batch.detail,
                session: state => state.session,
                learningActivity : state => state.relation,
            }),
        },
        methods: {
            ...mapActions({
                getDetail: 'session/getDetail',                
                clearDetail: 'session/clearDetail',
                deleteOne: 'session/deleteOne',
                getAll: 'session/getAll',
            }),
            getParam(){  
                this.$store.dispatch('relation/getAll', {
                    'object[]':this.batch.curriculum.id,
                    'table_code[]':'LRACT',
                    'relation[]':'C001',
                    'otype[]':'CURID'
                })
            
            },
            runFilter(){
                let params = {}
                
                if (this.filters.session_name)
                    params["session_name[]"] = this.filters.session_name
                if (this.filters.learning_activity)
                    params["learning_activity[]"] = this.filters.learning_activity
                if (this.filters.begin_date)
                    params["begin_date_lte"] = this.filters.begin_date;
                if (this.filters.end_date)
                    params["end_date_gte"] = this.filters.end_date;

                this.$router.push({ path : this.$route.path , query : params})
                this.getAll(params)

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearFilters(){
                this.filters = {
                    session_name:null,
                    learning_activity:null,
                    begin_date: null,
                    end_date: null,
                }

            },
            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('sessionForm')
            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.session.detail.begin_date
                this.end_date = this.session.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/session?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/session', {}, {
                            params: {
                                object_identifier: this.session.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('session/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },

            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
