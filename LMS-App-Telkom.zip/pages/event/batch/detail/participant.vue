<template>
    <div class="container page-section">
        <div class="container">
            <headerEventComponent />
        </div>
        <div class="container">
            <headerBatchComponent />
        </div>        

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Participant</h4>
                 <!-- <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>
                </span> -->
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
            
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.personnel_number"
                        type="text"
                        class="form-control"
                        id="personnel_number"
                        placeholder="personnel_number"
                        >
                        <small class="form-text text-muted">NIK</small>
                    </div>
                </div> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.complete_name"
                        type="text"
                        class="form-control"
                        id="complete_name"
                        placeholder="complete_name"
                        >
                        <small class="form-text text-muted">Participant Name</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select v-model="filters.company" class="form-control" name="company" id="company">
                      <option
                        v-for="(item, index) in company.list"
                        :key="index"
                        :value="item.business_code"
                      >{{item.company_name}}</option>
                    </select>
                    <small class="form-text text-muted">Company</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.participant_type"
                      class="form-control"
                      name="participant_type"
                      id="participant_type"
                    >
                      <option
                        v-for="(item, index) in PARTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Prticipant Type</small>
                  </div>
                </div>
                
                 <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                 
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; clearFilters()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>

            </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>   

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>NIK</th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Type</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in batchParticipant.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.participant.personnel_number }} </td>
                            <td> {{ item.participant.complete_name }} </td>
                            <td> {{ item.participant.business_code.company_name }} </td>
                            <td> {{ item.participant.participant_type.value }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;"></button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <!-- <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button> -->
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier, item.begin_date, item.end_date)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="batchParticipant.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='batchParticipant' :storeModuleName="'batchParticipant'" />
            </div>
        </div>

        <div class="card shadow" v-if="type == 'event' && batch.reference.batch_id">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">Planned Participant</h4>
                <!-- <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>
                </span> -->
            </div>
    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-b" class="mt-2">
            <form class="p-2">
              <div class="row">
            
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.personnel_number"
                        type="text"
                        class="form-control"
                        id="personnel_number"
                        placeholder="personnel_number"
                        >
                        <small class="form-text text-muted">NIK</small>
                    </div>
                </div> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.complete_name"
                        type="text"
                        class="form-control"
                        id="complete_name"
                        placeholder="complete_name"
                        >
                        <small class="form-text text-muted">Participant Name</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select v-model="filters1.company" class="form-control" name="company" id="company">
                      <option
                        v-for="(item, index) in company.list"
                        :key="index"
                        :value="item.business_code"
                      >{{item.company_name}}</option>
                    </select>
                    <small class="form-text text-muted">Company</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters1.participant_type"
                      class="form-control"
                      name="participant_type"
                      id="participant_type"
                    >
                      <option
                        v-for="(item, index) in PARTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Prticipant Type</small>
                  </div>
                </div>
                
                 <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                 
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; clearFilters1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>NIK</th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Type</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in batchParticipant.listReference" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.participant.personnel_number }} </td>
                            <td> {{ item.participant.complete_name }} </td>
                            <td> {{ item.participant.business_code.company_name }} </td>
                            <td> {{ item.participant.participant_type.value }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='ref')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="batchParticipant.isLoadingR">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='batchParticipant' :storeModuleName="'batchParticipant'" />
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">All Participant</h4>
                <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-c>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>
                </span>
            </div>
    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-c" class="mt-2">
            <form class="p-2">
              <div class="row">
            
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters2.personnel_number"
                        type="text"
                        class="form-control"
                        id="personnel_number"
                        placeholder="personnel_number"
                        >
                        <small class="form-text text-muted">NIK</small>
                    </div>
                </div> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters2.complete_name"
                        type="text"
                        class="form-control"
                        id="complete_name"
                        placeholder="complete_name"
                        >
                        <small class="form-text text-muted">Participant Name</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select v-model="filters2.company" class="form-control" name="company" id="company">
                      <option
                        v-for="(item, index) in company.list"
                        :key="index"
                        :value="item.business_code"
                      >{{item.company_name}}</option>
                    </select>
                    <small class="form-text text-muted">Company</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters2.participant_type"
                      class="form-control"
                      name="participant_type"
                      id="participant_type"
                    >
                      <option
                        v-for="(item, index) in PARTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Prticipant Type</small>
                  </div>
                </div>
                
                 <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                 
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters2 = {}; clearFilters2()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter2" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>NIK</th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Type</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in participant.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.personnel_number }} </td>
                            <td> {{ item.complete_name }} </td>
                            <td> {{ item.business_code.company_name }} </td>
                            <td> {{ item.participant_type.value }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='all')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="participant.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='participant' :storeModuleName="'participant'" />
            </div>
        </div>
        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        <b-modal id="modalAll" centered title="Add Batch Participant" size="sm">
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalAll')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addParticipant">Save</button>
            </div>
        </b-modal>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import paginationBarR from '@@/components/paginationBarR'
    import headerEventComponent from '@@/components/headerEventComponent'
    import headerBatchComponent from '@@/components/headerBatchComponent'
    import {
        mapState,
        mapActions
    } from 'vuex'

    export default {
        layout: 'batch',
        components: {
            paginationBar,
            paginationBarR,
            headerEventComponent,
            headerBatchComponent,
        },
        middleware({
            store,
            redirect,
            route
        }) {
            if (route.query.type == 'event') {
                if (!store.state.batch.detail) redirect('/event/event')
            } else {
                if (!store.state.batch.detail) redirect('/event/event-plan')
            }            
            
        },
        fetch({store,params}) {
            store.dispatch('batchParticipant/clearAll');
            store.dispatch('batchParticipant/getAll');
            store.dispatch('batchParticipant/getReference');
            store.dispatch('participant/getAll');
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                begin_date: null,
                end_date: null,
                participant_id:null,
                type:this.$route.query.type,
                email:null,
                filters: {
                    begin_date: null,
                    end_date: null,
                    personnel_number: null,
                    complete_name: null,
                    company:null,
                    participant_type:null,
                },
                filters1: {
                    begin_date: null,
                    end_date: null,
                    personnel_number: null,
                    complete_name: null,
                    company:null,
                    participant_type:null,
                },
                filters2: {
                    begin_date: null,
                    end_date: null,
                    personnel_number: null,
                    complete_name: null,
                    company:null,
                    participant_type:null,

                }
            };
        },
        computed: {
            batch(){
                return this.$store.state.batch.detail;
            },
            ...mapState({
            batchParticipant : state => state.batchParticipant,
            participant : state => state.participant,
            company : state => state.company,
            PARTY : state => state.PARTY,
            })
        },
        methods: {
             getParam(){
            //  this.$store.dispatch("batchParticipant/getAll");
             this.$store.dispatch("company/getAll");
             this.$store.dispatch("PARTY/getAll");

             },
              runFilter() {
              let params = {};
              if (this.filters.complete_name)
              params["complete_name[]"] = this.filters.complete_name
              if (this.filters.company)
              params["business_code"] = [this.filters.company];
              if (this.filters.participant_type)
              params["participant_type[]"] = this.filters.participant_type
              if (this.filters.personnel_number)
              params["personnel_number[]"] = this.filters.personnel_number
              if (this.filters.begin_date)
              params["begin_date_lte"] = this.filters.begin_date;
              if (this.filters.end_date)
              params["end_date_gte"] = this.filters.end_date;

              this.$router.push({ path : this.$route.path , query : params})

              this.getAll(params);
             },
              clearFilters() {
              this.filters = {
                  personnel_number : null,
                  complete_name : null,
                  company : null,
                  participant_type : null,  
            };
            let params = {};
       
            this.getAll(params);
        },

            runFilter1() {
              let params1 = {};
              if (this.filters1.complete_name)
              params1["complete_name[]"] = this.filters1.complete_name
              if (this.filters.company)
              params1["business_code"] = [this.filters1.company];
              if (this.filters.participant_type)
              params1["participant_type[]"] = this.filters1.participant_type
              if (this.filters.personnel_number)
              params1["personnel_number[]"] = this.filters1.personnel_number
              if (this.filters.begin_date)
              params1["begin_date_lte"] = this.filters1.begin_date;
              if (this.filters.end_date)
              params1["end_date_gte"] = this.filters1.end_date;

              this.$router.push({ path : this.$route.path , query : params1})

              this.getAll1(params1);
             },
              clearFilters1() {
              this.filters1 = {
                  personnel_number : null,
                  complete_name : null,
                  company : null,
                  participant_type : null,  
            };
            let params1 = {};
       
            this.getAll1(params1);
        },

            runFilter2() {
              let params2 = {};
              if (this.filters2.complete_name)
              params2["complete_name[]"] = this.filters2.complete_name
              if (this.filters2.company)
              params2["business_code[]"] = this.filters2.company;
              if (this.filters2.participant_type)
              params2["participant_type[]"] = this.filters2.participant_type
              if (this.filters2.personnel_number)
              params2["personnel_number[]"] = this.filters2.personnel_number
              if (this.filters2.begin_date)
              params2["begin_date_lte"] = this.filters2.begin_date;
              if (this.filters2.end_date)
              params2["end_date_gte"] = this.filters2.end_date;

              this.$router.push({ path : this.$route.path , query : params2})

              this.getAll2(params2);
             },
              clearFilters2() {
              this.filters2 = {
                begin_date: null,
                end_date: null,
                personnel_number: null,
                complete_name: null,
                company:null,
                participant_type:null,  
            };
            let params2 = {};
       
            this.getAll2(params2);
        },
            

            ...mapActions({
                getDetail: 'batchParticipant/getDetail',
                getDetailReference: 'batchParticipant/getDetailReference',
                getDetailAll: 'participant/getDetail',
                clearDetail: 'batchParticipant/clearDetail',
                deleteOne: 'batchParticipant/deleteOne',
                getAll: 'batchParticipant/getAll',
                getAll1: 'batchParticipant/getReference',
                getAll2: 'participant/getAll',
            }),

            async addParticipant() {
                await this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/batchparticipant', {
                            batch: this.batch.batch_id,
                            participant: this.participant_id,
                            business_code: this.batch.business_code.business_code,
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                        })
                        .then(() => {
                            this.$axios.get('lms/api/participantcommunication?communication_type[]=2&participant[]='+this.participant_id)
                            .then(response => {
                                this.email = response.data.data[0].communication_text                
                            }).catch(e => {
                                console.log(e);
                            });
                            if(this.email){
                                let data = new FormData();

                                data.append('to[]', this.email)
                                data.append('subject', "Undangan Event")
                                data.append('message', "Anda diundang di event "+ this.batch.event.event_name +"batch "+this.batch.batch_name)                       

                                this.$axios.post('lms/api/sendmail', data)
                                this.email = null
                            }
                            
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('batchParticipant/getAll');
                            this.$bvModal.hide('modalAll')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },
            async submit(object_identifier,from) {
                if (from == 'all') {
                    await this.getDetailAll(object_identifier)
                    this.end_date = null
                    this.begin_date = null
                    this.$validator.reset('collection')
                    this.participant_id= this.participant.detail.participant_id
                    this.$bvModal.show('modalAll')
                } else {
                    await this.getDetailReference(object_identifier)
                    this.participant_id= this.batchParticipant.detail.participant.participant_id
                    this.business_code = this.batchParticipant.detail.business_code.business_code
                    this.begin_date = this.batchParticipant.detail.begin_date
                    this.end_date = this.batchParticipant.detail.end_date

                    this.$axios.post('lms/api/batchparticipant', {
                        batch: this.batch.batch_id,
                        participant: this.participant_id,
                        business_code: this.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$axios.get('lms/api/participantcommunication?communication_type[]=2&participant[]='+this.participant_id)
                            .then(response => {
                                this.email = response.data.data[0].communication_text                
                            }).catch(e => {
                                console.log(e);
                            });
                            if(this.email){
                                let data = new FormData();

                                data.append('to[]', this.email)
                                data.append('subject', "Undangan Event")
                                data.append('message', "Anda diundang di event "+ this.batch.event.event_name +"batch "+this.batch.batch_name)                       

                                this.$axios.post('lms/api/sendmail', data)
                                this.email = null
                            }
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.$store.dispatch('batchParticipant/getAll');
                        this.$bvModal.hide('modalAll')
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
                }

            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.batchParticipant.detail.begin_date
                this.end_date = this.batchParticipant.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/batchparticipant?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/batchparticipant', {}, {
                            params: {
                                object_identifier: this.batchParticipant.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('batchParticipant/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
