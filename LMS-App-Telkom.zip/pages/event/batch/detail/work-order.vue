<template>
    <div class="container page-section">
        <div class="container">
            <headerEventComponent />
        </div>
        <div class="container">
            <headerBatchComponent />
        </div>
        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Work Order</h4>
            <span>
                <button @click="clearDetail(); $bvModal.show('saranaRequestForm')" class="btn btn-success btn-sm">+
                    Create Work Order</button>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                <i class="fa fa-search"></i> Search         
                </b-button> 
            </span>
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.facility"
                      class="form-control"
                      name="facility"
                      id="facility"
                    >
                      <option
                        v-for="(item, index) in FACCD.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Facility</small>
                  </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.quantity"
                        type="text"
                        class="form-control"
                        id="quantity"
                        placeholder="Quantity"
                        >
                        <small class="form-text text-muted">Quantity</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.description"
                        type="text"
                        class="form-control"
                        id="description"
                        placeholder="Description"
                        >
                        <small class="form-text text-muted">Description</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <!-- <th>Batch</th> -->
                            <th>Facility</th>
                            <th>Quantity</th>
                            <th>Description</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in saranaRequest.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <!-- <td> {{ item.batch.batch_name }} </td> -->
                            <td> {{ item.facility.value }} </td>
                            <td> {{ item.quantity }} </td>
                            <td> {{ item.description }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;"></button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="saranaRequest.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='saranaRequest' :storeModuleName="'saranaRequest'" />
            </div>
        </div>

        <div class="card shadow" v-if="type == 'event' && batch.reference.batch_id">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">Planned Work Order</h4>
            <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>  
                <i class="fa fa-search"></i> Search         
                </b-button>
            </span>
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-b" class="mt-2">
            <form class="p-2">
              <div class="row">
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters1.facility"
                      class="form-control"
                      name="facility"
                      id="facility"
                    >
                      <option
                        v-for="(item, index) in FACCD.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Facility</small>
                  </div>
                </div>  

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.quantity"
                        type="text"
                        class="form-control"
                        id="quantity"
                        placeholder="Quantity"
                        >
                        <small class="form-text text-muted">Quantity</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.description"
                        type="text"
                        class="form-control"
                        id="description"
                        placeholder="Description"
                        >
                        <small class="form-text text-muted">Description</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; runFilter1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <!-- <th>Batch</th> -->
                            <th>Facility</th>
                            <th>Quantity</th>
                            <th>Description</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in saranaRequest.listReference" :key="index">
                            <td> {{ index + 1 }} </td>
                            <!-- <td> {{ item.batch.batch_name }} </td> -->
                            <td> {{ item.facility.value }} </td>
                            <td> {{ item.quantity }} </td>
                            <td> {{ item.description }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier)">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="saranaRequest.isLoadingR">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='saranaRequest' :storeModuleName="'saranaRequest'" />
            </div>
        </div>

        <b-modal v-model="modalShow" ref="saranaRequestForm" hide-footer hide-header id="saranaRequestForm" size="lg">
            <saranaRequestForm v-if="modalShow" />
        </b-modal>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>
    </div>
</template>

<script>
    import moment from 'moment'
    import saranaRequestForm from '@@/components/forms/saranaRequestForm'
    import paginationBar from '@@/components/paginationBar'
    import paginationBarR from '@@/components/paginationBarR'
    import headerEventComponent from '@@/components/headerEventComponent'
    import headerBatchComponent from '@@/components/headerBatchComponent'
    import {
        mapState,
        mapActions
    } from 'vuex'

    export default {
        layout: 'batch',
        components: {
            saranaRequestForm,
            paginationBar,
            paginationBarR,
            headerEventComponent,
            headerBatchComponent,
        },
        middleware({
            store,
            redirect,
            route
        }) {
            if (route.query.type == 'event') {
                if (!store.state.batch.detail) redirect('/event/event')
            } else {
                if (!store.state.batch.detail) redirect('/event/event-plan')
            }            
            
        },
        fetch({store,params}) {
            store.dispatch('saranaRequest/getAll');
            store.dispatch('saranaRequest/getReference');
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                business_code: null,
                begin_date: null,
                end_date: null,
                type:this.$route.query.type,
                filters: {
                    facility: null,
                    quantity: null,
                    description: null,
                    begin_date: null,
                    end_date: null
                },
                filters1: {
                    facility: null,
                    quantity: null,
                    description: null,
                    begin_date: null,
                    end_date: null
                }
            };
        },
        computed: {
            batch(){
                return this.$store.state.batch.detail
            },
            ...mapState({
                saranaRequest: state => state.saranaRequest,
                FACCD: state => state.FACCD,
            })
        },
        methods: {
            getParam(){
        this.$store.dispatch("FACCD/getAll");
        
        },
            ...mapActions({
                getDetail: 'saranaRequest/getDetail',
                clearDetail: 'saranaRequest/clearDetail',
                deleteOne: 'saranaRequest/deleteOne',
                getAll1: "saranaRequest/getReference",
                getAll: "saranaRequest/getAll",
            }),

            runFilter() {
            let params = {};
            if (this.filters.facility)
                params["facility"] = [this.filters.facility];
            if (this.filters.quantity)
                params["quantity"] = [this.filters.quantity];
            if (this.filters.description)
                params["description"] = [this.filters.description];
            if (this.filters.begin_date)
                params["begin_date_lte"] = this.filters.begin_date;
            if (this.filters.end_date)
                params["end_date_gte"] = this.filters.end_date;
                this.$router.push({ path : this.$route.path , query : params})
                this.getAll(params);
            },
            clearFilters() {
                this.filters = {
                    facility: null,
                    quantity: null,
                    description: null,
                };
            },

            runFilter1() {
            let params = {};
            if (this.filters1.facility)
                params["facility"] = [this.filters1.facility];
            if (this.filters1.quantity)
                params["quantity"] = [this.filters1.quantity];
            if (this.filters1.description)
                params["description"] = [this.filters1.description];
            if (this.filters1.begin_date)
                params["begin_date_lte"] = this.filters1.begin_date;
            if (this.filters1.end_date)
                params["end_date_gte"] = this.filters.end_date;
                this.$router.push({ path : this.$route.path , query : params})
                this.getAll1(params);
            },
            clearFilters1() {
                this.filters1 = {
                    facility: null,
                    quantity: null,
                    description: null,
                };
            },
            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('saranaRequestForm')
            },
            async submit(object_identifier) {
                await this.getDetailReference(object_identifier)
                this.facility = this.saranaRequest.detail.facility.id
                this.quantity = this.saranaRequest.detail.quantity
                this.description = this.saranaRequest.detail.description
                this.business_code = this.saranaRequest.detail.business_code.business_code
                this.begin_date = this.saranaRequest.detail.begin_date
                this.end_date = this.saranaRequest.detail.end_date

                this.$axios.post('lms/api/requestsarana', {
                    batch: this.batch.batch_id,
                    facility: this.facility,
                    quantity: this.quantity,
                    description: this.description,
                    business_code: this.business_code,
                    begin_date: this.begin_date,
                    end_date: this.end_date,
                })
                .then(() => {
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                    this.$store.dispatch('saranaRequest/getAll');
                })
                .catch(err => {
                    console.log(err.response);
                })
            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.saranaRequest.detail.begin_date
                this.end_date = this.saranaRequest.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/requestsarana?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/requestsarana', {}, {
                            params: {
                                object_identifier: this.saranaRequest.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('saranaRequest/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
