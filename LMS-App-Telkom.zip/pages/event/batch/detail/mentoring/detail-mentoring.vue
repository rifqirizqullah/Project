<template>
<div>
        <div class="container">
            <headerEventComponent/>
        </div>
        <div class="container">
            <headerBatchComponent/>
        </div>
        <div class="container">
            <headerSessionComponent/>
        </div>

    <div class="container page-section">
        

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Mentor</h4>
                <span>
                <b-button type="button" @click="getParamMentorr" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span>
            </div>
            <div class="">
                        <div class="text-right">
                            <div class="bg-white">
                                <!-- Elements to collapse -->
                                <b-collapse id="collapse-a" class="mt-2 p-4">
                                    <form action="">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersMentorr.personnel_number"
                                                    type="text"
                                                    class="form-control"
                                                    id=""
                                                    placeholder="nik"
                                                    >
                                                    <small class="form-text text-muted">NIK</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersMentorr.mentor_name"
                                                    type="text"
                                                    class="form-control"
                                                    id=""
                                                    placeholder="name"
                                                    >
                                                    <small class="form-text text-muted">Name</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <select v-model="filtersMentorr.company" class="form-control" name="company" id="company">
                                                    <option
                                                        v-for="(item, index) in company.list"
                                                        :key="index"
                                                        :value="item.business_code"
                                                    >{{item.company_name}}</option>
                                                    </select>
                                                    <small class="form-text text-muted">Company</small>
                                                </div>
                                            </div>
                                            
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersMentorr.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select start date" name="begin_date" id="begin_date"
                                                    />
                                                    <small class="form-text text-muted">Begin Date</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersMentorr.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select end date" name="end_date" id="end_date"
                                                    />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group text-right">
                                                    <b-button @click="filtersMentorr = {}; clearfiltersMentorr()" variant="secondary" >Clear Filter</b-button>
                                                    <b-button @click="runfiltersMentorr" variant="info" >
                                                        <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>NIK</th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in mentoringMentor.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{item.id.personnel_number}} </td>
                            <td> {{item.id.mentor_name}} </td>
                            <td> {{item.id.business_code.company_name}} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;"></button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <!-- <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button> -->
                                        <button class="dropdown-item"
                                            @click="deleteDataMentor(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitFormMentor(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="mentoringMentor.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='mentoringMentor' :storeModuleName="'mentoringMentor'" />
            </div>
        </div>
        
        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">List Mentor</h4>
                <span>
                <b-button type="button" @click="getParamMentor" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span>
            </div>
            <div class="">
                        <div class="text-right">
                            <div class="bg-white">
                                <!-- Elements to collapse -->
                                <b-collapse id="collapse-a" class="mt-2 p-4">
                                    <form action="">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersMentor.personnel_number"
                                                    type="text"
                                                    class="form-control"
                                                    id=""
                                                    placeholder="nik"
                                                    >
                                                    <small class="form-text text-muted">NIK</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersMentor.mentor_name"
                                                    type="text"
                                                    class="form-control"
                                                    id=""
                                                    placeholder="name"
                                                    >
                                                    <small class="form-text text-muted">Name</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <select v-model="filtersMentor.company" class="form-control" name="company" id="company">
                                                    <option
                                                        v-for="(item, index) in company.list"
                                                        :key="index"
                                                        :value="item.business_code"
                                                    >{{item.company_name}}</option>
                                                    </select>
                                                    <small class="form-text text-muted">Company</small>
                                                </div>
                                            </div>
                                            
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersMentor.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select start date" name="begin_date" id="begin_date"
                                                    />
                                                    <small class="form-text text-muted">Begin Date</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersMentor.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select end date" name="end_date" id="end_date"
                                                    />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group text-right">
                                                    <b-button @click="filtersMentor = {}; clearfiltersMentor()" variant="secondary" >Clear Filter</b-button>
                                                    <b-button @click="runfiltersMentor" variant="info" >
                                                        <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>NIK</th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in mentor.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.personnel_number }} </td>
                            <td> {{ item.mentor_name }} </td>
                            <td> {{ item.business_code.company_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submitMentor(item.object_identifier)">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="mentor.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='mentor' :storeModuleName="'mentor'" />
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Mentee</h4>
                <!-- <span>
                <b-button type="button" @click="getParamMenteee" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span> -->
            </div>
            <div class="">
                        <div class="text-right">
                            <div class="bg-white">
                                <!-- Elements to collapse -->
                                <b-collapse id="collapse-a" class="mt-2 p-4">
                                    <form action="">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersMenteee.personnel_number"
                                                    type="text"
                                                    class="form-control"
                                                    id=""
                                                    placeholder="nik"
                                                    >
                                                    <small class="form-text text-muted">NIK</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersMenteee.complete_name"
                                                    type="text"
                                                    class="form-control"
                                                    id=""
                                                    placeholder="name"
                                                    >
                                                    <small class="form-text text-muted">Name</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <select v-model="filtersMenteee.company" class="form-control" name="company" id="company">
                                                    <option
                                                        v-for="(item, index) in company.list"
                                                        :key="index"
                                                        :value="item.business_code"
                                                    >{{item.company_name}}</option>
                                                    </select>
                                                    <small class="form-text text-muted">Company</small>
                                                </div>
                                            </div>
                                            
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersMenteee.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select start date" name="begin_date" id="begin_date"
                                                    />
                                                    <small class="form-text text-muted">Begin Date</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersMenteee.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select end date" name="end_date" id="end_date"
                                                    />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group text-right">
                                                    <b-button @click="filtersMenteee = {}; clearfiltersMenteee()" variant="secondary" >Clear Filter</b-button>
                                                    <b-button @click="runfiltersMenteee" variant="info" >
                                                        <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>NIK</th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in mentoringMentee.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.id.personnel_number }} </td>
                            <td> {{ item.id.complete_name }} </td>
                            <td> {{ item.id.business_code.company_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;"></button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <!-- <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button> -->
                                        <button class="dropdown-item"
                                            @click="deleteDataMentee(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitFormMentee(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="mentoringMentee.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='mentoringMentee' :storeModuleName="'mentoringMentee'" />
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Batch Participant</h4>
                <span>
                <b-button type="button" @click="getParamMentee" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span>
            </div>
            <div class="">
                        <div class="text-right">
                            <div class="bg-white">
                                <!-- Elements to collapse -->
                                <b-collapse id="collapse-a" class="mt-2 p-4">
                                    <form action="">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersMentee.personnel_number"
                                                    type="text"
                                                    class="form-control"
                                                    id=""
                                                    placeholder="nik"
                                                    >
                                                    <small class="form-text text-muted">NIK</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input
                                                    v-model="filtersMentee.complete_name"
                                                    type="text"
                                                    class="form-control"
                                                    id=""
                                                    placeholder="name"
                                                    >
                                                    <small class="form-text text-muted">Name</small>
                                                </div>
                                            </div>    
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <select v-model="filtersMentee.company" class="form-control" name="company" id="company">
                                                    <option
                                                        v-for="(item, index) in company.list"
                                                        :key="index"
                                                        :value="item.business_code"
                                                    >{{item.company_name}}</option>
                                                    </select>
                                                    <small class="form-text text-muted">Company</small>
                                                </div>
                                            </div>
                                            
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersMentee.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select start date" name="begin_date" id="begin_date"
                                                    />
                                                    <small class="form-text text-muted">Begin Date</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr
                                                        v-model="filtersMentee.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                        placeholder="Select end date" name="end_date" id="end_date"
                                                    />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group text-right">
                                                    <b-button @click="filtersMentee = {}; clearfiltersMentee()" variant="secondary" >Clear Filter</b-button>
                                                    <b-button @click="runfiltersMentee" variant="info" >
                                                        <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>NIK</th>
                            <th>Name</th>
                            <th>Company</th>
                            
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in batchParticipant.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.participant.personnel_number }} </td>
                            <td> {{ item.participant.complete_name }} </td>
                            <td> {{ item.business_code.company_name }} </td>
                            
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submitMentee(item.object_identifier)">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="batchParticipant.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='batchParticipant' :storeModuleName="'batchParticipant'" />
            </div>
        </div>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        <b-modal id="modalMentor" centered title="Add Mentor" size="sm">
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalMentor')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addMentor">Save</button>
            </div>
        </b-modal>
        <b-modal id="modalMentee" centered title="Add Mentee" size="sm">
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalMentee')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addParticipant">Save</button>
            </div>
        </b-modal>
        
    </div>
    </div>
</template>
<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import headerEventComponent from '@@/components/headerEventComponent'
    import headerBatchComponent from '@@/components/headerBatchComponent'
    import headerSessionComponent from '@@/components/headerSessionComponent'
    import {
        mapState,
        mapActions
    } from 'vuex'

    export default {
        layout : 'mentoring',
        components : { paginationBar, headerEventComponent, headerBatchComponent, headerSessionComponent },
    
        middleware: ({ store, redirect }) => {
            if (!store.state.mentoring.detail) return redirect('/event/event/')
        },
        fetch({store,params}) {
            // store.dispatch('mentoring/getAll');
            store.dispatch('mentoringMentor/getAll');
            //store.dispatch('mentoringMentor/getReference');
            store.dispatch('mentoringMentee/getAll');
            //store.dispatch('mentoringMentee/getReference');
            store.dispatch('batchParticipant/getAll');
            store.dispatch('mentor/getAll');
            
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                begin_date: null,
                end_date: null,
                personnel_number: null,
                business_code: null,
                object_identifier: null,
                typeMentoring:null,
                mentor_id: null,
                id:null,
                type:this.$route.query.type,
                email:null,
                filtersMentorr : {
                    personnel_number: null,
                    mentor_name: null,
                    company:null,
                    begin_date: null,
                    end_date: null
                },
                filtersMentor : {
                    personnel_number: null,
                    mentor_name: null,
                    company:null,
                    begin_date: null,
                    end_date: null
                },
                filtersMenteee : {
                    personnel_number: null,
                    complete_name: null,
                    company:null,
                    begin_date: null,
                    end_date: null
                },
                filtersMentee : {
                    personnel_number: null,
                    complete_name: null,
                    company:null,
                    begin_date: null,
                    end_date: null
                },
            }
        },
        computed: {
            session(){
                return this.$store.state.session.detail
            },
            ...mapState(['batchParticipant','mentor','mentoringMentee','mentoringMentor','mentoring', 'company'])
        },
        methods: {
            getParamMentorr(){

            },
            getParamMentor(){

            },
            getParamMenteee(){

            },
            getParamMentee(){

            },
            ...mapActions({
                getDetailMentor: 'mentor/getDetail',
                getDetailMentorr: 'mentoringMentor/getDetail',
                getDetailMentee: 'batchParticipant/getDetail',
                getDetailMenteee: 'mentoringMentee/getDetail',
                deleteOneMentor: 'mentoringMentor/deleteOne',
                deleteOneMentee: 'mentoringMentee/deleteOne',
                getAllMentorr: 'mentoringMentor/getAll',
                getAllMentor: 'mentor/getAll',
                getAllMenteee: 'mentoringMentee/getAll',
                getAllMentee: 'batchParticipant/getAll',
            }),
            runfiltersMentorr(){
                let paramsMentorr = {}
                if (this.filtersMentorr.company)
                    paramsMentorr["business_code"] = [this.filtersMentorr.company];
                if (this.filtersMentorr.mentor_name)
                    paramsMentorr["mentor_name[]"] = this.filtersMentorr.mentor_name
                if (this.filtersMentorr.personnel_number)
                    paramsMentorr["personnel_number[]"] = this.filtersMentorr.personnel_number
                
                if (this.filtersMentorr.begin_date)
                    paramsMentorr["begin_date_lte"] = this.filtersMentorr.begin_date;
                if (this.filtersMentorr.end_date)
                    paramsMentorr["end_date_gte"] = this.filtersMentorr.end_date;

                this.$router.push({ path : this.$route.path , query : paramsMentorr})
                this.getAllMentorr(paramsMentorr)

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearfiltersMentorr(){
                this.filtersMentorr = {
                    company: null,
                    mentor_name: null,
                    personnel_number:null,
                }
                this.getAllMentorr();

            },
            runfiltersMentor(){
                let paramsMentor = {}
                if (this.filtersMentor.company)
                    paramsMentor["business_code"] = [this.filtersMentor.company];
                if (this.filtersMentor.mentor_name)
                    paramsMentor["mentor_name[]"] = this.filtersMentor.mentor_name
                if (this.filtersMentor.personnel_number)
                    paramsMentor["personnel_number[]"] = this.filtersMentor.personnel_number
                
                if (this.filtersMentor.begin_date)
                    paramsMentor["begin_date_lte"] = this.filtersMentor.begin_date;
                if (this.filtersMentor.end_date)
                    paramsMentor["end_date_gte"] = this.filtersMentor.end_date;

                this.$router.push({ path : this.$route.path , query : paramsMentor})
                this.getAllMentor(paramsMentor)

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearfiltersMentor(){
                this.filtersMentor = {
                    company: null,
                    mentor_name: null,
                    personnel_number:null,
                }
                this.getAllMentor();

            },
            runfiltersMentee(){
                let paramsMentee = {}
                if (this.filtersMentee.company)
                    paramsMentee["business_code"] = [this.filtersMentee.company];
                if (this.filtersMentee.complete_name)
                    paramsMentee["complete_name[]"] = this.filtersMentee.complete_name
                if (this.filtersMentee.personnel_number)
                    paramsMentee["personnel_number[]"] = this.filtersMentee.personnel_number
                
                if (this.filtersMentee.begin_date)
                    paramsMentee["begin_date_lte"] = this.filtersMentee.begin_date;
                if (this.filtersMentee.end_date)
                    paramsMentee["end_date_gte"] = this.filtersMentee.end_date;

                this.$router.push({ path : this.$route.path , query : paramsMentee})
                this.getAllMentee(paramsMentee)

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearfiltersMentee(){
                this.filtersMentee = {
                    company: null,
                    complete_name: null,
                    personnel_number:null,
                }
                this.getAllMentee();

            },
            runfiltersMenteee(){
                let paramsMenteee = {}
                if (this.filtersMenteee.company)
                    paramsMenteee["business_code"] = [this.filtersMenteee.company];
                if (this.filtersMenteee.complete_name)
                    paramsMenteee["complete_name[]"] = this.filtersMenteee.complete_name
                if (this.filtersMenteee.personnel_number)
                    paramsMenteee["personnel_number[]"] = this.filtersMenteee.personnel_number
                
                if (this.filtersMenteee.begin_date)
                    paramsMenteee["begin_date_lte"] = this.filtersMenteee.begin_date;
                if (this.filtersMenteee.end_date)
                    paramsMenteee["end_date_gte"] = this.filtersMenteee.end_date;

                this.$router.push({ path : this.$route.path , query : paramsMenteee})
                this.getAllMenteee(paramsMenteee)

                // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
            },
            clearfiltersMenteee(){
                this.filtersMenteee = {
                    company: null,
                    complete_name: null,
                    personnel_number:null,
                }
                this.getAllMenteee();

            },
            async addMentor() {
                await this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/mentoringparticipant', {
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                            personnel_number: this.mentor.detail.personnel_number,
                            business_code: this.mentoring.detail.business_code,
                            mentoring: this.mentoring.detail.mentoring_id,
                            otype: 'MNTOR',
                            id: this.mentor.detail.mentor_id,
                            
                        })
                        .then(() => {
                            this.$axios.get('lms/api/mentorcommunication?communication_type[]=2&mentor[]='+this.mentor.mentor_id)
                            .then(response => {
                                this.email = response.data.data[0].communication_text                
                            }).catch(e => {
                                console.log(e);
                            });
                            if(this.email){
                                let data = new FormData();

                                data.append('to[]', this.email)
                                data.append('subject', "Undangan Event")
                                data.append('message', "Anda diundang di event "+ this.session.batch.event.event_name +"batch "+this.session.batch.batch_name+"session "+this.session.session_name+"mentoring "+this.mentoring.detail.title)                       

                                this.$axios.post('lms/api/sendmail', data)
                                this.email = null
                            }
                            
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('mentoringMentor/getAll');
                            this.$bvModal.hide('modalMentor')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },
            async addParticipant() {
                await this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/mentoringparticipant', {
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                            personnel_number: this.batchParticipant.detail.participant.personnel_number,
                            business_code: this.mentoring.detail.business_code,
                            mentoring: this.mentoring.detail.mentoring_id,
                            otype: 'PARTI',
                            id: this.batchParticipant.detail.participant.participant_id,
                            
                        })
                        .then(() => {
                            this.$axios.get('lms/api/participantcommunication?communication_type[]=2&participant[]='+this.batchParticipant.detail.participant.participant_id)
                            .then(response => {
                                this.email = response.data.data[0].communication_text                
                            }).catch(e => {
                                console.log(e);
                            });
                            if(this.email){
                                let data = new FormData();

                                data.append('to[]', this.email)
                                data.append('subject', "Undangan Event")
                                data.append('message', "Anda diundang di event "+ this.session.batch.event.event_name +"batch "+this.session.batch.batch_name+"session "+this.session.session_name+"mentoring "+this.mentoring.detail.title)                       

                                this.$axios.post('lms/api/sendmail', data)
                                this.email = null
                            }
                            
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('mentoringMentee/getAll');
                            this.$bvModal.hide('modalMentee')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },
            async submitMentor(object_identifier) {
                
                    await this.getDetailMentor(object_identifier) 
                    this.begin_date = null
                    this.end_date = null                  
                    this.$validator.reset('collection')                
                    this.$bvModal.show('modalMentor')
                

            },
            async submitMentee(object_identifier) {
                
                    await this.getDetailMentee(object_identifier)
                    this.begin_date = null
                    this.end_date = null
                    this.$validator.reset('collection')
                    this.$bvModal.show('modalMentee')
                
            },
            async showDelimitFormMentor(object_identifier) {
                await this.getDetailMentorr(object_identifier)
                this.typeMentoring = 'Mentor'
                this.object_identifier = object_identifier
                this.begin_date = this.mentoringMentor.detail.begin_date
                this.end_date = this.mentoringMentor.detail.end_date
                this.$bvModal.show('modalDelimit')
            },
            async showDelimitFormMentee(object_identifier) {
                await this.getDetailMenteee(object_identifier)
                this.typeMentoring = 'Mentee'
                this.object_identifier = object_identifier
                this.begin_date = this.mentoringMentee.detail.begin_date
                this.end_date = this.mentoringMentee.detail.end_date
                this.$bvModal.show('modalDelimit')
            },
            deleteDataMentor(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/mentoringparticipant?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOneMentor(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },
            deleteDataMentee(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/mentoringparticipant?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOneMentee(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },
            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/mentoringparticipant', {}, {
                            params: {
                                object_identifier: this.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            if(this.typeMentoring == 'Mentee'){
                                this.$store.dispatch('mentoringMentee/getAll');
                            }
                            else {
                                this.$store.dispatch('mentoringMentor/getAll');
                            }
                             this.$bvModal.hide('modalDelimit')
                             this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success')
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>