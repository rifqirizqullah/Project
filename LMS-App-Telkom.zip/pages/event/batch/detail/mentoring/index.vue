<template>
    <div>
        <div class="container">
            <headerEventComponent/>
        </div>
        <div class="container">
            <headerBatchComponent/>
        </div>
        <div class="container">
            <headerSessionComponent/>
        </div>
        <div class="container page-section pt-0">

            <span class="d-flex justify-content-between align-items-center">
                <h2 class="m-3"> <i class="material-icons text-info">person</i> Mentoring</h2>
                <span>
                    <button @click="clearDetail(); $bvModal.show('mentoringForm')" class="btn btn-success btn-sm">+ Create Mentoring</button>
                    <button v-if="type == 'event' && session.reference.session_id"  @click="clearDetail(); $bvModal.show('mentoringFormReference')" class="btn btn-sm btn-success">+ Add Planned Mentoring</button>
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button> 
                </span>
            </span>
     <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
            <div class="form-group">
                <label for="schedule_name">Title</label>
                <input
                    v-model="filters.title" type="text" class="form-control" name="title" id="title" placeholder="title"
                />
                <small class="form-text text-muted">Title</small>
            </div>

            <div class="col-sm-12 col-md-3">
            <div class="form-group">
                <label for="topic">Topic</label>
                <input
                    v-model="filters.topic" type="text" class="form-control" name="topic" id="topic" placeholder="Topic ..."
                />
                 <small class="form-text text-muted">Topic</small>
            </div>
            </div>

            <div class="col-sm-12 col-md-3">
            <div class="form-group">
                <label for="topic">Decription</label>
                <input
                    v-model="filters.description" type="text" class="form-control" name="description" id="description" placeholder="description"
                />
                 <small class="form-text text-muted">description</small>
            </div>
            </div>

            <div class="col-sm-12 col-md-3">
                <label for="schedule_date">Begin Date</label>
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

              <div class="col-sm-12 col-md-3">
                <label for="schedule_date">End Date</label>
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>

            </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>   

                <table class="table table-responsive table-flush table-hover">
                    <thead class="">
                        <tr class="">
                            <th>Title</th>
                            <th>Topic</th>
                            <th>Description</th>
                            <th>Duration</th>
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in mentoring.list" :key="index">
                            <td @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/mentoring/detail-mentoring?type=event')" style="cursor:pointer;"> 
                               <strong> {{ item.title }} </strong>
                            </td>
                            <td> {{ item.topic }} </td>
                            <td> {{ item.description }} </td>
                            <td>
                               {{ item.duration }}
                            </td>                            
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                        <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/mentoring/detail-mentoring?type=event')">Detail</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="mentoring.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
            </div>

            <b-modal v-model="modalShow" ref="mentoringForm" hide-footer hide-header id="mentoringForm" size="lg">
                <mentoringForm v-if="modalShow" />
            </b-modal>

            <b-modal v-model="modalReferenceShow" ref="mentoringFormReference" hide-footer title="Add Planned Mentoring" id="mentoringFormReference" size="lg">
                <mentoringFormReference v-if="modalReferenceShow" />
            </b-modal>

            <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        </div>


    
</template>

<script>
import moment from 'moment'
import mentoringForm from '@@/components/forms/mentoringForm'
import mentoringFormReference from '@@/components/forms/mentoringFormReference'
import paginationBar from '@@/components/paginationBar'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'schedule',
    components : { mentoringForm, paginationBar, headerEventComponent, headerBatchComponent, mentoringFormReference, headerSessionComponent },
    
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            modalReferenceShow : false,

            begin_date : null,
            end_date : null,

            type : this.$route.query.type,
            filters: {
                 begin_date: null,
                 end_date: null,
                 title: null,
                 topic: null,
                 description: null,
        }                
        };
    },
    created() {
        this.$store.dispatch('mentoring/getAll');
        // this.$store.dispatch('mentoring/getReference');
        // this.business_code = this.session.business_code.business_code
    },
    computed: {
        ...mapState({
            session : state => state.session.detail,
            mentoring : state => state.mentoring,
        }),
    },
    methods: {
        getParam(){
        this.$store.dispatch("mentoring/getAll");

         },
        ...mapActions({
            getDetail: 'mentoring/getDetail',
            getDetailReference: 'mentoring/getDetailReference',
            clearDetail: 'mentoring/clearDetail',
            deleteOne: 'mentoring/deleteOne',
            getAll: 'mentoring/getAll'
        }),
        runFilter() {
        let params = {};
         if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
         if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;
         if (this.filters.description)
            params["description[]"] = this.filters.description;
         if (this.filters.title)
            params["title[]"] = this.filters.title
         if (this.filters.topic)
            params["topic[]"] = this.filters.topic
            
            this.$router.push({ path : this.$route.path , query : params})

            this.getAll(params);
        },

          clearFilters() {
            this.filters = {
                description : null,
                title : null,
                topic : null,
                begin_date: null,
                end_date: null,
            };
        },

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('mentoringForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.mentoring.detail.begin_date
            this.end_date = this.mentoring.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/mentoring?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/mentoring', {}, {
                    params : {
                        object_identifier : this.mentoring.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('mentoring/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>