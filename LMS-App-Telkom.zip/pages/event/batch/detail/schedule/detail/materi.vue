<template>
    <div class="container page-section">

        <headerScheduleComponent/>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Materi</h4>
                   <!-- <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>
                </span> -->
            </div>

       <div class>
       <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.materi_name"
                        type="text"
                        class="form-control"
                        id="materi_name"
                        placeholder="materi_name"
                        >
                        <small class="form-text text-muted">Materi Name </small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.description"
                        type="text"
                        class="form-control"
                        id="description"
                        placeholder="description"
                        >
                        <small class="form-text text-muted"> Description </small>
                    </div>
                </div>

 
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.materi_type"
                      class="form-control"
                      name="materi_type"
                      id="materi_type"
                    >
                      <option
                        v-for="(item, index) in MATTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Tipe Materi</small>
                  </div>
                </div>
 
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.method"
                      class="form-control"
                      name="method"
                      id="method"
                    >
                      <option
                        v-for="(item, index) in TCMTD.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Method</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.competence"
                      class="form-control"
                      name="competence"
                      id="competence"
                    >
                      <option
                        v-for="(item, index) in CMPTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Competence</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.pl_code"
                      class="form-control"
                      name="pl_code"
                      id="pl_code"
                    >
                      <option
                        v-for="(item, index) in PLCOD.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">PL Code</small>
                  </div>
                </div>
    
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; clearFilters()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Materi</th>
                            <th>Type</th>
                            <!-- <th>Link</th> -->
                            <th>PL Code</th>
                            <th>Method</th>
                            <th>Competence</th>
                            <th>Description</th>
                            <th>Begin</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_materi.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.child.materi_name }} </td>
                            <td> {{ item.child.materi_type.value }} </td>
                            <!-- <td> {{ item.child.address }} </td> -->
                            <td> {{ item.child.pl_code.value }} </td>
                            <td> {{ item.child.method.value }} </td>
                            <td> {{ item.child.competence.value }} </td>
                            <td> {{ item.child.description }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;"></button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <!-- <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button> -->
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="schedule_materi.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='schedule_materi' :storeModuleName="'schedule_materi'" />
            </div>
        </div>

        <div class="card shadow" v-if="type == 'event' && schedule.reference.schedule_id">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">Planned Materi</h4>
                <!-- <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>
                </span> -->
            </div>
           <div class>
          <div class="text-right">
          <div class="bg-white">
          <b-collapse id="collapse-b" class="mt-2">
            <form class="p-2">
              <div class="row">

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.materi_name"
                        type="text"
                        class="form-control"
                        id="materi_name"
                        placeholder="materi_name"
                        >
                        <small class="form-text text-muted">Materi Name </small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.description"
                        type="text"
                        class="form-control"
                        id="description"
                        placeholder="description"
                        >
                        <small class="form-text text-muted"> Description </small>
                    </div>
                </div>

 
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters1.materi_type"
                      class="form-control"
                      name="materi_type"
                      id="materi_type"
                    >
                      <option
                        v-for="(item, index) in MATTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Tipe Materi</small>
                  </div>
                </div>
 
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters1.method"
                      class="form-control"
                      name="method"
                      id="method"
                    >
                      <option
                        v-for="(item, index) in TCMTD.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Method</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters1.competence"
                      class="form-control"
                      name="competence"
                      id="competence"
                    >
                      <option
                        v-for="(item, index) in CMPTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Competence</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters1.pl_code"
                      class="form-control"
                      name="pl_code"
                      id="pl_code"
                    >
                      <option
                        v-for="(item, index) in PLCOD.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">PL Code</small>
                  </div>
                </div>
    
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; clearFilters1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Materi</th>
                            <th>Type</th>
                            <!-- <th>Link</th> -->
                            <th>PL Code</th>
                            <th>Method</th>
                            <th>Competence</th>
                            <th>Description</th>
                            <th>Begin</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_materi.listReference" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.child.materi_name }} </td>
                            <td> {{ item.child.materi_type.value }} </td>
                            <!-- <td> {{ item.child.address }} </td> -->
                            <td> {{ item.child.pl_code.value }} </td>
                            <td> {{ item.child.method.value }} </td>
                            <td> {{ item.child.competence.value }} </td>
                            <td> {{ item.child.description }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='ref')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="schedule_materi.isLoadingR">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='schedule_materi' :storeModuleName="'schedule_materi'" />
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">All Materi</h4>
                <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-c>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>
                </span>
            </div>
            <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-c" class="mt-2">
            <form class="p-2">
              <div class="row">

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters2.materi_name"
                        type="text"
                        class="form-control"
                        id="materi_name"
                        placeholder="materi_name"
                        >
                        <small class="form-text text-muted">Materi Name </small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters2.description"
                        type="text"
                        class="form-control"
                        id="description"
                        placeholder="description"
                        >
                        <small class="form-text text-muted"> Description </small>
                    </div>
                </div>

 
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters2.materi_type"
                      class="form-control"
                      name="materi_type"
                      id="materi_type"
                    >
                      <option
                        v-for="(item, index) in MATTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Tipe Materi</small>
                  </div>
                </div>
 
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters2.method"
                      class="form-control"
                      name="method"
                      id="method"
                    >
                      <option
                        v-for="(item, index) in TCMTD.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Method</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters2.competence"
                      class="form-control"
                      name="competence"
                      id="competence"
                    >
                      <option
                        v-for="(item, index) in CMPTY.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">Competence</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters2.pl_code"
                      class="form-control"
                      name="pl_code"
                      id="pl_code"
                    >
                      <option
                        v-for="(item, index) in PLCOD.list"
                        :key="index"
                        :value="item.id"
                      >{{item.value}}</option>
                    </select>
                    <small class="form-text text-muted">PL Code</small>
                  </div>
                </div>
    
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters2 = {}; clearFilters2()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter2" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Materi</th>
                            <th>Type</th>
                            <!-- <th>Link</th> -->
                            <th>PL Code</th>
                            <th>Method</th>
                            <th>Competence</th>
                            <th>Description</th>
                            <th>Begin</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in materi.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.materi_name }} </td>
                            <td> {{ item.materi_type.value }} </td>
                            <!-- <td> {{ item.address }} </td> -->
                            <td> {{ item.pl_code.value }} </td>
                            <td> {{ item.method.value }} </td>
                            <td> {{ item.competence.value }} </td>
                            <td> {{ item.description }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='all')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="materi.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='materi' :storeModuleName="'materi'" />
            </div>
        </div>
        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        <b-modal id="modalAll" centered title="Add Schedule Materi" size="sm">
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalAll')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addParticipant">Save</button>
            </div>
        </b-modal>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import paginationBarR from '@@/components/paginationBarR'
    import headerScheduleComponent from '@@/components/headerScheduleComponent'

    import { mapState, mapActions } from 'vuex'

    export default {
        layout: 'schedule-detail',
        components: { paginationBar, paginationBarR, headerScheduleComponent },
        created() {
            this.$store.dispatch('schedule_materi/getReference',{'parent[]':this.schedule.reference.schedule_id});
            this.$store.dispatch('schedule_materi/getAll',{'parent[]':this.schedule.schedule_id});
            this.$store.dispatch('materi/getAll');
        },
        middleware: ({ store, redirect }) => {
            if (!store.state.schedule.detail) return redirect('/event/event/')
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                business_code: null,
                begin_date: null,
                end_date: null,
                materi_id:null,
                type:this.$route.query.type,
                filters: {                
                     materi_name: null,
                     materi_type: null,
                     method: null,
                     description: null,
                     competence: null,
                     begin_date: null,
                     end_date: null,
                     pl_code: null,
                },
                 filters1: {                
                     materi_name: null,
                     materi_type: null,
                     method: null,
                     description: null,
                     competence: null,
                     begin_date: null,
                     end_date: null,
                     pl_code: null,
                },
                 filters2: {                
                     materi_name: null,
                     materi_type: null,
                     method: null,
                     description: null,
                     competence: null,
                     begin_date: null,
                     end_date: null,
                     pl_code: null,

                }
            };
        },
        computed: {
            schedule(){
                return this.$store.state.schedule.detail
            },
            ...mapState({
                schedule_materi : state => state.schedule_materi,
                materi : state => state.materi,
                TCMTD : state => state.TCMTD,
                MATTY : state => state.MATTY,
                CMPTY : state => state.CMPTY,
                PLCOD : state => state.PLCOD,
            })
        },
        methods: {
            getParam(){
          
            this.$store.dispatch("TCMTD/getAll");
            this.$store.dispatch("MATTY/getAll");
            this.$store.dispatch("CMPTY/getAll");
            this.$store.dispatch("PLCOD/getAll");

        },
            ...mapActions({
                getDetail: 'schedule_materi/getDetail',
                getDetailReference: 'schedule_materi/getDetailReference',
                getDetailAll: 'materi/getDetail',
                clearDetail: 'schedule_materi/clearDetail',
                deleteOne: 'schedule_materi/deleteOne',
                getAll: 'schedule_materi/getAll',
                getAll1: 'schedule_materi/getReference',
                getAll2: 'materi/getAll',
            }),

        runFilter() {
        let params = {'parent[]':this.schedule.schedule_id};
       
        if (this.filters.materi_type)
            params["materi_type[]"] = this.filters.materi_type;
        if (this.filters.materi_name)
            params["materi_name[]"] = [this.filters.materi_name];
        if (this.filters.description)
            params["description[]"] = [this.filters.description];
        if (this.filters.method)
            params["method"] = this.filters.method;
        if (this.filters.competence)
            params["competence"] = this.filters.competence;
        if (this.filters.pl_code)
            params["pl_code[]"] = [this.filters.pl_code];
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;

            this.$router.push({ path : this.$route.path , query : params})
            
            this.getAll(params);
        },
        clearFilters() {
            this.filters = {
                materi_name: null,
                materi_type: null,
                method: null,
                description: null,
                competence: null,
                begin_date: null,
                end_date: null,
                pl_code: null,
            };
            let params = {'parent[]':this.schedule.schedule_id};
       
            this.getAll(params);
        },

        runFilter1() {
        let params1 = {'parent[]':this.schedule.reference.schedule_id};
       
        if (this.filters1.materi_type)
            params1["materi_type[]"] = this.filters1.materi_type;
        if (this.filters1.materi_name)
            params1["materi_name[]"] = [this.filters1.materi_name];
        if (this.filters1.description)
            params1["description[]"] = [this.filters1.description];
        if (this.filters1.method)
            params1["method"] = this.filters1.method;
        if (this.filters1.competence)
            params1["competence"] = this.filters1.competence;
        if (this.filters1.pl_code)
            params1["pl_code[]"] = [this.filters1.pl_code];
        if (this.filters1.begin_date)
            params1["begin_date_lte"] = this.filters1.begin_date;
        if (this.filters1.end_date)
            params1["end_date_gte"] = this.filters1.end_date;
            this.$router.push({ path : this.$route.path , query : params1})
            
            this.getAll1(params1);
        },
        clearFilters1() {
            this.filters1 = {
                materi_name: null,
                materi_type: null,
                description: null,
                method: null,
                competence: null, 
            };
            let params1 = {'parent[]':this.schedule.reference.schedule_id};
       
            this.getAll1(params1);
        },
        runFilter2() {
        let params2 = {};
       
        if (this.filters2.materi_type)
            params2["materi_type[]"] = this.filters2.materi_type;
        if (this.filters2.materi_name)
            params2["materi_name[]"] = this.filters2.materi_name;
        if (this.filters2.description)
            params2["description[]"] = this.filters2.description;
        if (this.filters2.method)
            params2["method"] = this.filters2.method;
        if (this.filters2.competence)
            params2["competence"] = this.filters2.competence;
        if (this.filters2.pl_code)
            params2["pl_code[]"] = this.filters2.pl_code;
        if (this.filters2.begin_date)
            params2["begin_date_lte"] = this.filters2.begin_date;
        if (this.filters2.end_date)
            params2["end_date_gte"] = this.filters2.end_date;
            this.$router.push({ path : this.$route.path , query : params2})
            
            this.getAll2(params2);
        },
        clearFilters2() {
            this.filters2 = {
                materi_name: null,
                     materi_type: null,
                     method: null,
                     description: null,
                     competence: null,
                     begin_date: null,
                     end_date: null,
                     pl_code: null, 
            };
            let params2 = {};
       
            this.getAll2(params2);
        },

            addParticipant() {
                this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/lmsrelation', {
                            otype_parent : "SCHDL",
                            parent : this.schedule.schedule_id,
                            relation : "S003",
                            otype_child : "MATER",
                            child : this.materi_id,
                            business_code: this.schedule.business_code.business_code,
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                        })
                        .then(() => {
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('schedule_materi/getAll',{'parent[]':this.schedule.schedule_id});
                            this.$bvModal.hide('modalAll')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },

            async submit(object_identifier,from) {
                if (from == 'all') {
                    await this.getDetailAll(object_identifier)
                    this.end_date = null
                    this.begin_date = null
                    this.$validator.reset('collection')
                    this.materi_id= this.materi.detail.materi_id
                    this.$bvModal.show('modalAll')
                } else {
                    await this.getDetailReference(object_identifier)
                    this.materi_id= this.schedule_materi.detail.child.materi_id
                    this.business_code = this.schedule_materi.detail.business_code.business_code
                    this.begin_date = this.schedule_materi.detail.begin_date
                    this.end_date = this.schedule_materi.detail.end_date

                    this.$axios.post('lms/api/lmsrelation', {
                        otype_parent : "SCHDL",
                        parent : this.schedule.schedule_id,
                        relation : "S003",
                        otype_child : "MATER",
                        child : this.materi_id,
                        business_code: this.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.$store.dispatch('schedule_materi/getAll',{'parent[]':this.schedule.schedule_id});
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
                }

            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.schedule_materi.detail.begin_date
                this.end_date = this.schedule_materi.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/lmsrelation?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/lmsrelation', {}, {
                            params: {
                                object_identifier: this.schedule_materi.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('schedule_materi/getAll',{'parent[]':this.schedule.schedule_id});
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },

            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
