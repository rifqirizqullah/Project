<template>
    <div class="container page-section">

        <headerScheduleComponent/>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Room</h4>
                <!-- <span> 
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>      
                </span> -->
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row"> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.room_name"
                        type="text"
                        class="form-control"
                        id="room_name"
                        placeholder="Room Name"
                        >
                        <small class="form-text text-muted">Room Name</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters.building" class="form-control" name="building" id="building">
                        <option
                            v-for="(item, index) in building.list"
                            :key="index"
                            :value="item.build_code"
                        >{{item.build_name}}</option>
                        </select>
                        <small class="form-text text-muted">Building</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.floor"
                        type="text"
                        class="form-control"
                        id="floor"
                        placeholder="Floor"
                        >
                        <small class="form-text text-muted">Floor</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters.company" class="form-control" name="company" id="company">
                        <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                        >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                    </div>
                </div>
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Room Name</th>
                            <th>Building</th>
                            <th>Floor</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_room.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.child.room_name }} </td>
                            <td> {{ item.child.building.building_name }} </td>
                            <td> {{ item.child.floor }} </td>
                            <td> {{ item.child.business_code.company_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;"></button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <!-- <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button> -->
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="schedule_room.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='schedule_room' :storeModuleName="'schedule_room'" />
            </div>
        </div>

        <div class="card shadow" v-if="type == 'event' && schedule.reference.schedule_id">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">Planned Room</h4>
            <!-- <span> 
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>      
            </span> -->
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-b" class="mt-2">
            <form class="p-2">
              <div class="row"> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.room_name"
                        type="text"
                        class="form-control"
                        id="room_name"
                        placeholder="Room Name"
                        >
                        <small class="form-text text-muted">Room Name</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters1.building" class="form-control" name="building" id="building">
                        <option
                            v-for="(item, index) in building.list"
                            :key="index"
                            :value="item.build_code"
                        >{{item.build_name}}</option>
                        </select>
                        <small class="form-text text-muted">Building</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.floor"
                        type="text"
                        class="form-control"
                        id="floor"
                        placeholder="Floor"
                        >
                        <small class="form-text text-muted">Floor</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters1.company" class="form-control" name="company" id="company">
                        <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                        >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                    </div>
                </div>
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; runFilter1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Room</th>
                            <th>Building</th>
                            <th>Floor</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_room.listReference" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.child.room_name }} </td>
                            <td> {{ item.child.building.building_name }} </td>
                            <td> {{ item.child.floor }} </td>
                            <td> {{ item.child.business_code.company_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='ref')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="schedule_room.isLoadingR">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='schedule_room' :storeModuleName="'schedule_room'" />
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">All Room</h4>
            <span> 
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-c>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>      
            </span>
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-c" class="mt-2">
            <form class="p-2">
              <div class="row"> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters2.room_name"
                        type="text"
                        class="form-control"
                        id="room_name"
                        placeholder="Room Name"
                        >
                        <small class="form-text text-muted">Room Name</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters2.building" class="form-control" name="building" id="building">
                        <option
                            v-for="(item, index) in building.list"
                            :key="index"
                            :value="item.build_code"
                        >{{item.build_name}}</option>
                        </select>
                        <small class="form-text text-muted">Building</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters2.floor"
                        type="text"
                        class="form-control"
                        id="floor"
                        placeholder="Floor"
                        >
                        <small class="form-text text-muted">Floor</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters2.company" class="form-control" name="company" id="company">
                        <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                        >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                    </div>
                </div>
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters2 = {}; runFilter2()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter2" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Room</th>
                            <th>Building</th>
                            <th>Floor</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in room.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.room_name }} </td>
                            <td> {{ item.building.building_name }} </td>
                            <td> {{ item.floor }} </td>
                            <td> {{ item.business_code.company_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='all')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="room.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='room' :storeModuleName="'room'" />
            </div>
        </div>
        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        <b-modal id="modalAll" centered title="Add Schedule Room" size="sm">
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalAll')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addParticipant">Save</button>
            </div>
        </b-modal>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import paginationBarR from '@@/components/paginationBarR'
    import headerScheduleComponent from '@@/components/headerScheduleComponent'
    import { mapState, mapActions } from 'vuex'

    export default {
        layout: 'schedule-detail',
        components: {
            paginationBar,
            paginationBarR,
            headerScheduleComponent
        },
        created() {
            this.$store.dispatch('schedule_room/getReference',{'parent[]':this.schedule.reference.schedule_id});
            this.$store.dispatch('schedule_room/getAll',{'parent[]':this.schedule.schedule_id});
            this.$store.dispatch('room/getAll');
            
        },
        middleware: ({ store, redirect }) => {
            if (!store.state.schedule.detail) return redirect('/event/event/')
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                business_code: null,
                begin_date: null,
                end_date: null,
                room_id:null,
                type:this.$route.query.type,
                filters: {
                    room_name: null,
                    building: null,
                    floor: null,
                    company: null,  
                    begin_date: null,
                    end_date: null
                },
                filters1: {
                    room_name: null,
                    building: null,
                    floor: null,
                    company: null,  
                    begin_date: null,
                    end_date: null
                },
                filters2: {
                    room_name: null,
                    building: null,
                    floor: null,
                    company: null,  
                    begin_date: null,
                    end_date: null
                },
            };
        },
        computed: {
            schedule(){
                return this.$store.state.schedule.detail
            },
            ...mapState({
            schedule_room : state => state.schedule_room,
            room : state => state.room,
            company : state => state.company,
            building : state => state.building,
            }),
        },
        methods: {
            getParam(){
                this.$store.dispatch('company/getAll');
                this.$store.dispatch("building/getAll");

        },
            ...mapActions({
                getDetail: 'schedule_room/getDetail',
                getDetailAll: 'room/getDetail',
                clearDetail: 'schedule_room/clearDetail',
                deleteOne: 'schedule_room/deleteOne',
                getAll: 'schedule_room/getAll',
                getAll1: 'schedule_room/getReference',
                getAll2: 'room/getAll',

            }),

            runFilter() {
            let params = {'parent[]':this.schedule.schedule_id};
            if (this.filters.room_name)
                params["room_name[]"] = this.filters.room_name;
            if (this.filters.building)
                params["build_code[]"] = this.filters.building;
            if (this.filters.floor)
                params["floor[]"] = this.filters.floor;
            if (this.filters.company)
                params["business_code"] = [this.filters.company];
            if (this.filters.begin_date)
                params["begin_date_lte"] = this.filters.begin_date;
            if (this.filters.end_date)
                params["end_date_gte"] = this.filters.end_date;
                this.$router.push({ path : this.$route.path , query : params})
                this.getAll(params);
            },
            clearFilters() {
                this.filters = {
                    room_name: null,
                    building: null,
                    floor: null,
                    company: null,
                };
                let params = {'parent[]':this.schedule.schedule_id};
                this.getAll(params);
            },

            runFilter1() {
            let params1 = {'parent[]':this.schedule.reference.schedule_id};
            if (this.filters1.room_name)
                params1["room_name[]"] = this.filters1.room_name;
            if (this.filters1.building)
                params1["build_code[]"] = this.filters1.building;
            if (this.filters1.floor)
                params1["floor[]"] = this.filters1.floor;
            if (this.filters1.company)
                params1["business_code"] = [this.filters1.company];
            if (this.filters1.begin_date)
                params1["begin_date_lte"] = this.filters1.begin_date;
            if (this.filters1.end_date)
                params1["end_date_gte"] = this.filters1.end_date;
                this.$router.push({ path : this.$route.path , query : params1})
                this.getAll1(params1);
            },
            clearFilters1() {
                this.filters1 = {
                    room_name: null,
                    building: null,
                    floor: null,
                    company: null,

                    
                };
                let params1 = {'parent[]':this.schedule.reference.schedule_id};
                this.getAll1(params1);
            },

            runFilter2() {
            let params2 = {};
            if (this.filters2.room_name)
                params2["room_name[]"] = this.filters2.room_name;
            if (this.filters2.building)
                params2["building[]"] = this.filters2.building;
            if (this.filters2.floor)
                params2["floor[]"] = this.filters2.floor;
            if (this.filters2.company)
                params2["business_code"] = [this.filters2.company];
            if (this.filters2.begin_date)
                params2["begin_date_lte"] = this.filters2.begin_date;
            if (this.filters2.end_date)
                params2["end_date_gte"] = this.filters2.end_date;
                this.$router.push({ path : this.$route.path , query : params2})
                this.getAll2(params2);
            },
            clearFilters2() {
                this.filters2 = {
                    room_name: null,
                    building: null,
                    floor: null,
                    company: null,
                };
                let params2 = {};
                this.getAll2(params2);
            },
            addParticipant() {
                this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/lmsrelation', {
                            otype_parent : "SCHDL",
                            parent : this.schedule.schedule_id,
                            relation : "S001",
                            otype_child : "ROOMS",
                            child : this.room_id,
                            business_code: this.schedule.business_code.business_code,
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                        })
                        .then(() => {
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('schedule_room/getAll',{'parent[]':this.schedule.schedule_id});
                            this.$bvModal.hide('modalAll')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },
            async submit(object_identifier,from) {
                if (from == 'all') {
                    await this.getDetailAll(object_identifier)
                    this.end_date = null
                    this.begin_date = null
                    this.$validator.reset('collection')
                    this.room_id= this.room.detail.room_id
                    this.$bvModal.show('modalAll')
                } else {
                    await this.getDetailReference(object_identifier)
                    this.room_id= this.schedule_room.detail.child.room_id
                    this.business_code = this.schedule_room.detail.business_code.business_code
                    this.begin_date = this.schedule_room.detail.begin_date
                    this.end_date = this.schedule_room.detail.end_date

                    this.$axios.post('lms/api/lmsrelation', {
                        otype_parent : "SCHDL",
                        parent : this.schedule.schedule_id,
                        relation : "S001",
                        otype_child : "ROOMS",
                        child : this.room_id,
                        business_code: this.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.$store.dispatch('schedule_room/getAll',{'parent[]':this.schedule.schedule_id});
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
                }

            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.schedule_room.detail.begin_date
                this.end_date = this.schedule_room.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/lmsrelation?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/lmsrelation', {}, {
                            params: {
                                object_identifier: this.schedule_room.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('schedule_room/getAll',{'parent[]':this.schedule.schedule_id});
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
