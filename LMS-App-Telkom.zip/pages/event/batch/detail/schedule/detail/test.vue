<template>
    <div class="container page-section">

        <headerScheduleComponent/>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Template Test</h4>
                <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span> 
            </div>
            <div class="">
                <div class="text-right">
                    <div class="bg-white">
                        <!-- Elements to collapse -->
                        <b-collapse id="collapse-a" class="mt-2 p-4">
                            <form action="">
                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters1.test_code" class="form-control" name="TSTCD" id="TSTCD">
                                                <option
                                                    v-for="(item, index) in TSTCD.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Temp Test</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters1.test_type" class="form-control" name="TSTTY" id="TSTTY">
                                                <option
                                                    v-for="(item, index) in TSTTY.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Type</small>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters1 = {}; clearFilter1()" variant="secondary" >Clear Filter</b-button>
                                            <b-button @click="runFilter1" variant="info" >
                                                <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                            </b-button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </b-collapse>
                    </div>
                </div>
            </div>  
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Template Test</th>
                            <th>Type</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_templateTest.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.test_code.value }} </td>
                            <td> {{ item.test_type.value }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;">
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="schedule_templateTest.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='schedule_templateTest' :storeModuleName="'schedule_templateTest'" />
            </div>
        </div>

        <div class="card shadow" v-if="type == 'event' && schedule.reference.schedule_id">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">Planned Template Test</h4>
                <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span> 
            </div>
            <div class="">
                <div class="text-right">
                    <div class="bg-white">
                        <!-- Elements to collapse -->
                        <b-collapse id="collapse-b" class="mt-2 p-4">
                            <form action="">
                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters2.test_code" class="form-control" name="TSTCD" id="TSTCD">
                                                <option
                                                    v-for="(item, index) in TSTCD.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Temp Test</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters2.test_type" class="form-control" name="TSTTY" id="TSTTY">
                                                <option
                                                    v-for="(item, index) in TSTTY.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Type</small>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters2.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters2.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters2 = {}; clearFilter2()" variant="secondary" >Clear Filter</b-button>
                                            <b-button @click="runFilter2" variant="info" >
                                                <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                            </b-button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </b-collapse>
                    </div>
                </div>
            </div>  
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Template Test</th>
                            <th>Type</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_templateTest.listReference" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.test_code.value }} </td>
                            <td> {{ item.test_type.value }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='ref')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="schedule_templateTest.isLoadingR">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='schedule_templateTest' :storeModuleName="'schedule_templateTest'" />
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">All Template Test</h4>
                <span>
                <b-button type="button"  class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-c>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span>    
            </div>
            <div class="">
                <div class="text-right">
                    <div class="bg-white">
                        <!-- Elements to collapse -->
                        <b-collapse id="collapse-c" class="mt-2 p-4">
                            <form action="">
                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters.test_code" class="form-control" name="TSTCD" id="TSTCD">
                                                <option
                                                    v-for="(item, index) in TSTCD.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Temp Qustioner</small>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters = {}; clearFilter()" variant="secondary" >Clear Filter</b-button>
                                            <b-button @click="runFilter" variant="info" >
                                                <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                            </b-button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </b-collapse>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Template</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in TSTCD.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.value }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='all')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="TSTCD.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='TSTCD' :storeModuleName="'TSTCD'" />
            </div>
        </div>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        <b-modal id="modalAll" centered title="Add Schedule Test" size="md">
            <div class="form-group">
                <label for="object2">Template Type</label>
                <select
                    v-model="object2" class="form-control" name="object2" id="object2"
                    :class="{ 'is-danger': errors.has('collection.object2') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in TSTTY.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.object2')" class="help is-danger">{{ errors.first('collection.object2') }}</p>
            </div>

            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalAll')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addTest">Save</button>
            </div>
        </b-modal>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import paginationBarR from '@@/components/paginationBarR'
    import headerScheduleComponent from '@@/components/headerScheduleComponent'
    import { mapState, mapActions } from 'vuex'

    export default {
        layout: 'schedule-detail',
        components: {
            paginationBar,
            paginationBarR,
            headerScheduleComponent,
        },
        middleware: ({ store, redirect }) => {
            if (!store.state.schedule.detail) return redirect('/event/event/')
        },
        created() {
            this.$store.dispatch('schedule_templateTest/clearAll')
            this.$store.dispatch('schedule_templateTest/getReference', {'schedule[]' : this.schedule.reference.schedule_id});
            this.$store.dispatch('schedule_templateTest/getAll', {'schedule[]' : this.schedule.schedule_id});
            // this.$store.dispatch('TSTCD/getAll')
            // this.$store.dispatch('TSTTY/getAll')
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,

                business_code: null,
                begin_date: null,
                end_date: null,
                object2 : null,
                filters : {
                    test_code: null,
                    begin_date: null,
                    end_date: null,
                    
                },
                filters1 : {
                    test_code: null,
                    test_type: null,
                    begin_date: null,
                    end_date: null,
                    
                },
                filters2 : {
                    test_code: null,
                    test_type: null,
                    begin_date: null,
                    end_date: null,
                    
                },
                type:this.$route.query.type
            }
        },
        computed: {
            schedule(){
                return this.$store.state.schedule.detail
            },
            ...mapState(['schedule_templateTest', 'TSTCD', 'TSTTY'])
        },
        methods: {
            getParam(){
                this.$store.dispatch('TSTCD/getAll');
                this.$store.dispatch('TSTTY/getAll');
            },
            
            ...mapActions({
                getDetail: 'schedule_templateTest/getDetail',
                getDetailReference: 'schedule_templateTest/getDetailReference',
                clearDetail: 'schedule_templateTest/clearDetail',
                deleteOne: 'schedule_templateTest/deleteOne',
                getDetailAll: 'TSTCD/getDetail',
                getAll: 'TSTCD/getAll',
                getAll1: 'schedule_templateTest/getAll',
                getAll2: 'schedule_templateTest/getReference',
            }),
            runFilter() {
                let params = {}
                
                if (this.filters.test_code)
                    params["short_text[]"] = this.filters.test_code
                
                if (this.filters.begin_date)
                    params["begin_date_lte"] = this.filters.begin_date;
                if (this.filters.end_date)
                    params["end_date_gte"] = this.filters.end_date;

                this.$router.push({ path : this.$route.path , query : params})
                
                this.getAll(params)
            },
            clearFilter(){
                this.filters = {
                    template_code: null,
                    
                }
                this.getAll()
            },
            runFilter1() {
                let params1 = {'schedule[]' : this.schedule.schedule_id}
                if (this.filters1.test_code)
                    params1["test_code[]"] = this.filters1.test_code
                if (this.filters1.test_type)
                    params1["test_type[]"] = this.filters1.test_type
               
                if (this.filters1.begin_date)
                    params1["begin_date_lte"] = this.filters1.begin_date;
                if (this.filters1.end_date)
                    params1["end_date_gte"] = this.filters1.end_date;

                this.$router.push({ path : this.$route.path , query : params1})
                this.getAll1(params1)
            },
            clearFilter1(){
                this.filters1 = {
                    test_code: null,
                    template_type: null,
                    
                }
                let params1 = {'schedule[]' : this.schedule.schedule_id}
                this.getAll1(params1)
            },
            runFilter2() {
                let params2 = {'schedule[]' : this.schedule.reference.schedule_id}
                if (this.filters2.test_code)
                    params2["test_code[]"] = this.filters2.test_code
                if (this.filters2.test_type)
                    params2["test_type[]"] = this.filters2.test_type
               
                if (this.filters2.begin_date)
                    params2["begin_date_lte"] = this.filters2.begin_date;
                if (this.filters2.end_date)
                    params2["end_date_gte"] = this.filters2.end_date;

                this.$router.push({ path : this.$route.path , query : params2})
                this.getAll2(params2)
            },
            clearFilter2(){
                this.filters2 = {
                    test_code: null,
                    template_type: null,
                    
                }
                let params2 = {'schedule[]' : this.schedule.reference.schedule_id}
                this.getAll2(params2)
            },
            addTest() {
                this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/relationquestion', {
                            business_code: this.schedule.business_code.business_code,
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                            // table_code : "SCHDL",
                            // relation : "S004",
                            // id : this.schedule.schedule_id,
                            // otype1 : "TSTCD",
                            // object1 : this.TSTCD.detail.id,
                            // otype2 : "TSTTY",
                            // object2 : this.object2,                            
                            test_code: this.TSTCD.detail.id,
                            test_type: this.object2,
                            schedule:  this.schedule.schedule_id                            
                        })
                        .then(() => {
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('schedule_templateTest/getAll', {'schedule[]' : this.schedule.schedule_id});
                            this.$bvModal.hide('modalAll')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },
            async submit(object_identifier,from) {
                if (from == 'all') {
                    await this.getDetailAll(object_identifier)
                    this.end_date = null
                    this.begin_date = null
                    this.object2 = null
                    this.$validator.reset('collection')
                    this.$bvModal.show('modalAll')
                } else {
                    await this.getDetailReference(object_identifier)
                    this.begin_date = this.schedule_templateTest.detail.begin_date
                    this.end_date = this.schedule_templateTest.detail.end_date

                    this.$axios.post('lms/api/relationquestion', {
                        business_code: this.schedule.business_code.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        // table_code : "SCHDL",
                        // relation : "S004",
                        // id : this.schedule.schedule_id,
                        // otype1 : "TSTCD",
                        // object1 : this.schedule_templateTest.detail.object1.id,
                        // otype2 : "TSTTY",
                        // object2 : this.schedule_templateTest.detail.object2.id,
                        test_code: this.schedule_templateTest.detail.test_code.id,
                        test_type: this.schedule_templateTest.detail.test_type.id,
                        schedule:  this.schedule.schedule_id
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.$store.dispatch('schedule_templateTest/getAll', {'schedule[]' : this.schedule.schedule_id});
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
                }

            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.schedule_templateTest.detail.begin_date
                this.end_date = this.schedule_templateTest.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/relationquestion?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/relationquestion', {}, {
                            params: {
                                object_identifier: this.schedule_templateTest.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('schedule_templateTest/getAll', {'schedule[]' : this.schedule.schedule_id});
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
