<template>
    <div>
        <div class="container">
            <headerEventComponent/>
            <headerBatchComponent/>
            <headerSessionComponent/>
            <headerScheduleComponent/>
        </div>

        <div class="container page-section">
            <div class="row">

                <div class="col-md-8">

                    <div class="">
                        <div class="mb-heading d-flex align-items-end px-3">
                            <div class="flex">
                                <h4 class="card-title">Materi</h4>
                            </div>
                            <div v-if="schedule_materi.isLoading" class="loader loader-accent text-center m-1"></div>
                            <nuxt-link :to="`detail/materi?type=${type}`" class="btn btn-sm btn-success">Manage</nuxt-link >
                        </div>
                        <div class="card">
                            <table class="table table-flush table-responsive table-hover">
                                <thead class="">
                                    <tr class="">
                                        <th>Materi</th>
                                        <th>Type</th>
                                        <th>Method</th>
                                        <!-- <th>Link</th> -->
                                        <th>Competency</th>
                                        <th>Proviciency Level</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in schedule_materi.list" :key="index">
                                        <td> {{ item.child.materi_name }} </td>
                                        <td> {{ item.child.materi_type.value }} </td>
                                        <td> {{ item.child.method.value }} </td>
                                        <!-- <td> {{ item.child.address }} </td> -->
                                        <td> {{ item.child.competence.value }} </td>
                                        <td> {{ item.child.pl_code.value }} </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="">
                        <div class="mb-heading d-flex align-items-end px-3">
                            <div class="flex">
                                <h4 class="card-title">Template Questioner</h4>
                            </div>
                            <div v-if="schedule_templateQuestioner.isLoading" class="loader loader-accent text-center m-1"></div>
                            <nuxt-link :to="`detail/questioner?type=${type}`" class="btn btn-sm btn-success">Manage</nuxt-link >
                        </div>
                        <div class="card">
                            <table class="table table-flush table-responsive table-hover">
                                <thead class="">
                                    <tr class="">
                                        <th>Template Name</th>
                                        <th>Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in schedule_templateQuestioner.list" :key="index">
                                        <td @click="getDetailQuiz(item.object_identifier); $router.push('/mockups/feedback-result?type='+type)" style="cursor:pointer;">
                                            <strong>{{ item.template_code.value }}</strong>
                                        </td>
                                        <td> {{ item.template_type.value }} </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="">
                        <div class="mb-heading d-flex align-items-end px-3">
                            <div class="flex">
                                <h4 class="card-title">Template Test</h4>
                            </div>
                            <div v-if="schedule_templateTest.isLoading" class="loader loader-accent text-center m-1"></div>
                            <nuxt-link :to="`detail/test?type=${type}`" class="btn btn-sm btn-success">Manage</nuxt-link >
                        </div>
                        <div class="card">
                            <table class="table table-flush table-responsive table-hover">
                                <thead class="">
                                    <tr class="">
                                        <th>Template Name</th>
                                        <th>Type</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in schedule_templateTest.list" :key="index">
                                        <td @click="getDetailTest(item.object_identifier); $router.push('/event/batch/detail/schedule/detail/generate_test?type='+type)" style="cursor:pointer;">
                                            <strong>{{ item.test_code.value }}</strong>
                                        </td>
                                        <td> {{ item.test_type.value }} </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>



                </div>

                <div class="col-md-4">

                    <div class="">
                        <div class="mb-heading d-flex align-items-end px-3">
                            <div class="flex">
                                <h4 class="card-title">Room</h4>
                            </div>
                            <div v-if="schedule_room.isLoading" class="loader loader-accent text-center m-1"></div>
                            <nuxt-link :to="`detail/room?type=${type}`" class="btn btn-sm btn-success">Manage</nuxt-link >
                        </div>
                        <div class="card">
                            <table class="table table-flush table-responsive table-hover">
                                <thead class="">
                                    <tr class="">
                                        <th>Room</th>
                                        <th>Building</th>
                                        <th>Floor</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in schedule_room.list" :key="index">
                                        <td> {{ item.child.room_name }} </td>
                                        <td> {{ item.child.building.building_name }} </td>
                                        <td> {{ item.child.floor }} </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="">
                        <div class="mb-heading d-flex align-items-end px-3">
                            <div class="flex">
                                <h4 class="card-title">Trainer</h4>
                            </div>
                            <div v-if="schedule_trainer.isLoading" class="loader loader-accent text-center m-1"></div>
                            <nuxt-link :to="`detail/trainer?type=${type}`" class="btn btn-sm btn-success">Manage</nuxt-link >
                        </div>
                        <div class="card">
                            <table class="table table-flush table-responsive table-hover">
                                <thead class="">
                                    <tr class="">
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th>Company</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in schedule_trainer.list" :key="index">
                                        <td> {{ item.child.trainer_name }} </td>
                                        <td> {{ item.child.trainer_status.value }} </td>
                                        <td> {{ item.child.business_code.company_name }} </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'
import headerScheduleComponent from '@@/components/headerScheduleComponent'

export default {
    layout : 'schedule-detail',
    components : { headerEventComponent, headerBatchComponent, headerSessionComponent, headerScheduleComponent  },
    data() {
        return {
            type : this.$route.query.type
        }
    },
    middleware: ({ store, redirect }) => {
        if (!store.state.schedule.detail) return redirect('/event/event/')
    },
    created() {
        this.$store.dispatch('schedule_room/getAll',{'parent[]':this.schedule.schedule_id});
        this.$store.dispatch('schedule_trainer/getAll',{'parent[]':this.schedule.schedule_id});
        this.$store.dispatch('schedule_materi/getAll',{'parent[]':this.schedule.schedule_id});
        this.$store.dispatch('schedule_templateQuestioner/getAll',{'schedule[]' : this.schedule.schedule_id});
        this.$store.dispatch('schedule_templateTest/getAll',{'schedule[]' : this.schedule.schedule_id});
    },
    computed: {
        ...mapState({
            schedule : state => state.schedule.detail,
            schedule_room : state => state.schedule_room,
            schedule_trainer : state => state.schedule_trainer,
            schedule_materi : state => state.schedule_materi,
            schedule_templateQuestioner : state => state.schedule_templateQuestioner,
            schedule_templateTest : state => state.schedule_templateTest,
        }),
    },
    methods: {
        ...mapActions({
            getDetailQuiz: 'schedule_templateQuestioner/getDetail',
            getDetailTest: 'schedule_templateTest/getDetail'            
        }),
    }
}
</script>
