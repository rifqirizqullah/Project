<template>
    <div class="container page-section">

        <headerScheduleComponent/>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Trainer</h4>
                <!-- <span> 
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button>      
                </span> -->
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row"> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.trainer_name"
                        type="text"
                        class="form-control"
                        id="trainer_name"
                        placeholder="Trainer"
                        >
                        <small class="form-text text-muted">Trainer</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters.trainer_status" class="form-control" name="trainer_status" id="trainer_status">
                        <option
                            v-for="(item, index) in STTAR.list"
                            :key="index"
                            :value="item.id"
                        >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Status</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters.company" class="form-control" name="company" id="company">
                        <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                        >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                    </div>
                </div>
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Trainer</th>
                            <th>Status</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Status</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_trainer.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.child.trainer_name }} </td>
                            <td> {{ item.child.trainer_status && item.child.trainer_status.value }} </td>
                            <td> {{ item.child.company && item.child.company.company_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td v-if="item.relation == 'ST02'" class="text-success"> 
                                Approved
                            </td>
                            <td v-if="item.relation == 'ST01'" class="text-secondary"> 
                                Not approved yet
                            </td>
                            <td v-if="item.relation == 'ST03'" class="text-danger"> 
                                Disapproved
                            </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;">
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="schedule_trainer.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='schedule_trainer' :storeModuleName="'schedule_trainer'" />
            </div>
        </div>

        <div class="card shadow" v-if="type == 'event' && schedule.reference.schedule_id">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">Planned Trainer</h4>
            <!-- <span> 
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>  
                <i class="fa fa-search"></i> Search         
                </b-button>      
            </span> -->
            </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-b" class="mt-2">
            <form class="p-2">
              <div class="row"> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.trainer_name"
                        type="text"
                        class="form-control"
                        id="trainer_name"
                        placeholder="Trainer"
                        >
                        <small class="form-text text-muted">Trainer</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters1.trainer_status" class="form-control" name="trainer_status" id="trainer_status">
                        <option
                            v-for="(item, index) in STTAR.list"
                            :key="index"
                            :value="item.id"
                        >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Status</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters1.company" class="form-control" name="company" id="company">
                        <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                        >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                    </div>
                </div>
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; runFilter1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Trainer</th>
                            <th>Status</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_trainer.listReference" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.child.trainer_name }} </td>
                            <td> {{ item.child.trainer_status && item.child.trainer_status.value }} </td>
                            <td> {{ item.child.company && item.child.company.company_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='ref')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="schedule_trainer.isLoadingR">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='schedule_trainer' :storeModuleName="'schedule_trainer'" />
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">All Trainer</h4>
            <span> 
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-c>  
                <i class="fa fa-search"></i> Search         
                </b-button>      
            </span>
            </div>

            <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-c" class="mt-2">
            <form class="p-2">
              <div class="row"> 

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters2.trainer_name"
                        type="text"
                        class="form-control"
                        id="trainer_name"
                        placeholder="Trainer"
                        >
                        <small class="form-text text-muted">Trainer</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters2.trainer_status" class="form-control" name="trainer_status" id="trainer_status">
                        <option
                            v-for="(item, index) in STTAR.list"
                            :key="index"
                            :value="item.id"
                        >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Status</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <select v-model="filters2.company" class="form-control" name="company" id="company">
                        <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                        >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                    </div>
                </div>
                
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters2.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters2 = {}; runFilter2()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter2" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div> 

            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Trainer</th>
                            <th>Status</th>
                            <th>Company</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in trainer.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.trainer_name }} </td>
                            <td> {{ item.trainer_status && item.trainer_status.value }} </td>
                            <td> {{ item.company && item.company.company_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='all')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="trainer.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='trainer' :storeModuleName="'trainer'" />
            </div>
        </div>
        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        <b-modal id="modalAll" centered title="Add Schedule Trainer" size="sm">
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalAll')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addParticipant">Save</button>
            </div>
        </b-modal>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import paginationBarR from '@@/components/paginationBarR'
    import headerScheduleComponent from '@@/components/headerScheduleComponent'
    import { mapState, mapActions } from 'vuex'

    export default {
        layout: 'schedule-detail',
        components: {
            paginationBar,
            paginationBarR,
            headerScheduleComponent,
        },
        middleware: ({ store, redirect }) => {
            if (!store.state.schedule.detail) return redirect('/event/event/')
        },
        created() {
            this.$store.dispatch('schedule_trainer/getReference',{'parent[]':this.schedule.reference.schedule_id});
            this.$store.dispatch('schedule_trainer/getAll',{'parent[]':this.schedule.schedule_id});
            this.$store.dispatch('trainer/getAll');
            
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                business_code: null,
                begin_date: null,
                end_date: null,
                trainer_id:null,
                type:this.$route.query.type,
                filters : {
                    company : null,
                    trainer_name : null,
                    trainer_status : null,
                    begin_date: null,
                    end_date: null,
                },
                filters1 : {
                    company : null,
                    trainer_name : null,
                    trainer_status : null,
                    begin_date: null,
                    end_date: null,
                },
                filters2 : {
                    company : null,
                    trainer_name : null,
                    trainer_status : null,
                    begin_date: null,
                    end_date: null,
                },
            };
        },
        computed: {
            schedule(){
                return this.$store.state.schedule.detail
            },
            ...mapState({
            schedule_trainer : state => state.schedule_trainer,
            trainer : state => state.trainer,
            company : state => state.company,
            STTAR : state => state.STTAR,
            }),
        },
        methods: {
            getParam(){
                this.$store.dispatch('company/getAll');
                this.$store.dispatch("STTAR/getAll");

            },
            ...mapActions({
                getDetail: 'schedule_trainer/getDetail',
                getDetailAll: 'trainer/getDetail',
                clearDetail: 'schedule_trainer/clearDetail',
                deleteOne: 'schedule_trainer/deleteOne',
                getAll: 'schedule_trainer/getAll',
                getAll1: 'schedule_trainer/getReference',
                getAll2: 'trainer/getAll',
            }),

            runFilter() {
            let params = {'parent[]':this.schedule.schedule_id};
            if (this.filters.trainer_name)
                params["trainer_name[]"] = this.filters.trainer_name;
            if (this.filters.trainer_status)
                params["trainer_status[]"] = this.filters.trainer_status;
            if (this.filters.company)
                params["business_code"] = [this.filters.company];
            if (this.filters.begin_date)
                params["begin_date_lte"] = this.filters.begin_date;
            if (this.filters.end_date)
                params["end_date_gte"] = this.filters.end_date;
                this.$router.push({ path : this.$route.path , query : params})
                this.getAll(params);
            },
            clearFilters() {
                this.filters = {
                    trainer_name: null,
                    trainer_status: null,
                    company: null,
                };
                let params = {'parent[]':this.schedule.schedule_id};

                this.getAll(params);
            },

            runFilter1() {
            let params1 = {'parent[]':this.schedule.reference.schedule_id};
            if (this.filters1.trainer_name)
                params1["trainer_name[]"] = this.filters1.trainer_name;
            if (this.filters1.trainer_status)
                params1["trainer_status[]"] = this.filters1.trainer_status;
            if (this.filters1.company)
                params1["business_code"] = [this.filters1.company];
            if (this.filters1.begin_date)
                params1["begin_date_lte"] = this.filters1.begin_date;
            if (this.filters1.end_date)
                params1["end_date_gte"] = this.filters1.end_date;
                this.$router.push({ path : this.$route.path , query : params1})
                this.getAll1(params1);
            },
            clearFilters1() {
                this.filters1 = {
                    trainer_name: null,
                    trainer_status: null,
                    company: null,
                };
                let params1 = {'parent[]':this.schedule.reference.schedule_id};

                this.getAll1(params1);
            },

            runFilter2() {
            let params2 = {};
            if (this.filters2.trainer_name)
                params2["trainer_name[]"] = this.filters2.trainer_name;
            if (this.filters2.trainer_status)
                params2["trainer_status[]"] = this.filters2.trainer_status;
            if (this.filters2.company)
                params2["business_code"] = [this.filters2.company];
            if (this.filters2.begin_date)
                params2["begin_date_lte"] = this.filters2.begin_date;
            if (this.filters2.end_date)
                params2["end_date_gte"] = this.filters2.end_date;
                this.$router.push({ path : this.$route.path , query : params2})
                this.getAll2(params2);
            },
            clearFilters2() {
                this.filters2 = {
                    trainer_name: null,
                    trainer_status: null,
                    company: null,
                };
                let params2 = {};

                this.getAll2(params2);
            },
            addParticipant() {
                this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/lmsrelation', {
                            otype_parent : "SCHDL",
                            parent : this.schedule.schedule_id,

                            relation : "ST01",
                            otype_child : "TRAINR",
                            child : this.trainer_id,
                            business_code: this.schedule.business_code.business_code,
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                        })
                        .then(() => {
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('schedule_trainer/getAll',{'parent[]':this.schedule.schedule_id});
                            this.$bvModal.hide('modalAll')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },
            async submit(object_identifier,from) {
                if (from == 'all') {
                    await this.getDetailAll(object_identifier)
                    this.end_date = null
                    this.begin_date = null
                    this.$validator.reset('collection')
                    this.trainer_id= this.trainer.detail.trainer_id
                    this.$bvModal.show('modalAll')
                } else {
                    await this.getDetailReference(object_identifier)
                    this.trainer_id= this.schedule_trainer.detail.child.trainer_id
                    this.business_code = this.schedule_trainer.detail.business_code.business_code
                    this.begin_date = this.schedule_trainer.detail.begin_date
                    this.end_date = this.schedule_trainer.detail.end_date
                    console.log('ini console' + this.schedule.schedule_id);

                    this.$axios.post('lms/api/lmsrelation', {
                        otype_parent : "SCHDL",
                        parent : this.schedule.schedule_id,
                        
                        relation : "ST01",
                        otype_child : "TRAINR",
                        child : this.trainer_id,
                        business_code: this.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.$store.dispatch('schedule_trainer/getAll',{'parent[]':this.schedule.schedule_id});
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
                }

            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.schedule_trainer.detail.begin_date
                this.end_date = this.schedule_trainer.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/lmsrelation?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/lmsrelation', {}, {
                            params: {
                                object_identifier: this.schedule_trainer.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('schedule_trainer/getAll',{'parent[]':this.schedule.schedule_id});
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
