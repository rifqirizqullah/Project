<template>
    <div class="container page-section">
        <div class="container">
            <headerEventComponent />
        </div>
        <div class="container">
            <headerBatchComponent />
            <headerSessionComponent/>
            <headerScheduleComponent/>
        </div>        
        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">{{schedule_templateTest.test_code.value}} - {{schedule_templateTest.relation_question_id}}</h4>
                <h4 class="card-title">{{batchParticipant && batchParticipant.participant.personnel_number}} - {{batchParticipant && batchParticipant.participant.complete_name}}</h4>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Question</th>
                            <th>Answer</th>
                            <th>Participant Answer</th>
                            <th>Max Score</th>
                            <th>Participant Score</th>                                                      
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in items" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.question }} </td>
                            <td><a v-for="(answerList, indexAnswer) in item.answer" :key="indexAnswer"><br>{{ answerList.text_choice }}</a></td>
                            <td><a v-for="(participantAnswerList, indexAnswerParti) in item.participantAnswer" :key="indexAnswerParti"><br>{{ participantAnswerList.text_choice }}</a></td>
                            <td> {{ item.maxScore }} </td>                    
                            <td><div v-if="item.questionType == '03'">{{ item.participantScore }}
                                <b-button @click="getNilai(item.oid,item.participantScore)" type="button" class="btn btn-info" size="sm">Edit</b-button>
                            </div>
                            <div v-else>{{ item.participantScore }}</div>  </td>                    
                        </tr>
                      
                    </tbody>
                </table>
                <div class="row">
                <div class="col-6">
                    <div class="bg-secondary text-white " role="alert">
                        <a class="btn text-right">
                            <span class="">Total Max Score : {{totalMaxScore}}</span>
                        </a>
                    </div>
                </div>
                <div class="col-6">
                    <div class="bg-secondary text-white " role="alert">
                        <a class="btn text-right">
                            <span class="">Total Participant Score : {{totalParticipantScore}}</span>
                        </a>
                    </div>
                </div>
                </div>
                <div class="col-12">
                    <div class="bg-secondary text-white " role="alert">
                        <a class="btn text-right">
                            <span class="">Final Score : {{finalScore}}</span>
                        </a>
                    </div>
                </div>
            </div>
            
        </div> 

        <b-modal
        v-model="modalEsayShow"
        id="modalEsay"
        centered
        title="Input Essay Value"
        header-bg-variant="light"
        size="sm"
        >    
        <div class="col-12">
            <div class="form-group">
            <label for="score_esay">Score Esay</label>
             <input v-model="scoreEsay" type="number" name="score_esay"
                    id="score_esay" class="form-control" placeholder="0-100"
                    aria-describedby="score_esay" v-bind:class="{ 'is-danger': errors.has('nilai.score_esay')}"
                    v-validate="'required'" data-vv-scope="nilai">                      
            <p
                v-show="errors.has('nilai.score_esay')"
                class="help is-danger"
            >{{ errors.first('nilai.score_esay') }}</p>
            </div>
        </div>    
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalEsay')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="patchNilai()">Save</button>
        </div>
        </b-modal>      
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import headerEventComponent from '@@/components/headerEventComponent'
    import headerBatchComponent from '@@/components/headerBatchComponent'
    import headerSessionComponent from '@@/components/headerSessionComponent'
    import headerScheduleComponent from '@@/components/headerScheduleComponent'
    import {
        mapState,
        mapActions
    } from 'vuex'

    export default {
        layout: 'batch',
        components: {
            paginationBar,
            headerEventComponent,
            headerBatchComponent,
            headerSessionComponent, 
            headerScheduleComponent
        },
        middleware({
            store,
            redirect,
            route
        }) {            
            if (!store.state.schedule_templateTest.detail) redirect('/event/event')                        
        },        
        data() {
            return {                
                type:this.$route.query.type,   
                items:[],
                totalMaxScore: null,
                totalParticipantScore : null,
                finalScore:null,
                oid:null,
                scoreEsay:null,
                modalEsayShow : false
            }
        },
        computed: {           
            ...mapState({
                batchParticipant : state => state.batchParticipant.detail,
                schedule_templateTest : state => state.schedule_templateTest.detail           
            }),
        },
        created(){
            this.getDetail()
            this.getScore()
        },
        methods: {            
            getNilai(object_identifier,score) { 
                console.log(score)           
                this.scoreEsay = score
                this.oid = object_identifier
                this.$bvModal.show('modalEsay')
            },
            async getDetail(){
               await this.$axios
                .get(
                    'lms/api/testresultdetail?include[]=participant&include[]=relation_question&include[]=question&participant[]=' 
                    + this.batchParticipant.participant.participant_id +
                    '&relation_question[]='+ this.schedule_templateTest.relation_question_id)
                .then(response => {                   
                    this.items = [];
                    response.data.data.forEach(async (item, key) => {
                        await this.items.push({
                            oid: item.object_identifier,
                            question: item.question.question_text ,
                            answer: [],
                            participantAnswer: [],
                            maxScore:item.question.score,
                            participantScore:item.score,
                            questionType:item.question.question_type.id,
                        });
                        this.$axios.get('lms/api/testquestionchoice?question[]=' + item
                            .question.question_id + '&flag_true[]=1')
                        .then(response => {
                            this.items[key].answer = response.data.data
                        }).catch(e => {
                            console.log(e);
                        });
                        this.$axios.get('lms/api/testquestionparticipantchoice?question[]=' + item
                            .question.question_id + '&relation_question[]=' + item.relation_question.relation_question_id + '&participant[]='
                            + item.participant.participant_id)
                        .then(response => {
                            this.items[key].participantAnswer = response.data.data
                        }).catch(e => {
                            console.log(e);
                        });
                    })                                                    
                }).catch(e => {
                    console.log(e);
                }); 
            },
            async getScore(){
               await this.$axios
                .get(
                    'lms/api/testresultheader?participant[]=' 
                    + this.batchParticipant.participant.participant_id +
                    '&relation_question[]='+ this.schedule_templateTest.relation_question_id)
                .then(response => {                   
                    this.totalMaxScore = response.data.data[0].maximmal_score;
                    this.totalParticipantScore = response.data.data[0].summary_score;                    
                    this.finalScore = response.data.data[0].final_score;                    
                }).catch(e => {
                    console.log(e);
                }); 
            },
            patchNilai() {
                this.$validator.validateAll('nilai').then(async result => {
                    if (!result) return;
                    this.$axios.put('lms/api/testresultdetail', {
                        object_identifier: this.oid,
                        score: this.scoreEsay,
                    
                        })
                        .then(response => {
                            this.getDetail();
                            this.getScore();
                            this.$bvModal.hide('modalEsay')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },                   
        },        
    }

</script>
