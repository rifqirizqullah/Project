<template>
    <div class="container page-section">

        <headerScheduleComponent/>

        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Template Questioner</h4>
                <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span>    
            </div>
            <div class="">
                <div class="text-right">
                    <div class="bg-white">
                        <!-- Elements to collapse -->
                        <b-collapse id="collapse-a" class="mt-2 p-4">
                            <form action="">
                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters1.template_code" class="form-control" name="TPLCD" id="TPLCD">
                                                <option
                                                    v-for="(item, index) in TPLCD.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Temp Qustioner</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters1.template_type" class="form-control" name="TPLTY" id="TPLTY">
                                                <option
                                                    v-for="(item, index) in TPLTY.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Type</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters1.relation_type" class="form-control" name="RQSTY" id="RQSTY">
                                                <option
                                                    v-for="(item, index) in RQSTY.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Object</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters1 = {}; clearFilter1()" variant="secondary" >Clear Filter</b-button>
                                            <b-button @click="runFilter1" variant="info" >
                                                <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                            </b-button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </b-collapse>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Template Questioner</th>
                            <th>Type</th>
                            <th>Object</th>
                            <th>Subject</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_templateQuestioner.list" :key="index">
                           <td> {{ index + 1 }} </td>
                            <td> {{ item.template_code.value }} </td>
                            <td> {{ item.template_type.value }} </td>
                            <td> {{ item.relation_type.value }} </td>
                            <td v-if="item.relation_type.id == 'ROOMS'"> {{ item.id.room_name }} </td>
                            <td v-if="item.relation_type.id == 'MATER'"> {{ item.id.materi_name }} </td>
                            <td v-if="item.relation_type.id == 'TRAINR'"> {{ item.id.trainer_name }} </td>
                            <td v-if="item.relation_type.id == 'EVENT'"> {{ item.id.event_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;">
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="schedule_templateQuestioner.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='schedule_templateQuestioner' :storeModuleName="'schedule_templateQuestioner'" />
            </div>
        </div>

        <div class="card shadow" v-if="type == 'event' && schedule.reference.schedule_id">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">Planned Template Questioner</h4>
                <span>
                <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span>    
            </div>
            <div class="">
                <div class="text-right">
                    <div class="bg-white">
                        <!-- Elements to collapse -->
                        <b-collapse id="collapse-b" class="mt-2 p-4">
                            <form action="">
                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters2.template_code" class="form-control" name="TPLCD" id="TPLCD">
                                                <option
                                                    v-for="(item, index) in TPLCD.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Temp Qustioner</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters2.template_type" class="form-control" name="TPLTY" id="TPLTY">
                                                <option
                                                    v-for="(item, index) in TPLTY.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Type</small>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters2.relation_type" class="form-control" name="RQSTY" id="RQSTY">
                                                <option
                                                    v-for="(item, index) in RQSTY.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Object</small>
                                        </div>
                                    </div>
                                    
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters2.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters2.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters2 = {}; clearFilter2()" variant="secondary" >Clear Filter</b-button>
                                            <b-button @click="runFilter2" variant="info" >
                                                <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                            </b-button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </b-collapse>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Template Questioner</th>
                            <th>Type</th>
                            <th>Object</th>
                            <th>Subject</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule_templateQuestioner.listReference" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.template_code.value }} </td>
                            <td> {{ item.template_type.value }} </td>
                            <td> {{ item.relation_type.value }} </td>
                            <td v-if="item.relation_type.id == 'ROOMS'"> {{ item.id.room_name }} </td>
                            <td v-if="item.relation_type.id == 'MATER'"> {{ item.id.materi_name }} </td>
                            <td v-if="item.relation_type.id == 'TRAINR'"> {{ item.id.trainer_name }} </td>
                            <td v-if="item.relation_type.id == 'EVENT'"> {{ item.id.event_name }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='ref')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="schedule_templateQuestioner.isLoadingR">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='schedule_templateQuestioner' :storeModuleName="'schedule_templateQuestioner'" />
            </div>
        </div>

        <div class="card shadow">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">All Template Questioner</h4>
                <span>
                <b-button type="button"  class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-c>
                <span class="btn-label"><i class="fa fa-search"></i>  Search</span>
                </b-button>
                </span>    
            </div>
            <div class="">
                <div class="text-right">
                    <div class="bg-white">
                        <!-- Elements to collapse -->
                        <b-collapse id="collapse-c" class="mt-2 p-4">
                            <form action="">
                                <div class="row">
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <select v-model="filters.template_code" class="form-control" name="TPLCD" id="TPLCD">
                                                <option
                                                    v-for="(item, index) in TPLCD.list"
                                                    :key="index"
                                                    :value="item.id"
                                                >{{item.value}}</option>
                                            </select>
                                            <small class="form-text text-muted">Temp Qustioner</small>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select start date" name="begin_date" id="begin_date"
                                            />
                                            <small class="form-text text-muted">Begin Date</small>
                                        </div>
                                    </div>

                                    <div class="col-sm-12 col-md-3">
                                        <div class="form-group">
                                            <flat-pickr
                                                v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                                                placeholder="Select end date" name="end_date" id="end_date"
                                            />
                                            <small class="form-text text-muted">End Date</small>
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-group text-right">
                                            <b-button @click="filters = {}; clearFilter()" variant="secondary" >Clear Filter</b-button>
                                            <b-button @click="runFilter" variant="info" >
                                                <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                            </b-button>
                                        </div>
                                    </div>

                                </div>
                            </form>
                        </b-collapse>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Template</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in TPLCD.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.value }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier,from='all')">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="TPLCD.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='TPLCD' :storeModuleName="'TPLCD'" />
            </div>
        </div>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        <b-modal id="modalAll" centered title="Add Schedule Questioner" size="md">
            <div class="form-group">
                <label for="object2">Template Type</label>
                <select
                    v-model="object2" class="form-control" name="object2" id="object2"
                    :class="{ 'is-danger': errors.has('collection.object2') }"
                    v-validate="'required'" data-vv-scope="collection"
                >
                    <option v-for="(item, index) in TPLTY.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.object2')" class="help is-danger">{{ errors.first('collection.object2') }}</p>
            </div>
            <div class="form-group">
                <label for="object1">Object</label>
                <select
                    v-model="object1" class="form-control" name="object1" id="object1"
                    :class="{ 'is-danger': errors.has('collection.object1') }"
                    v-validate="'required'" data-vv-scope="collection" @change="getObject()"
                >
                    <option v-for="(item, index) in RQSTY.list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.object1')" class="help is-danger">{{ errors.first('collection.object1') }}</p>
            </div>
            <div class="form-group" v-if="id_list.length > 0">
                <label for="id">Subject</label>
                <select
                    v-model="id" class="form-control" name="id" id="id"
                    :class="{ 'is-danger': errors.has('collection.id') }"
                    v-validate="'required'" data-vv-scope="collection" 
                >
                    <option v-for="(item, index) in id_list" :key="index" :value="item.id">{{item.value}}</option>
                </select>
                <p v-show="errors.has('collection.id')" class="help is-danger">{{ errors.first('collection.id') }}</p>
            </div>
            <div class="form-group">
                <label for="begin_date">Begin Date</label>
                <div class="form-inline">
                    <flat-pickr
                        v-model="begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                        v-validate="'required'" data-vv-scope="collection"
                    />
                    <button type="button" class="btn btn-info" @click="begin_date = new Date()">Today</button>
                    <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                </div>
            </div>

            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true, minDate: begin_date}" class="form-control"
                    placeholder="Select end date" name="end_date" id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'" data-vv-scope="collection"
                />
                <button type="button" class="btn btn-info" @click="end_date = '9999-12-31' ">Max</button>
                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalAll')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="addQuestioner">Save</button>
            </div>
        </b-modal>
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import paginationBarR from '@@/components/paginationBarR'
    import headerScheduleComponent from '@@/components/headerScheduleComponent'
    import { mapState, mapActions } from 'vuex'

    export default {
        layout: 'schedule-detail',
        components: {
            paginationBar,
            paginationBarR,
            headerScheduleComponent
        },
        middleware: ({ store, redirect }) => {
            if (!store.state.schedule.detail) return redirect('/event/event/')
        },
        created() {
            this.$store.dispatch('schedule_templateQuestioner/clearAll')
            this.$store.dispatch('schedule_templateQuestioner/getReference', {'schedule[]' : this.schedule.reference.schedule_id});
            this.$store.dispatch('schedule_templateQuestioner/getAll', {'schedule[]' : this.schedule.schedule_id});
            // this.$store.dispatch('TPLCD/getAll')
            // this.$store.dispatch('TPLTY/getAll')
            // this.$store.dispatch('RQSTY/getAll')
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,

                business_code: null,
                begin_date: null,
                end_date: null,
                object2 : null,
                object1 : null,
                id_list:[],
                id: null,
                filters : {
                    template_code: null,
                    begin_date: null,
                    end_date: null,
                    
                },
                filters1 : {
                    template_code: null,
                    template_type: null,
                    relation_type: null,
                    begin_date: null,
                    end_date: null,
                    
                },
                filters2 : {
                    template_code: null,
                    template_type: null,
                    relation_type: null,
                    begin_date: null,
                    end_date: null,
                    
                },
                type:this.$route.query.type
            }
        },
        computed: {
            schedule(){
                return this.$store.state.schedule.detail
            },
            event(){
                if (this.type == 'event') {
                    return this.$store.state.event.detail
                } else {
                    return this.$store.state.eventPlan.detail
                }
            },
            ...mapState(['schedule_templateQuestioner', 'TPLCD', 'TPLTY','RQSTY'])
        },
        methods: {
            getParam(){
                this.$store.dispatch('TPLCD/getAll');
                this.$store.dispatch('TPLTY/getAll');
                this.$store.dispatch('RQSTY/getAll');
            },
            
            ...mapActions({
                getDetail: 'schedule_templateQuestioner/getDetail',
                getDetailReference: 'schedule_templateQuestioner/getDetailReference',
                clearDetail: 'schedule_templateQuestioner/clearDetail',
                deleteOne: 'schedule_templateQuestioner/deleteOne',
                getDetailAll: 'TPLCD/getDetail',
                getAll: 'TPLCD/getAll',
                getAll1: 'schedule_templateQuestioner/getAll',
                getAll2: 'schedule_templateQuestioner/getReference',
            }),
            runFilter1() {
                let params1 = {'schedule[]' : this.schedule.schedule_id}
                if (this.filters1.template_code)
                    params1["template_code[]"] = this.filters1.template_code
                if (this.filters1.template_type)
                    params1["template_type[]"] = this.filters1.template_type
                
                if (this.filters1.relation_type)
                    params1["relation_type[]"] = this.filters1.relation_type
                
                if (this.filters1.begin_date)
                    params1["begin_date_lte"] = this.filters1.begin_date;
                if (this.filters1.end_date)
                    params1["end_date_gte"] = this.filters1.end_date;

                this.$router.push({ path : this.$route.path , query : params1})
                this.getAll1(params1)
            },
            clearFilter1(){
                this.filters1 = {
                    template_code: null,
                    template_type: null,
                    relation_type: null,
                    
                }
                let params1 = {'schedule[]' : this.schedule.schedule_id}
                this.getAll1(params1)
            },
            runFilter2() {
                let params2 = {'schedule[]' : this.schedule.reference.schedule_id}
                
                if (this.filters2.template_code)
                    params2["template_code[]"] = this.filters2.template_code
                if (this.filters2.template_type)
                    params2["template_type[]"] = this.filters2.template_type
                
                if (this.filters2.relation_type)
                    params2["relation_type[]"] = this.filters2.relation_type
                
                if (this.filters2.begin_date)
                    params2["begin_date_lte"] = this.filters2.begin_date;
                if (this.filters2.end_date)
                    params2["end_date_gte"] = this.filters2.end_date;

                this.$router.push({ path : this.$route.path , query : params2})
                
                this.getAll2(params2)
            },
            clearFilter2(){
                this.filters2 = {
                    template_code: null,
                    template_type: null,
                    relation_type: null,
                    
                }
                let params2 = {'schedule[]' : this.schedule.reference.schedule_id}
                
                this.getAll2(params2)
            },
            runFilter() {
                let params = {}
                
                if (this.filters.template_code)
                    params["short_text[]"] = this.filters.template_code
                
                if (this.filters.begin_date)
                    params["begin_date_lte"] = this.filters.begin_date;
                if (this.filters.end_date)
                    params["end_date_gte"] = this.filters.end_date;

                this.$router.push({ path : this.$route.path , query : params})
                
                this.getAll(params)
            },
            clearFilter(){
                this.filters = {
                    template_code: null,
                    
                }
                this.getAll()
            },
            async getObject(){
                if(this.object1 == 'TRAINR'){
                    await this.$axios.get('/lms/api/lmsrelation?begin_date_lte='+moment(new Date()).format("YYYY-MM-DD")+'&end_date_gte='+moment(new Date()).format("YYYY-MM-DD")
                    +'&otype_parent[]=SCHDL&otype_child[]=TRAINR&parent[]='+this.schedule.schedule_id)
                    .then(response => {
                        this.id_list = [];
                        response.data.data.forEach(async (item, key) => {
                            await this.id_list.push({
                                id: item.child.trainer_id,
                                value: item.child.trainer_name,                                                
                            });                            
                        })                                                       
                    }).catch(e => {
                        console.log(e);
                    });
                }else if(this.object1 == 'ROOMS'){
                    await this.$axios.get('/lms/api/lmsrelation?begin_date_lte='+moment(new Date()).format("YYYY-MM-DD")+'&end_date_gte='+moment(new Date()).format("YYYY-MM-DD")
                    +'&otype_parent[]=SCHDL&relation[]=S001&otype_child[]=ROOMS&parent[]='+this.schedule.schedule_id)
                    .then(response => {
                        this.id_list = [];
                        response.data.data.forEach(async (item, key) => {
                            await this.id_list.push({
                                id: item.child.room_id,
                                value: item.child.room_name,                                                
                            });                            
                        })                                                       
                    }).catch(e => {
                        console.log(e);
                    });
                }else if(this.object1 == 'EVENT'){
                        this.id_list = [];                        
                        await this.id_list.push({
                            id: this.event.event_id,
                            value: this.event.event_name,                                                
                        });                                                    
                }else{
                     await this.$axios.get('/lms/api/lmsrelation?begin_date_lte='+moment(new Date()).format("YYYY-MM-DD")+'&end_date_gte='+moment(new Date()).format("YYYY-MM-DD")
                     +'&otype_parent[]=SCHDL&relation[]=S003&otype_child[]=MATER&parent[]='+this.schedule.schedule_id)
                    .then(response => {
                        this.id_list = [];
                        response.data.data.forEach(async (item, key) => {
                            await this.id_list.push({
                                id: item.child.materi_id,
                                value: item.child.materi_name,                                                
                            });                            
                        })                                                       
                    }).catch(e => {
                        console.log(e);
                    });
                }
                
                 
                
            },
            addQuestioner() {
                this.$validator.validateAll('collection').then(async result => {
                    if (!result) return;
                        this.$axios.post('lms/api/relationquesioner', {
                            business_code: this.schedule.business_code.business_code,
                            begin_date: this.begin_date,
                            end_date: this.end_date,
                            // table_code : "SCHDL",
                            // relation : "S005",
                            // id : this.schedule.schedule_id,
                            // otype1 : "TPLCD",
                            // object1 : this.TPLCD.detail.id,
                            // otype2 : "TPLTY",
                            // object2 : this.object2,
          
                            template_code: this.TPLCD.detail.id,
                            template_type: this.object2,
                            schedule:  this.schedule.schedule_id,
                            relation_type:this.object1,
                            id:this.id
                        })
                        .then(() => {
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                            this.$store.dispatch('schedule_templateQuestioner/getAll', {'schedule[]' : this.schedule.schedule_id});
                            this.$bvModal.hide('modalAll')
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                })
            },
            async submit(object_identifier,from) {
                if (from == 'all') {
                    await this.getDetailAll(object_identifier)
                    this.end_date = null
                    this.begin_date = null
                    this.object2 = null
                    this.object1 = null
                    this.id = null
                    this.$validator.reset('collection')
                    this.$bvModal.show('modalAll')
                } else {
                    await this.getDetailReference(object_identifier)
                    this.begin_date = this.schedule_templateQuestioner.detail.begin_date
                    this.end_date = this.schedule_templateQuestioner.detail.end_date
                    if(this.schedule_templateQuestioner.detail.relation_type.id == 'ROOMS'){
                        this.id = this.schedule_templateQuestioner.detail.id.room_id
                    }else if(this.schedule_templateQuestioner.detail.relation_type.id =='MATER'){
                        this.id = this.schedule_templateQuestioner.detail.id.materi_id
                    }else if(this.schedule_templateQuestioner.detail.relation_type.id == 'TRAINR'){
                        this.id = this.schedule_templateQuestioner.detail.id.trainer_id
                    }else{
                        this.id = this.schedule_templateQuestioner.detail.id.event_id
                    }
                    this.$axios.post('lms/api/relationquesioner', {
                        business_code: this.schedule.business_code.business_code,
                        begin_date: this.begin_date,
                        end_date: this.end_date,
                        // table_code : "SCHDL",
                        // relation : "S005",
                        // id : this.schedule.schedule_id,
                        // otype1 : "TPLCD",
                        // object1 : this.schedule_templateQuestioner.detail.object1.id,
                        // otype2 : "TPLTY",
                        // object2 : this.schedule_templateQuestioner.detail.object2.id,
                        template_code: this.schedule_templateQuestioner.detail.template_code.id,
                        template_type: this.schedule_templateQuestioner.detail.template_type.id,
                        schedule:  this.schedule.schedule_id,
                        relation_type: this.schedule_templateQuestioner.detail.relation_type.id,
                        id: this.id
                    })
                    .then(() => {
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                        this.$store.dispatch('schedule_templateQuestioner/getAll', {'schedule[]' : this.schedule.schedule_id});
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
                }

            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.schedule_templateQuestioner.detail.begin_date
                this.end_date = this.schedule_templateQuestioner.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/relationquesioner?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/relationquesioner', {}, {
                            params: {
                                object_identifier: this.schedule_templateQuestioner.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('schedule_templateQuestioner/getAll', {'schedule[]' : this.schedule.schedule_id});
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
