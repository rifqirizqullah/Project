<template>
    <div class="container page-section">
        <div class="container">
            <headerEventComponent />
        </div>
        <div class="container">
            <headerBatchComponent />
            <headerSessionComponent/>
            <headerScheduleComponent/>
        </div>        
        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">{{schedule_templateTest.test_code.value}} - {{schedule_templateTest.relation_question_id}}</h4>
            </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>NIK</th>
                            <th>Name</th>
                            <th>Company</th>
                            <th>Type</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Score</th>
                            <th>Act</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in batchParticipant.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td> {{ item.participant.participant_id }} </td>
                            <td> {{ item.participant.complete_name }} </td>
                            <td> {{ item.participant.business_code.company_name }} </td>
                            <td> {{ item.participant.participant_type.value }} </td>
                            <td> {{ formatDate(item.begin_date) }} </td>
                            <td> {{ formatDate(item.end_date) }} </td>
                            <td> {{ item.participant.participant_type.value }} </td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="generate_nilai(item.object_identifier)">
                                    Detail
                                </button>
                            </td>
                        </tr>
                        <tr v-if="batchParticipant.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBar :state='batchParticipant' :storeModuleName="'batchParticipant'" />
            </div>
        </div>       
    </div>
</template>

<script>
    import moment from 'moment'
    import paginationBar from '@@/components/paginationBar'
    import headerEventComponent from '@@/components/headerEventComponent'
    import headerBatchComponent from '@@/components/headerBatchComponent'
    import headerSessionComponent from '@@/components/headerSessionComponent'
    import headerScheduleComponent from '@@/components/headerScheduleComponent'
    import {
        mapState,
        mapActions
    } from 'vuex'

    export default {
        layout: 'batch',
        components: {
            paginationBar,
            headerEventComponent,
            headerBatchComponent,
            headerSessionComponent, 
            headerScheduleComponent
        },
        middleware({
            store,
            redirect,
            route
        }) {            
            if (!store.state.schedule_templateTest.detail) redirect('/event/event')                        
        },
        fetch({store,params}) {
            store.dispatch('batchParticipant/clearAll');
            store.dispatch('batchParticipant/getAll');                        
        },
        data() {
            return {                
                type:this.$route.query.type,                
            }
        },
        computed: {
            schedule_templateTest(){
                return this.$store.state.schedule_templateTest.detail
            },
            ...mapState(['batchParticipant'])
        },
        methods: {
            ...mapActions({
                getDetail: 'batchParticipant/getDetail',
            }),    
            formatDate(date) {
                return moment(date).format('DD MMM YYYY')
            },

            async generate_nilai(oid){
                await this.getDetail(oid)                
                this.$axios.post('lms/api/testresultheader', {
                    relation_question: this.schedule_templateTest.relation_question_id,
	                participant: this.batchParticipant.detail.participant.participant_id,
                    business_code: this.schedule_templateTest.business_code.business_code,
                    begin_date: this.schedule_templateTest.begin_date,
                    end_date: this.schedule_templateTest.end_date,
                })
                .then(() => {
                    this.$router.push('/event/batch/detail/schedule/detail/hasil-test?type='+this.type)                  
                })
                .catch(err => {
                    console.log(err.response);
                })
                    
            }        
        },

    }

</script>
