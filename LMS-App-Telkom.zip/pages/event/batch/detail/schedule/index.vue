<template>
    <div>
        <div class="container">
            <headerEventComponent/>
        </div>
        <div class="container">
            <headerBatchComponent/>
        </div>
        <div class="container">
            <headerSessionComponent/>
        </div>
        <div class="container page-section pt-0">

            <span class="d-flex justify-content-between align-items-center">
                <h2 class="m-3"> <i class="material-icons text-info">access_time</i> Schedule</h2>
                <span>
                    <button @click="clearDetail(); $bvModal.show('scheduleForm')" class="btn btn-success btn-sm">+ Create Schedule</button>
                    <button v-if="type == 'event' && session.reference.session_id"  @click="clearDetail(); $bvModal.show('scheduleFormReference')" class="btn btn-sm btn-success">+ Add Planned Schedule</button>
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
                    <i class="fa fa-search"></i> Search         
                    </b-button> 
                </span>
            </span>
    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">

               <div class="col-sm-12 col-md-3">
                <label for="schedule_date">Schedule Date</label>
                <div class="form-group">
                    <flat-pickr
                        v-model="filters.schedule_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                        placeholder="Schedule" name="schedule_date" id="schedule_date"
                    />
                    <!-- <button type="button" class="btn btn-info" @click="schedule_date = new Date() ">Today</button> -->
                    <small class="form-text text-muted">Schedule Date</small>
                </div>
            </div>

            <div class="form-group">
                <label for="schedule_name">Title</label>
                <input
                    v-model="filters.schedule_name" type="text" class="form-control" name="schedule_name" id="schedule_name" placeholder="Schedule Name ..."
                />
                <small class="form-text text-muted">Title</small>
            </div>

            <div class="col-sm-12 col-md-3">
            <div class="form-group">
                <label for="topic">Topic</label>
                <input
                    v-model="filters.topic" type="text" class="form-control" name="topic" id="topic" placeholder="Topic ..."
                />
                 <small class="form-text text-muted">Topic</small>
            </div>
            </div>

            <div class="col-sm-12 col-md-3">
                <label for="schedule_date">Begin Date</label>
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

            <div class="col-sm-12 col-md-3">
                <label for="schedule_date">End Date</label>
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>
            
            <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>   

                <table class="table table-responsive table-flush table-hover">
                    <thead class="">
                        <tr class="">
                            <th>Day Num</th>
                            <th>Schedule Date</th>
                            <th>Time</th>
                            <th>Title</th>
                            <th>Topic</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in schedule.list" :key="index">
                            <td> {{ item.day_number }} </td>
                            <td> {{ formatDay(item.schedle_date) }} </td>
                            <td> {{ item.begin_time }} - {{ item.end_time }} </td>
                            <td @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/schedule/detail?type='+type)" style="cursor:pointer;">
                               <strong>{{ item.schedule_name }}</strong>
                            </td>
                            <td> {{ item.topic }} </td>
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                        <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                        <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/schedule/detail?type='+type)">Detail</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="schedule.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
                <div class="card-footer">
                    <paginationBar :state='schedule' :storeModuleName="'schedule'" />
                </div>
            </div>

            <b-modal v-model="modalShow" ref="scheduleForm" hide-footer hide-header id="scheduleForm" size="lg">
                <scheduleForm v-if="modalShow" />
            </b-modal>

            <b-modal v-model="modalReferenceShow" ref="scheduleFormReference" hide-footer title="Add Planned Schedule" id="scheduleFormReference" size="lg">
                <scheduleFormReference v-if="modalReferenceShow" />
            </b-modal>

            <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

        </div>

    
</template>

<script>
import moment from 'moment'
import scheduleForm from '@@/components/forms/scheduleForm'
import scheduleFormReference from '@@/components/forms/scheduleFormReference'
import paginationBar from '@@/components/paginationBar'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'schedule',
    components : { scheduleForm, paginationBar, headerEventComponent, headerBatchComponent, scheduleFormReference, headerSessionComponent },
    // middleware: ({ store, redirect }) => {
    //     if (!store.state.event.detail.event_id && !store.state.eventPlan.detail.event_id) return redirect('/event/event')
    // },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            modalReferenceShow : false,

            begin_date : null,
            end_date : null,
            
            type : this.$route.query.type,
            filters: {
                 begin_date: null,
                 end_date: null,
                 schedule_name: null,
                 topic: null,
                 schedule_date: null,
            }
        };
    },
    created() {
        this.$store.dispatch('schedule/getAll');
        // this.$store.dispatch('schedule/getReference');
        // this.business_code = this.session.business_code.business_code
    },
    computed: {
        ...mapState({
            session : state => state.session.detail,
            schedule : state => state.schedule,
        }),
    },
    methods: {
        getParam(){
        this.$store.dispatch("schedule/getAll");

        },
        ...mapActions({
            getDetail: 'schedule/getDetail',
            clearDetail: 'schedule/clearDetail',
            deleteOne: 'schedule/deleteOne',
            getAll: 'schedule/getAll'
        }),
        runFilter() {
        let params = {};
         if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
         if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;
         if (this.filters.schedule_date)
            params["schedule_date"] = this.filters.schedule_date;
         if (this.filters.schedule_name)
            params["schedule_name[]"] = this.filters.schedule_name
         if (this.filters.topic)
            params["topic[]"] = this.filters.topic
            
            this.$router.push({ path : this.$route.path , query : params})

            this.getAll(params);
        },
        clearFilters() {
            this.filters = {
                schedule_date : null,
                schedule_name : null,
                topic : null,
                begin_date: null,
                 end_date: null
            };
        },
        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('scheduleForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.schedule.detail.begin_date
            this.end_date = this.schedule.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/schedule?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/schedule', {}, {
                    params : {
                        object_identifier : this.schedule.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('schedule/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>
