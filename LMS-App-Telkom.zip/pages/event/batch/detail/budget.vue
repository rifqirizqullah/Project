<template>
    <div class="container page-section">
        <div class="container">
            <headerEventComponent />
        </div>
        <div class="container">
            <headerBatchComponent />
        </div>
        
        <div class="card shadow">
            <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title">Batch Budget</h4>
                <div class="float-right">
                    <button @click="clearDetail(); $bvModal.show('budgetForm')" class="btn btn-success btn-sm">+Create Batch Budget</button>
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                        <span class="btn-label"><i class="fa fa-search"></i> Search</span>
                    </b-button>
                </div>
            </div>

        <div class="card-body">
        <div class="">
        <div class=" text-right">
            <div>
                <b-collapse id="collapse-a" class="mt-2">
                    <form class="p-2">
                    <div class="row">
                                            
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters.wage_type"
                      class="form-control"
                      name="costItem"
                      id="costItem"
                    >
                      <option
                        v-for="(wage, index) in wage.list"
                        :key="index"
                        :value="wage.wage_type"
                      >{{wage.wage_name}}</option>
                     </select>
                    <small class="form-text text-muted">Cost item</small>
                  </div>
                </div>
                          
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters.price"
                        type="text"
                        class="form-control"
                        id="unitPrice"
                        placeholder="unitPrice"
                        >
                        <small class="form-text text-muted">Unit Price</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-3"> 
                    <div class="form-group">
                        <input
                        v-model="filters.quantity"
                        type="text"
                        class="form-control"
                        id="quantity"
                        placeholder="quantity"
                        >
                        <small class="form-text text-muted">Quantity</small>
                    </div>
                </div>


                 <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; clearFilters()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                    </div>
            <div class="table  table-responsive"  data-toggle="lists" data-lists-values='["name"]'>
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Cost Item</th>
                            <th>Unit Price</th>
                            <th>Quantity</th>
                            <th>Subtotal Price</th>
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in batchBudget.list" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td>{{ item.wage_type.wage_name }}</td>
                            <td>{{ numberFormat(item.price) }}</td>
                            <td>{{ item.quantity }}</td>
                            <td>{{ numberFormat(item.price * item.quantity) }}</td>
                            <td>{{ moment(item.begin_date) }}</td>
                            <td>{{ moment(item.end_date) }}</td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                        style="padding:6px;"></button>
                                    <div class="dropdown-menu" aria-labelledby="triggerId">
                                        <button class="dropdown-item"
                                            @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item"
                                            @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item"
                                            @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="batchBudget.isLoading">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
                <div class="col-6">
                    <div class="bg-secondary text-white " role="alert">
                        <a class="btn text-right">
                            <span class="">Total Budget : Rp. {{ numberFormat(totalBudget) }}</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <paginationBar :state='batchBudget' :storeModuleName="'batchBudget'" />
            </div>
        </div>

        <div class="card shadow" v-if="type == 'event' && batch.reference.batch_id">
            <div class="card-header bg-warning d-flex justify-content-between">
                <h4 class="card-title">Planned Batch Budget</h4>
                <span>
                <button @click="clearDetail(); $bvModal.show('budgetForm')" class="btn btn-success btn-sm">+Create Batch Budget</button>
                    <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-b>
                        <span class="btn-label"><i class="fa fa-search"></i> Search</span>
                    </b-button>
                </span>
            </div>
            <div class="card-body">
       <div class="">
        <div class=" text-right">
            <div>
                <b-collapse id="collapse-b" class="mt-2">
                    <form class="p-2">
                    <div class="row">
                                            
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select
                      v-model="filters1.wage_type"
                      class="form-control"
                      name="costItem"
                      id="costItem"
                    >
                      <option
                        v-for="(wage, index) in wage.list"
                        :key="index"
                        :value="wage.wage_type"
                      >{{wage.wage_name}}</option>
                     </select>
                    <small class="form-text text-muted">Cost item</small>
                  </div>
                </div>
                          
                <div class="col-sm-12 col-md-3">
                    <div class="form-group">
                        <input
                        v-model="filters1.price"
                        type="text"
                        class="form-control"
                        id="unitPrice"
                        placeholder="unitPrice"
                        >
                        <small class="form-text text-muted">Unit Price</small>
                    </div>
                </div>  

                <div class="col-sm-12 col-md-3"> 
                    <div class="form-group">
                        <input
                        v-model="filters1.quantity"
                        type="text"
                        class="form-control"
                        id="quantity"
                        placeholder="quantity"
                        >
                        <small class="form-text text-muted">Quantity</small>
                    </div>
                </div>

                <div class="col-sm-12 col-md-3"> 
                    <div class="form-group">
                        <input
                        v-model="filters1.subtotal"
                        type="text"
                        class="form-control"
                        id="subtotal"
                        placeholder="subtotal"
                        >
                        <small class="form-text text-muted">Subtotal</small>
                    </div>
                </div>

                 <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select start date" name="begin_date" id="begin_date"
                    />
                    <small class="form-text text-muted">Begin Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <flat-pickr
                        v-model="filters1.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                        placeholder="Select end date" name="end_date" id="end_date"
                    />
                    <small class="form-text text-muted">End Date</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters1 = {}; clearFilters1()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter1" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                    </div>
            <div class="card-body">
                <table class="table table-flush table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Cost Item</th>
                            <th>Unit Price</th>
                            <th>Quantity</th>
                            <th>Subtotal Price</th>
                            <th>Begin Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in batchBudget.listReference" :key="index">
                            <td> {{ index + 1 }} </td>
                            <td>{{ item.wage_type.wage_name }}</td>
                            <td>{{ numberFormat(item.price) }}</td>
                            <td>{{ item.quantity }}</td>
                            <td>{{ numberFormat(item.price * item.quantity) }}</td>
                            <td>{{ moment(item.begin_date) }}</td>
                            <td>{{ moment(item.end_date) }}</td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" @click="submit(item.object_identifier)">
                                    + Submit
                                </button>
                            </td>
                        </tr>
                        <tr v-if="batchBudget.isLoadingR">
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <paginationBarR :state='batchBudget' :storeModuleName="'batchBudget'" />
            </div>
        </div>

        <b-modal v-model="modalShow" ref="budgetForm" hide-footer hide-header id="budgetForm" size="lg">
            <budgetForm v-if="modalShow" />
        </b-modal>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>
     </div>
</div>
</template>


<script>
    import moment from 'moment'
    import budgetForm from '@@/components/forms/budgetForm'
    // import budgetFormReference from '@@/components/forms/budgetFormReference'
    import paginationBar from '@@/components/paginationBar'
    import paginationBarR from '@@/components/paginationBarR'
    import headerEventComponent from '@@/components/headerEventComponent'
    import headerBatchComponent from '@@/components/headerBatchComponent'
    import {
        mapState,
        mapActions
    } from 'vuex'

    export default {
        layout: 'batch',
        components: {
            budgetForm,
            //budgetFormReference,
            paginationBar,
            paginationBarR,
            headerEventComponent,
            headerBatchComponent,
        },

        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,
                price: null,
                quantity: null,
                wage_type: null,
                business_code: null,
                begin_date: null,
                end_date: null,
                type:this.$route.query.type,
                flatPickerConfig: {
                    altFormat: 'M	j, Y',
                    altInput: true,
                    dateFormat: 'Y-m-d',
               },
               filters: {                
                    wage_type: null,
                    price: null,
                    quantity: null,
                    subtotal: null,
                    begin_date: null,
                    end_date: null,
                },
                filters1: {                
                    wage_type: null,
                    price: null,
                    quantity: null,
                    subtotal: null,
                    begin_date: null,
                    end_date: null,
                },
            };
        },
        middleware: ({ store, redirect, route }) => {
            if (route.query.type == 'event') {
                if (!store.state.batch.detail) redirect('/event/event')
            } else {
                if (!store.state.batch.detail) redirect('/event/event-plan')
            }
        },
        fetch({store,params}) {
            store.dispatch('batchBudget/clearAll');
            store.dispatch('batchBudget/getAll');
            store.dispatch('batchBudget/getReference');
        },
        computed: {
            batch(){
                return this.$store.state.batch.detail
            },
            ...mapState({
                batchBudget : state => state.batchBudget,
                wage : state => state.wage,
            }),

            totalBudget() {
                return this.batchBudget.list.reduce((total, budget) => total + (budget.price * budget.quantity), 0);
            }
        },
        methods: {
            getParam(){
          
            this.$store.dispatch("wage/getAll");
            },

            numberFormat(value) {
                let val = (value / 1).toFixed(0)
                return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            },
            ...mapActions({
                getDetail: 'batchBudget/getDetail',
                getDetailReference: 'batchBudget/getDetailReference',
                clearDetail: 'batchBudget/clearDetail',
                deleteOne: 'batchBudget/deleteOne',
                getAll: 'batchBudget/getAll',
                getAll1: 'batchbudget/getReference',
            
            }),

            runFilter() {
        let params = {};
       
        if (this.filters.wage_type)
            params["wage_type"] = [this.filters.wage_type];
        if (this.filters.price)
            params["price"] = [this.filters.price];
        if (this.filters.quantity)
            params["quantity"] = [this.filters.quantity];        
        if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
        if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;
            this.$router.push({ path : this.$route.path , query : params})
            
            this.getAll(params);
        },
        clearFilters() {
            this.filters = {
                wage_type: null,
                price: null,
                quantity: null,
                subtotal: null,
                begin_date: null,
                end_date: null,
            };
            let params = {};
       
            this.getAll(params);
        },

        runFilter1() {
        let params1 = {};
       
        if (this.filters1.wage_type)
            params1["wage_type"] = [this.filters1.wage_type];
        if (this.filters.price)
            params1["price"] = [this.filters1.price];
        if (this.filters1.quantity)
            params["quantity"] = [this.filters1.quantity];
        if (this.filters1.begin_date)
            params["begin_date_lte"] = this.filters1.begin_date;
        if (this.filters1.end_date)
            params["end_date_gte"] = this.filters1.end_date;
            this.$router.push({ path : this.$route.path , query : params1})
            
            this.getAll1(params1);
        },
        clearFilters1() {
            this.filters1 = {
                wage_type: null,
                price: null,
                quantity: null,
                subtotal: null,
                begin_date: null,
                end_date: null,
            };
            let params = {};
       
            this.getAll1(params1);
        },



            showUpdateForm(object_identifier) {
                this.getDetail(object_identifier)
                this.$bvModal.show('budgetForm')
            },
            async submit(object_identifier) {
                await this.getDetailReference(object_identifier)
                this.price = this.batchBudget.detail.price
                this.quantity = this.batchBudget.detail.quantity
                this.wage_type = this.batchBudget.detail.wage_type.wage_type
                this.business_code = this.batchBudget.detail.business_code.business_code
                this.begin_date = this.batchBudget.detail.begin_date
                this.end_date = this.batchBudget.detail.end_date

                this.$axios.post('lms/api/batchbudget', {
                    batch: this.batch.batch_id,
                    price: this.price,
                    quantity: this.quantity,
                    wage_type: this.wage_type,
                    business_code: this.business_code,
                    begin_date: this.begin_date,
                    end_date: this.end_date,
                })
                .then(() => {
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                    this.$store.dispatch('batchBudget/getAll');
                })
                .catch(err => {
                    console.log(err.response);
                })
            },

            async showDelimitForm(object_identifier) {
                await this.getDetail(object_identifier)
                this.begin_date = this.batchBudget.detail.begin_date
                this.end_date = this.batchBudget.detail.end_date
                this.$bvModal.show('modalDelimit')
            },

            deleteData(id, index) {
                this.$swal({
                        title: 'Are you sure?',
                        text: "You won't be able to revert this!",
                        type: 'warning',
                        showCancelButton: true,
                    })
                    .then((result) => {
                        if (result.value) {
                            this.$axios.delete('lms/api/batchbudget?object_identifier=' + id)
                                .then(response => {
                                    return this.$swal('Deleted!', response.data.message, 'success')
                                })
                                .then((result) => {
                                    this.deleteOne(index)
                                })
                                .catch(e => {
                                    console.log(e.response);
                                })
                        }
                    });
            },

            delimitData() {
                this.$validator.validateAll('delimit').then(async result => {
                    if (!result) return;
                    this.$axios.patch('lms/api/batchbudget', {}, {
                            params: {
                                object_identifier: this.batchBudget.detail.object_identifier,
                                end_date: this.end_date,
                            }
                        })
                        .then(response => {
                            this.$store.dispatch('batchBudget/getAll');
                            this.$bvModal.hide('modalDelimit')
                            this.$swal(
                                'Saved!',
                                'Successfully saved data.',
                                'success'
                            )
                        })
                        .catch(e => {
                            console.log(e.response);
                        });
                });
            },
            moment(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

    }

</script>
