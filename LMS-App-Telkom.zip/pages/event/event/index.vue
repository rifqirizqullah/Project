<template>
    <div class="container page-section">
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">On Going Events</h4>
                            <p class="card-subtitle text-light">happening now</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of ongoing Event <span class="badge badge-pill badge-success badge-lg ml-3">{{Ongoing && Ongoing.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '01'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Upcoming Events</h4>
                            <p class="card-subtitle text-light">Upcoming</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Upcoming Event <span class="badge badge-pill badge-accent badge-lg ml-3">{{Upcoming && Upcoming.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '02'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Events Complete</h4>
                            <p class="card-subtitle text-light">Completed event</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Event Complete <span class="badge badge-pill badge-secondary badge-lg ml-3">{{Done && Done.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '03'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
          <div class="card-header bg-light d-flex justify-content-between align-items-center">
              <div class="flex">
                  <p class="card-title" style="font-size:25px;color:black">Manage Event</p>
                  <p style="font-size:15px;margin-top:-15px">List of Available Event</p>
              </div>
              <button @click="clearDetail(); $bvModal.show('eventForm')" class="btn btn-success btn-sm">
                + Create Event
              </button> 
              <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>  
              <i class="fa fa-search"></i> Search         
              </b-button> 
          </div>         
        <div class>
      <div class>
        <div class>
          <div class="text-right">
            <div class="bg-white">
              <b-collapse id="collapse-a" class="mt-2">
                <form class="p-2">
                  <div class="row">
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select v-model="filters.company" class="form-control" name="company" id="company">
                          <option
                            v-for="(item, index) in company.list"
                            :key="index"
                            :value="item.business_code"
                          >{{item.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Company</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <input
                          v-model="filters.event_name"
                          type="text"
                          class="form-control"
                          id="event_name"
                          placeholder="Event Name"
                        >
                        <small class="form-text text-muted">Event Name</small>
                      </div>
                    </div>
                    
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select
                          v-model="filters.event_type"
                          class="form-control"
                          name="event_type"
                          id="event_type"
                        >
                          <option
                            v-for="(item, index) in EVNTY.list"
                            :key="index"
                            :value="item.id"
                          >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Type</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select
                          v-model="filters.organization_code"
                          class="form-control"
                          name="organization_code"
                          id="organization_code"
                        >
                          <option
                            v-for="(item, index) in organizationData.list"
                            :key="index"
                            :value="item.organization_code"
                          >{{item.organization_name}}</option>
                        </select>
                        <small class="form-text text-muted">Unit</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select
                          v-model="filters.event_status"
                          class="form-control"
                          name="event_status"
                          id="event_status"
                        >
                          <option
                            v-for="(item, index) in LEVST.list"
                            :key="index"
                            :value="item.id"
                          >{{item.value}}</option>
                        </select>
                        <small class="form-text text-muted">Status</small>
                      </div>
                    </div>
                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <select
                          v-model="filters.vendor"
                          class="form-control"
                          name="vendor"
                          id="vendor"
                        >
                          <option
                            v-for="(item, index) in companyRelation.list"
                            :key="index"
                            :value="item.child_company.business_code"
                          >{{item.child_company.company_name}}</option>
                        </select>
                        <small class="form-text text-muted">Vendor</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.begin_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select start date" name="begin_date" id="begin_date"
                        />
                        <small class="form-text text-muted">Begin Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group">
                        <flat-pickr
                            v-model="filters.end_date" :config="{allowInput: true, altFormat : 'Y-m-d', altInput: true }" class="form-control"
                            placeholder="Select end date" name="end_date" id="end_date"
                        />
                        <small class="form-text text-muted">End Date</small>
                      </div>
                    </div>

                    <div class="col-sm-12 col-md-3">
                      <div class="form-group text-right">
                        <b-button
                          @click="filters = {}; runFilter()"
                          variant="secondary"
                        >Clear Filter</b-button>

                        <b-button @click="runFilter" variant="info">
                          <span class="btn-label">
                            <i class="fa fa-search"></i> Filter
                          </span>
                        </b-button>
                      </div>
                    </div>
                  </div>
                </form>
              </b-collapse>
            </div>
          </div>
        </div>

            <div class="" style="">
                <table class="table table-flush table-responsive  table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Company</th>
                        <th>Event Name</th>
                        <th>Type</th>
                        <th>Unit</th>
                        <th>Status</th>
                        <th>Vendor</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in event.list" :key="index">
                        <td> {{ index+1 }} </td>
                        <td> {{ item.business_code.company_name }} </td>
                        <td  @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')" style="cursor:pointer;">
                            <b> <i v-if="item.reference.event_id" class="material-icons text-warning">bookmark</i> {{ item.event_name }}</b>
                        </td>
                        <td> {{ item.event_type.value }} </td>
                        <td> {{item.organization.organization_name}}</td>
                        <td v-bind:class="{
                            'text-success': item.event_status.value == 'Ongoing',
                            'text-accent': item.event_status.value == 'Upcoming',
                            'text-secondary': item.event_status.value == 'Completed',
                            }" >
                            <b>{{ item.event_status.value }}</b>
                        </td>
                        <td> {{ item.vendor.company_name }} </td>
                        <td> {{formatDate(item.begin_date)}} </td>
                        <td> {{formatDate(item.end_date)}} </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                <div class="dropdown-menu dropdown-menu-right" >
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')">Detail</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="event.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            </div>
             <div class="card-footer">
                <paginationBar :state='event' :storeModuleName="'event'" />
            </div>

        </div>
        </div>
    </div>

        <b-modal v-model="modalShow" ref="eventForm" hide-footer hide-header id="eventForm" size="lg">
            <eventForm v-if="modalShow" />
        </b-modal>

        <b-modal
        v-model="modalDelimitShow"
        id="modalDelimit"
        centered
        title="Delimit Data"
        header-bg-variant="light"
        size="sm"
        >
        <div class="col-12">
            <div class="form-group">
            <label for="begin_date">Start Date</label>
            <div class="form-control">
                <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
            </div>
            </div>
        </div>
        <hr>
        <div class="col-12">
            <div v-show="begin_date" class="form-group">
            <label for="end_date">End Date</label>
            <flat-pickr
                v-model="end_date"
                :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                class="form-control"
                placeholder="Select end date"
                name="end_date"
                id="end_date"
                v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                v-validate="'required'"
                data-vv-scope="collection"
            />
            <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
            <p
                v-show="errors.has('collection.end_date')"
                class="help is-danger"
            >{{ errors.first('collection.end_date') }}</p>
            </div>
        </div>
        <div slot="modal-footer">
            <button
            type="button"
            class="btn btn-secondary"
            @click="$bvModal.hide('modalDelimit')"
            >Cancel</button>
            <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
        </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import eventForm from '@@/components/forms/eventForm'
import paginationBar from '@@/components/paginationBar'
import {mapState, mapActions} from 'vuex'
export default {
    layout : 'event',
    components : { eventForm, paginationBar },
    fetch ({ store, params }) {
        store.dispatch('event/getAll');
        store.dispatch('event/getAllStatus');
    },
    created() {  
    
  },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            
            begin_date:null,
            end_date: null,
            
            page_number: null,
            filters : {
                company: null,
                organization_code: null,
                begin_date: null,
                end_date: null,
                event_name: null,
                event_status: null,
                event_type:null,
                vendor: null,
            },
           
        }
    },
    computed: {
       ...mapState({
            event : state => state.event,
            Ongoing : state => state.event.Ongoing,
            Upcoming : state => state.event.Upcoming,
            Done : state => state.event.Done,
            organizationData : state => state.organizationData,
            EVNTY : state => state.EVNTY,
            LEVST : state => state.LEVST,
            companyRelation : state => state.companyRelation,
            company : state => state.company,
        }),    
        },

    methods: {
        getParam(){
      this.$store.dispatch("company/getAll");
      this.$store.dispatch("organizationData/getAll");
      this.$store.dispatch("EVNTY/getAll");
      this.$store.dispatch("LEVST/getAll");
      this.$store.dispatch('companyRelation/getAll');
      
      
    },
        ...mapActions({
            getDetail: 'event/getDetail',
            clearDetail: 'event/clearDetail',
            deleteOne: 'event/deleteOne',
            getAll: 'event/getAll',
        }),
        runFilter(){
            let params = {}
             if (this.filters.company)
            params["business_code"] = [this.filters.company];
             if (this.filters.event_name)
            params["event_name"] = [this.filters.event_name];
            if (this.filters.event_type)
            params["event_type"] = [this.filters.event_type];
            if (this.filters.organization_code)
            params["organization"] = [this.filters.organization_code];
            if (this.filters.vendor)
            params["vendor"] = [this.filters.vendor];
            if (this.filters.event_status)
            params["event_status"] = [this.filters.event_status];
           
           if (this.filters.begin_date)
            params["begin_date_lte"] = this.filters.begin_date;
            if (this.filters.end_date)
            params["end_date_gte"] = this.filters.end_date;

            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params)
        },
        clearFilters(){
            this.filters = {
                company: null,
                organization_code: null,
                begin_date: null,
                end_date: null,
                event_name: null,
                event_status: null,
                event_type:null,
                vendor: null,
            }
        },
        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('eventForm')
        },
        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.event.detail.begin_date
            // this.end_date = moment(new Date()).format("YYYY-MM-DD")
            this.end_date = this.event.detail.end_date
            this.$bvModal.show('modalDelimit')
        },
        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/event?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },
        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/event', {}, {
                    params : {
                        object_identifier : this.event.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('event/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>
<style scoped>
.dropdown-item:focus,
    .dropdown-item:hover {
        color: rgba(93, 86, 86, 0.9);
        text-decoration: none;
        background-color: #27202030;
    }
</style>

