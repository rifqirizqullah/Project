<template>
    <div>
        <ContentHeader
            headerTitle='Admin Trainer'
            headerDescription='To Manage All Event Trainer'
            headerSubDescription= 'Telkom Corporate University'
        />

        <div class="container page-section">
            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <span>
                        <h4 class="card-title">Trainer</h4>
                        <p class="card-subtitle">List of Approoved Trainer    </p>
                    </span>
                    <!-- <button @click="clearDetail(); $bvModal.show('eventForm')" class="btn btn-success btn-sm">+ Create Event</button> -->
                </div>

                <div class="" style="">
                    <table class="table table-flush table-responsive  table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Trainer Name</th>
                            <th>Phone Number</th>
                            <th>Trainer Status</th>
                            <th>Company</th>
                            <th>Event</th>
                            <th>Batch</th>
                            <th>Activity</th>
                            <th>Schedule</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr v-for="(item, index) in schedule_trainer_approoved.list" :key="index">
                             <td> {{ index+1 }} </td>
                            <td> {{ item.child.trainer_name }} </td>
                            <td> {{ item.business_code.phone }}</td>
                            <td> {{ item.child.trainer_status.value }}</td>
                            <td> {{ item.child.company.company_name}} </td>
                            <td> {{ item.parent.session && item.parent.session.batch.event.event_name}}</td>
                            <td> {{ item.parent.session && item.parent.session.batch.batch_name}}</td>
                            <td> {{ item.parent.session && item.parent.session.learning_activity.activity_name}}</td>
                            <td> {{ item.parent.schedule_name}}</td>
                            <td> {{ item.begin_date}}</td>
                            <td> {{ item.end_date}}</td>
                            <td v-bind:class="{
                                'text-success': item.parent.session && item.parent.session.batch.event.event_status == 'Completed'
                            }"
                                > {{ item.parent.session && item.parent.session.batch.event.event_status}}</td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                    <div class="dropdown-menu dropdown-menu-right" >
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                        <!-- <button class="dropdown-item" @click="approval(item.object_identifier)">Approve</button> -->
                                        <!-- <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                        <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')">Detail</button> -->
                                    </div>
                                </div>
                            </td>
                            <!-- <td  @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')" style="cursor:pointer;">
                                <b> <i v-if="item.reference.event_id" class="material-icons text-warning">bookmark</i> {{ item.event_name }}</b>
                            </td>
                            <td> {{ item.event_type.value }} </td>
                            <td> {{item.organization.organization_name}}</td>
                            <td v-bind:class="{
                                'text-success': item.event_status.value == 'Ongoing',
                                'text-accent': item.event_status.value == 'Upcoming',
                                'text-secondary': item.event_status.value == 'Completed',
                                }" >
                                <b>{{ item.event_status.value }}</b>
                            </td>
                            <td> {{ item.vendor.company_name }} </td>
                            <td> {{formatDate(item.begin_date)}} </td>
                            <td> {{formatDate(item.end_date)}} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                    <div class="dropdown-menu dropdown-menu-right" >
                                        <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                        <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')">Detail</button>
                                    </div>
                                </div>
                            </td> -->
                        </tr>
                     
                        
                        <tr v-if="event.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div>
                <div class="card-footer">
                    <paginationBar :state='schedule_trainer' :storeModuleName="'schedule_trainer'" />
                </div>
            </div>

            <!-- <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <span>
                        <h4 class="card-title">Event</h4>
                        <p class="card-subtitle">List of Event</p>
                    </span>
                    <button @click="clearDetail(); $bvModal.show('eventForm')" class="btn btn-success btn-sm">+ Create Event</button>
                </div>

                <div class="" style="">
                    <table class="table table-flush table-responsive  table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Company</th>
                            <th>Event Name</th>
                            <th>Type</th>
                            <th>Unit</th>
                            <th>Status</th>
                            <th>Vendor</th>
                            <th>Start</th>
                            <th>End</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in event.list" :key="index">
                            <td> {{ index+1 }} </td>
                            <td> {{ item.business_code.company_name }} </td>
                            <td  @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')" style="cursor:pointer;">
                                <b> <i v-if="item.reference.event_id" class="material-icons text-warning">bookmark</i> {{ item.event_name }}</b>
                            </td>
                            <td> {{ item.event_type.value }} </td>
                            <td> {{item.organization.organization_name}}</td>
                            <td v-bind:class="{
                                'text-success': item.event_status.value == 'Ongoing',
                                'text-accent': item.event_status.value == 'Upcoming',
                                'text-secondary': item.event_status.value == 'Completed',
                                }" >
                                <b>{{ item.event_status.value }}</b>
                            </td>
                            <td> {{ item.vendor.company_name }} </td>
                            <td> {{formatDate(item.begin_date)}} </td>
                            <td> {{formatDate(item.end_date)}} </td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                    <div class="dropdown-menu dropdown-menu-right" >
                                        <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                        <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')">Detail</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="event.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div>
                <div class="card-footer">
                    <paginationBar :state='event' :storeModuleName="'event'" />
                </div>
            </div> -->


            

            <!-- <b-modal v-model="modalShow" ref="eventForm" hide-footer hide-header id="eventForm" size="lg">
                <eventForm v-if="modalShow" />
            </b-modal> -->

            <b-modal
            v-model="modalDelimitShow"
            id="modalDelimit"
            centered
            title="Delimit Data"
            header-bg-variant="light"
            size="sm"
            >
            <div class="col-12">
                <div class="form-group">
                <label for="begin_date">Start Date</label>
                <div class="form-control">
                    <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
                </div>
                </div>
            </div>
            <hr>
            <div class="col-12">
                <div v-show="begin_date" class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr
                    v-model="end_date"
                    :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                    class="form-control"
                    placeholder="Select end date"
                    name="end_date"
                    id="end_date"
                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                    v-validate="'required'"
                    data-vv-scope="collection"
                />
                <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
                <p
                    v-show="errors.has('collection.end_date')"
                    class="help is-danger"
                >{{ errors.first('collection.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button
                type="button"
                class="btn btn-secondary"
                @click="$bvModal.hide('modalDelimit')"
                >Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
            </b-modal>
        </div>
    </div>
</template>

<script>
import Navbar from '@@/components/Navbar'
import Footer from '@@/components/Footer'
import ContentHeader from '@@/components/ContentHeader'

import moment from 'moment'
// import eventForm from '@@/components/forms/eventForm'
import paginationBar from '@@/components/paginationBar'
import {mapState, mapActions} from 'vuex'

export default {
    components: {
        Navbar,
        Footer,
        ContentHeader,
        // eventForm,
        paginationBar
    },
    async created()  {
        await this.$store.dispatch('schedule_trainer_approoved/getAll'); 
                   
    },
    fetch ({ store, params }) {
        store.dispatch('event/getAll');
        store.dispatch('event/getAllStatus');
        store.dispatch('trainer/getAll');
        store.dispatch('schedule_trainer_approoved/getAll');

    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            filters : {
                status : null,
            },
            begin_date:null,
            end_date: null,
        }
    },
    computed: {
        ...mapState({
            event : state => state.event,
            Ongoing : state => state.event.Ongoing,
            Upcoming : state => state.event.Upcoming,
            Done : state => state.event.Done,
            trainer : state => state.trainer,
            schedule_trainer_approoved : state => state.schedule_trainer_approoved,
            // PERNR : state => state.PERNR,
            // STTAR : state => state.STTAR,
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'schedule_trainer_approoved/getDetail',
            clearDetail: 'event/clearDetail',
            deleteOne: 'event/deleteOne',
            getAll: 'schedule_trainer_approoved/getAll',
        }),
        runFilter(){
            let params = {}
            if (this.filters.status)
                params["event_status[]"] = this.filters.status

            this.$router.push({ path : this.$route.path , query : params})
            this.getAll(params)
        },
        clearFilters(){
            this.filters = {
                status : null,
            }
        },
        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            // this.$bvModal.show('eventForm')
        },
        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.event.detail.begin_date
            // this.end_date = moment(new Date()).format("YYYY-MM-DD")
            this.end_date = this.event.detail.end_date
            this.$bvModal.show('modalDelimit')
        },
        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/event?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },
        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/event', {}, {
                    params : {
                        object_identifier : this.event.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('event/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>

<style>

</style>
