<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader
                headerTitle='Event Management'
                headerDescription='To manage all events that will be held.'
                headerSubDescription= 'Telkom Corporate University'
            />

            <div class="navbar navbar-expand-sm navbar-dark-white bg-gradient-primary p-sm-0 ">
                <div class="container page__container">

                    <!-- Navbar toggler -->
                    <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                        data-target="#navbar-submenu2">
                        <span class="material-icons">people_outline</span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbar-submenu2">
                        <div class="navbar-collapse__content pb-16pt pb-sm-0">
                            <ul class="nav navbar-nav">

                                <li class="nav-item">
                                    <nuxt-link to='/learning-plan/event/add-c3' class='nav-link'>Event</nuxt-link>
                                </li>
                                <li class="nav-item">
                                    <nuxt-link to='/learning-plan/event/add-c3-classroom' class='nav-link'>Classroom</nuxt-link>
                                </li>
                                <li class="nav-item">
                                    <nuxt-link to='/learning-plan/event/add-c3-budget' class='nav-link'>Budget</nuxt-link>
                                </li>
                                <li class="nav-item active">
                                    <nuxt-link to='/learning-plan/event/add-c3-expert' class='nav-link'>Expert</nuxt-link>
                                </li>
                                <li class="nav-item">
                                    <nuxt-link to='/learning-plan/event/add-c3-work' class='nav-link'>Work Order</nuxt-link>
                                </li>
                                <li class="nav-item">
                                    <nuxt-link to='/learning-plan/event/add-c3-delivery' class='nav-link'>Delivery</nuxt-link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="page-section bg-white border-bottom-2">
                <div class="container page__container">
                    <div class="container card">
                        <div class="card-header">
                            <span class="h2">Expert</span>
                        </div>
                        <div class="card-body">
                            <form action="" method="POST">
                                <div class="form-group">
                                    <div class="mb-heading d-flex align-items-end">
                                        <a class="btn btn-sm btn-primary float-right text-white m-2" data-toggle="modal" data-target="#myModalAddExpert">
                                            <i class="material-icons">add</i>&nbsp;Add
                                        </a>
                                    </div>
                                    <table class="table table-responsive">
                                        <thead>
                                            <th>Day</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Schedule Name</th>
                                            <th>Total JP</th>
                                            <th>Main Competency</th>
                                            <th>Action</th>
                                        </thead>
                                        <tbody>
                                            <tr v-for="(expert , index) in experts" :key="index">
                                                <td>
                                                    {{expert.day}}
                                                </td>
                                                <td>
                                                    {{expert.start}}
                                                </td>
                                                <td>
                                                    {{expert.end}}
                                                </td>
                                                <td>
                                                    {{expert.schedule}}
                                                </td>
                                                <td>
                                                    {{expert.total}}
                                                </td>
                                                <td>
                                                    {{expert.competency}}
                                                </td>
                                                <td>
                                                    <div class="nav-item dropdown d-none d-sm-flex">
                                                        <a href="#" data-toggle="dropdown" class="btn btn-sm btn-dark">
                                                            <i class="material-icons">settings</i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#">Edit</a>
                                                            <a class="dropdown-item"
                                                                onclick="return confirm('Are you sure you want to delete this?')"
                                                                href="#">Delete</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <input type="text" name="day" maxlength="255" class="textinput textInput form-control" placeholder="Day">
                                                </td>
                                                <td>
                                                    <input type="text" name="startTime" maxlength="255" class="textinput textInput form-control" placeholder="Start Time">
                                                </td>
                                                <td>
                                                    <input type="text" name="endTime" maxlength="255" class="textinput textInput form-control" placeholder="End Time">
                                                </td>
                                                <td>
                                                    <input type="text" name="scheduleName" maxlength="255" class="textinput textInput form-control" placeholder="Schedule Name">
                                                </td>
                                                <td>
                                                    <input type="text" name="totalJP" maxlength="255" class="textinput textInput form-control" placeholder="Total JP">
                                                </td>
                                                <td>
                                                    <select v-model="mainCompetency" class="form-control" name="mainCompetency" id="mainCompetency">
                                                        <option disabled value="">-</option>
                                                        <option v-for="(mainCompetencies, index) in mainCompetencies" :key="index">
                                                            {{mainCompetencies}}</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <div class="nav-item dropdown d-none d-sm-flex">
                                                        <a href="#" data-toggle="dropdown" class="btn btn-sm btn-dark">
                                                            <i class="material-icons">settings</i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#">Edit</a>
                                                            <a class="dropdown-item"
                                                                onclick="return confirm('Are you sure you want to delete this?')"
                                                                href="#">Delete</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </form>
                        </div>
                        <span class="h2">Remarks</span>
                        <textarea name="content" id="editor" class="container shadow mb-2" placeholder="Input your remarks here..">
                        </textarea>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Vue from 'vue'
import ContentHeader from '@@/components/ContentHeader'
// import flatPicker from "vue-flatpickr-component";
// import "flatpickr/dist/flatpickr.css";
// Vue.use(flatPicker);

export default {
    layout : 'home',

    components : {
        ContentHeader,
        // flatPicker,
    },
    data() {
        return {
            experts: [{
                day : '1',
                start : '08:00',
                end : '10:00',
                schedule : 'First Init',
                total : '2',
                competency : 'Git Base for Multi User Development',
            }],

            mainCompetencies : ['Git Base for Multi User Development','IT 4.0 For Better Generation of Human','Python is it Snake?'],

        }
    }
}
</script>
