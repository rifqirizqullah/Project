<template>

    <div class="container page-section">
        <!-- <b>
            <p style="font-size:20px">Expert Detail</p>
        </b> -->
        <div align="center">
  <b-card
    no-body
    style="max-width: 20rem;"
    img-src="https://placekitten.com/380/200"
    img-alt="Image"
    img-top
  >
    <h4 slot="header">642159 / LIDO H
    </h4>
    <button class="btn btn-sm btn-success" @click="$bvModal.show('')" >Edit Profile</button>

    <!-- <b-card-body>
      <b-card-title>Card Title</b-card-title>
      <b-card-sub-title class="mb-2">Card Sub Title</b-card-sub-title>
      <b-card-text>
        Some quick example text to build on the card title and make up the bulk of the card's
        content.
      </b-card-text>
    </b-card-body> -->
  </b-card>
</div>
        <div>
  <b-card-group>
    <b-card>
      <b-card-text>
         <div class="row p-2">
            <div class="col">
                <div class="row">
                <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>E-Mail</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Expert Type</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Date of Birth</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Major Competency</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Home Adress</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Level</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Instagram</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Blog</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Twitter</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Fee Rate Day</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Fee Rate Hour</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </b-card-text>
    </b-card>
    <b-card>
    <b-card-text>
         <div class="row p-2">
            <div class="col">
                <div class="row">
                <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Phone</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>User Status</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Religion</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Minor Competency</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Office Address</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Expert Group</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Youtube</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Facebook</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>LinkedIn</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>
                 <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-8">
                                <b>
                                    <p>Previous Learning Hour</p>
                                </b>
                            </div>
                            <div class="col-sm-4">
                                <p>: -</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
      </b-card-text>
    </b-card>

  
    </b-card-group>
    <!-- </div>
<div> -->
    <b-tabs content-class="mt-1" justified>
    <b-tab title="On Progress" active>
        <div class="card">
            <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr>
                    <th>No</th>
                    <th>Type</th>
                    <th>Activity</th>
                    <th>Title of Activities</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Status</th>
                    <th>Timeline</th>
                </tr>
            </thead>
            <tbody >
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                 <!-- <tr v-if=".isLoading" >
                    <td colspan="10">
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </td>
                </tr> -->

            </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='questioner' :storeModuleName="'questioner'" />
            </div>

        </div>
    </b-tab>
    <b-tab title="Formal">
                <div class="card">
            <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr>
                    <th>No</th>
                    <th>Education Level</th>
                    <th>Institution</th>
                    <th>Finished Study</th>
                </tr>
            </thead>
            <tbody >
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                 <!-- <tr v-if=".isLoading" >
                    <td colspan="10">
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </td>
                </tr> -->

            </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='questioner' :storeModuleName="'questioner'" />
            </div>

        </div>
    </b-tab>
    <b-tab title="Training">
            <div class="card">
            <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr>
                    <th>No</th>
                    <th>Training</th>
                    <th>Providers</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                </tr>
            </thead>
            <tbody >
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                 <!-- <tr v-if=".isLoading" >
                    <td colspan="10">
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </td>
                </tr> -->

            </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='questioner' :storeModuleName="'questioner'" />
            </div>

        </div>
    </b-tab>
    <b-tab title="Certification" >
                <div class="card">
            <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr>
                    <th>No</th>
                    <th>Certification Name</th>
                    <th>Certification Date</th>
                    <th>Point</th>
                </tr>
            </thead>
            <tbody >
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                 <!-- <tr v-if=".isLoading" >
                    <td colspan="10">
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </td>
                </tr> -->

            </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='questioner' :storeModuleName="'questioner'" />
            </div>

        </div>
    </b-tab>
    <b-tab title="Skill And Endorsment" >
                <div class="card">
            <table class="table table-hover table-flush table-responsive">
                <thead class="thead">
                <tr>
                    <th>No</th>
                    <th>Skill Name</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody >
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
                 <!-- <tr v-if=".isLoading" >
                    <td colspan="10">
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </td>
                </tr> -->

            </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='questioner' :storeModuleName="'questioner'" />
            </div>

        </div>
    </b-tab>
  </b-tabs>
</div>
    </div>

</template>
