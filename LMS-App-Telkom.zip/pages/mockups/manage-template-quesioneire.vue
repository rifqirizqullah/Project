<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <div class="page-section bg-gray">
                <div class="container page__container">
                     <div class="form-group">
                                <b-form-group label-cols-lg="2" label="Template Name:">
                                <b-form-input v-model="textTemplateName" placeholder="Enter Template Name"></b-form-input>
                                <!-- <div class="mt-2">Value: {{ textTemplateName }}</div> -->
                                </b-form-group>
                                <br>
                                <b-form-group label-cols-lg="2" label="Template Type:">
                                    <b-form-select  v-model="selected" class="mb-3">
                                        <template slot="first">
                                            <option :value="null" disabled>-- Please select an option --</option>
                                        </template>
                                    <option v-for="(item, index) in templateType" :key="index">{{item}}</option>
                                    </b-form-select>
                                </b-form-group>


                                </div>

                    <div class="card">
                        <div class="card-header bg-info">
                            <h4 class="card-title text-light">Quesioner Template</h4>
                            <div class="text-right">
                            </div>
                        </div>
                        <div class="card-body">
                             <table class="table border table-responsive">
                                <thead class="thead-light">
                                    <tr>
                                       <th>No</th>
                                        <th>Template Questioner</th>
                                        <th>Type</th>
                                        <th>Start</th>
                                        <th>End</th>
                                        <th>Act</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td>1</td>
                                    <td>Quesioner</td>
                                    <td>True False</td>
                                    <td></td>
                                    <td></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                                    <a class="dropdown-item" @click="editData()">Edit</a>
                                                    <a class="dropdown-item" @click="delimitData()">Delimit</a>
                                                    <a class="dropdown-item" @click="deleteData()">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer text-muted">
                            Footer
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header bg-info">
                            <h4 class="card-title text-light">Planned Template Questioner</h4>
                            <div class="text-right">
                            </div>
                        </div>
                        <div class="card-body">
                             <table class="table border table-responsive">
                                <thead class="thead-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Template Questioner</th>
                                        <th>Type</th>
                                        <th>Start</th>
                                        <th>End</th>
                                        <th>Act</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                                    <a class="dropdown-item" @click="editData()">Edit</a>
                                                    <a class="dropdown-item" @click="delimitData()">Delimit</a>
                                                    <a class="dropdown-item" @click="deleteData()">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer text-muted">
                            Footer
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header bg-info">
                            <h4 class="card-title text-light">All Template Questioner</h4>
                            <div class="text-right">
                            </div>
                        </div>
                        <div class="card-body">
                             <table class="table border table-responsive">
                                <thead class="thead-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Template</th>
                                        <th>Start</th>
                                        <th>End</th>
                                        <th>Act</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                                    <a class="dropdown-item" @click="editData()">Edit</a>
                                                    <a class="dropdown-item" @click="delimitData()">Delimit</a>
                                                    <a class="dropdown-item" @click="deleteData()">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer text-muted">
                            Footer
                        </div>
                    </div>


                    <div class="card">
                        <div class="card-header bg-info">
                            <h4 class="card-title text-light">Quesioner</h4>
                            <div class="text-right">
                                <button type="button" class="btn btn-success" @click="showModal">
                                    + Add Quesioner
                                </button>
                            </div>
                        </div>
                        
                        <div class="card-body">
              
                            <table class="table border table-responsive">
                                <thead class="thead-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Company</th>
                                        <th>Quesioner ID</th>
                                        <th>Quesioner Type</th> 
                                        <th>Quesioner Category </th>
                                        <th>Quesioner Purpose </th>
                                        <th>Quesioner Text </th>
                                        <th>Number of Choice </th>
                                        <th>Start</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in questionBank" :key="index">
                                        <td> {{ index + 1 }} </td>
                                        <td> {{ item.company }} </td>
                                        <td> {{ item.quesionerID }} </td>
                                        <td> {{ item.quesionerType }} </td>
                                        <td> {{ item.quesionerCategory }} </td>
                                        <td> {{ item.quesionerPurpose }} </td>
                                        <td> {{ item.quesionerText }} </td>
                                        <td> {{ item.numberOfChoice }} </td>
                                        <!-- <td> {{ item.start }} </td>
                                        <td> {{ item.end }} </td> -->
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                                    <a class="dropdown-item" @click="editData()">Edit</a>
                                                    <a class="dropdown-item" @click="delimitData()">Delimit</a>
                                                    <a class="dropdown-item" @click="deleteData()">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer text-muted">
                            Footer
                        </div>
                    </div>
                    
                           <div class="card">
                        <div class="card-header bg-info">
                            <h4 class="card-title text-light">Quesioner Choice</h4>
                            <div class="text-right">
                            </div>
                        </div>
                        <div class="card-body">

                            <table class="table border table-responsive">
                                <thead class="thead-light">
                                    <tr>
                                        <th>No</th>
                                        <th>Company</th>
                                        <th>Quesioner ID</th>
                                        <th>Sequence Number</th>
                                        <th>Text Choice </th>
                                        <th>Start</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(item, index) in questionChoice" :key="index">
                                        <td> {{ index + 1 }} </td>
                                        <td> {{ item.company }} </td>
                                        <td> {{ item.quesionerID }} </td>
                                        <td> {{ item.sequenceNumber }} </td>
                                        <td> {{ item.textChoice }} </td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                                    <a class="dropdown-item" @click="editData()">Edit</a>
                                                    <a class="dropdown-item" @click="delimitData()">Delimit</a>
                                                    <a class="dropdown-item" @click="deleteData()">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="card-footer text-muted">
                            Footer
                        </div>
                    </div>
                    <!-- Start Modal -->
                      <b-modal ref="my-modal" hide-footer size="lg" title="Add New Question">
                        <div class="modal-header">
                            <h5 class="modal-title">Add Quesioner</h5>
                            <button type="button" class="close" aria-label="Close" @click="closeFormModal">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                            <label for="request_type">Company</label>
                                <select
                                v-model="business_code" class="form-control" name="company" id="company"
                                :class="{ 'is-danger': errors.has('collection.company') }"
                                v-validate="'required'" data-vv-scope="collection" @change="getParam()"
                                >
                                    <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                                </select>
                                <p v-show="errors.has('collection.company')" class="help is-danger">{{ errors.first('collection.company') }}</p>
                            </div>
                            <div class="form-group">
                            <label for="quesioner_type">Quesioner Type</label>
                                <select v-model="quesioner_type" class="form-control" name="quesioner_type"
                                id="quesioner_type" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_type') }"
                                v-validate="'required'" data-vv-scope="collection">
                                <option v-for="(quesioner_type, index) in QSNTY.list" :key="index" :value="quesioner_type.id">
                                {{quesioner_type.value}}</option>
                                </select>
                                <p v-show="errors.has('collection.quesioner_type')" class="help is-danger">{{ errors.first('collection.quesioner_type') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="quesioner_category">Quesioner Category</label>
                                    <select v-model="quesioner_category" class="form-control" name="quesioner_category"
                                    id="quesioner_category" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_category') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <option v-for="(quesioner_category, index) in QSTCT.list" :key="index" :value="quesioner_category.id">
                                    {{quesioner_category.value}}</option>
                                    </select>
                                <p v-show="errors.has('collection.quesioner_category')" class="help is-danger">{{ errors.first('collection.quesioner_category') }}</p>
                            </div>

                            <div class="form-group">
                                <label for="quesioner_purpose">Quesioner Purpose</label>
                                    <select v-model="quesioner_purpose" class="form-control" name="quesioner_purpose"
                                    id="quesioner_purpose" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_purpose') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <option v-for="(quesioner_purpose, index) in QSTPR.list" :key="index" :value="quesioner_purpose.id">
                                    {{quesioner_purpose.value}}</option>
                                    </select>
                                <p v-show="errors.has('collection.quesioner_purpose')" class="help is-danger">{{ errors.first('collection.quesioner_purpose') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="quesioner_text">Quesioner Text</label>
                                    <input v-model="quesioner_text" type="text" name="Title"
                                    id="quesioner_text" class="form-control" placeholder="quesioner_text"
                                    aria-describedby="quesioner_text" v-bind:class="{ 'is-danger': errors.has('collection.quesioner_text')}"
                                    v-validate="'required'" data-vv-scope="collection">
                                <p v-show="errors.has('collection.quesioner_text')" class="help is-danger"> {{ errors.first('collection.quesioner_text') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="number_of_choice">Num Of Choices</label>
                                    <input v-model.number="number_of_choice" type="number" name="Choices"
                                    id="number_of_choice" class="form-control"
                                    aria-describedby="number_of_choice" v-bind:class="{ 'is-danger': errors.has('collection.number_of_choice')}"
                                    v-validate="'required'" data-vv-scope="collection">
                                <p v-show="errors.has('collection.number_of_choice')" class="help is-danger"> {{ errors.first('collection.number_of_choice') }}</p>
                            </div>
                        </div>
                        <div class="card-footer text-right">
                        <b-button variant="secondary" @click="$bvModal.hide('my-modal')">Cancel</b-button>
                        <b-button v-if="!object_identifier" variant="warning" @click="resetForm">Reset</b-button>
                        <b-button v-if="!object_identifier" variant="success" @click="saveData">Save</b-button>
                        <b-button v-if="object_identifier" variant="success" @click="updateData">Update</b-button>
                    </div>
                        <!-- <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" @click="closeFormModal">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="saveData">Save</button>
                        </div> -->
                    </b-modal>
                    <!-- End Modal -->

                    <!-- Start Delimit Modal -->
                       <b-modal ref="my-modal-delimit" hide-footer size="lg" title="Delimit Activity Learning">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="endDate">End Date</label>
                                <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                    placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.endDate')}"
                                    v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                                    <p v-show="errors.has('delimit.endDate')" class="help is-danger"> {{ errors.first('delimit.endDate') }}</p>
                            </div>
                           
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" @click="closeFormModalDelimit">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="delimitDataSave()">Save</button>
                        </div>
                    </b-modal>
                    <!-- End Delimit Modal -->
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment';
import Vue from 'vue';
import VeeValidate from 'vee-validate';
import VueSweetalert2 from 'vue-sweetalert2';
import ContentHeader from '@@/components/ContentHeader';
import paginationBar from '@@/components/paginationBar';
import { mapState } from 'vuex';

Vue.use(VueSweetalert2);
Vue.use(VeeValidate);

export default {
    layout: 'learning-activity',
    components: {
        paginationBar
    },

    data() {
        return {
            questionBank: [],
            quesionerTypes : [],
            questionCategorys : [],
            today: null,
            flatPickerConfig: {
                altFormat: 'M	j, Y',
                altInput: true,
                dateFormat: 'Y-m-d',
            },
        }
    },
   created(){
        this.getToday();
        this.getData();
        this.$store.dispatch('company/getAll');
    },
    computed: {
       ...mapState({
            company : state => state.company,
            QSNTY : state => state.QSNTY,
            QSTCT : state => state.QSTCT,
            QSTPR : state => state.QSTPR,
        })
    },
    methods: {
         getParam(){
            this.$store.dispatch('TPLCD/getAll', {business_code : ['*', this.business_code]});
            this.$store.dispatch('QSNTY/getAll', {business_code : ['*', this.business_code]});
            this.$store.dispatch('QSTCT/getAll', {business_code : ['*', this.business_code]});
            this.$store.dispatch('QSTPR/getAll', {business_code : ['*', this.business_code]});
        },
        getData() {
          this.$axios.get('lms/api/quesioner?begin_date_lte='+this.today+'&end_date_gte='+this.today)
              .then(res => {
                this.questionBank =[];
                res.data.data.forEach(async (data, key) => {
                    await this.questionBank.push({
                        company : data.business_code.company_name,
                        quesionerID : data.quesioner_id,
                        quesionerType : data.quesioner_type.value,
                        quesionerCategory : data.quesioner_category.value,
                        quesionerPurpose : data.quesioner_purpose.value,
                        quesionerText : data.quesioner_text,
                        numberOfChoice : data.number_of_choice,
                        start : data.begin_date,
                        end : data.end_date,
                    })
                });
              })
              this.$axios.get('lms/api/quesionerchoice?begin_date_lte='+this.today+'&end_date_gte='+this.today)
              .then(res => {
                this.questionChoice =[];
                res.data.data.forEach(async (data, key) => {
                    await this.questionChoice.push({
                        company : data.business_code.company_name,
                        quesionerID : data.quesioner.quesioner_id,
                        sequenceNumber : data.sequence_no,
                        textChoice : data.text_choice,
                        start : data.begin_date,
                        end : data.end_date,
                    })
                });
              })
              .catch(err => {
                  console.log(err.response);
              })
        },
        getToday(){
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth()+1;
            var yyyy = today.getFullYear();
            if(dd<10)
            {
                dd='0'+dd;
            }

            if(mm<10)
            {
                mm='0'+mm;
            }
            this.today = yyyy+'-'+mm+'-'+dd;
        },
        delimitData(id){
            this.showModalDelimit();
        this.$validator.validateAll('delimit').then(async result => {
            if (!result) return;
            this.$axios.patch('lms/api/quesioner?end_date='+this.endDate+'&object_identifier=' + this.object_id)
                .then(response => {
                this.getData();
                this.closeFormModalDelimit();
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )

                })
                .catch(e => {
                console.log(e);
                });
            });
        },
        async saveData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            this.$axios.post('lms/api/quesioner', {
                quesioner_title : this.quesioner_title,
                quesioner_type : this.quesioner_type,
                quesioner_purpose : this.quesioner_purpose,
                quesioner_category : this.quesioner_category,
                quesioner_text : this.quesioner_text,
                number_of_choice : this.number_of_choice,
                business_code : '1000',
                begin_date : this.formatDate(new Date),
                end_date : "9999-12-12",
            })
            .then((res) => {
                console.log(res);
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('my-modal')
                this.$store.dispatch('questioner/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },
        resetForm() {
            this.object_identifier = null
            this.quesioner_title = null
            this.quesioner_type = null
            this.quesioner_purpose = null
            this.quesioner_category = null
            this.quesioner_text = null
            this.number_of_choice = null
            this.business_code = null
            this.begin_date = null
            this.end_date = null

            this.$validator.reset('collection')
        },
        editData(id) {
                this.showModal();
                this.getDetail(id);
            },
        async getDetail(id) {
            let data = await this.questionBank.find(data => data.object_identifier == id);
            this.object_identifier = data.object_identifier;
            this.quesioner_title = null;
            this.quesioner_type = data.quesioner_type.value;
            this.quesioner_purpose = data.quesioner_purpose.value;
            this.quesioner_category = data.quesioner_category.value;
            this.quesioner_text = data.quesioner_text;
            this.number_of_choice = data.number_of_choice;
            this.begin_date = data.begin_date;
            this.end_date = data.end_date;
                
            },
         async updateData() {
            let isValid = await this.$validator.validateAll('collection')
            if (!isValid) return false

            this.$axios.put('lms/api/quesioner', {
                object_identifier : this.object_identifier,
                quesioner_title : this.quesioner_title,
                quesioner_type : this.quesioner_type,
                quesioner_purpose : this.quesioner_purpose,
                quesioner_category : this.quesioner_category,
                quesioner_text : this.quesioner_text,
                number_of_choice : this.number_of_choice,
                business_code : '1000',
                begin_date : this.formatDate(new Date),
                end_date : "9999-12-12",
            })
            .then(() => {
                this.$swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                this.resetForm()
                this.$bvModal.hide('my-modal')
                this.$store.dispatch('questioner/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },
        delimitDataSave() {
            this.$validator.validateAll('delimit').then(async result => {
            if (!result) return;
            this.$axios.patch('lms/api/quesioner?end_date='+this.endDate+'&object_identifier=' + this.object_id)
                .then(response => {
                this.getData();
                this.closeFormModalDelimit();
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )

                })
                .catch(e => {
                console.log(e);
                });
            });
        },
        deleteData(id, key) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/learningactivity?object_identifier=' + id)
                    .then(response => {
                        this.$swal(
                        'Deleted!',
                        response.data.message,
                        'success'
                        )
                    })
                    .catch(e => {
                        console.log(e);
                    })
                    .then(() => {
                        this.removeData(key);
                    })
                }
            });
        },
        removeData(key) {
            this.questionBank.splice(key, 1);
        },
        showModal() {
            this.$refs['my-modal'].show()
        },
        hideModal() {
            this.$refs['my-modal'].hide()
        },
        showModalDelimit() {
            this.$refs['my-modal-delimit'].show()
        },
        hideModalDelimit() {
            this.$refs['my-modal-delimit'].hide()
        },
        onlyNumber($event) {
            let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
            if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
                $event.preventDefault();
            }
        },
        closeFormModal(){
            this.hideModal()
            this.company = null;
            this.quesionerID = null;
            this.quesionerType = null;
            this.quesionerCategory = null;
            this.quesionerPurpose = null;
            this.quesionerText = null;
            this.numberOfChoice = null;
            this.start = null;
            // this.end = null;
            this.$nextTick(() => this.$validator.reset());
        },
        closeFormModalDelimit(){
            this.hideModalDelimit()
            this.id= null;
            this.object_id=null;
            this.startDate= null;
            this.endDate= null;
            this.learningActivityName='';
            this.cycle=null;
            this.type=null;
            this.flag_online=null;
            this.event_number=null;
            this.$nextTick(() => this.$validator.reset());
        },
        moment(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
