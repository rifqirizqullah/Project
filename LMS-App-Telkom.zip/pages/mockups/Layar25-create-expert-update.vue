<template>
                <div class="container page-section">
                    <form>
                        <div class="card shadow">
                            <div class="card-header bg-info">
                                <h4 class="text-light">Create Expert</h4>
                            </div>
                            <div class="card-body p-4">
                                <div align="center">
                                    <b-card
                                    no-body
                                    style="max-width: 20rem;"
                                    img-src="https://placekitten.com/380/200"
                                    img-alt="Image"
                                    img-top
                                    >
                                    <h4 slot="header">
                                    <b-form-file v-model="file2" class="mt-3" plain></b-form-file>
                                    </h4>
                                </b-card>
                                </div>
                                <div class="row">
                                    <div class="form-group col-4">
                                        <label for="NIK">NIK</label>
                                        <input type="text" v-model="NIK" class="form-control" name="NIK" id="NIK" aria-describedby="helpId" placeholder="NIK / Personal Number">
                                        <small id="helpId" class="form-text text-muted">NIK / Personal Number</small>
                                    </div>
                                    <div class="form-group col-8">
                                        <label for="name">Name</label>
                                        <input type="text" v-model="name" class="form-control" name="name" id="name" aria-describedby="helpId" placeholder="Expert Name">
                                        <small id="helpId" class="form-text text-muted">Expert Name</small>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-4">
                                        <label for="birthPlace">Birth Place</label>
                                        <input type="text" v-model="birthPlace" class="form-control" name="birthPlace" id="birthPlace" aria-describedby="helpId" placeholder="Birth Place">
                                        <small id="helpId" class="form-text text-muted">Birth Place</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="birth_date">Birth Date</label>
                                        <div class="form-inline">
                                            <flat-pickr
                                                v-model="birth_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                                placeholder="Select birth date" name="birth_date" id="birth_date"
                                                v-bind:class="{ 'is-danger': errors.has('collection.birth_date')}"
                                                v-validate="'required'" data-vv-scope="collection"
                                            />
                                            <p v-show="errors.has('collection.birth_date')" class="help is-danger"> {{ errors.first('collection.birth_date') }}</p>
                                        </div>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="religion">Religion</label>
                                        <select v-model="religion" class="form-control" name="religion" id="religion">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in religionType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-4">
                                        <label for="gender">Gender</label>
                                        <select v-model="gender" class="form-control" name="gender" id="gender">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in genderType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="email">E-mail</label>
                                        <input type="text" v-model="email" class="form-control" name="email" id="email" aria-describedby="helpId" placeholder="E-mail">
                                        <small id="helpId" class="form-text text-muted">E-mail</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="phone">Phone</label>
                                        <input type="text" v-model="phone" class="form-control" name="phone" id="phone" aria-describedby="helpId" placeholder="Phone">
                                        <small id="helpId" class="form-text text-muted">Phone</small>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    
                                      <div class="form-group col-4">
                                        <label for="alternatifEmail">Alternatif E-mail</label>
                                        <input type="text" v-model="alternatifEmail" class="form-control" name="alternatifEmail" id="alternatifEmail" aria-describedby="helpId" placeholder="Alternatif E-mail">
                                        <small id="helpId" class="form-text text-muted">Alternatif E-mail</small>
                                    </div>
                                    <div class="form-group col-8">
                                        <label for="expertise">Expertise</label>
                                        <select v-model="expertise" class="form-control" name="expertise" id="expertise">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in expertiseType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                </div>
                                 <div class="row">
                                    <div class="form-group col-4">
                                        <label for="expertType">Expert Type</label>
                                        <select v-model="expertType" class="form-control" name="expertType" id="expertType">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in expertType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="majorCompetency">Major Competency</label>
                                        <select v-model="majorCompetency" class="form-control" name="majorCompetency" id="majorCompetency">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in majorCompetencyType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="minorCompetency">Minor Competency</label>
                                        <select v-model="minorCompetency" class="form-control" name="minorCompetency" id="minorCompetency">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in minorCompetencyType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-4">
                                        <label for="expertGroup">Expert Group</label>
                                        <select v-model="expertGroup" class="form-control" name="expertGroup" id="expertGroup">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in expertGroupType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="userStatus">User Status</label>
                                        <select v-model="userStatus" class="form-control" name="userStatus" id="userStatus">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in userStatusType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="level">Level</label>
                                        <select v-model="level" class="form-control" name="level" id="level">
                                            <option disabled value="">-</option>
                                            <option v-for="(item, index) in levelType" :key="index">{{item}}</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-4">
                                        <label for="homeAddress">Home Address</label>
                                        <b-form-textarea
                                        id="textarea"
                                        v-model="text"
                                        placeholder="Enter Home Address..."
                                        rows="6"
                                        max-rows="6"
                                        ></b-form-textarea>
                                        <small id="helpId" class="form-text text-muted">Home Address</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="officeAddress">Office Address</label>
                                        <b-form-textarea
                                        id="textarea"
                                        v-model="text"
                                        placeholder="Enter Office Address..."
                                        rows="6"
                                        max-rows="6"
                                        ></b-form-textarea>
                                        <small id="helpId" class="form-text text-muted">Office Address</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="remarks">Remarks</label>
                                        <b-form-textarea
                                        id="textarea"
                                        v-model="text"
                                        placeholder="Enter Remarks..."
                                        rows="6"
                                        max-rows="6"
                                        ></b-form-textarea>
                                        <small id="helpId" class="form-text text-muted">Remarks</small>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-4">
                                        <label for="youtube">Youtube</label>
                                        <input type="text" v-model="youtube" class="form-control" name="youtube" id="youtube" aria-describedby="helpId" placeholder="Youtube">
                                        <small id="helpId" class="form-text text-muted">Youtube</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="blog">Blog</label>
                                        <input type="text" v-model="blog" class="form-control" name="blog" id="blog" aria-describedby="helpId" placeholder="Blog">
                                        <small id="helpId" class="form-text text-muted">Blog</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="instagram">Instagram</label>
                                        <input type="text" v-model="instagram" class="form-control" name="instagram" id="instagram" aria-describedby="helpId" placeholder="Instagram">
                                        <small id="helpId" class="form-text text-muted">Instagram</small>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-4">
                                        <label for="twitter">Twitter</label>
                                        <input type="text" v-model="twitter" class="form-control" name="twitter" id="twitter" aria-describedby="helpId" placeholder="Twitter">
                                        <small id="helpId" class="form-text text-muted">Twitter</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="facebook">Facebook</label>
                                        <input type="text" v-model="facebook" class="form-control" name="facebook" id="facebook" aria-describedby="helpId" placeholder="Facebook">
                                        <small id="helpId" class="form-text text-muted">Facebook</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="linkedIn">LinkedIn</label>
                                        <input type="text" v-model="linkedIn" class="form-control" name="linkedIn" id="linkedIn" aria-describedby="helpId" placeholder="LinkedIn">
                                        <small id="helpId" class="form-text text-muted">LinkedIn</small>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="form-group col-4">
                                        <label for="feeRateDay">Fee Rate Day</label>
                                        <input type="text" v-model="feeRateDay" class="form-control" name="feeRateDay" id="feeRateDay" aria-describedby="helpId" placeholder="Fee Rate Day">
                                        <small id="helpId" class="form-text text-muted">Fee Rate Day</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="feeRateHour">Fee Rate Hour</label>
                                        <input type="text" v-model="feeRateHour" class="form-control" name="feeRateHour" id="feeRateHour" aria-describedby="helpId" placeholder="Fee Rate Hour">
                                        <small id="helpId" class="form-text text-muted">Fee Rate Hour</small>
                                    </div>
                                    <div class="form-group col-4">
                                        <label for="previousLearningHour">Previous Learning Hour</label>
                                        <input type="text" v-model="previousLearningHour" class="form-control" name="previousLearningHour" id="previousLearningHour" aria-describedby="helpId" placeholder="Previous Learning Hour">
                                        <small id="helpId" class="form-text text-muted">Previous Learning Hour</small>
                                    </div>
                                </div>
                            </div>

                            <div class="card-footer text-muted d-flex justify-content-end">
                                <button type="button" class="btn btn-secondary m-2">Cancel</button>
                                <button type="button" class="btn btn-success m-2">Save</button>
                            </div>

                        </div>
                    </form>

                </div>
</template>

<script>
import moment from 'moment'
import Vue from 'vue';
import VeeValidate from 'vee-validate';
import VueSweetalert2 from 'vue-sweetalert2';
// import ContentHeader from '../../../components/ContentHeader'

Vue.use(VueSweetalert2);
Vue.use(VeeValidate);

export default {

    data() {
        return {
         feedbackPurpose:'',
         feedbackType : [],
         feedbackTest: [],
         feedbackCategory: [],
         csScale: ['1','2',],
         csLowest: [],
         cshighest: [],

         birth_date: null,
        }
    },

    methods: {

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },
    },

}
</script>
