<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader headerTitle='My Event' headerDescription='In Class Learning'
                headerSubDescription='Telkom Corporate Univ' />

            <div class="page-section container page__container">
                <div class="container page__container">
                    <form action="" method="POST">
                        <div class="card p-4">
                            <div class="card-header card-title">
                                <h3>In Class Learning</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p>
                                                Curriculum Name
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <p>
                                            Security Network Multiplatform
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="curriculum_name">
                                                Event Title
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <p id="curriculum_answer">
                                            Bangmat DL Prime
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="event_type">
                                                Event Type
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">

                                        <p id="event_answer">
                                            Self Lead Learning
                                        </p>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-12 col-sm-12">
                                    <b-card>
                                        <div class="col-md-12 col-sm-12">
                                            <table class="table table-bordered table-responsive ">
                                                <tbody>
                                                    <tr>
                                                        <td>A</td>
                                                        <td>Confirm to Attend</td>
                                                        <td>:</td>
                                                        <td>Not Confirmed</td>
                                                        <td>
                                                            <button type="button" class="btn btn-primary btn-sm"
                                                                data-toggle="modal" data-target="#modalconfirm">
                                                                Confirm
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>B</td>
                                                        <td>Attend Session</td>
                                                        <td>:</td>
                                                        <td>
                                                            <b-form-select v-model="selected" :options="options"
                                                                size="sm" class="mt-3"></b-form-select>
                                                        </td>
                                                        <td>
                                                            <button type="button" class="btn btn-primary btn-sm"
                                                                data-toggle="modal" data-target="#modalqr">
                                                                Scan Qr Code
                                                            </button>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>C</td>
                                                        <td>Feedback</td>
                                                        <td>:</td>
                                                        <td>
                                                            OK
                                                        </td>
                                                        <td>
                                                            <button type="submit" class="btn btn-primary mr-3 btn-sm"
                                                                value="Add" v-b-tooltip.hover title="Get Feedback" ><nuxt-link to='/mockups/event/peserta/feedback_penyelenggara'
                                                            class="dropdown-item" style="color:white">GO</nuxt-link></button>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>D</td>
                                                        <td>Material</td>
                                                        <td>:</td>
                                                        <td>
                                                            OK
                                                        </td>
                                                        <td>
                                                            <table class="table table-bordered table-responsive">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Material</th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr v-for="(item, index) in choosematerial"
                                                                        :key="index">
                                                                        <td>{{item.material}}</td>
                                                                        <td>
                                                                            <button type="submit"
                                                                                class="btn btn-primary mr-3 btn-sm"
                                                                                value="Add">View</button>
                                                                        </td>
                                                                    </tr>

                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>E</td>
                                                        <td>Quiz</td>
                                                        <td>:</td>
                                                        <td>
                                                            OK
                                                        </td>
                                                        <td>
                                                            <table class="table table-bordered table-responsive">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Quiz</th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr v-for="(item, index) in choosequiz"
                                                                        :key="index">
                                                                        <td>{{item.quiz}}</td>
                                                                        <td>
                                                                            <button type="submit"
                                                                                class="btn btn-primary mr-3 btn-sm"
                                                                                value="Add">Go</button>
                                                                        </td>
                                                                    </tr>

                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>F</td>
                                                        <td>Assignment</td>
                                                        <td>:</td>
                                                        <td>
                                                            <table class="table table-bordered table-responsive">
                                                                <thead>
                                                                    <tr>
                                                                        <th>Assignment</th>
                                                                        <th>Nama File</th>
                                                                        <th>Action</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <tr v-for="(item, index) in assignment"
                                                                        :key="index">
                                                                        <td>{{item.assignments}}</td>
                                                                        <td>{{item.namafile}}</td>
                                                                        <td>
                                                                            <!-- Plain mode -->
                                                                            <b-form-file v-model="file2" class="mt-3 btn-sm"
                                                                                plain></b-form-file>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </b-card>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal Confirm -->
        <div class="modal fade " id="modalconfirm" tabindex="-1" role="dialog" aria-labelledby="modalconfirm"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-md" role="document">
                <div class="modal-content shadow">
                    <div class="modal-body">
                        <div class="form-group">
                            <div class="col-md-12 col-sm-12 text-center">
                                <label for="learningactivities">Are You Sure to Confirm ?</label>
                            </div>
                            <div class="text-center">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Yes</button>
                                <button type="button" class="btn btn-secondary">No</button>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- modal end -->
         <!-- Modal QrCode -->
        <div class="modal fade " id="modalqr" tabindex="-1" role="dialog" aria-labelledby="modalconfirm"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-md" role="document">
                <div class="modal-content shadow">
                    <div class="modal-body">
                        <div class="form-group">
                            <div class="col-md-12 col-sm-12 text-center">
                                <label for="learningactivities">Scan Qr Code</label>
                            </div>
                            <div class="text-center">

                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- modal end -->



    </div>
</template>
<script>
    import ContentHeader from '@@/components/ContentHeader.vue'
    export default {
        layout: 'home',
        components: {
            ContentHeader,
        },
        data() {
            return {
                selected: null,
                options: [{
                        value: null,
                        text: '24/Mei/2019- Pembukaan'
                    },
                    {
                        value: 'a',
                        text: '25/Mei/2019- Penyambutan'
                    },
                    {
                        value: 'b',
                        text: '26/Mei/2019- Penutupan'
                    },

                ],
                choosematerial: [{
                        material: 'Material 1',
                    },
                    {
                        material: 'Material 2'
                    }
                ],
                choosequiz: [{
                        quiz: 'Quiz 1',
                    },
                    {
                        quiz: 'Quiz 2'
                    }
                ],
                assignment: [{
                        assignments: 'assignment 1',
                        namafile: 'tugas1.pdf',

                    },
                    {
                        assignments: 'assignment 2',
                        namafile: 'tugas1.pdf'
                    }
                ]

            }
        }

    }

</script>
<style>

</style>
