<template>
    <div class="page-section">
        <div class="container page__container">
            <div class="card shadow">
                <div class="card-header bg-info">
                    <h4 class="text-light">Supervysor Feedback</h4>
                </div>

                <br>
                <br>
                <div class="container page__container mb-5">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="supervysor-tab" data-toggle="tab" href="#home" role="tab"
                                aria-controls="home" aria-selected="true">Supervysor</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel"
                            aria-labelledby="supervysor-tab">
                            <div class="card-body p-4">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="text-center mb-3">
                                            <h3>Supervysor Feedback</h3>
                                        </div>
                                        <div class="" style="text-align:center" >
                                            <table class="table table-responsive">
                                                <thead class="thead-light" align="center">
                                                    <tr>
                                                        <th>Question</th>
                                                        <th>Range of Values</th>
                                                    </tr>
                                                </thead>
                                                <tbody align="center">
                                                    <tr>
                                                        <td>Is it?</td>
                                                        <td>
                                                            <div class="radio">
                                                                <label>Low</label>
                                                                <input type="radio" name="optradio">
                                                                <input type="radio" name="optradio">
                                                                <input type="radio" name="optradio">
                                                                <input type="radio" name="optradio">
                                                                <input type="radio" name="optradio">
                                                                <label>High</label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>Apakah?</td>
                                                        <td>
                                                            <div class="radio">
                                                                <label>Low</label>
                                                                <input type="radio" name="optradio1">
                                                                <input type="radio" name="optradio1">
                                                                <input type="radio" name="optradio1">
                                                                <input type="radio" name="optradio1">
                                                                <input type="radio" name="optradio1">
                                                                <label>High</label>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>


                                    </div>
                                </div>
                                <button type="button" class="btn btn-accent float-right"
                                    data-dismiss="modal">Save</button>
                                <button type="submit" class="btn btn-primary float-right mr-3"
                                    value="Submit">Cancel</button>
                            </div>
                        </div>
                       
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
    import moment from 'moment'
    import Vue from 'vue';
    import VeeValidate from 'vee-validate';
    import VueSweetalert2 from 'vue-sweetalert2';
    import ContentHeader from '@@/components/ContentHeader'
    Vue.use(VueSweetalert2);
    Vue.use(VeeValidate);
    export default {
        layout: 'event',

        components: {
            ContentHeader,
        },
        data() {
            return {

            }
        }

    }

</script>
