<template>
    <div class="container page-section">
        <div class="row align-items-center mb-8pt">
            <div class="col-sm-12 col-md-4">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title">On Going Events</h4>
                            <p class="card-subtitle">happening now</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="text-70">Total of ongoing Event <span
                                class="badge badge-pill badge-info badge-lg">10</span></p>
                        <div class="text-right" id="app">
                            <button class="btn btn-accent" v-on:click="isHiddenOngoing = !isHiddenOngoing">Show</button>

                        </div>

                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-4">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title">Upcoming Events</h4>
                            <p class="card-subtitle">Event teacan jalan</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="text-70">Total of Upcoming Event <span
                                class="badge badge-pill badge-info badge-lg">10</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent"
                                v-on:click="isHiddenUpcoming = !isHiddenUpcoming">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 col-md-4">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title">Events Done</h4>
                            <p class="card-subtitle">Completed event</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="text-70">Total of Event done <span
                                class="badge badge-pill badge-info badge-lg">10</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" v-on:click="isHiddenDone = !isHiddenDone">Show</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="card" v-if="isHiddenOngoing">
            <div class="card-header bg-light d-flex justify-content-between">
                <h4 class="card-title">Event List - Ongoing Event</h4>

            </div>
            <div class="card-body">
                <table class="table table-responsive">
                    <thead class="thead-light">
                        <tr>
                            <th>Curriculum Name</th>
                            <th>Event Tittle</th>
                            <th>Cycle</th>
                            <th>Event Type</th>
                            <th>Academy</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Onsite / Online</th>
                            <th>Status</th>

                        </tr>
                    </thead>
                    <tbody>
                        <!-- <tr v-for="(event , index) in events" :key="index">
                            <td>{{event.object_identifier}}</td>
                            <td>{{event.business_code.company_name}}</td>
                            <td>{{moment(event.begin_date)}}</td>
                            <td>{{moment(event.end_date)}}</td>
                            <td>undefine</td>
                            <td><span class="float-right btn btn-accent btn-sm"><i
                                        class="material-icons">settings</i></span></td>
                        </tr> -->
                        <tr v-for="(event , index) in ongoing" :key="index">
                            <!-- <nuxt-link to='organization-strategy/edit'
                                                        class="dropdown-item">Edit</nuxt-link> -->
                            <td>{{event.curriculumname}}</td>
                            <td>{{event.eventtitle}}</td>
                            <td class="light" v-b-tooltip.hover title="Click Here"><b><a @click="cyclee(index)"
                                        href="#">{{event.cycle}}</a></b></td>
                            <td>{{event.eventtype}}</td>
                            <td>{{event.academy}}</td>
                            <td>{{event.start}}</td>
                            <td>{{event.end}}</td>
                            <td>{{event.onsite}}</td>
                            <td>{{event.status}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="card" v-if="isHiddenUpcoming" id="upcoming">
            <div class="card-header bg-light d-flex justify-content-between">
                <h4 class="card-title">Event List - Upcoming Event</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive ">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>Event Name</th>
                                <th>Company Name</th>
                                <th>Curriculum Title</th>
                                <th>Academy</th>
                                <th>Location</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Onsite / Online</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(event , index) in events" :key="index">
                                <td>{{event.object_identifier}}</td>
                                <td>{{event.business_code.company_name}}</td>
                                <td>{{moment(event.begin_date)}}</td>
                                <td>{{moment(event.end_date)}}</td>
                                <td>undefine</td>
                                <td><span class="float-right btn btn-accent btn-sm"><i
                                            class="material-icons">settings</i></span></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>

        <div class="card" v-if="isHiddenDone" id="done">
            <div class="card-header bg-light d-flex justify-content-between">
                <h4 class="card-title">Event List - Done Event</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>Event Name</th>
                                <th>Company Name</th>
                                <th>Curriculum Title</th>
                                <th>Academy</th>
                                <th>Location</th>
                                <th>Start Date</th>
                                <th>End Date</th>
                                <th>Onsite / Online</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(event , index) in events" :key="index">
                                <td>{{event.object_identifier}}</td>
                                <td>{{event.business_code.company_name}}</td>
                                <td>{{moment(event.begin_date)}}</td>
                                <td>{{moment(event.end_date)}}</td>
                                <td>undefine</td>
                                <td><span class="float-right btn btn-accent btn-sm"><i
                                            class="material-icons">settings</i></span></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-title">
                Learning Roadmap
            </div>
            <div class="text-center">
                <b-button-group class="mt-2">
                    <b-button variant="info">Current Roadmap</b-button>
                    <b-button variant="info">Future Roadmap</b-button>
                </b-button-group>
            </div>
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Required Competencies: A</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Basic</th>
                                <th>Intermediate</th>
                                <th>Advance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Fundamental of Cisco Router</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td></td>
                                <td>GPMP V</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td></td>
                                <td></td>
                                <td>Coaching for Supervisor</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">Required Competencies: B</h4>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Basic</th>
                                <th>Intermediate</th>
                                <th>Advance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Fundamental of Cisco Router</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td></td>
                                <td>GPMP V</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td></td>
                                <td></td>
                                <td>Coaching for Supervisor</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="card-header bg-info d-flex justify-content-between">
                    <h4 class="card-title">My Learning Proposal</h4>
                    <nuxt-link :to="{ path: `/mockups/student/event/proposed-learning`}">
                        <b-button variant="success">Proposed Learning</b-button>
                    </nuxt-link>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead class="thead-light">
                            <tr>
                                <th>No.</th>
                                <th>Curriculum Name</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td>Advanced HTML Programming</td>
                                <td>Planned</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>GPMP V</td>
                                <td>Planned</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>Public Speaking</td>
                                <td>Planned as Public Course</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    function myFunction() {
        alert("cek");
    }

</script>

<script>
    import moment from 'moment'
    import Vue from 'vue';
    import VeeValidate from 'vee-validate';
    import VueSweetalert2 from 'vue-sweetalert2';
    import ContentHeader from '@@/components/ContentHeader'
    Vue.use(VueSweetalert2);
    Vue.use(VeeValidate);

    export default {
        layout: 'event_peserta',
        components: {
            ContentHeader,
        },

        data() {
            return {
                isHiddenOngoing: false,
                isHiddenUpcoming: false,
                isHiddenDone: false,

                ongoing: [{
                        curriculumname: 'Phyton for programming',
                        eventtitle: 'Bangmat DL',
                        cycle: '1',
                        eventtype: 'E-Learning',
                        location: 'Telkom Coorperate University',
                        academy: 'Cooperate University',
                        start: '27 March 2019',
                        end: '02 April 2019',
                        onsite: 'Onsite',
                        status: 'On Going'
                    },
                    {
                        curriculumname: 'Phyton for programming',
                        eventtitle: 'Bangmat DL',
                        cycle: '2',
                        eventtype: 'E-Learning',
                        location: 'Telkom Coorperate University',
                        academy: 'Cooperate University',
                        start: '27 March 2019',
                        end: '02 April 2019',
                        onsite: 'Onsite',
                        status: 'On Going'
                    },
                    {
                        curriculumname: 'Phyton for programming',
                        eventtitle: 'Bangmat DL',
                        cycle: '3',
                        eventtype: 'E-Learning',
                        location: 'Telkom Coorperate University',
                        academy: 'Cooperate University',
                        start: '27 March 2019',
                        end: '02 April 2019',
                        onsite: 'Onsite',
                        status: 'On Going'
                    },
                    {
                        curriculumname: 'Phyton for programming',
                        eventtitle: 'Bangmat DL',
                        cycle: '4',
                        eventtype: 'E-Learning',
                        location: 'Telkom Coorperate University',
                        academy: 'Cooperate University',
                        start: '27 March 2019',
                        end: '02 April 2019',
                        onsite: 'Onsite',
                        status: 'On Going'
                    },
                    {
                        curriculumname: 'Phyton for programming',
                        eventtitle: 'Bangmat DL',
                        cycle: '5',
                        eventtype: 'E-Learning',
                        location: 'Telkom Coorperate University',
                        academy: 'Cooperate University',
                        start: '27 March 2019',
                        end: '02 April 2019',
                        onsite: 'Onsite',
                        status: 'On Going'
                    },
                    {
                        curriculumname: 'Phyton for programming',
                        eventtitle: 'Bangmat DL',
                        cycle: '6',
                        eventtype: 'E-Learning',
                        location: 'Telkom Coorperate University',
                        academy: 'Cooperate University',
                        start: '27 March 2019',
                        end: '02 April 2019',
                        onsite: 'Onsite',
                        status: 'On Going'
                    },
                ],
                mode: "ongoing"
            }
        },

        mounted() {
            // this.fetchEvent()
        },

        methods: {
            fetchEvent() {
                this.$axios.get(process.env.API_LMSMAIN_URL + '/api/events', {
                        headers: {
                            'Authorization': `bearer ${localStorage.getItem('access_token')}`
                        }
                    })
                    .then(res => {
                        this.events = res.data.data
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },

            moment(date) {
                return moment(date).format('DD MMM YYYY')
            },

            cyclee(key) {

                if (this.ongoing[key].cycle == '1') {
                    this.$router.push('/mockups/event/peserta/cycle-1')
                } else if (this.ongoing[key].cycle == '2') {
                    this.$router.push('/mockups/event/peserta/cycle-2')
                } else if (this.ongoing[key].cycle == '3') {
                    this.$router.push('/mockups/event/peserta/cycle-3')
                } else if (this.ongoing[key].cycle == '4') {
                    this.$router.push('/mockups/event/peserta/cycle-4')
                } else if (this.ongoing[key].cycle == '5') {
                    this.$router.push('/mockups/event/peserta/cycle-5')
                } else if (this.ongoing[key].cycle == '6') {
                    this.$router.push('/mockups/event/peserta/cycle-6')
                }
            }


        },

    }

</script>

<style scoped>
    .has-margin {
        margin-bottom: 15px;
    }

    .light {
        background-color: #E9ECEF;
        color: black;
        text-align: center;

    }

</style>
