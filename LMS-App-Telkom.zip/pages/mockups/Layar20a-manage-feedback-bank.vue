<template>
<!-- halaman ini consume pake api questioner termasuk form -->
    <div class="container page-section">
        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <p class="card-title" style="font-size:25px;color:black">Manage Feedback Bank</p>
                <!-- <p  style="font-size:15px;margin-top:-15px">List of Available Learning Activity</p> -->
            </div>
            <button @click="clearDetail(); $bvModal.show('questionerForm')" class="btn btn-primary btn-sm">+
                Add Feedback Test</button>
            <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-success" v-b-toggle.collapse-a>
            <span class="btn-label"><i class="fa fa-upload"></i>  Upload</span>
            </b-button>
        </div>
        <div class="card">
            <!-- <b-form-file v-model="file2" class="btn btn-primary mx-2 mb-16pt float-right" plain></b-form-file> -->
            <!-- <div class="btn btn-primary mx-2 mb-16pt float-right">Upload {{ file2 ? file2.name : '' }}</div> -->
            <!-- <b-form-file v-model="file2" class="mt-3" plain></b-form-file> -->

            <!-- <nuxt-link :to="'/mockups/add-feedback-test'" class="btn btn-success mx-2 mb-16pt float-right"> Upload </nuxt-link>
            <nuxt-link :to="'/mockups/add-feedback-test'" class="btn btn-primary mx-2 mb-16pt float-right"> Add Feedback Test</nuxt-link> -->
            
            <!-- <b-button size="sm" variant="primary">+ Add Feedback Test</b-button>
            <b-button size="sm" variant="success" class="ml-3 btn-labeled ">Upload</b-button> -->
            
            <table class="table table-flush table-hover table-responsive">
                <thead class="thead">
                    <tr>
                        <th>Feedback Purpose</th>
                        <th>Feedback Type</th>
                        <th>Feedback Category</th>
                        <th>Feedback Test</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody class="list">
                    <tr v-for="(item, index) in questioner.list" :key="index">
                        <td>{{item.quesioner_title}}</td>
                        <td>{{item.quesioner_type.value}}</td>
                        <td>{{item.quesioner_category.value}}</td>
                        <td>{{item.quesioner_text}}</td>
                        <td>
                            <div class="nav-item dropdown d-none d-sm-flex">
                                <a href="#" data-toggle="dropdown" class="btn btn-sm btn-primary">
                                    <i class="material-icons">settings</i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <nuxt-link :to="'/learning-plan/budget'" class="dropdown-item">Manage Batch</nuxt-link>
                                    <button class="dropdown-item" onclick="return confirm('Are you sure you want to delete this?')"> Delete </button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="questioner.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
            <div class="card-footer">
                <paginationBar :state='questioner' :storeModuleName="'quesioner'" />
            </div>
        </div>
        <b-modal v-model="modalShow" ref="questionerForm" hide-footer hide-header id="questionerForm"
            size="lg">
            <questionerForm v-if="modalShow" />
        </b-modal>
    </div>
</template>

<script>

    import ContentHeader from '@@/components/ContentHeader'
    import paginationBar from '@@/components/paginationBar'
    import questionerForm from '@@/components/forms/questionerForm'
    import { mapState, mapActions } from 'vuex'



    export default {
        layout: 'learning-activity',
        components: {
            questionerForm,
            paginationBar
        },
        created() {
            this.$store.dispatch('questioner/getAll');
        },
        data() {
            return {
                modalShow: false,
                feedbackTest : [{
                feedbackPurpose: '-',
                feedbackType: '-',
                feedbackCategory: '-',
                feedbackT: '-',
            },],
            }
        },
        computed: {
            ...mapState(['questioner'])
        },
        methods: {
            ...mapActions({
                getDetail: 'questioner/getDetail',
                clearDetail: 'questioner/clearDetail',
                getAll: 'questioner/getAll',
            }),
        }
    }
</script>

<style scoped>
    .active-cyan-2 input[type=text]:focus:not([readonly]) {
        border: 1px solid #4dd0e1;
        box-shadow: 0 1px 0 0 #4dd0e1;
    }
    .active-cyan .fa,
    .active-cyan-2 .fa {
        color: #4dd0e1;
    }
</style>