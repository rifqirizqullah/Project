<template>
    <div class="container page-section">
        <div class="page-section bg-white border-bottom-2">
            <div class="container page__container">
                <div class="container card">
                <div class="card-header bg-white d-flex justify-content-between">
                <h4 class="card-title">Batch Budget</h4>
                <div class="float-right"> 
                <b-button v-b-modal.addBudgetModal class="btn btn-sm btn-success">+ Add Batch Budget</b-button>
                <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                    <span class="btn-label"><i class="fa fa-search"></i> Search</span>
                </b-button>
                        <b-modal hide-footer hide-header no-close-on-backdrop size="lg" id="addBudgetModal" centered title="BootstrapVue">
                                    <div class="modal-header bg-info">
                                        <h4 class="modal-title ">Batch Budget</h4>
                                    </div>
                                    <div class="modal-body">
                                        
                                        <!--<div class="form-group">
                                            <label for="company">Company</label>
                                                <select
                                                    v-model="business_code" class="form-control" name="business_code" id="business_code"
                                                    :class="{ 'is-danger': errors.has('collection.business_code') }"
                                                    v-validate="'required'" data-vv-scope="collection"
                                                    >
                                                    <option v-for="(item, index) in company" :key="index" :value="item.business_code">{{item.company_name}}</option>
                                                </select>
                                                <p v-show="errors.has('collection.business_code')" class="help is-danger">{{ errors.first('collection.business_code') }}</p>
                                        </div>-->
                                        <!--<div class="form-group">
                                                <label for="startDate">Start Date</label>
                                                <flat-pickr v-model="startDate" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                                placeholder="Select start date" name="date" v-bind:class="{ 'is-danger': errors.has('collection.startDate')}"
                                                v-validate="'required'" data-vv-scope="collection"> </flat-pickr>
                                                <p v-show="errors.has('collection.startDate')" class="help is-danger"> {{ errors.first('collection.startDate') }}</p>
                                        </div> -->
                                        <!-- <div class="form-group">
                                                <label for="finishDate">Finish Date</label>
                                                <flat-pickr v-model="finishDate" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                                placeholder="Select finish date" name="date" v-bind:class="{ 'is-danger': errors.has('collection.finishDate')}"
                                                v-validate="'required'" data-vv-scope="collection"> </flat-pickr>
                                                <p v-show="errors.has('collection.finishDate')" class="help is-danger"> {{ errors.first('collection.finishDate') }}</p>
                                        </div>        -->
                                        <div class="form-group">
                                            <label for="acedemy">Cost Item</label>
                                            <select v-model="costItem" class="form-control" >
                                                <option disabled value="">-</option>
                                                <option v-for="(item, index) in costItemsOptions" :key="index">{{item}}</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for="inputPrice">Unit Price</label>
                                            <input type="number" v-model="unitPrice" @keypress="onlyNumber" class="form-control" name="inputPrice" id="inputPrice" aria-describedby="helpId" placeholder="Unit Price">
                                            <small id="helpId" class="form-text text-muted">Price</small>
                                        </div>
                                        <div class="form-group">
                                             <label for="qty">Quantity</label>
                                                <input v-model="quantity" type="number"
                                                    class="form-control" name="qty" id="qty" aria-describedby="helpId" placeholder="qty">
                                                <small id="helpId" class="form-text text-muted">Quantity</small>
                                        </div>
                                        <div class="form-group">
                                            <label for="subtotal">Subtotal</label>
                                            <input v-model="subtotal" type="number"
                                                class="form-control" name="subtotal" id="subtotal" aria-describedby="helpId" placeholder="subtotal" disabled>
                                                <small id="helpId" class="form-text text-muted">subtotal</small>
                                        </div>
                                        <div class="form-row">
                                            <div class="col-6 ">
                                                <div class="form-group">
                                                <label for="begin_date">Begin Date</label>
                                                <div class="form-inline">
                                                    <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}"
                                                        class="form-control" placeholder="Select start date"
                                                        name="begin_date" id="begin_date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                                        v-validate="'required'" data-vv-scope="collection" />
                                                    <button type="button" class="btn btn-info"
                                                        @click="begin_date = new Date()">Today</button>
                                                    <p v-show="errors.has('collection.begin_date')"
                                                        class="help is-danger">
                                                        {{ errors.first('collection.begin_date') }}</p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div v-show="begin_date" class="form-group">
                                                <label for="end_date">End Date</label>
                                                <div class="form-inline">
                                                    <flat-pickr v-model="end_date"
                                                        :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                                        class="form-control" placeholder="Select end date"
                                                        name="end_date" id="end_date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                                        v-validate="'required'" data-vv-scope="collection" />
                                                    <button type="button" class="btn btn-info"
                                                        @click="end_date = '9999-12-31' ">Max</button>
                                                    <p v-show="errors.has('collection.end_date')"
                                                        class="help is-danger">
                                                        {{ errors.first('collection.end_date') }}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <b-button type="button" class="btn btn-secondary"
                                        @click="$bvModal.hide('addBudgetModal')">Cancel</b-button>
                                    <button type="button" class="btn btn-primary"
                                        @click="delimitDataSave()">Save</button>
                                </div>
                            </b-modal>
                        </div>
                    </div>
                    <div class="card card-body">
                         <div class="">
                        <div class=" text-right">
                            <div>
                                <b-collapse id="collapse-a" class="mt-2">
                                    <form class="p-2">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-3">
                                                   <div class="form-group">
                                                    <select class="form-control" name="company"
                                                        id="company">
                                                        <option></option>
                                                    </select>
                                                    <small class="form-text text-muted">Company</small>
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control"
                                                        id="exampleFormControlInput1" placeholder="Cost Item">
                                                    <small class="form-text text-muted">Cost Item</small>
                                                </div>
                                                <div class="form-group">
                                                   <flat-pickr
                                                    v-model="end_date" :config="{dateFormat: 'Y-m-d', minDate: begin_date}" class="form-control"
                                                    placeholder="Select end date" name="end_date" id="end_date"
                                                    v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                                    v-validate="'required'" data-vv-scope="collection"
                                                />
                                                <p v-show="errors.has('collection.end_date')" class="help is-danger"> {{ errors.first('collection.end_date') }}</p>
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                <flat-pickr v-model="startDate" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                                placeholder="Select start date" name="date" v-bind:class="{ 'is-danger': errors.has('collection.startDate')}"
                                                v-validate="'required'" data-vv-scope="collection"> </flat-pickr>
                                                <p v-show="errors.has('collection.startDate')" class="help is-danger"> {{ errors.first('collection.startDate') }}</p>
                                                <small class="form-text text-muted">Start Date</small>
                                                </div>
                                                 <div class="form-group">
                                                    <input type="text" class="form-control"
                                                        id="exampleFormControlInput1" placeholder="Unit Price">
                                                    <small class="form-text text-muted">Unit Price</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                     <flat-pickr v-model="finishDate" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                                placeholder="Select finish date" name="date" v-bind:class="{ 'is-danger': errors.has('collection.finishDate')}"
                                                v-validate="'required'" data-vv-scope="collection"> </flat-pickr>
                                                <p v-show="errors.has('collection.finishDate')" class="help is-danger"> {{ errors.first('collection.finishDate') }}</p>
                                                    <small class="form-text text-muted">Finish Date</small>
                                                </div>
                                                <div class="form-group">
                                                    <input type="text" class="form-control"
                                                        id="exampleFormControlInput1" placeholder="Quantity">
                                                    <small class="form-text text-muted">Quantity</small>
                                                </div>
                                            </div>
                                               <div class="col-sm-12 col-md-3">
                                        
                                                <div class="form-group">
                                                    <input type="text" class="form-control"
                                                        id="exampleFormControlInput1" placeholder="Batch">
                                                    <small class="form-text text-muted">Batch</small>
                                                </div>
                                                <div class="form-group">
                                                    <flat-pickr
                                                    v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" class="form-control"
                                                    placeholder="Select start date" name="begin_date" id="begin_date"
                                                    v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                                    v-validate="'required'" data-vv-scope="collection"
                                                />
                                                <p v-show="errors.has('collection.begin_date')" class="help is-danger"> {{ errors.first('collection.begin_date') }}</p>
                                                    <small class="form-text text-muted">Begin Date</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-12">
                                                <div class="form-group text-right">
                                                    <b-button type="button"
                                                        class="ml-3 btn btn-sm btn-labeled btn-secondary"
                                                        v-b-toggle.collapse-a>
                                                        <span class="btn-label">
                                                            Clear Search</span>
                                                    </b-button>
                                                    <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info"
                                                        v-b-toggle.collapse-a>
                                                        <span class="btn-label">
                                                            Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                    </div>
                        <div class="table  table-responsive"  data-toggle="lists" data-lists-values='["name"]'>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <!-- BUSCD -->
                                        <!-- <th>Company</th> -->
                                        <!-- <th>Start Date</th> -->
                                        <!-- <th>Finish Date</th> -->
                                        <!-- Batch -->
                                        <!-- <th>Batch</th> -->
                                        <!-- COSTC -->
                                        <th>Cost Item</th>
                                        <!-- PRICE -->
                                        <th>Unit Price</th>
                                        <!-- QUATY -->
                                        <th>Quantity</th>
                                        <th>Subtotal Price</th>
                                        <th>Begin Date</th>
                                        <th>End Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody class="list bg-white">
                                    <tr v-for="(budget, index) in budgets" :key="index">
                                        <td>{{ index +1 }}</td>
                                        <!-- <td>{{ budget.company_name }}</td> -->
                                        <!-- <td>{{ budget.batch }}</td> -->
                                        <td>{{ budget.wage_type }}</td>
                                        <td>{{ numberFormat(budget.price) }}</td>
                                        <td>{{ budget.quantity }}</td>
                                        <td>{{ numberFormat(budget.price * budget.quantity) }}</td>
                                        <td>{{ moment(budget.begin_date) }}</td>
                                        <td>{{ moment(budget.end_date) }}</td>
                                        <td>
                                             <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                                <div class="dropdown-menu dropdown-menu-right" >
                                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/')">Detail</button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr >
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td></td>
                                        <td>
                                             <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                                <div class="dropdown-menu dropdown-menu-right" >
                                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/')">Detail</button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-6">
                            <div class="bg-secondary text-white " role="alert">
                                <a class="btn text-right">
                                    <span class="">Total Budget : Rp. {{ numberFormat(totalBudget) }}</span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Start Modal -->
                    <b-modal ref="my-modal" centered hide-header hide-footer>
                        <div class="modal-header">
                            <h5 class="modal-title">Budget</h5>
                            <button type="button" class="close" aria-label="Close" @click="closeFormModal">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="costItem">Cost Item</label>
                                <select v-model="costItem" class="form-control" name="costItem" id="costItem"
                                    v-bind:class="{ 'is-danger': errors.has('collection.costItem') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <option disabled value="">Cost Item</option>
                                    <option v-for="(wage, index) in costItems" :key="index" :value="wage.wage_type">
                                        {{ wage.wage_name }}
                                    </option>
                                </select>
                                <p v-show="errors.has('collection.costItem')" class="help is-danger">
                                    {{ errors.first('collection.costItem') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="unitPrice">Unit Price</label>
                                <input type="text" v-model="unitPrice" @keypress="onlyNumber" class="form-control"
                                    name="unitPrice" id="unitPrice"
                                    v-bind:class="{ 'is-danger': errors.has('collection.unitPrice') }"
                                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId"
                                    placeholder="Unit Price">
                                <small id="helpId" class="form-text text-muted">Price</small>
                                <p v-show="errors.has('collection.unitPrice')" class="help is-danger">
                                    {{ errors.first('collection.unitPrice') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="quantity">Quantity</label>
                                <input type="text" v-model="quantity" @keypress="onlyNumber" class="form-control"
                                    name="quantity" id="quantity"
                                    v-bind:class="{ 'is-danger': errors.has('collection.quantity') }"
                                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId"
                                    placeholder="Quantity">
                                <small id="helpId" class="form-text text-muted">Quantity</small>
                                <p v-show="errors.has('collection.quantity')" class="help is-danger">
                                    {{ errors.first('collection.quantity') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="subtotal">Subtotal</label>
                                <input type="number" v-model="subtotal" class="form-control" name="subtotal"
                                    id="subtotal" v-bind:class="{ 'is-danger': errors.has('collection.subtotal') }"
                                    v-validate="'required'" data-vv-scope="collection" aria-describedby="helpId"
                                    placeholder="Subtotal" disabled>
                                <small id="helpId" class="form-text text-muted">Subtotal</small>
                                <p v-show="errors.has('collection.subtotal')" class="help is-danger">
                                    {{ errors.first('collection.subtotal') }}</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" @click="closeFormModal">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="saveData">Save</button>
                        </div>
                    </b-modal>
                    <!-- End Modal -->

                    <!-- Start Delimit Modal -->
                    <b-modal ref="my-modal-delimit" centered hide-header hide-footer>
                        <div class="modal-header">
                            <h5 class="modal-title">Delimit Budget</h5>
                            <button type="button" class="close" aria-label="Close" @click="closeFormModalDelimit">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="endDate">End Date</label>
                                <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                    placeholder="Select end date" name="date"
                                    v-bind:class="{ 'is-danger': errors.has('delimit.endDate')}" v-validate="'required'"
                                    data-vv-scope="delimit"> </flat-pickr>
                                <p v-show="errors.has('delimit.endDate')" class="help is-danger">
                                    {{ errors.first('delimit.endDate') }}</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary"
                                @click="closeFormModalDelimit">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="delimitDataSave()">Save</button>
                        </div>
                    </b-modal>
                    <!-- End Delimit Modal -->
                </div>
            </div>
        </div>
    </div>
</template>


<script>
    import moment from 'moment'
    import Vue from 'vue';
    import VeeValidate from 'vee-validate';
    import VueSweetalert2 from 'vue-sweetalert2';
    import ContentHeader from '@@/components/ContentHeader'

    Vue.use(VueSweetalert2);
    Vue.use(VeeValidate);

    export default {
        layout: 'batch',
        components: {
            ContentHeader
        },

        data() {
            return {
                business_code: '',
                begin_date: '',
                end_date: '',
                costItemsOptions: ['a', 'b', 'c'],
                keycode: 'null',
                budgets: [],
                costItems: [],
                objectIdentifier: null,
                costItem: '',
                unitPrice: null,
                quantity: null,
                startDate: null,
                endDate: null,
                batch: null,
                today: null,
                finishDate:null,

                flatPickerConfig: {
                    altFormat: 'M	j, Y',
                    altInput: true,
                    dateFormat: 'Y-m-d',
                },

                buscd: this.$auth.user
            }
        },
        computed: {
            subtotal: function () {
                return Number(this.unitPrice) * Number(this.quantity)
            }
        },
        created() {
            this.getToday();
            this.fetchBudget();
            this.getWage();

        },

        methods: {
            isNumber: function (evt) {
                evt = (evt) ? evt : window.event;
                var charCode = (evt.which) ? evt.which : evt.keyCode;
                if ((charCode > 31 && (charCode < 48 || charCode > 57)) && charCode !== 46) {
                    evt.preventDefault();;
                } else {
                    return true;
                }
            },
            submit() {
                console.log(this.model);
            },
            numberFormat(value) {
                let val = (value / 1).toFixed(0)
                return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
            },
            onlyNumber($event) {
                let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
                if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
                    $event.preventDefault();
                }
            },
            getToday() {
                var today = new Date();
                var dd = today.getDate();
                var mm = today.getMonth() + 1;
                var yyyy = today.getFullYear();
                if (dd < 10) {
                    dd = '0' + dd;
                }

                if (mm < 10) {
                    mm = '0' + mm;
                }
                this.today = yyyy + '-' + mm + '-' + dd;
            },
            getWage() {
                this.$axios.get('hcis/api/wage?begin_date_lte='+this.today+'&end_date_gte='+this.today)
                .then(response => {
                    this.costItems = [];
                    response.data.data.forEach(async (data, key) => {
                        await this.costItems.push({
                            wage_type: data.wage_type,
                            wage_name: data.wage_name
                        })
                    });
                })
                .catch(err => {
                    console.log(err.response);
                });
            },
            fetchBudget() {
                this.$axios.get('lms/api/batchbudget?begin_date_lte='+this.today+'&end_date_gte='+this.today)
                    .then(res => {
                        this.budgets = [];
                        res.data.forEach(async (budget, index) => {
                            await this.budgets.push({
                                object_identifier: budget.object_identifier,
                                company_name: budget.company_code,
                                wage_type: budget.wage_type.wage_name,
                                price: budget.price,
                                quantity: budget.quantity,
                                begin_date : budget.begin_date,
                                end_date : budget.end_date,
                            })
                        });
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },
            async getData(objectIdentifier) {
                let budget = await this.budgets.find(budget => budget.object_identifier == objectIdentifier);
                this.objectIdentifier = budget.object_identifier;
                this.business_code = this.learningPlanBatch.detail.business_code.business_code   
                this.batch = this.learningPlanBatch.detail.batch;
                this.startDate = this.learningPlanBatch.detail.start_date;
                this.finishDate = this.learningPlanBatch.detail.finish_date;
                this.costItem = budget.wage_type.object_identifier;
                this.unitPrice = budget.price.object_identifier;
                this.quantity = budget.quantity.object_identifier;
                this.startDate = budget.begin_date;
                this.endDate = budget.end_date;
            },
            editData(objectIdentifier) {
                this.showModal();
                this.getData(objectIdentifier);
            },
            showModal() {
                this.$refs['my-modal'].show()
            },
            hideModal() {
                this.$refs['my-modal'].hide()
            },
            closeFormModal() {
                this.hideModal()
                this.objectIdentifier = null;
                this.business_code = null;
                this.batch = null;
                this.costItem = null;
                this.unitPrice = null;
                this.quantity = null;
                this.startDate = null;
                this.endDate = null;
                this.$nextTick(() => this.$validator.reset());
            },
            storeData() {
                this.$validator.validateAll('collection').then(async result => {
                if (!result) return;
                this.$axios.post('lms/api/batchbudget',
                    {
                        // object_identifier   : this.objectIdentifier,
                        business_code   : "1000",
                        batch           : "2",
                        wage_type       : this.costItem,
                        price           : this.unitPrice,
                        quantity        : this.quantity,
                        begin_date      : this.today,
                        end_date        : "9999-12-31"
                    })
                    .then(response => {
                        this.fetchBudget();
                        this.closeFormModal();
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                    })
                    .catch(e => {
                        console.log(e);
                    });
                });
            },
            updateData() {
                this.$validator.validateAll('collection').then(async result => {
                if (!result) return;
                this.$axios.put('lms/api/batchbudget',
                    {
                        object_identifier   : this.objectIdentifier,
                        business_code       : "1000",
                        wage_type           : this.costItem,
                        price               : this.unitPrice,
                        quantity            : this.quantity
                    })
                    .then(response => {
                        this.fetchBudget();
                        this.closeFormModal();
                        this.$swal(
                            'Saved!',
                            'Successfully updated data.',
                            'success'
                        )
                    })
                    .catch(e => {
                        console.log(e);
                    });
                });
            },
            saveData() {
                this.objectIdentifier ? this.updateData(this.objectIdentifier) : this.storeData();
            },
            delimitData(objectIdentifier){
                this.showModalDelimit();
                this.getData(objectIdentifier);
            },
            showModalDelimit() {
                this.$refs['my-modal-delimit'].show()
            },
            hideModalDelimit() {
                this.$refs['my-modal-delimit'].hide()
            },
            closeFormModalDelimit() {
                this.hideModalDelimit()
                this.objectIdentifier = null;
                this.business_code = null;
                this.batch = null;
                this.costItem = null;
                this.unitPrice = null;
                this.quantity = null;
                this.startDate = null;
                this.endDate = null;
                this.$nextTick(() => this.$validator.reset());
            },
            delimitDataSave() {
                this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/batchbudget?end_date=' + this.endDate + '&object_identifier=' + this.objectIdentifier)
                    .then(response => {
                        this.fetchBudget();
                        this.closeFormModalDelimit();
                        this.$swal(
                            'Saved!',
                            'Successfully saved data.',
                            'success'
                        )
                    })
                    .catch(e => {
                        console.log(e);
                    });
                });
            },
            deleteData(objectIdentifier, key) {
                this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                    if (result.value) {
                        this.$axios.delete('lms/api/batchbudget?object_identifier=' + objectIdentifier)
                        .then(response => {
                            this.$swal(
                                'Deleted!',
                                response.data.message,
                                'success'
                            )
                        })
                        .catch(err => {
                            console.log(err.response);
                        })
                        .then(() => {
                            this.removeData(key);
                        })
                    }
                });
            },
            removeData(key) {
                this.budgets.splice(key, 1);
            },
            moment(date) {
                return moment(date).format('DD MMM YYYY')
            }
        },

        computed: {
            totalBudget() {
                return this.budgets.reduce((total, budget) => total + (budget.price * budget.quantity), 0);
            },
            subtotal: function () {
                return Number(this.unitPrice) * Number(this.quantity)
            }
        }
    }

</script>
