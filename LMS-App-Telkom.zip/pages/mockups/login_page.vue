<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content pb-0">
            <div class="bg-gradient-primary py-32pt">
                <div class="container d-flex flex-column flex-md-row align-items-center text-center text-md-left">
                    <!-- <img src="whitesvg" class="mr-md-32pt mb-32pt mb-md-0" alt="student"> -->
                    <div class="flex mb-32pt mb-md-0">
                        <h1 class="text-white mb-0">Sign In</h1>
                        <p class="lead measure-lead text-white-50">Sign in to get new knowledge</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-section">
            <div class="container page__container">


                <div class="col-md-5 p-0 mx-auto" >
                    <form @submit.prevent="login">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group">
                                <label for="email">Username:</label>
                                <input class="form-control" type="text" v-bind:class="{ 'is-danger': errs.username }" v-model="nik"
                                    placeholder="Username">
                                <p v-if="errs.username" class="help is-danger">{{ errs.username[0] }}</p>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input class="form-control" type="password" v-bind:class="{ 'is-danger': errs.password }"
                                    v-model="password" placeholder="Password">
                                <p v-if="errs.password" class="help is-danger">{{ errs.password[0] }}</p>
                            </div>
                            <div class="field is-grouped is-grouped-left login-btn-group text-right">
                                <button type="submit" class="btn btn-success ">
                                    Login
                                </button>
                                <!-- <p v-if="errs != null" class="help is-danger">{{ errs }}</p> -->
                            </div>
                        </div>
                    </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</template>


<script>
export default {
    // layout: 'auth',
    // middleware: 'guest',
    data() {
        return {
            nik: '',
            password: '',
            errs: []
        }
    },
    created(){
        console.log(this.$auth)
    },
    methods: {
        async login() {
            try {
            await this.$auth.loginWith('local', {
                data: {
                username: this.nik,
                password: this.password,
                application_id : '2'
                }
            });
            // console.log(this.$auth.user.username)
            this.$router.push('/');
            } catch (error) {
                this.errs = error.response.data.errors
            }
        }
    }
        // async login() {
            // try {
            // await this.$auth.loginWith('local', {
            //     data: {
            //         username: this.nik,
            //         password: this.password
            //     }
            // });
            //this.$router.push('/');
            //console.log(this.$auth)
            // if (this.$auth.user) {
            //     this.errs = null
            //     this.$router.push('/home');
            // } else {
            //     //this.$router.push('/logout');
            //     this.errs = 'wrong username or password !'
            // }

            // } catch (error) {
            //   this.errs = 'username atau password falah !'
            // }
        //     console.log('ajax call ');

        //     this.$axios.post( process.env.API_LDAP_URL + '/api/auth/login', {
        //         username : this.nik,
        //         password : this.password,
        //         application_id : '2'
        //     })
        //     .then(res => {
        //         if(res.data.access_token) {
        //             localStorage.setItem('access_token',res.data.access_token)
        //             this.$router.push('/');
        //         }
        //     })
        //     .catch(err => {
        //         this.errs = err.response.data.message
        //     })
        // }

}
</script>
