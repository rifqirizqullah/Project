<template>
	<div class="mdk-header-layout js-mdk-header-layout">
       <div class="mdk-header-layout__content page-content ">
            <ContentHeader
                headerTitle='Event Management'
                headerDescription='To manage all events that will be held.'
                headerSubDescription= 'Telkom Corporate University'
            />

            <div class="page-section bg-white">
                <div class="container page__container">
                    <div class="tabs row">
                        <div class="tab-button-outer">

                            <ul id="tab-button">
                                <li class="is-active">
                                    <a href="#ongoing">
                                        <div class="col-lg-12">
                                            <div class="border-1 border-left-3 border-left-accent rounded text-black-70 text-center mb-lg-0">
                                                <div class="card-body">
                                                    On Going Event
                                                    <p class="lead text-body mb-0"><strong>3 of 3 Curriculum</strong></p>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li class="">
                                    <a href="#upcoming">
                                        <div class="col-lg-12">
                                            <div class="border rounded text-black-70 text-center mb-lg-0">
                                                <div class="card-body">
                                                    Upcoming Event
                                                    <p class="lead text-body mb-0"><strong>50 Event</strong></p>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li class="">
                                    <a href="#done">
                                        <div class="col-lg-12">
                                            <div class="border rounded text-black-70 text-center mb-lg-0">
                                                <div class="card-body">
                                                    Event Done
                                                    <p class="lead text-body mb-0"><strong>200 Event</strong></p>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-select-outer">
                            <select id="tab-select">
                                <div class="col-lg-4">
                                    <div class="border rounded text-black-70 text-center mb-lg-0">
                                        <div class="card-body">
                                            <option value="#ongoing">On Going Event
                                                <p class="lead text-body mb-0"><strong>10 of 3 Curriculum</strong></p>
                                            </option>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="border rounded text-black-70 text-center mb-lg-0">
                                        <div class="card-body">
                                            <option value="#upcoming">Upcoming Event
                                                <p class="lead text-body mb-0"><strong>150</strong></p>
                                            </option>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="border rounded text-black-70 text-center mb-lg-0">
                                        <div class="card-body">
                                            <option value="#done">Event Done
                                                <p class="lead text-body mb-0"><strong>150</strong></p>
                                            </option>
                                        </div>
                                    </div>
                                </div>
                            </select>
                        </div>
                    </div>

                    <div class="card">
                        <div id="" class="tab-contents" >
                            <div class="mb-heading d-flex align-items-end">
                                <div class="flex">
                                    <h4 class="card-title">Event Plan List</h4>
                                </div>
                                <!-- <a href="instructor-earnings.html" class="text-underline text-black-70">View Earnings</a> -->
                            </div>
                            <div class="card p-24pt mb-32pt">
                                <table class="table table-responsive">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Event Name</th>
                                            <th>Company Name</th>
                                            <th>Curriculum Title</th>
                                            <th>Vendor Request</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                            <th>Onsite / Online</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(eventPlan , index) in eventPlans" :key="index">
                                            <td>{{eventPlan.object_identifier}}</td>
                                            <td>{{eventPlan.business_code.company_name}}</td>
                                            <td>{{moment(eventPlan.begin_date)}}</td>
                                            <td>{{moment(eventPlan.end_date)}}</td>
                                            <td>undefine</td>
                                            <td><span class="float-right btn btn-accent btn-sm"><i class="material-icons">settings</i></span></td>
                                        </tr>
                                    </tbody>
                                </table>

                                <hr>
                                <div class="panel panel-default">
                                    <div class="panel-heading">Model</div>
                                    <div class="panel-body">
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'
import ContentHeader from '@@/components/ContentHeader'

export default {
    layout: 'home',

    components : {
        ContentHeader,
    },

    data() {
        return {
            eventPans: []
        }
    },

    mounted() {
        // this.fetchEvent()
    },

    methods: {
        fetchEvent() {
            this.$axios.get(process.env.API_LMSMAIN_URL + '/api/event_plans', {
                    headers: {
                        'Authorization': `bearer ${localStorage.getItem('access_token')}`
                    }
                })
                .then(res => {
                    this.event_plans = res.data.data
                })
                .catch(err => {
                    console.log(err.response);
                })
        },

        moment(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>

<style scoped>

</style>

