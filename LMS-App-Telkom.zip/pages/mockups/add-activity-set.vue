<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <div class="container page__container page-section">
                <div class="card shadow">
                    <div class="card-header card-title bg-info">
                        <h4 class="text-light">Create Learning Activity Set Material</h4>
                    </div>
                    <div class="card-body p-4">
                        <div class="form-group">
                            <label class="form-label"> Learning Activity Set Type </label>
                            <select v-model="setType" name="company" class="select form-control">
                                <option value="" disabled>---------</option>
                                <option v-for="type in types">{{ type }}</option>
                            </select>
                        </div>
                        <div v-if="setType === 'Material'">
                            <form>
                                <div class="form-group row" >
                                    <div class="col-3">
                                        <label for="id_material" class="col-form-label requiredField">
                                            Material Name
                                        </label>
                                    </div>
                                    <div class="col-9">
                                        <input v-model="materialName" type="text" name="title" maxlength="255" class="textinput textInput form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row" >
                                    <div class="col-3">
                                        <label for="id_description" class="col-form-label requiredField">
                                            Description
                                        </label>
                                    </div>
                                    <div class="col-9">
                                        <input v-model="description" type="text" name="title" maxlength="255" class="textinput textInput form-control" required>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <div class="col-3">
                                        <label class="form-label"> Material Type </label>
                                    </div>
                                    <div class="col-9">
                                        <select name="company" class="select form-control">
                                            <option value="" disabled>---------</option>
                                            <option value="material" selected>Materi Trainer</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label for="id_file" class="col-form-label">
                                            File
                                        </label>
                                    </div>
                                    <div class="custom-file col-8 ml-2">
                                        <input type="file" class="custom-file-input" id="validatedCustomFile" required>
                                        <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                    </div>
                                </div>
                                <div class="form-group row" >
                                    <div class="col-3">
                                        <label for="id_link" class="col-form-label requiredField">
                                            Link
                                        </label>
                                    </div>
                                    <div class="col-9">
                                        <input v-model="link" type="text" name="title" maxlength="255" class="textinput textInput form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label for="startDate">Begin Date</label>
                                    </div>
                                    <div class="col-9">
                                        <flat-pickr v-model="startDate" :config="flatPickerConfig" id="startDate" class="form-control"
                                        placeholder="Select start date" name="startdate"> </flat-pickr>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label for="endDate">End Date</label>
                                    </div>
                                    <div class="col-9">
                                        <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select end date" name="enddate"> </flat-pickr>
                                    </div>
                                </div>
                                <div class="card-footer text-center">
                                    <button type="submit" class="btn btn-primary mr-3" value="Add">Save</button>
                                    <a href="#" class="btn btn-secondary mr-3">Cancel</a>
                                </div>
                            </form>
                        </div>
                        <div v-if="setType === 'Quiz'">
                            <form>
                                <div class="form-group row" >
                                    <div class="col-3">
                                        <label for="id_quizName" class="col-form-label requiredField">
                                            Quiz Name
                                        </label>
                                    </div>
                                    <div class="col-9">
                                        <input v-model="quizName" type="text" name="title" maxlength="255" class="textinput textInput form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label>Quiz Type</label>
                                    </div>
                                    <div class="col-9">
                                        <select v-model="quiz.type" class="form-control">
                                            <option disabled value="">-</option>
                                            <option v-for="(type, index) in quiz.typeOptions" :key="index">{{type}}</option>
                                        </select>
                                    </div>
                                </div>
                                <div id="div_id_title" class="form-group row align-items-center">
                                    <label for="id_title" class="col-form-label requiredField col-md-3">
                                        Total Question
                                    </label>
                                    <div class="row">
                                        <div class="col-md-1 col-md-2 pl-4">
                                            <input type="text" name="title" maxlength="10" value="15" class="textinput textInput form-control" required id="id_title">
                                        </div>
                                        <div class="col-md-3 align-self-center">
                                            Question
                                        </div>
                                        <button class="btn btn-primary">View Question</button>
                                    </div>
                                </div>
                                <div class="form-group row">

                                    <label for="id_file" class="col-form-label col-md-3">
                                        Question
                                    </label>
                                    <div class="custom-file row ml-2 col-md-3">
                                        <b-button v-b-modal.modal-question variant="primary">Choose Question</b-button>
                                    </div>

                                    <div id="div_id_dur" class="form-group row align-items-center mt-4">
                                        <label class="form-label col-md-4 ml-2" for="flatpickrSample01">Duration</label>
                                        <br>
                                        <div class="col-sm-1 ml-3">
                                            <input type="text" name="title" maxlength="255" class="textinput textInput form-control" required id="id_hour">
                                        </div>
                                        :
                                        <div class="col-sm-1">
                                            <input type="text" name="title" maxlength="255" class="textinput textInput form-control" required id="id_min">
                                        </div>
                                        :
                                        <div class="col-sm-1">
                                            <input type="text" name="title" maxlength="255" class="textinput textInput form-control" required id="id_sec">
                                        </div>

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label for="startDate">Begin Date</label>
                                    </div>
                                    <div class="col-9">
                                        <flat-pickr v-model="startDate" :config="flatPickerConfig" id="startDate" class="form-control"
                                            placeholder="Select start date" name="startdate"> </flat-pickr>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label for="endDate">End Date</label>
                                    </div>
                                    <div class="col-9">
                                        <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                            placeholder="Select end date" name="enddate"> </flat-pickr>
                                    </div>
                                </div>
                                <div class="card-footer text-center">
                                    <button type="submit" class="btn btn-primary mr-3" value="Add">Save</button>
                                    <a href="#" class="btn btn-secondary mr-3">Cancel</a>
                                </div>
                            </form>
                        </div>
                        <div v-if="setType === 'Assignment'">
                            <form>
                                <div id="div_id_quiz" class="form-group row">
                                    <label for="id_title" class="col-form-label requiredField col-md-3">
                                        Assignment Name
                                    </label>
                                    <div class="col-md-9">
                                        <input type="text" name="title" maxlength="255" class="textinput textInput form-control" required id="id_quiz">
                                    </div>
                                </div>
                                <div id="div_id_LAST" class="form-group row">
                                    <div class="col-3">
                                        <label for="id_company" class="col-form-label">
                                            Assignment Type
                                        </label>
                                    </div>
                                    <div class="col-9">
                                        <select name="company" class="select form-control" id="id_LAST">
                                            <option value="">Upload / Entry</option>
                                            <option value="material">Material</option>
                                        </select>
                                    </div>
                                </div>
                                <div id="div_id_title" class="form-group row align-items-center">
                                    <label for="id_title" class="col-form-label requiredField col-3">
                                        Total Assignment
                                    </label>
                                    <div class="col-9">
                                        <div class="col-md-6">
                                            2 Assignment
                                            <button class="btn btn-primary col-md-5 ml-4">View Assignment</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label for="id_file" class="col-form-label">
                                            File
                                        </label>
                                    </div>
                                    <div class="custom-file ml-3 col-8">
                                        <input type="file" class="custom-file-input" id="validatedCustomFile" required>
                                        <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label for="startDate">Begin Date</label>
                                    </div>
                                    <div class="col-9">
                                        <flat-pickr v-model="startDate" :config="flatPickerConfig" id="startDate" class="form-control"
                                            placeholder="Select start date" name="startdate">
                                        </flat-pickr>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-3">
                                        <label for="endDate">End Date</label>
                                    </div>
                                    <div class="col-9">
                                        <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                            placeholder="Select end date" name="enddate">
                                        </flat-pickr>
                                    </div>
                                </div>
                                <div class="card-footer text-center">
                                    <button type="submit" class="btn btn-primary mr-3" value="Add">Save</button>
                                    <a href="curriculum-index.html" class="btn btn-secondary mr-3">Cancel</a>
                                </div>
                            </form>
                        </div>
                        <div v-if="setType === 'Feedback'">
                            <div id="div_id_feedback" class="form-group row">
                                <label for="id_feedback" class="col-form-label requiredField col-md-3">
                                    Feedback Name
                                </label>
                                <div class="col-md-9">
                                    <input type="text" name="title" maxlength="255" class="textinput textInput form-control" required id="id_feedback">
                                </div>
                            </div>
                            <div id="div_id_type" class="form-group row">
                                <div class="col-3">
                                    <label for="id_company" class="col-form-label">
                                        Feedback type
                                    </label>
                                </div>
                                <div class="col-9">
                                    <select v-model="set_type_feedback" class="form-control" name="set_type_feedback"
                                        id="set_type_feedback">
                                        <option disabled value="">----</option>
                                        <option v-for="(set_type_feedback, index) in set_type_feedbacks" :key="index">
                                            {{set_type_feedback}}</option>
                                    </select>
                                </div>
                            </div>
                            <div id="div_id_title" class="form-group row align-items-center">
                                <label for="id_title" class="col-form-label requiredField col-md-3">
                                    Total Question
                                </label>
                                <div class="row">
                                    <div class="col-md-1 col-md-2 pl-4">
                                        <input type="text" name="title" maxlength="10" value="15"
                                            class="textinput textInput form-control" required id="id_title">
                                    </div>
                                    <div class="col-md-3 align-self-center">
                                        Question
                                    </div>
                                    <button type="button" class="btn btn-primary">View Question</button>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="id_file" class="col-form-label col-md-3">
                                    Question
                                </label>
                                <div class="custom-file row ml-2 col-md-3">
                                    <b-button v-b-modal.modal-xl variant="primary">Choose Feedback</b-button>
                                </div>
                            </div>
                            <div id="div_id_duration" class="form-group">
                                <div class="row">
                                    <div class="column col-sm-3">
                                        <label for="id_duration" class="col-form-label ">
                                            <strong>
                                                <p>Duration</p>
                                            </strong>
                                        </label>
                                    </div>
                                    <div class="column col-sm-9">
                                        <label for="id_name" type="time" class="col-form-label requiredField">
                                            00: 15 : 00
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-3">
                                    <label for="beginDate">Begin Date</label>
                                </div>
                                <div class="col-9">
                                    <flat-pickr v-model="startDate" :config="flatPickerConfig" id="beginDate"
                                        class="form-control" placeholder="Select begin date" name="begindate">
                                    </flat-pickr>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-3">
                                    <label for="endDate">End Date</label>
                                </div>
                                <div class="col-9">
                                    <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                    placeholder="Select end date" name="enddate"> </flat-pickr>
                                </div>
                            </div>


                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-3" value="Add">Save</button>
                                <a href="#" class="btn btn-secondary mr-3">Cancel</a>
                            </div>
                        </div>


                        <div v-if="setType === 'Schedule'">
                            <div class="form-group row" >
                                <div class="col-3">
                                    <label for="id_lASName" class="col-form-label requiredField">
                                        Learning Activity Set Name
                                    </label>
                                </div>
                                <div class="col-9">
                                    <input v-model="lASName" type="text" name="title" maxlength="255" class="textinput textInput form-control" required>
                                </div>
                            </div>
                            <div id="div_id_type" class="form-group row">
                                <div class="col-3">
                                    <label for="id_company" class="col-form-label ">
                                        Day
                                    </label>
                                </div>
                                <div class="col-9">
                                    <select v-model="set_type_feedback" class="form-control" name="set_type_feedback"
                                        id="set_type_feedback">
                                        <option disabled value="">----</option>
                                        <option v-for="(set_type_feedback, index) in set_type_feedbacks" :key="index">
                                            {{set_type_feedback}}</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-3">
                                    <label for="beginDate">Begin Date</label>
                                </div>
                                <div class="col-9">
                                    <flat-pickr v-model="startDate" :config="flatPickerConfig" id="beginDate"
                                        class="form-control" placeholder="Select begin date" name="begindate">
                                    </flat-pickr>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-3">
                                    <label for="endDate">End Date</label>
                                </div>
                                <div class="col-9">
                                    <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select end date" name="enddate"> </flat-pickr>
                                </div>
                            </div>
                            <div class="form-group row" >
                                <div class="col-3">
                                    <label for="id_scheduleName" class="col-form-label requiredField">
                                        Schedule Name
                                    </label>
                                </div>
                                <div class="col-9">
                                    <input v-model="scheduleName" type="text" name="title" maxlength="255" class="textinput textInput form-control" required>
                                </div>
                            </div>
                            <div class="form-group row" >
                                <div class="col-3">
                                    <label for="id_description" class="col-form-label requiredField">
                                        Description
                                    </label>
                                </div>
                                <div class="col-9">
                                    <input v-model="description" type="text" name="title" maxlength="255" class="textinput textInput form-control" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-3">
                                    <label for="beginDate">Begin Date</label>
                                </div>
                                <div class="col-9">
                                    <flat-pickr v-model="startDate" :config="flatPickerConfig" id="beginDate"
                                        class="form-control" placeholder="Select begin date" name="begindate">
                                    </flat-pickr>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-3">
                                    <label for="endDate">End Date</label>
                                </div>
                                <div class="col-9">
                                    <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select end date" name="enddate"> </flat-pickr>
                                </div>
                            </div>
                            <div class="form-group row" >
                                <div class="col-3">
                                    <label for="id_totalJP" class="col-form-label requiredField">
                                        Total JP
                                    </label>
                                </div>
                                <div class="col-9">
                                    <input v-model="totalJP" type="text" name="title" maxlength="255" class="textinput textInput form-control" required>
                                </div>
                            </div>
                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary mr-3" value="Add">Save</button>
                                <a href="#" class="btn btn-secondary mr-3">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- modal feedback -->
        <b-modal id="modal-xl" size="xl" title="">
            <table class="table border table-responsive">
                <thead class="thead-light">
                    <tr>
                        <td>Feedback Purpose</td>
                        <td>Feedback Category</td>
                        <td>Feedback Text</td>
                        <td>Choose</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                    <!-- <n-link class="dropdown-item" :to="`/learning-activity/${learningActivity.object_identifier}/detail`">Detail</n-link>
                                    <button class="dropdown-item" @click="editData(learningActivity.object_identifier)">Edit</button>
                                    <button class="dropdown-item" @click="delimitData(learningActivity.object_identifier)">Delimit</button>
                                    <button class="dropdown-item" @click="deleteData(learningActivity.object_identifier, index)">Delete</button> -->
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </b-modal>
        <!-- end modal feedback -->

        <!-- modal question -->
        <b-modal id="modal-question" size="xl" title="">
            <table class="table border table-responsive">
                <thead class="thead-light">
                    <tr>
                        <td>Question Name</td>
                        <td>Question Text</td>
                        <td>Choose</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                    <!-- <n-link class="dropdown-item" :to="`/learning-activity/${learningActivity.object_identifier}/detail`">Detail</n-link>
                                    <button class="dropdown-item" @click="editData(learningActivity.object_identifier)">Edit</button>
                                    <button class="dropdown-item" @click="delimitData(learningActivity.object_identifier)">Delimit</button>
                                    <button class="dropdown-item" @click="deleteData(learningActivity.object_identifier, index)">Delete</button> -->
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </b-modal>
        <!-- end modal question -->

    </div>
</template>

<script>
export default {
    layout: 'learning-activity',
    data() {
        return {
            setType : this.$route.query.type || '',
            types: ['Material','Quiz','Assignment','Feedback','Schedule'],
            quiz: {
                typeOptions : ['Material', 'Quiz', 'Assignment', ' Feedback', 'Schedule'],
                type : '',
                name : '',
            },
            material: {
                quizName : '',
                quizType : '',
                duration : '',
                startDate : '',
                endDate : '',

                flatPickerConfig: {
                    altFormat: 'M	j, Y',
                    altInput: true,
                    dateFormat: 'Y-m-d',
                },

                tipePickerConfig : {
                    enableTime: true,
                    noCalendar: true,
                    dateFormat: "H:i",
                    time_24hr: true,
                },
            },


        }
    },

}
</script>

<style>

</style>
