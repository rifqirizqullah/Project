<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <div class="container page__container page-section">
            	<div class="mb-heading d-flex align-items-end">
                    <div class="flex">
                        <h4 class="card-title">Cycle 4</h4>
                    </div>
                </div>

                <div class="card p-24pt mb-32pt table-responsive">
                    <table class="table table-bordered table-responsive">
                        <tr>
                            <td>
                                Curriculum Name
                            </td>
                            <td>
                                :
                            </td>
                            <td>
                                Python for Data Science
                                <p class="float-right"> Nama Mentor : Aan Priyatna</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Event Title
                            </td>
                            <td>
                                :
                            </td>
                            <td>
                                Bangmat DL Prime
                            </td>
                        </tr>
                        <tr>
                            <td>
                                Event Type
                            </td>
                            <td>
                                :
                            </td>
                            <td>
                                Mentoring
                            </td>
                            <!-- <td>
                                Nama Mentor : Aan Priyatna
                            </td> -->
                        </tr>
                        <tr>
                            <td valign="top">
                                Upload Evidence
                            </td>
                            <td valign="top">
                                :
                            </td>
                            <td>
                                <div class="form-group m-0">
                                    <div class="custom-file col-6">
                                        <input type="file" id="file" class="custom-file-input">
                                        <label for="file" class="custom-file-label">Choose file</label>
                                    </div>
                                    <button class="btn btn-primary col-1 mt-2">Save</button>
                                </div>
                                <div class="card col-6 p-3">
                                    Evidence.pdf <br>
                                    Evidence.php
                                </div>
                            </td>
                        </tr>
                        <tr>
                           <td colspan="3">
                               <div class="card p-24pt mb-32pt">
                                    <div class="container">
                                        <h3 class=" text-center">Messaging</h3>
                                        <div class="messaging">
                                            <div class="inbox_msg">
                                                <div class="mesgs">
                                                    <div class="msg_history">
                                                        <div class="incoming_msg">
                                                            <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                                                            <div class="received_msg">
                                                                <div class="received_withd_msg">
                                                                    <p>Saya sudah mengumpulkan tugas
                                                                    </p>
                                                                    <span class="time_date"> 11:01 AM    |    June 9</span></div>
                                                            </div>
                                                        </div>
                                                        <div class="outgoing_msg">
                                                            <div class="sent_msg">
                                                                <p>ya, ada masalah?
                                                                </p>
                                                                <span class="time_date"> 11:01 AM    |    June 9</span> </div>
                                                        </div>
                                                        <div class="incoming_msg">
                                                            <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                                                            <div class="received_msg">
                                                                <div class="received_withd_msg">
                                                                    <p>Tidak pak, cuman mohon direview saja</p>
                                                                    <span class="time_date"> 11:01 AM    |    Yesterday</span></div>
                                                            </div>
                                                        </div>
                                                        <div class="outgoing_msg">
                                                            <div class="sent_msg">
                                                                <p>Ya, segera direview</p>
                                                                <span class="time_date"> 11:01 AM    |    Today</span> </div>
                                                        </div>
                                                        <div class="incoming_msg">
                                                            <div class="incoming_msg_img"> <img src="https://ptetutorials.com/images/user-profile.png" alt="sunil"> </div>
                                                            <div class="received_msg">
                                                                <div class="received_withd_msg">
                                                                    <p>Terimakasih :)</p>
                                                                    <span class="time_date"> 11:01 AM    |    Today</span></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="type_msg">
                                                        <div class="input_msg_write">
                                                            <input type="text" class="write_msg" placeholder="Type a message" />
                                                            <button class="msg_send_btn" type="button"><i class="fa fa-paper-plane-o" aria-hidden="true"></i></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>                            
                                </div>
                           </td> 
                        </tr>
                        <tr>
                            <td colspan="4" class="text-center">
                                <button class="btn btn-primary">Give Feedback</button>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>
    .container{max-width:1170px; margin:auto;}
    img{ max-width:100%;}
    .inbox_msg {
      border: 1px solid #c4c4c4;
      clear: both;
      overflow: hidden;
    }
    .top_spac{ margin: 20px 0 0;}

    .chat_ib h5{ font-size:15px; color:#464646; margin:0 0 8px 0;}
    .chat_ib h5 span{ font-size:13px; float:right;}
    .chat_ib p{ font-size:14px; color:#989898; margin:auto}
    .chat_img {
      float: left;
      width: 11%;
    }
    .chat_ib {
      float: left;
      padding: 0 0 0 15px;
      width: 88%;
    }

    .chat_people{ overflow:hidden; clear:both;}
    .chat_list {
      border-bottom: 1px solid #c4c4c4;
      margin: 0;
      padding: 18px 16px 10px;
    }
    .inbox_chat { height: 550px; overflow-y: scroll;}

    .incoming_msg_img {
      display: inline-block;
      width: 6%;
    }
    .received_msg {
      display: inline-block;
      padding: 0 0 0 10px;
      vertical-align: top;
      width: 92%;
     }
     .received_withd_msg p {
      background: #ebebeb none repeat scroll 0 0;
      border-radius: 3px;
      color: #646464;
      font-size: 14px;
      margin: 0;
      padding: 5px 10px 5px 12px;
      width: 100%;
    }
    .time_date {
      color: #747474;
      display: block;
      font-size: 12px;
      margin: 8px 0 0;
    }
    .received_withd_msg { width: 57%;}
    .mesgs {
      float: left;
      padding: 30px 15px 0 25px;
      width: 100%;
    }

     .sent_msg p {
      background: #05728f none repeat scroll 0 0;
      border-radius: 3px;
      font-size: 14px;
      margin: 0; color:#fff;
      padding: 5px 10px 5px 12px;
      width:100%;
    }
    .outgoing_msg{ overflow:hidden; margin:26px 0 26px;}
    .sent_msg {
      float: right;
      width: 46%;
    }
    .input_msg_write input {
      background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
      border: medium none;
      color: #4c4c4c;
      font-size: 15px;
      min-height: 48px;
      width: 100%;
    }

    .type_msg {border-top: 1px solid #c4c4c4;position: relative;}
    .msg_send_btn {
      background: #05728f none repeat scroll 0 0;
      border: medium none;
      border-radius: 50%;
      color: #fff;
      cursor: pointer;
      font-size: 17px;
      height: 33px;
      position: absolute;
      right: 0;
      top: 11px;
      width: 33px;
    }
    .messaging { padding: 0 0 50px 0;}
    .msg_history {
      height: 516px;
      overflow-y: auto;
    }
</style>
