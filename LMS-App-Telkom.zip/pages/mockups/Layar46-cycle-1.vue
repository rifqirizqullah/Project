<template>
    <div class="mdk-header-layout js-mdk-header-layout">

        <div class="mdk-header-layout__content page-content ">
            <ContentHeader headerTitle='Manage Curriculum' headerDescription='Curriculum Management '
                headerSubDescription='Telkom Corporate Unv' />

            <div class="page-section container page__container">
                <div class="container page__container">
                    <form action="" method="POST">
                        <div class="card p-4">
                            <div class="card-header card-title">
                                <h3>Self Lead Learning</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p>
                                                Curriculum Name
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <p>
                                            Phyton for Data Science
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="curriculum_name">
                                                Event Title
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <p id="curriculum_answer">
                                            Bangmat DL Prime
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="event_type">
                                                Event Type
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">

                                        <p id="event_answer">
                                            Self Lead Learning
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="Link">
                                                Link
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <table class="table table-bordered table-responsive">
                                                    <thead>
                                                        <tr>
                                                            <th>Document Link</th>
                                                            <th>Download</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="(dokumen, key) in link" :key="key">
                                                            <td>{{dokumen.document}}</td>
                                                            <td>
                                                                <button type="submit" class="btn btn-primary mr-3"
                                                                    value="Add">Download</button>
                                                            </td>
                                                        </tr>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="event_type">
                                                Upload Evidence
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-5 col-sm-8">

                                        <label for="file" class="custom-file-label">Choose file</label>
                                    </div>
                                    <div class="col-md-4 col-sm-4">
                                        <button class="btn btn-primary ">Save</button>
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                    </div>
                                    <div class="col-md-5 col-sm-8">
                                        <div class="card">
                                            <table class="table table-bordered table-responsive" >
                                                <thead>
                                                    <tr>
                                                        <th>Document Link</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr v-for="(dokumen, key) in link" :key="key">
                                                        <td>{{dokumen.document}}</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                    <div class="col-md-3 col-sm-4">
                                        <button class="btn btn-primary ">Give Feedback</button>
                                    </div>
                                </div>


                                <div class="card-footer text-center">
                                    <button type="submit" class="btn btn-primary mr-3" value="Add">Save</button>
                                    <a href="#" class="btn btn-secondary mr-3">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div>
</template>
<script>
    import ContentHeader from '@@/components/ContentHeader.vue'
    export default {
        layout: 'home',
        components: {
            ContentHeader,
        },
        data() {
            return {
                link: [{
                        document: 'document1.pdf',
                    },
                    {
                        document: 'document2.pdf'
                    }
                ],
            }
        }

    }

</script>
<style>

</style>
