<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader
                headerTitle='Event Management'
                headerDescription='To manage all events that will be held.'
                headerSubDescription= 'Telkom Corporate University'
            />

            <div class="page-section bg-white border-bottom-2">
                <div class="container page__container">

                    <form>
                        <div class="card">
                            <div class="card-header">
                                Add New Event Plan
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="eventType">Event Type</label>
                                    <select v-model="eventType" class="form-control" name="eventType"
                                        id="eventType">
                                        <option disabled value="">-</option>
                                        <option v-for="(eventTypes, index) in eventTypes" :key="index">{{eventTypes}}
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="learningPlan">Learning Plan</label>
                                    <select v-model="learningPlan" class="form-control" name="learningPlan"
                                        id="learningPlan">
                                        <option disabled value="">-</option>
                                        <option v-for="(learningPlans, index) in learningPlans" :key="index">{{learningPlans}}
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="eventName">Event Name</label>
                                    <input v-model="eventName" type="text" name="eventName"
                                        id="eventName" class="form-control" placeholder="Event Name"
                                        aria-describedby="eventName">
                                </div>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Participant
                                            <a class="btn btn-sm btn-primary float-right text-white" data-toggle="modal" data-target="#myModal">
                                            <i class="material-icons">add</i>&nbsp;Add Participant
                                            </a>
                                            <div class="modal" id="myModal">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content">

                                                        <!-- Modal Header -->
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Participant Candidates</h4>
                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                        </div>

                                                        <!-- Modal body -->
                                                        <div class="modal-body">
                                                            <select name="#" class="form form-control" id="#" multiple>
                                                                <option value="1">Yahya Z</option>
                                                            </select>
                                                        </div>

                                                        <!-- Modal footer -->
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary m-2" data-toggle="modal" data-target="#myModal2">Add</button>
                                                            <div class="modal" id="myModal2">
                                                                <div class="modal-dialog modal-dialog-centered">

                                                                    <div class="modal-body">
                                                                        <div class="card card-body mb-32pt">
                                                                            <div class="row">

                                                                                <div class="col-lg-12 d-flex align-items-center">
                                                                                    <form class="flex">
                                                                                        <div class="modal-header">
                                                                                            <h5 class="modal-title" id="addModalLabel">ADD PARTICIPANT</h5>
                                                                                        </div>
                                                                                                 <!-- Search -->
                                                                                        <div class="search-form search-form--light mb-3">
                                                                                            <input type="text" class="form-control search" placeholder="Search">
                                                                                            <button class="btn" type="button" role="button"><i class="material-icons">search</i></button>
                                                                                        </div>
                                                                                        <div class="form-group">
                                                                                            <label class="form-label" for="">ID:</label>
                                                                                            <input type="text" class="form-control" id="exampleInput" placeholder="">
                                                                                        </div>
                                                                                        <div class="form-group">
                                                                                            <label class="form-label" for="">Name:</label>
                                                                                            <input type="text" class="form-control" id="exampleInput" placeholder="">
                                                                                        </div>
                                                                                        <div class="footer float-right">
                                                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                                                                            <button type="submit" class="btn btn-primary">Save</button>
                                                                                        </div>
                                                                                    </form>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </h4>
                                        <div class="list-group">
                                            <a href="#" class="list-group-item list-group-item-action">Participant 1
                                                <span class="float-right btn btn-accent btn-sm"><i class="material-icons">delete</i></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Learning Activity</h4>
                                        <div class="list-group">
                                            <div class="row list-group-item list-group-item-action m-1">
                                                <div class="">
                                                    Getting Started with Javascript
                                                </div>
                                                <div class="">
                                                    <span class="float-right btn btn-accent btn-sm m-1"><i class="material-icons">delete</i></span>
                                                </div>
                                                <div class="">
                                                    <a href="learning-plan-add-event.html" class="float-right btn btn-primary btn-sm m-1"><i class="material-icons">add</i></a>
                                                </div>
                                                <div class="">
                                                    <span class="float-right custom-checkbox m-1"><i class="material-icons">done</i></span>
                                                </div>
                                                <div class="">
                                                    <span class="float-right badge badge-secondary badge-pill m-1">Reading</span>
                                                </div>
                                                <div class="">
                                                    <span class="float-right badge badge-outline-secondary badge-pill m-1">2 Event</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="eventOrganizer">Event Organizer</label>
                                    <select v-model="eventOrganizer" class="form-control" name="acedemy" id="eventOrganizer">
                                        <option disabled value="">-</option>
                                        <option v-for="(eventOrganizers, index) in eventOrganizers" :key="index">{{eventOrganizers}}</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="feedbackTemplate">Feedback Template</label>
                                    <select v-model="feedbackTemplate" class="form-control" name="feedbackTemplate"
                                        id="feedbackTemplate">
                                        <option disabled value="">-</option>
                                        <option v-for="(feedbackTemplates, index) in feedbackTemplates" :key="index">
                                            {{feedbackTemplates}}</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="eventStart">Event Start</label>
                                    <flat-pickr v-model="eventStart" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select start date" name="date"> </flat-pickr>
                                </div>
                                <div class="form-group">
                                    <label for="eventFinish">Event Finish</label>
                                    <flat-pickr v-model="eventFinish" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select end date" name="date"> </flat-pickr>
                                </div>

                            </div>

                            <div class="card-footer text-muted d-flex justify-content-end">
                                <button type="button" class="btn btn-secondary m-2">Cancel</button>
                                <button type="button" class="btn btn-accent m-2" data-toggle="modal" data-target="#modalCreateNonPlannedEvent">
                                        + Create Non Planned Event
                                    </button>
                                <button type="button" class="btn btn-success m-2">Save</button>
                            </div>


                        </div>
                    </form>


                    <!-- Modal -->
                    <div class="modal fade " id="modalCreateNonPlannedEvent" tabindex="-1" role="dialog" aria-labelledby="modalCreateNonPlannedEvent" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
                            <div class="modal-content shadow">
                                <div class="modal-header">
                                    <h5 class="modal-title">Add Event Plan</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="curriculum">Curriculum</label>
                                        <select v-model="curriculum" class="form-control" name="curriculum"
                                            id="curriculum">
                                            <option disabled value="">-</option>
                                            <option v-for="(curriculums, index) in curriculums" :key="index">
                                                {{curriculums}}</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="eventCycle">Event Cycle</label>
                                        <select v-model="eventCycle" class="form-control" name="eventCycle"
                                            id="eventCycle">
                                            <option disabled value="">-</option>
                                            <option v-for="(eventCycles, index) in eventCycles" :key="index">
                                                {{eventCycles}}</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                    <button type="button" class="btn btn-primary">Add</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- modal end -->


                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Vue from 'vue'
import moment from 'moment'
import ContentHeader from '@@/components/ContentHeader'
// import flatPicker from "vue-flatpickr-component";
// import "flatpickr/dist/flatpickr.css";
// Vue.use(flatPicker);

let now = new Date()
export default {
    layout : 'home',
    components : {
        ContentHeader,
        // flatPicker,
    },
    data() {
        return {
            eventTypes : ['Event 1','Event 2','Event 3'],
            learningPlans : ['Learning Plan  1','Learning Plan 2','Learning Plan 3'],
            eventOrganizers : ['Event Organizer 1','Event Organizer 2','Event Organizer 3'],
            feedbackTemplates : ['Feedback 1','Feedback 2','Feedback 3'],
            curriculums : ['Curriculum 1','Curriculum 2','Curriculum 3'],
            eventCycles : ['Event Cycle 1','Event Cycle 2','Event Cycle 3'],

            eventType: '',
            learningPlan: '',
            eventName: '',
            eventOrganizer: '',
            feedbackTemplate: '',
            eventStart: null,
            eventFinish: null,
            curriculum:'',
            eventCycle:'',

            flatPickerConfig: {
                altFormat: 'M   j, Y',
                altInput: true,
                dateFormat: 'Y-m-d',
            },
        }
    }
}
</script>
