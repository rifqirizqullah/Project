<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <div class="page-section bg-white border-bottom-2">
                <div class="container page__container">

                    <form>
                        <div class="card shadow">
                            <div class="card-header bg-info">
                                <h4 class="text-light">Add Feedback Test</h4>
                            </div>
                            <div class="card-body p-4">
                                <div class="form-group">
                                  <label for="inputPrice">Feedback Purpose</label>
                                  <input type="text" v-model="feedbackPurpose" class="form-control" name="feedbackPurpose" id="feedbackPurpose" aria-describedby="helpId" placeholder="feedback Purpose">
                                  <small id="helpId" class="form-text text-muted">feedback Purpose</small>
                                </div>
                             <div class="form-group">
                                    <label for="fType">Feedback Type</label>
                                    <select v-model="fType" class="form-control" name="fType" id="fType">
                                        <option disabled value="">-</option>
                                        <option v-for="(item, index) in feedbackType" :key="index">{{item}}</option>
                                    </select>
                                </div>
                                 <div class="form-group">
                                    <label for="fCategory">Feedback Category</label>
                                    <select v-model="fCategory" class="form-control" name="fCategory" id="fCategory">
                                        <option disabled value="">-</option>
                                        <option v-for="(item, index) in feedbackCategory" :key="index">{{item}}</option>
                                    </select>
                                </div>
                                 <div class="form-group">
                                    <label for="fTest">Feedback Test</label>
                                    <select v-model="fTest" class="form-control" name="fTest" id="fTest">
                                        <option disabled value="">-</option>
                                        <option v-for="(item, index) in feedbackTest" :key="index">{{item}}</option>
                                    </select>
                                </div>
                                <div class="form-group">
  
                                <b-card bg-variant="light">
                                <b-form-group label-cols-lg="2" label="Multiple Choice :" label-size="lg" class="mb-0">
                                <b-form-group label-cols-lg="2" label="Scale:">
                                    <b-form-select  v-model="selected" class="mb-3">
                                        <template slot="first">
                                            <option :value="null" disabled>-- Please select an option --</option>
                                        </template>
                                    <option v-for="(item, index) in csScale" :key="index">{{item}}</option>
                                    </b-form-select>
                                </b-form-group>

                                <b-form-group label-cols-lg="2" label="Lowest:">
                                    <b-form-select  v-model="selected" class="mb-3">
                                        <template slot="first">
                                            <option :value="null" disabled>-- Please select an option --</option>
                                        </template>
                                    <option v-for="(item, index) in csLowest" :key="index">{{item}}</option>
                                    </b-form-select>
                                </b-form-group>

                                <b-form-group label-cols-lg="2" label="Highest:">
                                    <b-form-select  v-model="selected" class="mb-3">
                                        <template slot="first">
                                            <option :value="null" disabled>-- Please select an option --</option>
                                        </template>
                                    <option v-for="(item, index) in cshighest" :key="index">{{item}}</option>
                                    </b-form-select>
                                </b-form-group>
                                </b-form-group>
                                </b-card>

                                </div>
                            
                            </div>

                            <div class="card-footer text-muted d-flex justify-content-end">
                                <button type="button" class="btn btn-secondary m-2">Cancel</button>
                                <button type="button" class="btn btn-success m-2">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Vue from 'vue';
import VeeValidate from 'vee-validate';
import VueSweetalert2 from 'vue-sweetalert2';
// import ContentHeader from '../../../components/ContentHeader'

Vue.use(VueSweetalert2);
Vue.use(VeeValidate);

export default {
    // components : {
    //     ContentHeader,
    // },

    data() {
        return {
         feedbackPurpose:'',
         feedbackType : [],
         feedbackTest: [],
         feedbackCategory: [],
         csScale: ['1','2',],
         csLowest: [],
         cshighest: [],
        }
    },

}
</script>
