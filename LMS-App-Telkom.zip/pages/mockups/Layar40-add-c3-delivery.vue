<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader headerTitle='Event Management' headerDescription='To manage all events that will be held'
                headerSubDescription='' />
        </div>


        <div class="navbar navbar-expand-sm navbar-dark-white bg-gradient-primary p-sm-0 ">
            <div class="container page__container">

                <!-- Navbar toggler -->
                <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                    data-target="#navbar-submenu2">
                    <span class="material-icons">people_outline</span>
                </button>

                <div class="collapse navbar-collapse" id="navbar-submenu2">
                    <div class="navbar-collapse__content pb-16pt pb-sm-0">
                        <ul class="nav navbar-nav">

                            <li class="nav-item">
                                <nuxt-link to='/learning-plan/event/add-c3' class='nav-link'>Event</nuxt-link>
                            </li>
                            <li class="nav-item">
                                <nuxt-link to='/learning-plan/event/add-c3-classroom' class='nav-link'>Classroom</nuxt-link>
                            </li>
                            <li class="nav-item">
                                <nuxt-link to='/learning-plan/event/add-c3-budget' class='nav-link'>Budget</nuxt-link>
                            </li>
                            <li class="nav-item">
                                <nuxt-link to='/learning-plan/event/add-c3-expert' class='nav-link'>Expert</nuxt-link>
                            </li>
                            <li class="nav-item">
                                <nuxt-link to='/learning-plan/event/add-c3-work' class='nav-link'>Work Order</nuxt-link>
                            </li>
                            <li class="nav-item active">
                                <nuxt-link to='/learning-plan/event/add-c3-delivery' class='nav-link'>Delivery</nuxt-link>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-section border-bottom-2">
            <div class="container page__container">
                <div class="card card-body mb-32pt">
                    <span class="h2">Delivery Schedule</span>
                    <form action="" method="POST">
                        <div class="form-group">
                            <table class="table table-responsive">
                                <thead>
                                    <tr>
                                        <th>Learning Activity Set</th>
                                        <th>Open Time</th>
                                        <th>Close Time</th>
                                        <th>Duration</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <a class="btn btn-sm btn-primary text-white" data-toggle="modal"
                                                    data-target="#myModal">
                                                    <i class="material-icons">add</i>
                                                </a>
                                                <a>Material</a>
                                            </div>

                                        <td>
                                            <div class="form-group">
                                                <flat-pickr v-model="startDate" :config="flatPickerConfig"
                                                    id="open-time" class="form-control" placeholder="Select open date"
                                                    name="opentime">
                                                </flat-pickr>

                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <flat-pickr v-model="endDate" :config="flatPickerConfigCloseTime"
                                                    id="close-time" class="form-control" placeholder="Select open date"
                                                    name="closetime">
                                                </flat-pickr>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-group">
                                                <a>1 Hour</a>
                                            </div>
                                        </td>
                                        <td></td>

                                    </tr>
                                    <tr v-for="(feedback, key) in material" :key="key">
                                        <td>{{feedback.learning_activity_set}}</td>
                                        <td>
                                            {{feedback.open_time}}
                                        </td>
                                        <td>
                                            {{feedback.close_time}}
                                        </td>
                                        <td>
                                            1 Hour
                                        </td>
                                        <td></td>

                                    </tr>

                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <a class="btn btn-sm btn-primary text-white" data-toggle="modal"
                                                    data-target="#myModal">
                                                    <i class="material-icons">add</i>
                                                </a>
                                                <a>Quiz</a>
                                            </div>
                                        <td>
                                        </td>
                                        <td>
                                        </td>
                                        <td>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr v-for="(feedback, key) in quiz" :key="key">
                                        <td>{{feedback.learning_activity_set}}</td>
                                        <td>
                                            {{feedback.open_time}}
                                        </td>
                                        <td>
                                            {{feedback.close_time}}
                                        </td>
                                        <td>

                                        </td>
                                        <td></td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <a class="btn btn-sm btn-primary text-white" data-toggle="modal"
                                                    data-target="#myModal">
                                                    <i class="material-icons">add</i>
                                                </a>
                                                <a>Assignment</a>
                                            </div>

                                        <td>
                                        </td>
                                        <td>
                                        </td>
                                        <td>
                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr v-for="(feedback, key) in assignment" :key="key">
                                        <td>{{feedback.learning_activity_set}}</td>
                                        <td>
                                            {{feedback.open_time}}
                                        </td>
                                        <td>
                                            {{feedback.close_time}}
                                        </td>
                                        <td>

                                        </td>
                                        <td></td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <a class="btn btn-sm btn-primary text-white" data-toggle="modal"
                                                    data-target="#myModal">
                                                    <i class="material-icons">add</i>
                                                </a>
                                                <a>Feedback</a>
                                            </div>

                                        <td>
                                        </td>
                                        <td>

                                        </td>
                                        <td>

                                        </td>
                                        <td></td>
                                    </tr>
                                    <tr v-for="(feedback, key) in feed" :key="key">
                                        <td>{{feedback.learning_activity_set}}</td>
                                        <td>
                                            {{feedback.open_time}}
                                        </td>
                                        <td>
                                            {{feedback.close_time}}
                                        </td>
                                        <td>

                                        </td>
                                        <td></td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <a>LIM 1</a>
                                            </div>

                                        <td>
                                        </td>
                                        <td>

                                        </td>
                                        <td>

                                        </td>
                                        <td><a data-toggle="modal" href="#myModal2" class="btn btn-secondary ">Send
                                                Notification</a>

                                            <div class="modal fade" id="myModal2">
                                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Send Notification</h4>
                                                            <button type="btn btn-sm btn-primary text-white"
                                                                class="close" data-dismiss="modal">&times;</button>
                                                        </div>

                                                        <div class="modal-body">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>NIK</th>
                                                                        <th>Participant Name</th>
                                                                        <th>Position</th>
                                                                        <th>NIK Supervisor</th>
                                                                        <th>Supervisor Name</th>
                                                                        <th>Delivery Status</th>
                                                                        <th>Send Notification</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="list">
                                                                    <tr v-for="(item, index) in sendNotif" :key="index">
                                                                        <td>{{item.nik}}</td>
                                                                        <td>{{item.participantName}}</td>
                                                                        <td>{{item.position}}</td>
                                                                        <td>{{item.nikSupervisor}}</td>
                                                                        <td>{{item.supervisorName}}</td>
                                                                        <td>{{item.status}}</td>
                                                                        <td> <i class="material-icons">mail</i></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div><!-- /.modal-content -->
                                                </div><!-- /.modal-dialog -->
                                            </div><!-- /.modal -->
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-group">
                                                <a>LIM 2</a>
                                            </div>
                                        <td>
                                        </td>
                                        <td>

                                        </td>
                                        <td>

                                        </td>
                                        <td><a data-toggle="modal" href="#myModal2" class="btn btn-secondary ">Send
                                                Notification</a>

                                            <div class="modal fade" id="myModal2">
                                                <div class="modal-dialog modal-dialog-centered modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <!-- <h4 class="modal-title">Send Notification</h4>
                                                                        <button type="button" class="close" data-dismiss="modal">&times;</button> -->
                                                        </div>

                                                        <div class="modal-body">
                                                            <table class="table">
                                                                <thead>
                                                                    <tr>
                                                                        <th>NIK</th>
                                                                        <th>Participant Name</th>
                                                                        <th>Position</th>
                                                                        <th>NIK Supervisor</th>
                                                                        <th>Supervisor Name</th>
                                                                        <th>Delivery Status</th>
                                                                        <th>Send Notification</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody class="list">
                                                                    <tr>
                                                                        <td>12345</td>
                                                                        <td>Mutiara Ulfah</td>
                                                                        <td>Senior Manager</td>
                                                                        <td>123242</td>
                                                                        <td>Aan Priyatna</td>
                                                                        <td>Sent</td>
                                                                        <td></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>12345</td>
                                                                        <td>Shintya N A</td>
                                                                        <td> Manager</td>
                                                                        <td>123242</td>
                                                                        <td>Aan Priyatna</td>
                                                                        <td>Not Sent</td>
                                                                        <td></td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="form-group">

                                                <a>Schedule</a>
                                            </div>

                                        <td>
                                        </td>
                                        <td>
                                        </td>
                                        <td>
                                        </td>
                                        <td></td>
                                    </tr>


                                </tbody>
                            </table>
                        </div>

                    </form>
                </div>

                <div class="footer float-right">
                    <nuxt-link to="/learning-plan/event/add-c3-delivery" class="btn btn-danger" data-dismiss="modal">Cancel
                    </nuxt-link>
                    <button type="submit" class="btn btn-secondary">Submit</button>

                </div>

            </div>
        </div>


    </div>

</template>
<script>
    import Vue from 'vue'
    import moment from 'moment'
    import flatPicker from "vue-flatpickr-component";
    import "flatpickr/dist/flatpickr.css";
    import ContentHeader from "@@/components/ContentHeader"
    Vue.use(flatPicker);
    let now = new Date()
    export default {
        layout: 'home',
        components: {
            flatPicker,
            ContentHeader,
        },
        data() {
            return {
                startDate: '',
                endDate: '',
                sendNotif: [{
                    nik: '-',
                    participantName: '-',
                    position: '-',
                    nikSupervisor: '-',
                    supervisorName: '-',
                    status: '-',

                }, ],
                flatPickerConfig: {
                    dateFormat: 'Y-m-d H:i',
                    enableTime: true,
                },
                flatPickerConfigCloseTime: {
                    dateFormat: 'Y-m-d H:i',
                    enableTime: true,
                },
                material: [{
                    learning_activity_set: 'Material 1',
                    open_time : '12/03/14 08:00',
                    close_time : '12/03/14 09:00',
                }],
                quiz: [{
                    learning_activity_set: '',
                    open_time : '',
                    close_time : '',
                }],
                assignment: [{
                    learning_activity_set: '',
                    open_time : '',
                    close_time : '',
                }],
                feed: [{
                    learning_activity_set: '',
                    open_time : '',
                    close_time : '',
                }],
            }

        }

    }

</script>
