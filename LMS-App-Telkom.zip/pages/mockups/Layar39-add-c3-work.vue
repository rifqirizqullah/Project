<template>
    <div class="container page-section">


        <div class="page-section bg-white border-bottom-2">
            <div class="container page__container">
                <div class="container card">
                    <div class="mb-heading d-flex align-items-end px-3">
                        <div class="flex">
                            <h4 class="card-title">Work Order</h4>
                        </div>
                        <button @click="runShowModal" class="btn btn-success btn-sm">+
                            Create Work Order</button>
                        <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                            <span class="btn-label"><i class="fa fa-search"></i> Search</span></b-button>
                    </div>
                    <div class="">
                        <div class=" text-right">
                            <div>
                                <!-- Elements to collapse -->
                                <b-collapse id="collapse-a" class="mt-2">
                                    <br>
                                    <form action="">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select
                                                        v-model="business_code" class="form-control" name="business_code" id="business_code"
                                                        :class="{ 'is-danger': errors.has('collection.business_code') }"
                                                        v-validate="'required'" data-vv-scope="collection"
                                                    >
                                                        <option v-for="(item, index) in company.list" :key="index" :value="item.business_code">{{item.company_name}}</option>
                                                    </select>
                                                    <small class="form-text text-muted">Company</small>
                                                </div>
                                            </div>
                                            <!-- <div class="col-md-3">
                                                <div class="form-group">
                                                    <select v-model="room" class="form-control" name="room"
                                                        id="room"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.room') }"
                                                        v-validate="'required'" data-vv-scope="collection">
                                                        <option v-for="(room, index) in ACDCD" :key="index"
                                                            :value="room.id">{{room.value}}
                                                        </option>

                                                    </select>
                                                    <small class="form-text text-muted">Room</small>
                                                </div>
                                            </div> -->
                                            <!-- <div class="col-md-3">
                                                <div class="form-group">
                                                    <input type="text" class="form-control" id="floor"
                                                        placeholder="Floor">
                                                </div>
                                            </div> -->
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}"
                                                        class="form-control" placeholder="Select start date" name="date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                                        v-validate="'required'" data-vv-scope="collection"> </flat-pickr>
                                                    <p v-show="errors.has('collection.begin_date')" class="help is-danger">
                                                        {{ errors.first('collection.begin_date') }}</p>

                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d'}"
                                                        class="form-control" placeholder="Select end date" name="date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                                        v-validate="'required'" data-vv-scope="collection"> </flat-pickr>
                                                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                                        {{ errors.first('collection.end_date') }}</p>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select v-model="event" class="form-control"
                                                        name="event" id="event"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.event') }"
                                                        v-validate="'required'" data-vv-scope="collection">
                                                        <option v-for="(event, index) in events" :key="index"
                                                            :value="event.event_name">
                                                            {{event.event_name}}
                                                        </option>
                                                    </select>
                                                    <small class="form-text text-muted">Event</small>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select v-model="facility" class="form-control"
                                                        name="facility" id="facility"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.facility') }"
                                                        v-validate="'required'" data-vv-scope="collection">
                                                        <option v-for="(facility, index) in facilities" :key="index"
                                                            :value="event.event_name">
                                                            <!-- {{event.event_name}} -->
                                                        </option>
                                                    </select>
                                                    <small class="form-text text-muted">Facility</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-6 col-lg-3">
                                                <div class="form-group">
                                                    <input v-model="facility_quantity" type="text" class="form-control" id="name" placeholder="Facility Quantity">
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-6 col-lg-3">
                                                <div class="form-group">
                                                    <input v-model="description" type="text" class="form-control" id="name" placeholder="Description">
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr v-model="end_date" :config="{dateFormat: 'Y-m-d'}"
                                                        class="form-control" placeholder="Select Change Date" name="date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                                        v-validate="'required'" data-vv-scope="collection"> </flat-pickr>
                                                    <p v-show="errors.has('collection.end_date')" class="help is-danger">
                                                        {{ errors.first('collection.end_date') }}</p>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <select v-model="facility" class="form-control"
                                                        name="user_changer" id="user_changer"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.user_changer') }"
                                                        v-validate="'required'" data-vv-scope="collection">
                                                        <option v-for="(user_changer, index) in users_changer" :key="index"
                                                            :value="event.event_name">
                                                            <!-- {{event.event_name}} -->
                                                        </option>
                                                    </select>
                                                    <small class="form-text text-muted">User Changer</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-12">
                                                <div class="form-group text-right">
                                                    <b-button type="button"
                                                        class="ml-3 btn btn-sm btn-labeled btn-secondary"
                                                        v-b-toggle.collapse-a>
                                                        <span class="btn-label">
                                                            Clear Search</span>
                                                    </b-button>
                                                    <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info"
                                                        v-b-toggle.collapse-a>
                                                        <span class="btn-label">
                                                            Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                        <table class="table border table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Company</th>
                                    <th>Begin Date</th>
                                    <th>End Date</th>
                                    <th>Event</th>
                                    <th>Facility</th>
                                    <th>Facility Quantity</th>
                                    <th>Description</th>
                                    <th>Change Date</th>
                                    <th>User Changer</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item , index) in works" :key="index">
                                    <td>{{index+1}}</td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                            <div class="dropdown-menu dropdown-menu-right" >
                                                <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                                <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                                <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                                <!-- <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch?type=event')">Detail</button> -->
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <b-modal v-model="modalShow" ref="saranaRequestForm" hide-footer hide-header id="saranaRequestForm" size="lg">
                        <saranaRequestForm v-if="modalShow" />
                    </b-modal>

                    <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                                placeholder="Select end date" name="date"
                                v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}" v-validate="'required'"
                                data-vv-scope="delimit"> </flat-pickr>
                            <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                                {{ errors.first('delimit.end_date') }}</p>
                        </div>
                        <div slot="modal-footer">
                            <button type="button" class="btn btn-secondary"
                                @click="$bvModal.hide('modalDelimit')">Cancel</button>
                            <!-- <button type="button" class="btn btn-primary" @click="delimitData">Save</button> -->
                        </div>
                    </b-modal>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue'
    import ContentHeader from '@@/components/ContentHeader'
    // import flatPicker from "vue-flatpickr-component";
    // import "flatpickr/dist/flatpickr.css";
    // Vue.use(flatPicker);
    import moment from 'moment'
    import {
        mapState
    } from 'vuex'

    import saranaRequestForm from '@@/components/forms/saranaRequestForm'

    let now = new Date()
    export default {
        layout: 'batch',
        components: {
            saranaRequestForm
        },
        data() {
            return {
                modalShow: false,
                modalDelimitShow: false,

                today: null,
                works: [],
                id: null,

                end_date: null,


            }
        },
        created() {
            this.$store.dispatch('company/getAll')
        },
        computed: {
            ...mapState(['company'])
        },
        methods: {
            fetchWork() {
                this.$axios.get('lms/api/listrequestsarana?begin_date_lte='+this.today+'&end_date_gte='+this.today)
                    .then(res => {
                        this.works = res.data.data
                    })
                    .catch(err => {
                        console.log(err.response);
                    })
            },
            async getData(id) {
                let data = await this.works.find(data => data.object_identifier == id);

            },

            runShowModal() {
                this.$bvModal.show('saranaRequestForm')
            }
        }
    }

</script>
