<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader
                headerTitle='My Event'
                headerDescription='740106 - AAN PRIYATNA'
                headerSubDescription= 'Telkom Corporate Unv'
            />
            <div class="container page__container page-section">
                <div class="mb-heading d-flex align-items-end">
                    <div class="flex">
                        <h4 class="card-title">Quiz</h4>
                    </div>
                    <p>00 : 25 : 00</p>
                </div>
                <div class="card p-24pt mb-32pt" style="overflow-y: scroll;">
                    <h3 style="text-align: center;">Quiz 1</h3>
                    <p>
                        1. Apakah ....................................?<br>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios1" id="exampleRadios1" value="option1">
                            <label class="form-check-label" for="A">
                                A. PHP
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios1" id="exampleRadios2" value="option2">
                            <label class="form-check-label" for="B">
                                B. Framework
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios1" id="exampleRadios3" value="option3">
                            <label class="form-check-label" for="C">
                                C. HTML
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios1" id="exampleRadios4" value="option4">
                            <label class="form-check-label" for="D">
                                D. Java
                            </label>
                        </div>
                    </p>
                    <p>
                        2. Apakah ....................................?<br>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1">
                            <label class="form-check-label" for="A">
                                A. PHP
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                            <label class="form-check-label" for="B">
                                B. Framework
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios3" value="option3">
                            <label class="form-check-label" for="C">
                                C. HTML
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios4" value="option4">
                            <label class="form-check-label" for="D">
                                D. Java
                            </label>
                        </div>
                    </p>
                    <p>
                        3. Apakah ....................................?<br>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios3" id="exampleRadios1" value="option1">
                            <label class="form-check-label" for="A">
                                A. PHP
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios3" id="exampleRadios2" value="option2">
                            <label class="form-check-label" for="B">
                                B. Framework
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios3" id="exampleRadios3" value="option3">
                            <label class="form-check-label" for="C">
                                C. HTML
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios4" value="option4">
                            <label class="form-check-label" for="D">
                                D. Java
                            </label>
                        </div>
                    </p>
                    <div class="text-muted d-flex justify-content-end">
                        <button class="btn btn-primary mr-2"><< Back</button>
                        <button class="btn btn-primary mr-4">Next >></button>
                    </div>
                   <div class="card-footer text-center">
                        <button type="button" class="btn btn-secondary m-2">Cancel</button>
                        <button type="button" class="btn btn-success m-2" @click="saveData()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Vue from 'vue';
import ContentHeader from '@@/components/ContentHeader'
export default {
    layout : 'home',
    components : {
        ContentHeader,
    },
}
</script>
