<template>
    <div>
        <video-player
                ref="videoPlayer"
                :options="playerOptions"
                :playsinline="true"
        >
        </video-player>
    </div>
</template>


<script>
    import { videoPlayer } from 'vue-video-player'
    import 'video.js/dist/video-js.css'
    import 'vue-video-player/src/custom-theme.css'


    export default {
        name: 'foo',

        components: {
            videoPlayer,
        },

        data () {
            return {
                playerOptions: {
                    muted: true,
                    language: 'en',
                    techOrder: ['html5', 'flvjs'],
                    playbackRates: [0.7, 1.0, 1.5, 2.0],
                    width: '800px',
                    height: '800px',
                    plugins: {

                    },


                    sources: [{
                        type: "video/mp4",
                        src: "https://cdn.theguardian.tv/webM/2015/07/20/150716YesMen_synd_768k_vp8.webm"
                    }],

                    poster: "/static/images/defaults/image.png",
                },


            }
        },
    }
</script>
