<template>
    <div class="container page-section">


        <div class="page-section bg-white border-bottom-2">
            <div class="container page__container">
                <div class="container card">
                    <div class="mb-heading d-flex align-items-end px-3">
                        <div class="flex">
                            <h4 class="card-title">Classroom Session</h4>
                        </div>
                        <button class="btn btn-sm btn-success" @click="$bvModal.show('sessionForm')">+
                            Create Classroom</button>
                        <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                            <span class="btn-label"><i class="fa fa-search"></i> Search</span>
                        </b-button>
                    </div>

                    <div class="">
                        <div class=" text-right">
                            <div>
                                <b-collapse id="collapse-a" class="mt-2">
                                    <form class="p-2">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input type="text" class="form-control"
                                                        id="exampleFormControlInput1" placeholder="Session Name">
                                                    <small class="form-text text-muted">Session Name</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <select class="form-control" name="learning_activity"
                                                        id="learning_activity">
                                                        <option></option>
                                                    </select>
                                                    <small class="form-text text-muted">learning Activity</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}"
                                                        class="form-control" placeholder="Select start date"
                                                        name="begin_date" id="begin_date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                                        v-validate="'required'" data-vv-scope="collection" />
                                                    <small class="form-text text-muted">Start Date</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr v-model="end_date"
                                                        :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                                        class="form-control" placeholder="Select end date"
                                                        name="end_date" id="end_date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                                        v-validate="'required'" data-vv-scope="collection" />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div>

                                            <div class="col-sm-12 col-md-12">
                                                <div class="form-group text-right">
                                                    <b-button type="button"
                                                        class="ml-3 btn btn-sm btn-labeled btn-secondary"
                                                        v-b-toggle.collapse-a>
                                                        <span class="btn-label">
                                                            Clear Search</span>
                                                    </b-button>
                                                    <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info"
                                                        v-b-toggle.collapse-a>
                                                        <span class="btn-label">
                                                            Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                    </div>
                    <!-- table -->
                    <div class="table">
                        <table class="table table-border table-responsive">
                            <thead class="thead">
                                <tr>
                                    <th>No</th>
                                    <th>Session Name</th>
                                    <th>Learning Activity</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white">
                                <tr v-for="(data, index) in classroom" :key="index">
                                    <td>{{data.No}}</td>
                                    <td>{{data.Session_Name}}</td>
                                    <td>{{data.Learning_Activity}}</td>
                                    <td>{{data.Start_Date}}</td>
                                    <td>{{data.End_Date}}</td>

                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button"
                                                id="triggerId" data-toggle="dropdown" aria-haspopup="true"
                                                aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                                <button class="dropdown-item"
                                                    @click="showUpdateForm(item)">Update</button>
                                                <button class="dropdown-item"
                                                    @click="deleteData(item, index)">Delete</button>

                                            </div>
                                        </div>

                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

        <!-- Start Modal -->

        <b-modal v-model="modalShow" ref="sessionForm" hide-footer hide-header id="sessionForm" size="lg">
            <sessionForm v-if="modalShow" />
        </b-modal>
        <!-- End Modal -->
    </div>

</template>

<script>
    import Vue from 'vue'
    import ContentHeader from '@@/components/ContentHeader'
    import sessionForm from '@@/components/forms/sessionForm'

    let now = new Date()
    export default {
        layout: 'batch',
        components: {
            ContentHeader,
            sessionForm,
        },
        data() {
            return {
                modalShow: false,
                classroom: [{
                        No: '1',
                        Session_Name: 'Session 1',
                        Learning_Activity: 'Learning 1',
                        Start_Date: '18 Mei 2019',
                        End_Date: '21 Mei 2019',
                    },
                    {
                        No: '2',
                        Session_Name: 'Session 2',
                        Learning_Activity: 'Learning 2',
                        Start_Date: '18 Mei 2019',
                        End_Date: '21 Mei 2019',
                    },
                    {
                        No: '3',
                        Session_Name: 'Session 3',
                        Learning_Activity: 'Learning 3',
                        Start_Date: '18 Mei 2019',
                        End_Date: '21 Mei 2019',
                    },
                ],

                flatPickerConfig: {
                    altFormat: 'M   j, Y',
                    altInput: true,
                    dateFormat: 'Y-m-d',
                },
            }
        },
        methods: {
            deleteData(id, index) {
                this.$swal({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                })

            },
            showUpdateForm() {
                this.$bvModal.show('sessionForm')
            },
        }
    }

</script>

