<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <div class="page-section bg-gray">
                <div class="container page__container">

                    <div class="card">
                        <div class="card-header bg-info">
                            <h4 class="card-title text-light">Manage Question</h4>
                            <div class="text-right">
                                <button type="button" class="btn btn-success btn-sm" @click="showModal">
                                    + Add Question
                                </button>
                                <button type="button" class="btn btn-success btn-sm">
                                    Upload Question
                                </button>
                            </div>
                        </div>
                        <div class="card-body">

                            <table class="table border table-responsive">
                                <thead class="thead-light">
                                    <tr>
                                        <th>Question Name</th>
                                        <th>Question Type</th>
                                        <th>Question Text</th>
                                        <th>Question Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(question, index) in questions" :key="index">
                                        <td>{{ question.name }}</td>
                                        <td>{{ question.type }}</td>
                                        <td>{{ question.text }}</td>
                                        <td>{{ question.image }}</td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                                    <a class="dropdown-item" @click="editData()">Edit</a>
                                                    <a class="dropdown-item" @click="delimitData()">Delimit</a>
                                                    <a class="dropdown-item" @click="deleteData()">Delete</a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <ul class="mt-4 pagination justify-content-center pagination-sm">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true" class="material-icons">chevron_left</span>
                                        <span>Prev</span>
                                    </a>
                                </li>
                                <li class="page-item active">
                                    <a class="page-link" href="#" aria-label="1">
                                        <span>1</span>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="1">
                                        <span>2</span>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Next">
                                        <span>Next</span>
                                        <span aria-hidden="true" class="material-icons">chevron_right</span>
                                    </a>
                                </li>
                            </ul>

                        </div>
                        <div class="card-footer text-muted">
                            Footer
                        </div>
                    </div>

                    <!-- Start Modal -->
                    <b-modal ref="my-modal" hide-footer size="lg" title="Add New Question">
                        <!-- <div class="modal-header">
                            <h5 class="modal-title">Edit Learning Activity</h5>
                            <button type="button" class="close" aria-label="Close" @click="closeFormModal">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div> -->
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="mainCompetency">Competency</label>
                                <select v-model="mainCompetency" class="form-control" name="mainCompetency"
                                    id="mainCompetency" v-bind:class="{ 'is-danger': errors.has('collection.mainCompetency') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <!-- <option disabled value="">-</option> -->
                                    <option v-for="(competencies, index) in CMPTY" :key="index" :value="competencies.id">
                                        {{competencies.value}}
                                    </option>
                                </select>
                                <p v-show="errors.has('collection.mainCompetency')" class="help is-danger">{{ errors.first('collection.mainCompetency') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="proficiencyLevel">Proficiency Level</label>
                                <select v-model="proficiencyLevel" class="form-control" name="proficiencyLevel"
                                    id="proficiencyLevel" v-bind:class="{ 'is-danger': errors.has('collection.proficiencyLevel') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <!-- <option disabled value="">-</option> -->
                                    <option v-for="(proficiencyLevel, index) in PLCOD" :key="index" :value="proficiencyLevel.id">
                                        {{proficiencyLevel.value}}</option>
                                </select>
                                <p v-show="errors.has('collection.proficiencyLevel')" class="help is-danger">{{ errors.first('collection.proficiencyLevel') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="questionName">Question Name</label>
                                <input v-model="questionName" type="text" name="questionName"
                                    id="questionName" class="form-control" placeholder="questionName"
                                    aria-describedby="questionName" v-bind:class="{ 'is-danger': errors.has('collection.questionName')}"
                                    v-validate="'required'" data-vv-scope="collection">
                                <p v-show="errors.has('collection.questionName')" class="help is-danger"> {{ errors.first('collection.questionName') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="questionType">Question Type</label>
                                <select v-model="questionType" class="form-control" name="questionType"
                                    id="questionType" v-bind:class="{ 'is-danger': errors.has('collection.questionType') }"
                                    v-validate="'required'" data-vv-scope="collection">
                                    <!-- <option disabled value="">-</option> -->
                                    <option v-for="(questionTypes, index) in questionTypes" :key="index">{{questionTypes}}
                                        </option>
                                </select>
                                <p v-show="errors.has('collection.questionType')" class="help is-danger">{{ errors.first('collection.questionType') }}</p>
                            </div>
                            <div class="form-group">
                                <label for="questionText">Question Text</label>
                                <input v-model="questionText" type="text" name="questionText"
                                    id="questionText" class="form-control" placeholder="questionText"
                                    aria-describedby="questionText" v-bind:class="{ 'is-danger': errors.has('collection.questionText')}"
                                    v-validate="'required'" data-vv-scope="collection">
                                <p v-show="errors.has('collection.questionText')" class="help is-danger"> {{ errors.first('collection.questionText') }}</p>
                            </div>
                            <div class="card">
                                <label for="">Answer Options</label>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="answerA">A</label>
                                            <input v-model="answerA" type="text" name="answerA"
                                                id="answerA" class="form-control" placeholder="answerA"
                                                aria-describedby="answerA" v-bind:class="{ 'is-danger': errors.has('collection.answerA')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.answerA')" class="help is-danger"> {{ errors.first('collection.answerA') }}</p>
                                        </div>
                                        <div class="form-group col-6">
                                            <label for="scoreA">Score</label>
                                            <input v-model="scoreA" type="text" name="scoreA" @keypress="onlyNumber"
                                                id="scoreA" class="form-control" placeholder="%"
                                                aria-describedby="scoreA" v-bind:class="{ 'is-danger': errors.has('collection.scoreA')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.scoreA')" class="help is-danger"> {{ errors.first('collection.scoreA') }}</p>
                                        </div>    
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="answerB">B</label>
                                            <input v-model="answerB" type="text" name="answerB"
                                                id="answerB" class="form-control" placeholder="answerB"
                                                aria-describedby="answerB" v-bind:class="{ 'is-danger': errors.has('collection.answerB')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.answerB')" class="help is-danger"> {{ errors.first('collection.answerB') }}</p>
                                        </div>
                                        <div class="form-group col-6">
                                            <label for="scoreB">Score</label>
                                            <input v-model="scoreB" type="text" name="scoreB" @keypress="onlyNumber"
                                                id="scoreB" class="form-control" placeholder="%"
                                                aria-describedby="scoreB" v-bind:class="{ 'is-danger': errors.has('collection.scoreB')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.scoreB')" class="help is-danger"> {{ errors.first('collection.scoreB') }}</p>
                                        </div>    
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="answerC">C</label>
                                            <input v-model="answerC" type="text" name="answerC"
                                                id="answerC" class="form-control" placeholder="answerC"
                                                aria-describedby="answerC" v-bind:class="{ 'is-danger': errors.has('collection.answerC')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.answerC')" class="help is-danger"> {{ errors.first('collection.answerC') }}</p>
                                        </div>
                                        <div class="form-group col-6">
                                            <label for="scoreC">Score</label>
                                            <input v-model="scoreC" type="text" name="scoreC" @keypress="onlyNumber"
                                                id="scoreC" class="form-control" placeholder="%"
                                                aria-describedby="scoreC" v-bind:class="{ 'is-danger': errors.has('collection.scoreC')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.scoreC')" class="help is-danger"> {{ errors.first('collection.scoreC') }}</p>
                                        </div>    
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="answerD">D</label>
                                            <input v-model="answerD" type="text" name="answerD"
                                                id="answerD" class="form-control" placeholder="answerD"
                                                aria-describedby="answerD" v-bind:class="{ 'is-danger': errors.has('collection.answerD')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.answerD')" class="help is-danger"> {{ errors.first('collection.answerD') }}</p>
                                        </div>
                                        <div class="form-group col-6">
                                            <label for="scoreD">Score</label>
                                            <input v-model="scoreD" type="text" name="scoreD" @keypress="onlyNumber"
                                                id="scoreD" class="form-control" placeholder="%"
                                                aria-describedby="scoreD" v-bind:class="{ 'is-danger': errors.has('collection.scoreD')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.scoreD')" class="help is-danger"> {{ errors.first('collection.scoreD') }}</p>
                                        </div>    
                                    </div>
                                    <div class="row">
                                        <div class="form-group col-6">
                                            <label for="answerE">E</label>
                                            <input v-model="answerE" type="text" name="answerE" 
                                                id="answerE" class="form-control" placeholder="answerE"
                                                aria-describedby="answerE" v-bind:class="{ 'is-danger': errors.has('collection.answerE')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.answerE')" class="help is-danger"> {{ errors.first('collection.answerE') }}</p>
                                        </div>
                                        <div class="form-group col-6">
                                            <label for="scoreE">Score</label>
                                            <input v-model="scoreE" type="text" name="scoreE" @keypress="onlyNumber"
                                                id="scoreE" class="form-control" placeholder="%"
                                                aria-describedby="scoreE" v-bind:class="{ 'is-danger': errors.has('collection.scoreE')}"
                                                v-validate="'required'" data-vv-scope="collection">
                                            <p v-show="errors.has('collection.scoreE')" class="help is-danger"> {{ errors.first('collection.scoreE') }}</p>
                                        </div>    
                                    </div>
                                    
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="questionImage">
                                    Question Image
                                </label>
                                <div class="custom-file row ml-2 col-md-3">
                                    <input type="file" class="custom-file-input col-md-9 pl-5" id="validatedCustomFile" required>
                                    <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" @click="closeFormModal">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="saveData">Save</button>
                        </div>
                    </b-modal>
                    <!-- End Modal -->

                    <!-- Start Delimit Modal -->
                    <b-modal ref="my-modal-delimit" hide-footer size="lg" title="Delimit Activity Learning">
                        <!-- <div class="modal-header">
                            <h5 class="modal-title">Delimit Curriculum</h5>
                            <button type="button" class="close" aria-label="Close" @click="closeFormModalDelimit">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div> -->
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="endDate">End Date</label>
                                <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                    placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.endDate')}"
                                    v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                                    <p v-show="errors.has('delimit.endDate')" class="help is-danger"> {{ errors.first('delimit.endDate') }}</p>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" @click="closeFormModalDelimit">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="delimitDataSave()">Save</button>
                        </div>
                    </b-modal>
                    <!-- End Delimit Modal -->
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import moment from 'moment'
import Vue from 'vue';
import VeeValidate from 'vee-validate';
import VueSweetalert2 from 'vue-sweetalert2';
import ContentHeader from '@@/components/ContentHeader'

Vue.use(VueSweetalert2);
Vue.use(VeeValidate);

export default {
    layout: 'learning-activity',

    data() {
        return {
            questions: [{
                name : 'Python',
                type : 'Multiple Choices',
                text : 'Python is it a kind of Snake?',
                image : 'Python-wallpaper.jpg',
            }],

            questionTypes : ['Multiple Choices','Essay','True or false'],

            learningActivities: [],
            id:null,
            object_id:null,
            startDate: null,
            endDate: null,
            learningActivityName:'',
            cycle:null,
            type:null,
            flag_online:null,
            event_number:null,
            today: null,
            flatPickerConfig: {
                altFormat: 'M	j, Y',
                altInput: true,
                dateFormat: 'Y-m-d',
            },
            ACTTY:[],
            CYCLE : [],
            buscd:this.$auth.user,
            // curriculum_id: this.$route.query.id
        }
    },
   created(){
        this.getToday();
        this.getData()
        this.getACCTY();
        this.getCYCLE();
        this.getPLCOD();
        this.getCMPTY();

    },
    methods: {
        getData() {
          this.$axios.get('lms/api/learningactivity?begin_date_lte='+this.today+'&end_date_gte='+this.today)
              .then(res => {
                this.learningActivities =[];
                res.data.data.forEach(async (data, key) => {
                    await this.learningActivities.push({
                        activity_id: data.activity_id,
                        object_identifier: data.object_identifier,
                        activity_name: data.activity_name,
                        buscd : data.business_code,
                        cycle : data.cycle,
                        activity_type : data.activity_type,
                        begin_date : data.begin_date,
                        end_date : data.end_date,
                        flag_online : data.flag_online,
                        event_number : data.event_number,
                        // curriculum : data.curriculum
                    })
                });
              })
              .catch(err => {
                  console.log(err.response);
              })
        },
        getToday(){
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth()+1;
            var yyyy = today.getFullYear();
            if(dd<10)
            {
                dd='0'+dd;
            }

            if(mm<10)
            {
                mm='0'+mm;
            }
            this.today = yyyy+'-'+mm+'-'+dd;
        },
        getACCTY() {
            this.$axios.get('ldap/api/objects?object_type=ACTTY')
            .then(response => {
                this.ACTTY = [];
                response.data.data.forEach(async (data, key) => {
                    await this.ACTTY.push({
                    id: data.id,
                    value: data.value,
                    })
                });
            })
            .catch(e => {
                console.log(e);
            });
        },
        getCYCLE() {
            this.$axios.get('ldap/api/objects?object_type=CYCLE')
            .then(response => {
                this.CYCLE = [];
                response.data.data.forEach(async (data, key) => {
                    await this.CYCLE.push({
                    id: data.id,
                    value: data.value,
                    })
                });
            })
            .catch(e => {
                console.log(e);
            });
        },
        getPLCOD() {
            this.$axios.get('ldap/api/objects?object_type=PLCOD')
                .then(response => {
                    this.PLCOD = [];
                    response.data.data.forEach(async (data, key) => {
                        await this.PLCOD.push({
                            id: data.id,
                            value: data.value,
                        })
                    });
                })
                .catch(e => {
                    console.log(e);
                });
        },
        getCMPTY() {
            this.$axios.get('ldap/api/objects?object_type=CMPTY')
                .then(response => {
                    this.CMPTY = [];
                    response.data.data.forEach(async (data, key) => {
                        await this.CMPTY.push({
                            id: data.id,
                            value: data.value,
                        })
                    });
                })
                .catch(e => {
                    console.log(e);
                });
        },
        editData(id) {
            this.showModal();
            this.getDataDetail(id);
        },
        async getDataDetail(id) {
            let data = await this.learningActivities.find(data => data.object_identifier == id);
            this.id = data.activity_id;
            this.object_id= data.object_identifier;
            this.startDate= data.begin_date;
            this.endDate= data.end_date;
            this.learningActivityName= data.activity_name;
            this.cycle           = data.cycle.id;
            this.type   = data.activity_type.id,
            this.flag_online= data.flag_online;
            this.event_number= data.event_number;
        },
        delimitData(id){
            this.showModalDelimit();
            this.getDataDetail(id);
        },
        saveData() {
            this.id ? this.updateData(this.id) : this.storeData();
        },
        storeData() {
            this.$validator.validateAll('collection').then(async result => {
            if (!result) return;
            this.$axios.post('lms/api/learningactivity',
                {
                    begin_date      : this.startDate,
                    end_date        : this.endDate,
                    business_code   : "1000",
                    activity_name   : this.learningActivityName,
                    // curriculum      : this.curriculum_id,
                    cycle           : this.cycle,
                    activity_type   : this.type,
                    flag_online     : this.flag_online,
                    event_number    : this.event_number
                })
                .then(response => {
                this.getData();
                this.closeFormModal();
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )

                })
                .catch(e => {
                console.log(e);
                });
            });
        },
        updateData() {
            this.$validator.validateAll('collection').then(async result => {
            if (!result) return;
            this.$axios.put('lms/api/learningactivity',
                {
                    object_identifier: this.object_id,
                    begin_date      : this.startDate,
                    end_date        : this.endDate,
                    business_code   : "1000",
                    activity_id     : this.id,
                    activity_name   : this.learningActivityName,
                    // curriculum      : this.curriculum_id,
                    cycle           : this.cycle,
                    activity_type   : this.type,
                    flag_online     : this.flag_online,
                    event_number    : this.event_number
                })
                .then(response => {
                this.getData();
                this.closeFormModal();
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )

                })
                .catch(e => {
                console.log(e);
                });
            });
        },
        delimitDataSave() {
            this.$validator.validateAll('delimit').then(async result => {
            if (!result) return;
            this.$axios.patch('lms/api/learningactivity?end_date='+this.endDate+'&object_identifier=' + this.object_id)
                .then(response => {
                this.getData();
                this.closeFormModalDelimit();
                this.$swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )

                })
                .catch(e => {
                console.log(e);
                });
            });
        },
        deleteData(id, key) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/learningactivity?object_identifier=' + id)
                    .then(response => {
                        this.$swal(
                        'Deleted!',
                        response.data.message,
                        'success'
                        )
                    })
                    .catch(e => {
                        console.log(e);
                    })
                    .then(() => {
                        this.removeData(key);
                    })
                }
            });
        },
        removeData(key) {
            this.learningActivities.splice(key, 1);
        },
        showModal() {
            this.$refs['my-modal'].show()
        },
        hideModal() {
            this.$refs['my-modal'].hide()
        },
        showModalDelimit() {
            this.$refs['my-modal-delimit'].show()
        },
        hideModalDelimit() {
            this.$refs['my-modal-delimit'].hide()
        },
        onlyNumber($event) {
            let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
            if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
                $event.preventDefault();
            }
        },
        closeFormModal(){
            this.hideModal()
            this.id= null;
            this.object_id=null;
            this.startDate= null;
            this.endDate= null;
            this.learningActivityName='';
            this.cycle=null;
            this.type=null;
            this.flag_online=null;
            this.event_number=null;
            this.$nextTick(() => this.$validator.reset());
        },
        closeFormModalDelimit(){
            this.hideModalDelimit()
            this.id= null;
            this.object_id=null;
            this.startDate= null;
            this.endDate= null;
            this.learningActivityName='';
            this.cycle=null;
            this.type=null;
            this.flag_online=null;
            this.event_number=null;
            this.$nextTick(() => this.$validator.reset());
        },
        moment(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
