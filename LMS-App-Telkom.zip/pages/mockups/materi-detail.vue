<template>
    <div class="container page-section">

        <b><p style="font-size:20px">Materi Detail</p></b>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">Materi Name</h3>
                </div>
                <div class="row card-body">
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Type</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>Materi Tertutup</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Method</p></b>
                            </div>
                            <div class="col-sm-8">
                                 <p>Lecturing</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Competence</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>KOMPETENSI 1</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Proficiency Level</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>Basic</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Selling Price</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>Rp 20.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Purchase Price</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>Rp 30.000</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Link</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>materi.pdf     <i class="fa fa-download"></i></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-8 col-md-8">
                        <div class="row">
                            <div class="col-sm-4">
                                <b><p>Description</p></b>
                            </div>
                            <div class="col-sm-8">
                                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</template>
<script>
    export default {
        layout: 'home',
        components: {
            
        },
        data() {
            return {
                
            }
        }

    }

</script>
