<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader
                headerTitle='My Event'
                headerDescription='740106 - AAN PRIYATNA'
                headerSubDescription= 'Telkom Corporate Unv'
            />

            <div class="page-section border-bottom-2">
                <div class="container page__container">
                    <div class="card shadow">
                        <div class="card-header bg-info">
                            <h4 class="text-light">Feedback</h4>
                        </div>
                        <div class="text-center mt-5">
                            <h2>Student Feedback</h2>
                        </div>
                        <div class="container page__container mb-5">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="management-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Penyelenggaraan</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="material-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Material</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="trainer-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Trainer</a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="management-tab">
                                    <div class="card-body p-4">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="text-center mb-3">
                                                    <h3>Management Feedback</h3>
                                                </div>
                                                <table class="table table-responsive">
                                                    <thead class="thead-light" align="center">
                                                        <tr>
                                                            <th>Question</th>
                                                            <th>Range of Values</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody align="center">
                                                        <tr>
                                                            <td>Is it?</td>
                                                            <td>
                                                                <div class="radio">
                                                                    <label>Low</label>
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <label>High</label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Apakah?</td>
                                                            <td>
                                                                <div class="radio">
                                                                    <label>Low</label>
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <label>High</label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <div class="text-center mb-3">
                                                    <h3>Suggestion</h3>
                                                </div>
                                                <textarea name="content" id="editor" class="shadow container" placeholder="input your suggestion here..">
                                                </textarea>

                                            </div>
                                        </div>
                                        <button type="button" class="btn btn-accent float-right" data-dismiss="modal">Back</button>
                                        <button type="submit" class="btn btn-primary float-right mr-3" value="Submit">Submit</button>
                                    </div>

                                </div>
                                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="material-tab">
                                    <div class="card-body p-4">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="text-center mb-3">
                                                    <h3>Material Feedback</h3>
                                                </div>
                                                <table class="table table-responsive">
                                                    <thead class="thead-light" align="center">
                                                        <tr>
                                                            <th>Question</th>
                                                            <th>Range of Values</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody align="center">
                                                        <tr>
                                                            <td>Is it?</td>
                                                            <td>
                                                                <div class="radio">
                                                                    <label>Low</label>
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <label>High</label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Apakah?</td>
                                                            <td>
                                                                <div class="radio">
                                                                    <label>Low</label>
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <label>High</label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <div class="text-center mb-3">
                                                    <h3>Suggestion</h3>
                                                </div>
                                                <textarea name="content" id="editor" class="container shadow" placeholder="input your suggestion here..">
                                                </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-accent float-right" data-dismiss="modal">Back</button>
                                    <button type="submit" class="btn btn-primary float-right mr-3" value="Submit">Submit</button>
                                </div>
                                <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="trainer-tab">
                                    <div class="card-body p-4">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="text-center mb-3">
                                                    <h3>Trainer Feedback</h3>
                                                </div>
                                                <table class="table table-responsive">
                                                    <thead class="thead-light" align="center">
                                                        <tr>
                                                            <th colspan="2">Trainer Name: Aan Priyatna</th>
                                                        </tr>
                                                        <tr>
                                                            <th>Question</th>
                                                            <th>Range of Values</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody align="center">
                                                        <tr>
                                                            <td>Is it?</td>
                                                            <td>
                                                                <div class="radio">
                                                                    <label>Low</label>
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <label>High</label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Apakah?</td>
                                                            <td>
                                                                <div class="radio">
                                                                    <label>Low</label>
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <label>High</label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <table class="table table-responsive">
                                                    <thead class="thead-light" align="center">
                                                        <tr>
                                                            <th colspan="2">Trainer Name: Hikmat</th>
                                                        </tr>
                                                        <tr>
                                                            <th>Question</th>
                                                            <th>Range of Values</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody align="center">Material
                                                        <tr>
                                                            <td>Is it?</td>
                                                            <td>
                                                                <div class="radio">
                                                                    <label>Low</label>
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <input type="radio" name="optradio">
                                                                    <label>High</label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>Apakah?</td>
                                                            <td>
                                                                <div class="radio">
                                                                    <label>Low</label>
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <input type="radio" name="optradio1">
                                                                    <label>High</label>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <div class="text-center mb-3">
                                                    <h3>Suggestion</h3>
                                                </div>
                                                <textarea name="content" id="editor" class="container shadow" placeholder="input your suggestion here..">
                                                </textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <button type="button" class="btn btn-accent float-right" data-dismiss="modal">Back</button>
                                    <button type="submit" class="btn btn-primary float-right mr-3" value="Submit">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
import Vue from 'vue';
import ContentHeader from '@@/components/ContentHeader'
export default {
    layout : 'home',

    components : {
        ContentHeader,
    },
}
</script>
