<template>

    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader headerTitle='My Event' headerDescription='In Class Learning'
                headerSubDescription='Telkom Corporate Unv' />

        </div>
        <div class="page-section container page__container">
            <div class="container page__container">
                <div>
                    <b-card>
                        <div>
                            <h4>Online Communities</h4>
                        </div>
                        <br>
                        <div id="app">
                            <vue-editor v-model="content" placeholder="What do you think?"></vue-editor>
                        </div>
                        <br>
                        <div class="row text-center">
                            <div class="col-md-5">
                            </div>
                            <div class="col-md-7">
                                <div class="row text-center">
                                    <div class="col-sm-3">
                                        <button v-on:click="publishDisplay" type="button" class="btn btn-primary">
                                            Publish
                                        </button>
                                    </div>
                                    <div class="col-sm-3">
                                         <button v-on:click="saveDisplay" type="button" class="btn btn-primary" data-toggle="modal">
                                            Save
                                        </button>
                                    </div>
                                    <div class="col-sm-3">
                                         <button type="button" class="btn btn-primary" data-toggle="modal">
                                            Preview
                                        </button>
                                    </div>
                                    <div class="col-sm-3">
                                         <button type="button" class="btn btn-primary" data-toggle="modal">
                                            Give Feedback
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </b-card>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
 import ContentHeader from '@@/components/ContentHeader.vue'
    import {
        VueEditor
    } from 'vue2-editor'
    export default {
        components: {
            VueEditor,
            ContentHeader,
        },
        data() {
            return {
                content: ''
            }
        },
        methods: {
            publishDisplay() {
                this.$swal({
                title: 'Are you sure?',
                text: 'Do you want to publish this?',
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, publish it!',
                cancelButtonText: 'No, i still want to edit this!',
                showCloseButton: true,
                showLoaderOnConfirm: true
                }).then((result) => {
                    if(result.value) {
                        this.$swal('Published!', 'You successfully published this article!', 'success')
                    } else {
                        this.$swal('Cancelled', 'Go on to edit your article', 'info')
                    }
                })
            },
            saveDisplay() {
                this.$swal({
                title: 'Are you sure?',
                text: 'Do you want to save this?',
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, save it!',
                cancelButtonText: 'No, i still want to edit this!',
                showCloseButton: true,
                showLoaderOnConfirm: true
                }).then((result) => {
                    if(result.value) {
                        this.$swal('Saved!', 'You successfully saved this article!', 'success')
                    } else {
                        this.$swal('Cancelled', 'Go on to edit your article', 'info')
                    }
                })
            }

        }
    }

</script>

<style>

</style>
