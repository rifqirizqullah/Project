<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader headerTitle='Event Management' headerDescription='To manage all events that will be held'
                headerSubDescription='' />
            <div class="bg-gradient-primary border-bottom-white py-32pt">
                <div class="container d-flex flex-column flex-md-row align-items-center text-center text-md-left">

                </div>
            </div>
            <div class="page-section border-bottom-2">

                <div class="container page__container">
                    <div class="card p-24pt col-md-6">
                        <div>
                            <h3>Manage Expert Assignment</h3>
                        </div>
                        <br>
                        <table class="table table-responsive">
                            <tr>
                                <td>
                                    Event Name
                                </td>
                                <td>
                                    :
                                </td>
                                <td>
                                    <input type="text" name="title" maxlength="255"
                                        class="textinput textInput form-control" required id="event_name">
                                </td>
                            </tr>
                            <br>
                            <tr>
                                <td>
                                    Start Date
                                </td>
                                <td>
                                    :
                                </td>
                                <td>
                                    <flat-pickr v-model="startDate" :config="flatPickerConfig" id="beginDate"
                                        class="form-control" placeholder="Select begin date" name="begindate">
                                    </flat-pickr>
                                </td>
                            </tr>
                            <br>
                            <tr>
                                <td>
                                    End Date
                                </td>
                                <td>
                                    :
                                </td>
                                <td>
                                    <flat-pickr v-model="endDate" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select end date" name="enddate"> </flat-pickr>
                                </td>
                            </tr>
                            <br>
                            <tr>
                                <td>
                                    Status Assignment
                                </td>
                                <td>
                                    :
                                </td>
                                <td>
                                    <div for="set_type" class="col-20 mb-9">
                                        <select v-model="set_type" class="form-control" name="set_type" id="set_type">
                                            <option value="">----</option>
                                            <option v-for="(set_type, index) in set_types" :key="index">{{set_type}}
                                            </option>
                                        </select>
                                    </div>
                                </td>
                            </tr>

                        </table>
                    </div>
                    <div class="card">

                        <div class="card-header">
                            <div class="search-form search-form--light mx-2 mb-16pt float-right">
                                <input type="text" class="form-control" placeholder="Search" id="searchSample03">
                                <button class="btn" type="button" role="button"><i
                                        class="material-icons">search</i></button>
                            </div>

                        </div>


                        <div class="card-body">


                            <div class="table" data-toggle="lists" data-lists-values='["name"]'>
                                <table class="table table-responsive">

                                    <thead>
                                        <tr>
                                            <th>Event</th>
                                            <th>Curriculum Title</th>
                                            <th>Location</th>
                                            <th>Academy</th>
                                            <th>Start</th>
                                            <th>End</th>
                                            <th>Onsite/Online</th>
                                            <th>Status Event</th>
                                            <th>Status Assigment</th>
                                            <th>Expert Name</th>

                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody class="list">
                                        <tr v-for="(item, index) in expertAssigment" :key="index">
                                            <td>{{item.event}}</td>
                                            <td>{{item.curriculumTitle}}</td>
                                            <td>{{item.location}}</td>
                                            <td>{{item.academy}}</td>
                                            <td>{{item.start}}</td>
                                            <td>{{item.end}}</td>
                                            <td>{{item.onsiteOnline}}</td>
                                            <td>{{item.statusEvent}}</td>
                                            <td>{{item.statusAssigment}}</td>
                                            <td>{{item.expertName}}</td>

                                            <td>
                                                <div class="nav-item dropdown d-none d-sm-flex">
                                                    <a href="#" data-toggle="dropdown" class="btn btn-sm btn-dark">
                                                        <i class="material-icons">settings</i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <a class="dropdown-item" href="learning-plan-add.html">Add</a>
                                                        <a class="dropdown-item" href="learning-plan-edit.html">Edit</a>
                                                        <a class="dropdown-item"
                                                            onclick="return confirm('Are you sure you want to delete this?')"
                                                            href="#">Delete</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                    </tbody>


                                </table>

                            </div>


                            <ul class="pagination justify-content-center pagination-sm">
                                <li class="page-item disabled">
                                    <a class="page-link" href="#" aria-label="Previous">
                                        <span aria-hidden="true" class="material-icons">chevron_left</span>
                                        <span>Prev</span>
                                    </a>
                                </li>
                                <li class="page-item active">
                                    <a class="page-link" href="#" aria-label="1">
                                        <span>1</span>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="1">
                                        <span>2</span>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="#" aria-label="Next">
                                        <span>Next</span>
                                        <span aria-hidden="true" class="material-icons">chevron_right</span>
                                    </a>
                                </li>
                            </ul>
                        </div>

                    </div>

                </div>


            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue'
    import moment from 'moment'
    import flatPicker from "vue-flatpickr-component";
    import "flatpickr/dist/flatpickr.css";
    import ContentHeader from "@@/components/ContentHeader"
    Vue.use(flatPicker);
    let now = new Date()
    export default {
        layout: 'home',
        components: {
            flatPicker,
            ContentHeader,
        },
        data() {
            return {
                set_types: ['Assigned', 'Not Assigned', 'Draft'],
                expertAssigment: [{
                    event: '-',
                    curriculumTitle: '-',
                    location: '-',
                    academy: '-',
                    start: '-',
                    end: '-',
                    onsiteOnline: '-',
                    statusEvent: '-',
                    statusAssigment: '-',
                    expertName: '-',
                }, ],
                flatPickerConfig: {
                    altFormat: 'M	j, Y',
                    altInput: true,
                    dateFormat: 'Y-m-d',
                },
            }
        }
    }

</script>
