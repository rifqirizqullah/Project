<template>
    <div class="container page-section">
        <div>
            <div class="text-center mt-5 mb-4">
                <h2>Forum List</h2>
            </div>
            <b-card-group deck>
                <div class="row">
                    <div class="col-sm-6 col-md-3 has-margin">
                        <b-card>
                            <b-card-text>
                                Pyhton is kind of animal like to code a program, so its become a programming language
                                now.
                                <br>
                            </b-card-text>
                            <div slot="footer" class="text-center mt-3">
                                <strong>Pyhton for dummies</strong>
                            </div>
                        </b-card>
                    </div>
                    <div class="col-sm-6 col-md-3 has-margin">
                        <b-card>
                            <b-card-text>
                                Pyhton is kind of animal like to code a program, so its become a programming language
                                now.
                                <br>
                            </b-card-text>
                            <div slot="footer" class="text-center mt-3">
                                <strong>Pyhton for dummies</strong>
                            </div>
                        </b-card>
                    </div>
                    <div class="col-sm-6 col-md-3 has-margin">
                        <b-card>
                            <b-card-text>
                                Pyhton is kind of animal like to code a program, so its become a programming language
                                now.
                                <br>
                            </b-card-text>
                            <div slot="footer" class="text-center mt-3">
                                <strong>Pyhton for dummies</strong>
                            </div>
                        </b-card>
                    </div>
                    <div class="col-sm-6 col-md-3 has-margin">
                        <b-card>
                            <b-card-text>
                                Pyhton is kind of animal like to code a program, so its become a programming language
                                now.
                                <br>
                            </b-card-text>
                            <div slot="footer" class="text-center mt-3">
                                <strong>Pyhton for dummies</strong>
                            </div>
                        </b-card>
                    </div>
                </div>
            </b-card-group>

        </div>



    </div>
</template>

<script>
    function myFunction() {
        alert("cek");
    }

</script>

<script>
    import moment from 'moment'
    import Vue from 'vue';
    import VeeValidate from 'vee-validate';
    import VueSweetalert2 from 'vue-sweetalert2';
    import ContentHeader from '@@/components/ContentHeader'
    Vue.use(VueSweetalert2);
    Vue.use(VeeValidate);

    export default {
        layout: 'event_peserta',
        components: {
            ContentHeader,
        },

        data() {
            return {

            }
        },


    }

</script>

<style scoped>
    .has-margin {
        margin-bottom: 15px;
    }

</style>
