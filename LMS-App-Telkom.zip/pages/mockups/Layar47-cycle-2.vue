<template>
    <div class="mdk-header-layout js-mdk-header-layout">

        <div class="mdk-header-layout__content page-content ">
            <ContentHeader headerTitle='My Event' headerDescription='Curriculum Management '
                headerSubDescription='Telkom Corporate Univ' />

            <div class="page-section container page__container">
                <div class="container page__container">
                    <form action="" method="POST">
                        <div class="card p-4">
                            <div class="card-header card-title">
                                <h3>In Class Learning</h3>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p>
                                                Curriculum Name
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <p>
                                            Security Network Multiplatform
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="curriculum_name">
                                                Event Title
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <p id="curriculum_answer">
                                            Bangmat DL Prime
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="event_type">
                                                Event Type
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">

                                        <p id="event_answer">
                                            Self Lead Learning
                                        </p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="Link">
                                                Link
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <table class="table table-bordered table-responsive text-center">
                                                    <thead>
                                                        <tr>
                                                            <th>Document Link</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="(dokumen, key) in link" :key="key">
                                                            <td>{{dokumen.document}}</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <strong>
                                            <p id="event_type">
                                                Posttest Score
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-1 col-sm-6">
                                        <strong>
                                            <p>
                                                :
                                            </p>
                                        </strong>
                                    </div>
                                    <div class="col-md-9 col-sm-12">

                                        <p id="event_answer">
                                            90
                                        </p>
                                    </div>
                                </div>

                                <div class="card-footer text-center">
                                    <button type="submit" class="btn btn-primary mr-3" value="Add">Give Feedback</button>
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>


    </div>
</template>
<script>
    import ContentHeader from '@@/components/ContentHeader.vue'
    export default {
        layout: 'home',
        components: {
            ContentHeader,
        },
        data() {
            return {
                link: [{
                        document: 'document1.pdf',
                    },
                    {
                        document: 'document2.pdf'
                    }
                ],
            }
        }

    }

</script>

<style>

</style>
