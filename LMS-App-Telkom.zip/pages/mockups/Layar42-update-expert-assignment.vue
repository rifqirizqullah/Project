<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader headerTitle='Event Management' headerDescription='To manage all events that will be held'
                headerSubDescription='' />
            <div class="bg-gradient-primary border-bottom-white py-32pt">
                <div class="container d-flex flex-column flex-md-row align-items-center text-center text-md-left">


                </div>
            </div>
            <div class="page-section border-bottom-2">
                <div class="container page__container">
                    <!-- Wrapper -->
                    <div class="card card-body mb-32pt">
                        <div class="row">

                            <div class="col-lg-12 d-flex align-items-center">
                                <form class="flex">
                                    <div class="modal-header">
                                        <h3 class="modal-title" id="addModalLabel">Update Expert Assignment</h3>
                                    </div>
                                    <br>


                                    <div class="form-row">
                                        <div class="col-5 col-md-6 mb-3">
                                            <label class="form-label" for="">Event</label>
                                            <input v-model="event" type="text" name="event" id="event"
                                                class="form-control" placeholder="Event Name" aria-describedby="event">
                                        </div>

                                    </div>
                                    <div class="form-row">
                                        <div class="col-12 col-md-6 mb-3">
                                            <label class="form-label" for="">Curriculum Title</label>
                                            <input v-model="curriculumTitle" type="text" name="curriculumTitle"
                                                id="curriculumTitle" class="form-control" placeholder="Curriculum Title"
                                                aria-describedby="curriculumTitle">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-12 col-md-6 mb-3">
                                            <label class="form-label" for="">Location</label>
                                            <input v-model="location" type="text" name="location" id="location"
                                                class="form-control" placeholder="Location" aria-describedby="location">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-12 col-md-6 mb-3">
                                            <label class="form-label" for="">Academy</label>
                                            <input v-model="academy" type="text" name="academy" id="acedemy"
                                                class="form-control" placeholder="Academy" aria-describedby="academy">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-12 col-md-6 mb-3">
                                            <label for="startDate">Start Date</label>
                                            <flat-pickr v-model="startDate" :config="flatPickerConfig"
                                                class="form-control" placeholder="Select start date" name="date">
                                            </flat-pickr>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-12 col-md-6 mb-3">
                                            <label for="endDate">End Date</label>
                                            <flat-pickr v-model="endDate" :config="flatPickerConfig"
                                                class="form-control" placeholder="Select end date" name="date">
                                            </flat-pickr>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-12 col-md-6 mb-3">
                                            <label class="form-label" for="">Onsite / Online</label>
                                            <input v-model="onsiteOnline" type="text" name="onsiteOnline"
                                                id="onsiteOnline" class="form-control" placeholder=""
                                                aria-describedby="onsiteOnline">
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col-12 col-md-6 mb-3">
                                            <label class="form-label" for="">Status Event</label>
                                            <input v-model="statusEvent" type="text" name="statusEvent" id="statusEvent"
                                                class="form-control" placeholder="" aria-describedby="statusEvent">
                                        </div>
                                    </div>

                                </form>
                            </div>

                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive" data-toggle="lists" data-lists-values='["name"]'>
                                <table class="table">

                                    <thead>
                                        <tr>
                                            <th>Day</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Schedule Name</th>
                                            <th>Description</th>
                                            <th>Total JP</th>
                                            <th>Main Competency</th>
                                            <th>Expert Name</th>
                                        </tr>
                                    </thead>
                                    <tbody class="list">
                                        <tr v-for="(item, index) in manage" :key="index">
                                            <td>{{item.Day}}</td>
                                            <td>{{item.startTime}}</td>
                                            <td>{{item.endTime}}</td>
                                            <td>{{item.scheduleName}}</td>
                                            <td>{{item.dexcription}}</td>
                                            <td>{{item.totalJP}}</td>
                                            <td>{{item.mainCompetency}}</td>
                                            <td>
                                                <b-button-group vertical>
                                                <b-button size="sm">Add Expert</b-button>
                                                </b-button-group>
                                                
                                                <!-- <a href="#" class="btn btn-secondary ">Add Expert</a> -->
                                                <select v-model="expert" class="form-control" name="expert" id="expert">
                                                    <option disabled value="">---</option>
                                                    <option v-for="(expert, index) in expert" :key="index">{{expert}}
                                                    </option>
                                                </select>
                                            </td>
                                        </tr>


                                    </tbody>


                                </table>

                            </div>

                        </div>
                    </div>
                    <!-- <label class="form-label" for="">Remarks</label> -->
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Remarks</h4>
                            <!-- <p class="text-black-70"></p> -->
                            <div>
                                <b-form-textarea id="textarea" v-model="text" placeholder="Enter something..." rows="3" max-rows="6"></b-form-textarea>
                                <!-- <pre class="mt-3 mb-0">{{ text }}</pre> -->
                            </div>
                            <p class="text-black-70">
                                <!-- <small class="text-muted">Last updated 3 mins ago</small> -->
                            </p>
                        </div>
                    </div>

                    <div class="footer float-right">
                        <nuxt-link to="/expert-assignment" class="btn btn-danger" data-dismiss="modal">Cancel
                        </nuxt-link>
                        <button type="submit" class="btn btn-secondary">Submit</button>
                        <button type="submit" class="btn btn-primary">Save as Draft</button>
                    </div>

                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue'
    import moment from 'moment'
    import flatPicker from "vue-flatpickr-component";
    import "flatpickr/dist/flatpickr.css";
    import ContentHeader from "@@/components/ContentHeader"
    Vue.use(flatPicker);
    let now = new Date()
    export default {
        layout: 'home',
        components: {
            flatPicker,
            ContentHeader,
        },
        data() {
            return {
                event: '',
                curriculumTitle: '',
                location: '',
                academy: '',
                start: '',
                end: '',
                onsiteOnline: '',
                statusEvent: '',
                statusAssigment: '',
                expertName: '',
                manage: [{
                    day: '-',
                    startTime: '-',
                    endTime: '-',
                    scheduleName: '-',
                    description: '-',
                    totalJP: '-',
                    mainCompetency: '-',
                    expert: ['1', '2', '3'],
                }, ],
                flatPickerConfig: {
                    altFormat: 'M	j, Y',
                    altInput: true,
                    dateFormat: 'Y-m-d',
                },
                mode: "range",
                minDate: "today",
                dateFormat: "Y-m-d",
                text: '',
                disable: [
                    function (date) {
                        // disable every multiple of 8
                        return !(date.getDate() % 8);
                    }
                ]

            }
        }
    }

</script>
