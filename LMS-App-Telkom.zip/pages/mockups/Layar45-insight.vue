<template>
    <div class="container page-section">
        <div>
            <div class="text-center mt-5 mb-4">
                <h2>DIY & HOW TO EVERYTHING</h2>
            </div>
            <b-card-group deck>
                <div class="row">
                    <div class="col-sm-6 col-md-3 has-margin">
                        <b-card img-src="https://placekitten.com/1000/300" img-alt="Card image" img-top>
                            <b-card-text>
                                Some quick example text to build on the card and make up the bulk of the card's content.
                                <br>
                                <div class="text-center mt-3">
                                    John Doe
                                </div>
                            </b-card-text>
                        </b-card>
                    </div>
                    <div class="col-sm-6 col-md-3 has-margin">
                        <b-card img-src="https://placekitten.com/1000/300" img-alt="Card image" img-top>
                            <b-card-text>
                                Some quick example text to build on the card and make up the bulk of the card's content.
                                <br>
                                <div class="text-center mt-3">
                                    John Doe
                                </div>
                            </b-card-text>
                        </b-card>
                    </div>
                    <div class="col-sm-6 col-md-3 has-margin">
                        <b-card img-src="https://placekitten.com/1000/300" img-alt="Card image" img-top>
                            <b-card-text>
                                Some quick example text to build on the card and make up the bulk of the card's content.
                                <br>
                                <div class="text-center mt-3">
                                    John Doe
                                </div>
                            </b-card-text>
                        </b-card>
                    </div>
                    <div class="col-sm-6 col-md-3 has-margin">
                        <b-card img-src="https://placekitten.com/1000/300" img-alt="Card image" img-top>
                            <b-card-text>
                                Some quick example text to build on the card and make up the bulk of the card's content.
                                <br>
                                <div class="text-center mt-3">
                                    John Doe
                                </div>
                            </b-card-text>
                        </b-card>
                    </div>
                </div>
            </b-card-group>

        </div>



    </div>
</template>

<script>
    function myFunction() {
        alert("cek");
    }

</script>

<script>
    import moment from 'moment'
    import Vue from 'vue';
    import VeeValidate from 'vee-validate';
    import VueSweetalert2 from 'vue-sweetalert2';
    import ContentHeader from '@@/components/ContentHeader'
    Vue.use(VueSweetalert2);
    Vue.use(VeeValidate);

    export default {
        layout: 'event_peserta',
        components: {
            ContentHeader,
        },

        data() {
            return {

            }
        },


    }

</script>

<style scoped>
    .has-margin {
        margin-bottom: 15px;
    }

</style>
