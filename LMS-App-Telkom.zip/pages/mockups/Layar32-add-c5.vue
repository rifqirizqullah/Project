<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content">
            <ContentHeader
                headerTitle='Event Management'
                headerDescription='To manage all events that will be held.'
                headerSubDescription= 'Telkom Corporate University'
            />

            <div class="page-section bg-white border-bottom-2">
                <div class="container page__container">

                    <form action="" method="POST">
                        <div class="card">
                            <div class="card-header">
                                Discussion Forum
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="eventName">Event Name</label>
                                    <input v-model="eventName" type="text" name="eventName"
                                        id="eventName" class="form-control" placeholder="Event Name"
                                        aria-describedby="eventName">
                                </div>
                                <div class="form-group">
                                    <label for="feedbackTemplate">Feedback Template</label>
                                    <select v-model="feedbackTemplate" class="form-control" name="feedbackTemplate"
                                        id="feedbackTemplate">
                                        <option disabled value="">-</option>
                                        <option v-for="(feedbackTemplates, index) in feedbackTemplates" :key="index">
                                            {{feedbackTemplates}}</option>
                                    </select>
                                </div>
                                 <div class="form-group">
                                    <label for="discussionForum">Discussion Forum</label>
                                    <input v-model="discussionForum" type="text" name="discussionForum"
                                        id="discussionForum" class="form-control" placeholder="Discussion Forum"
                                        aria-describedby="discussionForum">
                                </div>
                                <div class="form-group">
                                    <label for="eventStart">Event Start</label>
                                    <flat-pickr v-model="eventStart" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select start date" name="date"> </flat-pickr>
                                </div>
                                <div class="form-group">
                                    <label for="eventFinish">Event Finish</label>
                                    <flat-pickr v-model="eventFinish" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select end date" name="date"> </flat-pickr>
                                </div>
                                <div class="form-group">
                                    <label for="">Participant</label>
                                    <button type="submit" class="btn btn-primary btn-sm float-right m-2"><i class="material-icons">add</i> Add Participant</button>
                                    <table class="table table-responsive">
                                        <thead>
                                            <tr>
                                              <th>NIK</th>
                                              <th>Participant Name</th>
                                              <th>Position</th>
                                              <th>Total Posting</th>
                                              <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>123456</td>
                                                <td data-toggle="modal" data-target="#myModal">Yahya</td>
                                                <td>Chief of Staff Development</td>
                                                <td>13</td>
                                                <td>
                                                    <div class="nav-item dropdown d-none d-sm-flex">
                                                        <a href="#" data-toggle="dropdown" class="btn btn-sm btn-dark">
                                                            <i class="material-icons">settings</i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="learning-plan-edit.html">Edit</a>
                                                            <a class="dropdown-item"
                                                                onclick="return confirm('Are you sure you want to delete this?')"
                                                                href="#">Delete</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>234567</td>
                                                <td data-toggle="modal" data-target="#myModal">Tegar</td>
                                                <td>Senior MAnager</td>
                                                <td>20</td>
                                                <td>
                                                    <div class="nav-item dropdown d-none d-sm-flex">
                                                        <a href="#" data-toggle="dropdown" class="btn btn-sm btn-dark">
                                                            <i class="material-icons">settings</i>
                                                        </a>
                                                        <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="learning-plan-edit.html">Edit</a>
                                                            <a class="dropdown-item"
                                                                onclick="return confirm('Are you sure you want to delete this?')"
                                                                href="#">Delete</a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="modal" id="myModal">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">

                                            <!-- Modal Header -->
                                            <div class="modal-header">
                                                <h4 class="modal-title">Find Person</h4>
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>

                                            <!-- Modal body -->
                                            <div class="modal-body">
                                                <div id="div_id_find_nik" class="form-group">
                                                    <label for="id_find_nik" class="col-form-label">
                                                        User<span class="asteriskField">*</span>
                                                    </label>
                                                    <div class="row m-4">
                                                        <input type="text" name="event_name" maxlength="150" class="textinput textInput form-control col-sm-8">
                                                        <button class="btn btn-primary float-right" type="button" role="button"><i class="material-icons">search</i> Search</button>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="modal-body">
                                                <table class="table table-responsive">
                                                    <thead>
                                                        <tr>
                                                          <th>Personal ID</th>
                                                          <th>Name</th>
                                                          <th>Position</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>123456</td>
                                                            <td>Mutiara Ulfah</td>
                                                            <td>Senior Manager</td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- Modal footer -->
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                <button type="submit" class="btn btn-primary">Add</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="card-footer text-muted d-flex justify-content-end">
                                <button type="button" class="btn btn-secondary m-2">Cancel</button>
                                <button type="button" class="btn btn-primary m-2">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Vue from 'vue'
import moment from 'moment'
import ContentHeader from '@@/components/ContentHeader'
// import flatPicker from "vue-flatpickr-component";
// import "flatpickr/dist/flatpickr.css";
// Vue.use(flatPicker);

let now = new Date()
export default {
    layout : 'home',

    components : {
        ContentHeader,
        // flatPicker,
    },
    data() {
        return {
            feedbackTemplates : ['Feedback 1','Feedback 2','Feedback 3'],

            eventName: '',
            discussionForum: '',
            feedbackTemplate: '',
            eventStart: null,
            eventFinish: null,

            flatPickerConfig: {
                altFormat: 'M   j, Y',
                altInput: true,
                dateFormat: 'Y-m-d',
            },
        }
    }
}
</script>
