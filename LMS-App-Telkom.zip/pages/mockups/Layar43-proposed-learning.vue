<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader headerTitle='My Event' headerDescription='740106 - AAN PRIYATNA' headerSubDescription='Telkom Corporate Unv' />
            <div class="page-section bg-white">
                <div class="container page__container">

                    <form>
                        <div class="card">
                            <div class="card-header bg-info">
                                <h4 class="card-title text-light">Proposed Learning</h4>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="internalLearning">Internal Learning</label>
                                    <select v-model="internalLearning" class="form-control" name="internalLearning"
                                        id="internalLearning">
                                        <option disabled value="">-</option>
                                        <option v-for="(internalLearnings, index) in internalLearnings" :key="index">{{internalLearnings}}
                                        </option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="externalLearning">External Learning</label>
                                    <input v-model="externalLearning" type="text" name="externalLearning"
                                        id="externalLearning" class="form-control" placeholder="External Learning"
                                        aria-describedby="externalLearning">
                                </div>
                                <div class="form-group">
                                    <label for="eventDate">Date</label>
                                    <flat-pickr v-model="eventDate" :config="flatPickerConfig" class="form-control"
                                        placeholder="Select date" name="date"> </flat-pickr>
                                </div>
                                <div class="form-group">
                                    <label for="desc">Description</label>
                                    <input v-model="desc" type="text" name="desc"
                                        id="desc" class="form-control" placeholder="Describe here."
                                        aria-describedby="desc">
                                </div>
                                <div class="form-group">
                                    <label for="file">File</label>
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="validatedCustomFile">
                                        <label class="custom-file-label" for="validatedCustomFile">Choose file...</label>
                                    </div>
                                </div>

                            </div>

                            <div class="card-footer text-muted d-flex justify-content-end">
                                <button type="button" class="btn btn-secondary m-2">Cancel</button>
                                <button type="button" class="btn btn-primary m-2">Save</button>
                            </div>


                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Vue from 'vue';
import moment from 'moment'
import ContentHeader from '@@/components/ContentHeader'

export default {
    layout: 'home',
    components : {
        ContentHeader,
    },

    data() {
        return {
            internalLearnings : ['Python is it snake?','Programming for dummies','Be a millionare with doing nothing'],
            externalLearning: '',
            eventDate: null,
            desc: '',

            flatPickerConfig: {
                altFormat: 'M   j, Y',
                altInput: true,
                dateFormat: 'Y-m-d',
            },
        }
    },

    mounted() {
        // this.fetchEvent()
    },

    methods: {

        moment(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>

<style scoped>

</style>

