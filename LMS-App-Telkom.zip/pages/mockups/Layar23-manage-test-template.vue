<template>
    <div class="mdk-header-layout js-mdk-header-layout">
        <div class="mdk-header-layout__content page-content ">
            <ContentHeader
                headerTitle='Learning Activity Set Management'
            />
            <div class="page-section bg-white border-bottom-2">
                <div class="container page__container">
                    <h4 class="text-center">Manage Test Template</h4>
                    <form>
                            <div class="card-body p-4">     
                                <div class="form-group">
                                <b-form-group label-cols-lg="2" label="Template Name:">
                                <b-form-input v-model="textTemplateName" placeholder="Enter Template Name"></b-form-input>
                                <!-- <div class="mt-2">Value: {{ textTemplateName }}</div> -->
                                </b-form-group>
                                <br>
                                <b-form-group label-cols-lg="2" label="Template Style:">
                                    <b-form-select  v-model="selected" class="mb-3">
                                        <template slot="first">
                                            <option :value="null" disabled>-- Please select an option --</option>
                                        </template>
                                    <option v-for="(item, index) in templateType" :key="index">{{item}}</option>
                                    </b-form-select>
                                </b-form-group>

                   
                                </div>
                            
                            
                        <!-- </div> -->  
                        <div class="card-header bg-info d-flex justify-content-between">
                <h4 class="card-title text-light">Manage Learning Activity</h4>
                <div class="text-right">
                    <b-button v-b-modal.addParticipantModal class="btn btn-success btn-sm float-right">+ Add Question</b-button>
                    <b-modal hide-footer hide-header size="lg" id="addParticipantModal" centered title="Add Question">
                                        
                                         <div class="table" data-toggle="lists" data-lists-values='["name"]'>
                                         <table class="table border table-responsive">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>No</th>
                                            <th>Question Name</th>
                                            <th>Question Type</th>
                                            <th>Question Test</th>
                                            <th>Question Image</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(item, index) in manageTestAdd" :key="index">
                                            <td>{{ item.no }}</td>
                                            <td>{{ item.questionName }}</td>
                                            <td>{{ item.questionType}}</td>
                                            <td>{{ item.questionTest }}</td>
                                            <td>{{item.questionImage }}</td>
                                            <td>
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                                    <button class="dropdown-item" @click="deleteData(learningActivity.object_identifier, index)">Delete</button>
                                                </div>
                                            </div>
                                            </td>
                                        </tr>
                                    </tbody>

                                </table>
                                  <div class="card-footer float-right text-muted d-flex justify-content-end">
                                <button type="button" class="btn btn-secondary m-2">Cancel</button>
                                <button type="button" class="btn btn-success m-2">Save</button>
                            </div>
                            </div>
                                        
                        </b-modal>
                </div>
                    </div>
                                <table class="table border table-responsive">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>No</th>
                                            <th>Question Name</th>
                                            <th>Question Type</th>
                                            <th>Question Test</th>
                                            <th>Question Image</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr v-for="(item, index) in manageTest" :key="index">
                                            <td>{{ item.no }}</td>
                                            <td>{{ item.questionName }}</td>
                                            <td>{{ item.questionType}}</td>
                                            <td>{{ item.questionTest }}</td>
                                            <td>{{item.questionImage }}</td>
                                            <td>
                                                <div class="dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                                    <!-- <n-link class="dropdown-item" :to="`/learning-activity/${learningActivity.object_identifier}/detail`">Detail</n-link>
                                                    <button class="dropdown-item" @click="editData(learningActivity.object_identifier)">Edit</button>
                                                    <button class="dropdown-item" @click="delimitData(learningActivity.object_identifier)">Delimit</button>
                                                    <button class="dropdown-item" @click="deleteData(learningActivity.object_identifier, index)">Delete</button> -->
                                                </div>
                                            </div>
                                            </td>
                                        </tr>
                                    </tbody>
                     
                                </table>
                            <div class="card-footer float-right text-muted d-flex justify-content-end">
                                <button type="button" class="btn btn-secondary m-2">Cancel</button>
                                <button type="button" class="btn btn-success m-2">Save</button>
                            </div>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import Vue from 'vue';
import VeeValidate from 'vee-validate';
import VueSweetalert2 from 'vue-sweetalert2';
import moment from 'moment'
import ContentHeader from '@@/components/ContentHeader'

Vue.use(VueSweetalert2);
Vue.use(VeeValidate);

export default {
    components : {
        ContentHeader,
    },

    data() {
        return {
         textTemplateName:'-',
         templateType:['1','2',],
         manageTest: [{
            no: null,
            questionName: '-',
            questionType: '-',
            questionTest: '-',
            questionImage: '-',
         },],
          manageTestAdd: [{
            no: null,
            questionName: '-',
            questionType: '-',
            questionTest: '-',
            questionImage: '-',
         },],
  
        }
    },

}
</script>
