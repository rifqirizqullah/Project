<template>
    <div class="container page-section">
        <div class="page-headline text-center">
            <h2>My Events</h2>
        </div>
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">On Going Events</h4>
                            <p class="card-subtitle text-light">happening now</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of ongoing Event <span class="badge badge-pill badge-success badge-lg ml-3">{{Ongoing && Ongoing.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '01'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Upcoming Events</h4>
                            <p class="card-subtitle text-light">Event teacan jalan</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Upcoming Event <span class="badge badge-pill badge-accent badge-lg ml-3">{{Upcoming && Upcoming.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '02'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header bg-gradient-purple d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title text-light">Events Done</h4>
                            <p class="card-subtitle text-light">Completed event</p>
                        </div>
                    </div>
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <p class="text-70">Total of Event done <span class="badge badge-pill badge-secondary badge-lg ml-3">{{Done && Done.total}}</span></p>
                        <div class="text-right">
                            <button class="btn btn-accent" @click="filters.status = '03'; runFilter()">Show</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="">

            <div class="mb-4 d-flex justify-content-between align-items-center">
                <span>
                    <h4 class="h4 ml-2">Event List</h4>
                </span>
                <button @click="clearDetail(); $bvModal.show('eventForm')" class="btn btn-outline-success ">+ Create Event</button>
            </div>

            <div class="row">
                <div v-for="(item, index) in event.list" :key="index" class="col-lg-6 col-md-12">
                    <div @click="getDetail(item.object_identifier); $router.push(`/student/event/${item.event_id}/batch`)"
                        class="card card-hover">
                        <img src="~static/img/eventCardBgLight.png" alt="Flinto" class="card-img" style="max-height: 100%; width: initial;">
                        <div class="fullbleed bg-primary" style="opacity: .5;"></div>
                        <span class="card-body fullbleed">
                            <span class="row p-2">
                                <span class="col-8">
                                    <span class="h2 text-white text-uppercase font-weight-normal m-0 d-block">{{ item.event_name }}</span>
                                    <p class="text-white-50">
                                        <span class="material-icons icon-16pt text-success mr-4pt">access_time</span>{{formatDate(item.begin_date)}}
                                        <span class="material-icons icon-16pt text-accent mr-4pt">access_time</span>{{formatDate(item.end_date)}}
                                    </p>
                                    <span class="text-white-60">{{ item.description }}</span>
                                </span>
                                <span class="col-4">
                                    <span class="text-right flex">
                                    </span>
                                    <span>
                                        <span class="h4 text-white m-0 d-block">{{ item.event_type.value }} Event</span>
                                        <hr>
                                        <small class="text-light">Unit</small>
                                        <p class="text-white-60">{{item.organization.organization_name}}</p>
                                        <small class="text-light">Vendor</small>
                                        <p class="text-white-60">{{item.vendor.company_name}}</p>
                                    </span>
                                </span>
                            </span>
                        </span>
                    </div>
                </div>
            </div>

            <div class="row my-3">
                <div class="col-12">
                    <paginationBar :state='event' :storeModuleName="'event'" />
                </div>
            </div>

        </div>

        <b-modal v-model="modalShow" ref="eventForm" hide-footer hide-header id="eventForm" size="lg">
            <eventForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="modal-body">
                    <div class="form-group">
                        <label for="endDate">Begin Date</label>
                        <flat-pickr disabled v-model="begin_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                            placeholder="Select end date" name="begin_date" v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}"
                            v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                            <p v-show="errors.has('delimit.begin_date')" class="help is-danger"> {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                    <div class="form-group">
                        <label for="endDate">End Date</label>
                        <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                            placeholder="Select end date" name="end_date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                            v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                            <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
                    </div>
                </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import eventForm from '@@/components/forms/eventForm'
import paginationBar from '@@/components/paginationBar'
import {mapState, mapActions} from 'vuex'

export default {
    layout : 'event',
    components : { eventForm, paginationBar },
    created() {
        this.$store.dispatch('companyRelation/getAll');
        this.$store.dispatch('event/getAll');
        this.$store.dispatch('event/getAllStatus');
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            filters : {
                status : null,
            },
            begin_date:null,
            end_date: null,
        }
    },
    computed: {
        ...mapState({
            event : state => state.event,
            Ongoing : state => state.event.Ongoing,
            Upcoming : state => state.event.Upcoming,
            Done : state => state.event.Done,
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'event/getDetail',
            clearDetail: 'event/clearDetail',
            deleteOne: 'event/deleteOne',
            getAll: 'event/getAll',
        }),
        runFilter(){
            let params = {}
            if (this.filters.status)
                params["event_status[]"] = this.filters.status
            this.getAll(params)
        },
        clearFilters(){
            this.filters = {
                status : null,
            }
        },
        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('eventForm')
        },
        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.event.detail.begin_date
            this.end_date = moment(new Date()).format("YYYY-MM-DD")
            this.$bvModal.show('modalDelimit')
        },
        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/event?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },
        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/event', {}, {
                    params : {
                        object_identifier : this.event.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('event/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },
}
</script>
