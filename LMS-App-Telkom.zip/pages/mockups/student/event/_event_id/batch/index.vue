<template>
    <section>
        <div class="container mt-4">
            <div class="card p-1">
                <img src="~static/img/bg-City.png" alt="bg_city" class="card-img" style="max-height: 100%; width: initial;">
                <div class="fullbleed bg-primary" style="opacity: .5;"></div>
                <div class="d-flex align-items-center justify-content-center fullbleed">
                    <div v-if="event" class="m-4">
                        <h1 class="text-white h1 mb-16pt mt-4">{{event.event_name}}</h1>
                        <div class="d-flex align-items-center mb-16pt justify-content-center">
                            <div class="d-flex align-items-center mr-16pt">
                                <span class="material-icons icon-16pt text-success mx-4pt">access_time</span>
                                <p class="flex text-white-50 lh-1 mb-0">{{formatDate(event.begin_date)}}</p>
                            </div>
                            <div class="d-flex align-items-center mr-16pt">
                                <span class="material-icons icon-16pt text-danger mx-4pt">access_time</span>
                                <p class="flex text-white-50 lh-1 mb-0">{{formatDate(event.end_date)}}</p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <h3 class="text-white">{{event.event_type.value}} Event</h3>
                        </div>
                        <div class="d-flex align-items-center mt-3 mb-16pt justify-content-center">
                            <div class="d-flex align-items-center">
                                <p class="flex text-white-50 lh-1 mb-0">UNIT : {{event.organization.organization_name}}</p>
                            </div>
                        </div>
                    </div>
                    <div v-else>
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="page-headline text-center">
                <h2>Batch</h2>
            </div>
            <div class="d-flex justify-content-between mb-4">
                <h4 class="h4">Available Batch</h4>
                <span>
                    <button @click="clearDetail(); $bvModal.show('batchForm')" class="btn btn-sm btn-success">+ Create Batch</button>
                    <button @click="clearDetail(); $bvModal.show('batchFormReference')" class="btn btn-sm btn-success">+ Add Planned Batch</button>
                </span>
            </div>
            <div v-if="batch.isLoading">
                <div class="row">
                    <div class="col d-flex justify-content-center">
                        <div class="loader loader-accent text-center"></div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div v-for="(item, index) in batch.list" :key="index"
                    class="col-xs-12 col-sm-6 col-md-3"  >
                    <div class="card">
                        <div class="card-body p-0" style="cursor : pointer;" @click="$router.push(`/student/event/${event.event_id}/batch/${item.batch_id}/activity`)">
                            <span class="d-flex justify-content-between align-items-start bg-light">
                                <h4 class="card-title pl-3 pt-3 h4 "> {{item.batch_name}}</h4>
                                <span v-if="item.reference.batch_id" class="badge badge-pill badge-info p-2 m-2">Planned</span>
                            </span>
                            <li class="list-group-item">
                                <i class="material-icons text-warning">location_on</i> Location : {{item.location.value}}
                            </li>
                            <li v-if="item.curriculum.value" class="list-group-item">
                                <i class="material-icons text-info">book</i> Curriculum : {{item.curriculum.value}}
                            </li>
                            <li v-if="item.vendor.company_name" class="list-group-item">
                                <i class="material-icons text-accent">build</i> Vendor : {{item.vendor.company_name}}
                            </li>
                        </div>
                        <div class="card-footer bg-light d-flex align-items-center">
                            <div class="text-muted flex">BATCH {{item.batch_id}}</div>
                            <div class="dropup">
                                <a href="#" class="dropdown-toggle" data-caret="false" data-toggle="dropdown" aria-expanded="false">
                                    <i class="material-icons">more_horiz</i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-155px, -110px, 0px);">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier)">Delimit</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/classroom?type='+type)">Detail</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row m-3">
                <div class="col-12">
                    <paginationBar :state='batch' :storeModuleName="'batch'" />
                </div>
            </div>
        </div>

        <b-modal v-model="modalShow" ref="batchForm" hide-footer hide-header id="batchForm" size="lg">
            <batchForm v-if="modalShow" />
        </b-modal>
        <b-modal v-model="modalReferenceShow" ref="batchFormReference" hide-footer hide-header id="batchFormReference" size="lg">
            <batchFormReference v-if="modalReferenceShow" />
        </b-modal>
        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="modal-body">
                <div class="form-group">
                    <label for="endDate">Begin Date</label>
                    <flat-pickr disabled v-model="begin_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                        placeholder="Select end date" name="begin_date" v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}"
                        v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                        <p v-show="errors.has('delimit.begin_date')" class="help is-danger"> {{ errors.first('delimit.begin_date') }}</p>
                </div>
                <div class="form-group">
                    <label for="endDate">End Date</label>
                    <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                        placeholder="Select end date" name="end_date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                        v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                        <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
                </div>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>




    </section>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'
import paginationBar from '@@/components/paginationBar'
import batchForm from '@@/components/forms/batchForm'
import batchFormReference from '@@/components/forms/batchFormReference'

export default {
    layout : 'event',
    components : {
        batchForm ,
        paginationBar,
        batchFormReference,
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,
            modalReferenceShow : false,
            begin_date: null,
            end_date: null,
        }
    },
    created() {
        this.$store.dispatch('event/getOne' , {"event_id[]" : this.$route.params.event_id})
        this.$store.dispatch('batch/getAll', {'event[]' : this.$route.params.event_id})
    },
    computed: {
        ...mapState({
            event: state => state.event.detail,
            batch: state => state.batch,
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'batch/getDetail',
            clearDetail: 'batch/clearDetail',
            deleteOne: 'batch/deleteOne'
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('batchForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.batch.detail.begin_date
            this.end_date = moment(new Date()).format("YYYY-MM-DD")
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/batch?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/batch', {}, {
                    params : {
                        object_identifier : this.batch.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('batch/getAll',{'type':this.type});
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>


<style scoped>
.card {
    transition: .2s !important;
}

.card:hover {
    box-shadow: 0 .4rem .8rem rgba(0, 0, 0, .15) !important;
}
</style>
