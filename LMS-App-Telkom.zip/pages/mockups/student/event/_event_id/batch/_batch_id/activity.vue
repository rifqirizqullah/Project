<template>
    <div>
        <div class="mb-0">
            <div class="card mb-0">
                <img src="~static/img/bg-City.png" alt="bg_city" class="card-img" style="max-height: 100%; width: initial;">
                <div class="fullbleed bg-primary" style="opacity: .5;"></div>
                <div class="d-flex align-items-center justify-content-center fullbleed">
                    <div v-if="event" class="m-4">
                        <h1 class="text-white text-center mt-4 mb-2">{{event.event_name}}</h1>
                        <p class="text-light text-center mb-2">{{event.description}}</p>
                        <div class="d-flex align-items-center mb-8pt justify-content-center">
                            <div class="d-flex align-items-center mr-16pt">
                                <span class="material-icons icon-16pt text-success mx-4pt">access_time</span>
                                <p class="flex text-white-50 lh-1 mb-0">{{formatDate(event.begin_date)}}</p>
                            </div>
                            <div class="d-flex align-items-center mr-16pt">
                                <span class="material-icons icon-16pt text-danger mx-4pt">access_time</span>
                                <p class="flex text-white-50 lh-1 mb-0">{{formatDate(event.end_date)}}</p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center justify-content-center">
                            <h3 class="text-white">{{event.event_type.value}} Event</h3>
                        </div>
                        <div class="d-flex align-items-center mt-3 mb-16pt justify-content-center">
                            <div class="d-flex align-items-center">
                                <p class="flex text-white-50 lh-1 mb-0">UNIT : {{event.organization.organization_name}}</p>
                            </div>
                        </div>
                    </div>
                    <div v-else>
                        <div class="row">
                            <div class="col d-flex justify-content-center">
                                <div class="loader loader-accent text-center"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       <div v-if="batch" class="container page-section">
           <div class="row">
               <div class="col-12">
                    <div class="card text-white bg-gradient-info">
                        <div class="card-body">
                            <div class="display-4 text-light text-center">{{batch.batch_name}}</div>
                        </div>
                    </div>
               </div>
           </div>
        </div>

        <div class="navbar navbar-expand-sm navbar-submenu p-sm-0">
            <div class="container">
                <!-- Navbar toggler -->
                <button class="navbar-toggler ml-n16pt" type="button" data-toggle="collapse"
                    data-target="#navbar-submenu2">
                    <span class="material-icons">people_outline</span>
                </button>
                <div class="collapse navbar-collapse" id="navbar-submenu2">
                    <div class="navbar-collapse__content pb-16pt pb-sm-0">
                        <ul class="nav navbar-nav">
                            <li class="nav-item">
                                <nuxt-link :to="'/event/batch/detail/classroom?type='+type" class='nav-link'>Activity </nuxt-link>
                            </li>
                            <li class="nav-item">
                                <nuxt-link :to="'/event/batch/detail/participant?type='+type" class='nav-link'>Participant </nuxt-link>
                            </li>
                            <li class="nav-item">
                                <nuxt-link to='/mockups/Layar35-add-c3-budget' class='nav-link'>Budget </nuxt-link>
                            </li>
                            <li class="nav-item">
                                <nuxt-link :to="'/event/batch/detail/work-order?type='+type" class='nav-link'>Work Order </nuxt-link>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>


        <div class="container page-section">

            <div class="card">
                <div class="card-header bg-light d-flex justify-content-between align-items-center">
                    <span>
                        <h4 class="card-title">Activity</h4>
                        <p class="card-subtitle">List of Available Activity</p>
                    </span>
                    <span>
                        <button @click="clearDetail(); $bvModal.show('sessionForm')" class="btn btn-success btn-sm">+ Create Activity</button>
                        <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                            <span class="btn-label"><i class="fa fa-search"></i> Search</span>
                        </b-button>
                    </span>
                </div>

                <table class="table table-responsive table-hover">
                    <thead class="">
                        <tr class="">
                            <th>No</th>
                            <th>Name</th>
                            <th>Learning Activity</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item, index) in session.list" :key="index">
                            <td> {{index+1}} </td>
                            <td @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/schedule')" style="cursor:pointer;">
                               <strong> {{ item.session_name }}</strong>
                            </td>
                            <td>{{ item.learning_activity.activity_name }}</td>
                            <td>{{ formatDate(item.begin_date) }}</td>
                            <td>{{ formatDate(item.end_date) }}</td>
                            <td>
                                <div class="btn-group">
                                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown"
                                        aria-haspopup="true" aria-expanded="false">
                                    </button>
                                    <div class="dropdown-menu dropdown-menu-right">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                        <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                        <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                        <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/batch/detail/schedule?type='+type)">Schedule</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="session.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>

                </table>
                <div class="card-footer">
                    <paginationBar :state='session' :storeModuleName="'session'" />
                </div>

            </div>

            <b-modal v-model="modalShow" ref="sessionForm" hide-footer hide-header id="sessionForm" size="lg">
                <sessionForm v-if="modalShow" />
            </b-modal>
            <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="endDate">Begin Date</label>
                        <flat-pickr disabled v-model="begin_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                            placeholder="Select end date" name="begin_date" v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}"
                            v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                            <p v-show="errors.has('delimit.begin_date')" class="help is-danger"> {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                    <div class="form-group">
                        <label for="endDate">End Date</label>
                        <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                            placeholder="Select end date" name="end_date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                            v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                            <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
                    </div>
                </div>
                <div slot="modal-footer">
                    <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                    <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
                </div>
            </b-modal>

        </div>

        </div>
    </div>
</template>

<script>
import moment from 'moment'
import sessionForm from '@@/components/forms/sessionForm'
import paginationBar from '@@/components/paginationBar'

import {mapState, mapActions} from 'vuex'

export default {
    components : { sessionForm, paginationBar },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            begin_date : this.begin_date,
            end_date : this.end_date,

            type : 'a'
        }
    },
    created() {
        if (!this.event) {
            this.$store.dispatch('event/getOne' , {"event_id[]" : this.$route.params.event_id})
        }
        if (!this.batch) {
            this.$store.dispatch('batch/getOne' , {"batch_id[]" : this.$route.params.batch_id})
        }
        this.$store.dispatch('session/getAll', {'batch[]' : this.$route.params.batch_id})
    },
    computed: {
        ...mapState({
            event: state => state.event.detail,
            batch: state => state.batch.detail,
            session : state => state.session
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'session/getDetail',
            getDetailReference: 'session/getDetailReference',
            clearDetail: 'session/clearDetail',
            deleteOne: 'session/deleteOne'
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('sessionForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.begin_date = this.batch.detail.begin_date
            this.end_date = moment(new Date()).format("YYYY-MM-DD")
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/session?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/session', {}, {
                    params : {
                        object_identifier : this.session.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('session/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
