<template>
    <div>
        <div class="container">
            <headerEventComponent/>
        </div>
        <div class="container">
            <headerBatchComponent/>
        </div>
        <div class="container">
            <headerSessionComponent/>
        </div>
        <div class="container">
            <headerQuizComponent/>
        </div>
        <div class="container page-section pt-0">
            <span class="d-flex justify-content-between align-items-center">
                <h2 class="m-3"> <i class="material-icons text-info">access_time</i> {{relation.id.quesioner_title}}</h2>               
            </span>
            <div class="card">
                <table class="table table-hover table-flush table-responsive">
                    <thead class="thead">
                        <tr>
                            <th>No</th>
                            <th>Feedback NIK Sender</th>                            
                            <th>Feedback Name Sender</th>                            
                            <th>Feedback Company Sender</th>                            
                            <th>Feedback Message</th>                            
                        </tr>
                    </thead>
                    <tbody v-if="quesionerParticipantChoice">
                        <tr v-for="(item , index) in quesionerParticipantChoice.list" :key="index">
                            <td>{{index +1}}</td>
                            <td>{{item.participant.personnel_number}}</td>                            
                            <td>{{item.participant.complete_name}}</td> 
                            <td>{{item.participant.business_code.company_name}}</td>                            
                            <td>{{item.text_choice}}</td>                          
                        </tr>
                        <tr v-if="quesionerParticipantChoice.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="card-footer">
                    <paginationBar :state='quesionerParticipantChoice' :storeModuleName="'quesionerParticipantChoice'" />
                </div>
            </div>           
        </div>
    </div>
</template>

<script>
import moment from 'moment'

import paginationBar from '@@/components/paginationBar'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'
import headerQuizComponent from '@@/components/headerQuizComponent'
import {mapState, mapActions} from 'vuex'

export default {
    layout : 'result-feedback',
    components : {paginationBar, headerEventComponent, headerBatchComponent, headerSessionComponent, headerQuizComponent },
    middleware: ({ store, redirect }) => {
        if (!store.state.relation.detail.object_identifier) return redirect('/event/event')
    },
    data() {
        return {
            type : this.$route.query.type
        }
    },
    created() {
        this.$store.dispatch('quesionerParticipantChoice/getAll')        
    },
    computed: {
        ...mapState({            
            relation : state => state.relation.detail,
            quesionerParticipantChoice : state => state.quesionerParticipantChoice
        }),
    },
    methods: {             
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>

