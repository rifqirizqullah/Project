<template>
  <div class="container page-section">
    <div class="mb-heading d-flex align-items-end px-3">
      <div class="flex">
        <p class="card-title" style="font-size:25px;color:black">List Expert</p>
        <!-- <p style="font-size:15px;margin-top:-15px">Manage All Learning Curriculum</p> -->
      </div>
      <button
        class="btn btn-sm btn-success"
        @click="clearDetail();$bvModal.show('expertForm')"
      >+ Create Expert</button>
      <b-button type="button" @click="getParam" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
        <span class="btn-label">
          <i class="fa fa-search"></i> Search
        </span>
      </b-button>
    </div>

    <div class>
      <div class="text-right">
        <div class="bg-white">
          <b-collapse id="collapse-a" class="mt-2">
            <form class="p-2">
              <div class="row">
          
                <div class="col-sm-12 col-md-3">
                <div class="form-group">
                    <select v-model="filters" class="form-control" name="company" id="company">
                     
                    </select>
                    <small class="form-text text-muted">Name</small>
                  </div>
                </div>
          
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <select v-model="filters" class="form-control" name="company" id="company">
                     
                    </select>
                    <small class="form-text text-muted">NIK</small>
                  </div>
                </div>

                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <div class="form-group">
                    <select v-model="filters" class="form-control" name="company" id="company">
                     
                    </select>
                    <small class="form-text text-muted">Expert Type</small>
                  </div>
                  
                  </div>
                </div>
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <div class="form-group">
                    <select v-model="filters" class="form-control" name="company" id="company">
                     
                    </select>
                    <small class="form-text text-muted">Expertise</small>
                  </div>
                  
                  </div>
                </div>
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <div class="form-group">
                    <select v-model="filters" class="form-control" name="company" id="company">
                     
                    </select>
                    <small class="form-text text-muted">Major Competency</small>
                  </div>
                  
                  </div>
                </div>
                <div class="col-sm-12 col-md-3">
                  <div class="form-group">
                    <div class="form-group">
                    <select v-model="filters" class="form-control" name="company" id="company">
                     
                    </select>
                    <small class="form-text text-muted">Group Institution</small>
                  </div>
                  
                  </div>
                </div>
                <div class="col-sm-12 col-md-12">
                  <div class="form-group text-right">
                    <b-button @click="filters = {}; runFilter()" variant="secondary">Clear Filter</b-button>
                    <b-button @click="runFilter" variant="info">
                      <span class="btn-label">
                        <i class="fa fa-search"></i> Filter
                      </span>
                    </b-button>
                  </div>
                </div>
              </div>
            </form>
          </b-collapse>
        </div>
      </div>
    </div>

    <div class="card" style="padding:10px">
      <div class>
        <table class="table table-hover table-flush table-responsive">
          <thead class="thead">
            <tr>
              <th>No</th>
              <th>Name</th>
              <th>NIK</th>
              <th>Expert Type</th>
              <th>Expertise</th>
              <th>Major Competency</th>
              <th>Group Institution</th>
              <th>Action</th>
            </tr>
          </thead>
          <!-- <tbody v-if="curriculum"> -->
              <tbody>
            <!-- <tr v-for="(item , index) in curriculum.list" :key="index"> -->
              <tr>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
                  <td>-</td>
              <!-- <td>{{index +1}}</td>
              <td>{{item.business_code.company_name}}</td>
              <td
                @click="getDetail(item.object_identifier); $router.push('/curriculum/detail')"
                style="cursor:pointer;"
              >
                <b>{{item.curriculum && item.curriculum.value}}</b>
              </td>
              <td>{{item.academic.value}}</td>
              <td>{{item.competence.value}}</td>
              <td>{{item.pl_code.value}}</td>
              <td>{{formatDate(item.begin_date)}}</td>
              <td>{{formatDate(item.end_date)}}</td> -->
              <td>
                <div class="dropdown d-sm-flex">
                  <button
                    class="btn btn-secondary dropdown-toggle"
                    type="button"
                    id="triggerId"
                    data-toggle="dropdown"
                    aria-haspopup="true"
                    aria-expanded="false"
                  ></button>
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                    <button
                      class="dropdown-item"
                      @click="showUpdateForm(item.object_identifier)"
                    >Update</button>
                    <button
                      class="dropdown-item"
                      @click="deleteData(item.object_identifier, index)"
                    >Delete</button>
                    <button
                      class="dropdown-item"
                      @click="showDelimitForm(item.object_identifier, item.end_date)"
                    >Delimit</button>
                    <button
                      class="dropdown-item"
                      @click="getDetail(item.object_identifier); $router.push('/curriculum/detail')"
                    >Detail</button>
                  </div>
                </div>
              </td>
            </tr>
          </tbody>
          <tfoot>
            <!-- <tr v-if="curriculum.isLoading">
              <td colspan="10">
                <div class="row">
                  <div class="col d-flex justify-content-center">
                    <div class="loader loader-accent text-center"></div>
                  </div>
                </div>
              </td>
            </tr> -->
          </tfoot>
        </table>
      </div>
      <!-- <div class="card-footer">
        <paginationBar :state="curriculum" :storeModuleName="'curriculum'"/>
      </div> -->
    </div>

    <b-modal
      v-model="modalShow"
      ref="curriculumForm"
      hide-footer
      hide-header
      id="curriculumForm"
      size="lg"
    >
      <curriculumForm v-if="modalShow"/>
    </b-modal>

    <b-modal
      v-model="modalDelimitShow"
      id="modalDelimit"
      centered
      title="Delimit Data"
      header-bg-variant="light"
      size="sm"
    >
      <div class="col-12">
        <div class="form-group">
          <label for="begin_date">Start Date</label>
          <div class="form-control">
            <input v-model="begin_date" :config="{dateFormat: 'Y-m-d'}" disabled  name="begin_date" id="begin_date">
          </div>
        </div>
      </div>
      <hr>
      <div class="col-12">
        <div v-show="begin_date" class="form-group">
          <label for="end_date">End Date</label>
          <flat-pickr
            v-model="end_date"
            :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
            class="form-control"
            placeholder="Select end date"
            name="end_date"
            id="end_date"
            v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
            v-validate="'required'"
            data-vv-scope="collection"
          />
          <u class="btn text-info" @click="end_date = new Date() ">Set Today</u>
          <p
            v-show="errors.has('collection.end_date')"
            class="help is-danger"
          >{{ errors.first('collection.end_date') }}</p>
        </div>
      </div>
      <div slot="modal-footer">
        <button
          type="button"
          class="btn btn-secondary"
          @click="$bvModal.hide('modalDelimit')"
        >Cancel</button>
        <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
      </div>
    </b-modal>
  </div>
</template>

<script>
import moment from "moment";
import curriculumForm from "@@/components/forms/curriculumForm";
import paginationBar from "@@/components/paginationBar";

import { mapState, mapActions } from "vuex";
export default {
     
  components: {
   
    paginationBar
  },
  data() {
    return {
    };
  },
//   created() {
//     this.$store.dispatch("curriculum/getAll");
//     this.$store.dispatch("company/getAll");
    
//   },
  computed: {
    ...mapState({
      curriculum: state => state.curriculum,
      CURID: state => state.CURID,
      ACDCD: state => state.ACDCD,
      CMPTY: state => state.CMPTY,
      PLCOD: state => state.PLCOD,
      company: state => state.company
    })
  },
  methods: {
    getParam(){
      this.$store.dispatch("CURID/getAll");
      this.$store.dispatch("ACDCD/getAll");
      this.$store.dispatch("CMPTY/getAll");
      this.$store.dispatch("PLCOD/getAll");
      
    },
    // ...mapActions({
    //   getDetail: "curriculum/getDetail",
    //   clearDetail: "curriculum/clearDetail",
    //   deleteOne: "curriculum/deleteOne",
    //   getAll: "curriculum/getAll"
    // }),

    // runFilter() {
    //   let params = {};
    //   if (this.filters.company)
    //         params["business_code"] = [this.filters.company];
    //   if (this.filters.curriculum)
    //     params["curriculum"] = [this.filters.curriculum];
    //   if (this.filters.academic) params["academic"] = [this.filters.academic];
    //   if (this.filters.competence)
    //     params["competence"] = [this.filters.competence];
    //   if (this.filters.pl_code) params["pl_code"] = [this.filters.pl_code];
    //   if (this.filters.begin_date)
    //       params["begin_date_lte"] = this.filters.begin_date;
    //   if (this.filters.end_date)
    //       params["end_date_gte"] = this.filters.end_date;
    //     this.$router.push({ path : this.$route.path , query : params})

    //   this.getAll(params);
    // },

    // clearFilters() {
    //   this.filters = {
    //     curriculum: null,
    //     academic: null,
    //     competence: null,
    //     pl_code: null
    //   };
    // },

    // showUpdateForm(object_identifier) {
    //   this.getDetail(object_identifier);
    //   this.$bvModal.show("curriculumForm");
    // },

    // async showDelimitForm(object_identifier) {
    //   await this.getDetail(object_identifier);
    //   this.begin_date = this.curriculum.detail.begin_date;
    //   this.end_date = this.curriculum.detail.end_date;
    //   this.$bvModal.show("modalDelimit");
    // },

    // deleteData(id, index) {
    //   this.$swal({
    //     title: "Are you sure?",
    //     text: "You won't be able to revert this!",
    //     type: "warning",
    //     showCancelButton: true
    //   }).then(result => {
    //     if (result.value) {
    //       this.$axios
    //         .delete("lms/api/curriculum?object_identifier=" + id)
    //         .then(response => {
    //           return this.$swal("Deleted!", response.data.message, "success");
    //         })
    //         .then(result => {
    //           this.deleteOne(index);
    //         })
    //         .catch(e => {
    //           console.log(e.response);
    //         });
    //     }
    //   });
    // },

    // delimitData() {
    //   this.$validator.validateAll("delimit").then(async result => {
    //     if (!result) return;
    //     this.$axios
    //       .patch(
    //         "lms/api/curriculum",
    //         {},
    //         {
    //           params: {
    //             object_identifier: this.curriculum.detail.object_identifier,
    //             end_date: this.end_date
    //           }
    //         }
    //       )
    //       .then(response => {
    //         this.$store.dispatch("curriculum/getAll");
    //         this.$bvModal.hide("modalDelimit");
    //         this.$swal("Saved!", "Successfully saved data.", "success");
    //       })
    //       .catch(e => {
    //         console.log(e.response);
    //       });
    //   });
    // },

    formatDate(date) {
      return moment(date).format("DD MMM YYYY");
    }
  }
};   

</script>