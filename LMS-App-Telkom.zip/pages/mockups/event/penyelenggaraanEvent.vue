<template>
    <div class="container page-section">
        <div class="row">
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title">On Going Events</h4>
                            <p class="card-subtitle">happening now</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="text-70">Total of ongoing Event <span class="badge badge-pill badge-success badge-lg ml-3">{{Ongoing && Ongoing.total}}</span></p>
                        <div class="text-right">
                            <!-- <button class="btn btn-accent">Show</button> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title">Upcoming Events</h4>
                            <p class="card-subtitle">Event teacan jalan</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="text-70">Total of Upcoming Event <span class="badge badge-pill badge-accent badge-lg ml-3">{{Upcoming && Upcoming.total}}</span></p>
                        <div class="text-right">
                            <!-- <button class="btn btn-accent">Show</button> -->
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <div class="flex">
                            <h4 class="card-title">Events Done</h4>
                            <p class="card-subtitle">Completed event</p>
                        </div>
                    </div>
                    <div class="card-body">
                        <p class="text-70">Total of Event done <span class="badge badge-pill badge-secondary badge-lg ml-3">{{Done && Done.total}}</span></p>
                        <div class="text-right">
                            <!-- <button class="btn btn-accent">Show</button> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <span>
                    <h4 class="card-title">Penyelenggaraan Event</h4>
                    <p class="card-subtitle">List of Penyelenggaraan Event</p>
                </span>
                <button @click="clearDetail(); $bvModal.show('eventForm')" class="btn btn-success btn-sm">+ Create Penyelenggaraan Event</button>
            </div>

            <table class="table table-flush table-responsive table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Event Name</th>
                        <th>Description</th>
                        <th>Status</th>
                        <th>Vendor</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in penyelenggaraanEvent.list" :key="index">
                        <td> {{ index+1 }} </td>
                        <td  @click="getDetail(item.object_identifier); $router.push('/event/detail')" style="cursor:pointer;">
                             {{ item.event.event_name }}
                        </td>
                        <td> {{ item.description }} </td>
                        <td v-bind:class="{
                            'text-success': item.event_status.value == 'Ongoing',
                            'text-accent': item.event_status.value == 'Upcoming',
                            'text-secondary': item.event_status.value == 'Done',
                            }" >
                            {{ item.event_status.value }}
                        </td>
                        <td> {{ item.vendor.company_name }} </td>
                        <td> {{formatDate(item.begin_date)}} </td>
                        <td> {{formatDate(item.end_date)}} </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="penyelenggaraanEvent.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>

        </div>

        <b-modal v-model="modalShow" ref="eventForm" hide-footer hide-header id="eventForm" size="lg">
            <eventForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                    v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                    <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import eventForm from '@@/components/forms/eventForm'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'event',
    components : { eventForm },
    fetch ({ store, params }) {
        store.dispatch('penyelenggaraanEvent/getAll');
        store.dispatch('penyelenggaraanEvent/getAllStatus');
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            end_date: null,
        }
    },
    computed: {
        ...mapState({
            penyelenggaraanEvent : state => state.penyelenggaraanEvent,
            Ongoing : state => state.penyelenggaraanEvent.Ongoing,
            Upcoming : state => state.penyelenggaraanEvent.Upcoming,
            Done : state => state.penyelenggaraanEvent.Done,
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'penyelenggaraanEvent/getDetail',
            clearDetail: 'penyelenggaraanEvent/clearDetail',
            deleteOne: 'penyelenggaraanEvent/deleteOne'
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('eventForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.end_date = this.penyelenggaraanEvent.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/penyelenggaraanevent?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/penyelenggaraanevent', {}, {
                    params : {
                        object_identifier : this.penyelenggaraanEvent.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('penyelenggaraanEvent/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
