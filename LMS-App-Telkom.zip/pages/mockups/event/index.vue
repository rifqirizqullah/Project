<template>
    <div class="container page-section">

        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <span>
                    <h4 class="card-title">Events</h4>
                    <p class="card-subtitle">List of available events</p>
                </span>
                <button @click="clearDetail(); $bvModal.show('eventForm')" class="btn btn-success btn-sm">+ Create Event</button>
            </div>

            <table class="table table-flush table-responsive table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Event Name</th>
                        <th>Type</th>
                        <th>Unit</th>
                        <!-- <th>Template</th> -->
                        <th>Start</th>
                        <th>End</th>
                        <th>Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in event.list" :key="index">
                        <td> {{index+1}} </td>
                        <td @click="getDetail(item.object_identifier); $router.push('/event/detail')" style="cursor:pointer;"> {{ item.event_name }} </td>
                        <td> {{ item.event_type.value }} </td>
                        <td> {{ item.organization.organization_name }} </td>
                        <!-- <td> {{ item.template.value }} </td> -->
                        <td> {{formatDate(item.begin_date)}} </td>
                        <td> {{formatDate(item.end_date)}} </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/detail')">Detail</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="event.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>

        </div>

        <b-modal v-model="modalShow" ref="eventForm" hide-footer hide-header id="eventForm" size="lg">
            <eventForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                    v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                    <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>

    </div>
</template>

<script>
import moment from 'moment'
import eventForm from '@@/components/forms/eventForm'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'event',
    components : { eventForm },
    fetch ({ store, params }) {
        store.dispatch('event/getAll');
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            end_date: null,
        }
    },
    computed: {
        ...mapState(['event'])
    },
    methods: {
        ...mapActions({
            getDetail: 'event/getDetail',
            clearDetail: 'event/clearDetail',
            deleteOne: 'event/deleteOne'
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('eventForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.end_date = this.event.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/event?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/event', {}, {
                    params : {
                        object_identifier : this.event.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('event/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });
        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
