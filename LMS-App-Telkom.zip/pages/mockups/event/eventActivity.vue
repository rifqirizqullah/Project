<template>
    <div class="container page-section">

        <div class="card">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <span>
                    <h4 class="card-title">Event Activity</h4>
                    <p class="card-subtitle">List of Event Activity</p>
                </span>
            </div>

            <table class="table table-flush table-responsive table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Event</th>
                        <!-- <th>Learning Plan</th> -->
                        <th>Learning Activity</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in eventActivity.list" :key="index" @click="" >
                        <td> {{ index+1 }} </td>
                        <td> {{ item.event.event_name }} </td>
                        <!-- <td> {{ item.learning_plan.title }} </td> -->
                        <td> {{ item.learning_activity.activity_name }} </td>
                        <td> {{ formatDate(item.begin_date) }} </td>
                        <td> {{ formatDate(item.end_date) }} </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="">Schedule</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="eventActivity.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>

        </div>

    </div>
</template>

<script>
import moment from 'moment'
import { mapState, mapActions } from 'vuex'

export default {
    layout : 'event',
    async created() {
        await this.$store.dispatch('event/clearDetail');
        this.$store.dispatch('eventActivity/getAll');
    },
    computed: {
        ...mapState(['eventActivity', 'event']),
    },
    methods: {

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }

    },

}
</script>
