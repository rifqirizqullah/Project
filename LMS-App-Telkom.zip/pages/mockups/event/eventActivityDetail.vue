<template>
    <div class="container page-section">

        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h4 class="card-title">Schedule Activity</h4>
                <p class="card-subtitle">Schedule Activity of This Event</p>
            </div>
            <button class="btn btn-sm btn-success" @click="$bvModal.show('scheduleActivityForm')" >+ Add Schedule Activity</button>
        </div>

        <div class="card">

            <table class="table table-flush table-responsive table-hover">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Event Activity</th>
                        <th>Topic</th>
                        <th>Method</th>
                        <th>Time Class</th>
                        <th>Unit</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in scheduleActivity.list" :key="index">
                        <td> {{ index+1 }} </td>
                        <td> {{ item.event_activity.event_activity_id }} </td>
                        <td> {{ item.topic }} </td>
                        <td> {{ item.method.value }} </td>
                        <td> {{ item.time_class }} </td>
                        <td> {{ item.unit.organization_name }} </td>
                        <td> {{ item.begin_time }} </td>
                        <td> {{ item.end_time }} </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="scheduleActivity.isLoading" >
                        <td colspan="10">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>

            </table>

        </div>
        <b-modal v-model="modalShow" ref="scheduleActivityForm" hide-footer hide-header id="scheduleActivityForm" size="lg" @hide='clearDetail'>
            <scheduleActivityForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                    v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                    <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>
    </div>
</template>

<script>
import moment from 'moment'
import scheduleActivityForm from '@@/components/forms/scheduleActivityForm'
import paginationBar from '@@/components/paginationBar'

import {mapState, mapActions} from 'vuex'

export default {
    layout : 'event',
    components : {
        scheduleActivityForm ,
        paginationBar
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            end_date: null,
        }
    },
    async created() {
        this.$store.dispatch('scheduleActivity/getAll');
    },
    computed: {
        ...mapState({
            scheduleActivity : state => state.scheduleActivity
            //event_id : state => state.event.detail.event_id
        }),

        // currentEventActivity() {
        //     return this.eventActivity.list.filter(item => {
        //         return item.event.event_id == this.event_id
        //     })
        // }
    },
    methods: {
        ...mapActions({
            getDetail: 'scheduleActivity/getDetail',
            clearDetail: 'scheduleActivity/clearDetail',
            deleteOne: 'scheduleActivity/deleteOne'
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('scheduleActivityForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.end_date = this.scheduleActivity.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/scheduleactivity?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/scheduleactivity', {}, {
                    params : {
                        object_identifier : this.scheduleActivity.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('scheduleActivity/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });

        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
