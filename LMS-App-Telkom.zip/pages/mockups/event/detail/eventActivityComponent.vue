<template>
    <div>
        <div class="mb-heading d-flex align-items-end px-3">
            <div class="flex">
                <h4 class="card-title">Event Activity</h4>
                <p class="card-subtitle">Activity of This Event</p>
            </div>
            <button class="btn btn-sm btn-success" @click="$bvModal.show('eventActivityForm')" >+ Add Event Activity</button>
        </div>

        <div class="card">
            <table class="table table-flush table-nowrap table-responsive">
                <thead class="">
                    <tr class="">
                        <th>No</th>
                        <th>Learning Plan</th>
                        <th>Learning Activity</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(item, index) in eventActivity.list" :key="index" >
                        <td> {{index+1}} </td>
                        <td> {{item.learning_plan && item.learning_plan.title}} </td>
                        <td> {{item.learning_activity && item.learning_activity.activity_name}} </td>
                        <td> {{formatDate(item.begin_date)}} </td>
                        <td> {{formatDate(item.end_date)}} </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="padding:6px;"></button>
                                <div class="dropdown-menu" aria-labelledby="triggerId">
                                    <button class="dropdown-item" @click="showUpdateForm(item.object_identifier)">Update</button>
                                    <button class="dropdown-item" @click="deleteData(item.object_identifier, index)">Delete</button>
                                    <button class="dropdown-item" @click="showDelimitForm(item.object_identifier, item.end_date)">Delimit</button>
                                    <button class="dropdown-item" @click="getDetail(item.object_identifier); $router.push('/event/eventActivityDetail')">Detail</button>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr v-if="eventActivity.isLoading" >
                        <td colspan="6">
                            <div class="row">
                                <div class="col d-flex justify-content-center">
                                    <div class="loader loader-accent text-center"></div>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>


            </table>
        </div>

        <b-modal v-model="modalShow" ref="eventActivityForm" hide-footer hide-header id="eventActivityForm" size="lg" @hide='clearDetail'>
            <eventActivityForm v-if="modalShow" />
        </b-modal>

        <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
            <div class="form-group">
                <label for="end_date">End Date</label>
                <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                    placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                    v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                    <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
            </div>
            <div slot="modal-footer">
                <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
            </div>
        </b-modal>


    </div>
</template>

<script>
import moment from 'moment'
import eventActivityForm from '@@/components/forms/eventActivityForm'
import paginationBar from '@@/components/paginationBar'

import {mapState, mapActions} from 'vuex'

export default {
    components : {
        eventActivityForm ,
        paginationBar
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            end_date: null,
        }
    },
    computed: {
        ...mapState({
            eventActivity : state => state.eventActivity,
            // event_id : state => state.event.detail.event_id
        }),

        // currentEventActivity() {
        //     return this.eventActivity.list.filter(item => {
        //         return item.event.event_id == this.event_id
        //     })
        // }
    },
    methods: {
        ...mapActions({
            getDetail: 'eventActivity/getDetail',
            clearDetail: 'eventActivity/clearDetail',
            deleteOne: 'eventActivity/deleteOne'
        }),

        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('eventActivityForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.end_date = this.eventActivity.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/eventactivity?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/eventactivity', {}, {
                    params : {
                        object_identifier : this.eventActivity.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('eventActivity/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });

        },
        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
