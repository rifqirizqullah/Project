<template>
    <div class="container page-section">

        <h1 class="display-4">Event Detail</h1>

        <div class="row p-2">
            <div class="col card p-0">
                <div class="card-header bg-light ">
                    <h3 class="card-title text-dark">{{event.event_name}}</h3>
                    <p class="card-subtitle text-dark">
                        ID <code> {{event.event_id}} </code>
                        Identifier <code> {{event.object_identifier}} </code>
                    </p>
                </div>
                <div class="row card-body">
                    <div class="col-lg-3">
                        <small>Event Type</small>
                        <p>{{event.event_type.value}}</p>
                    </div>
                    <div class="col-lg-3">
                        <small>Begin/End Date</small>
                        <p>{{formatDate(event.begin_date)}} - {{formatDate(event.end_date)}}</p>
                    </div>
                    <!-- <div class="col-lg-2">
                        <small>Event Template</small>
                        <p>{{event.template.value}}</p>
                    </div> -->
                    <div class="col-lg-2">
                        <small>Company</small>
                        <p>{{event.business_code.company_name}}</p>
                    </div>
                    <div class="col-lg-2">
                        <small>Organization</small>
                        <p>{{event.organization.organization_name}}</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-8pt">

            <div class="col-md-8">

                <eventActivityComponent/>

                <eventBudgetComponent/>

            </div>

            <div class="col-md-4">

                <eventParticipantComponent/>

            </div>

        </div>

    </div>
</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'

import eventBudgetComponent from './eventBudgetComponent'
import eventActivityComponent from './eventActivityComponent'
import eventParticipantComponent from './eventParticipantComponent'

export default {
    layout : 'event',
    components : {eventBudgetComponent, eventActivityComponent, eventParticipantComponent},
    middleware: ({ store, redirect }) => {
        if (!store.state.event.detail) return redirect('/event')
    },
    async fetch ({ store, param }) {
        store.dispatch('eventActivity/getAll')
        store.dispatch('eventBudget/getAll')
        store.dispatch('eventParticipant/getAll')
    },
    computed: {
        ...mapState({
            event: state => state.event.detail,
            event_id: state=> state.event.detail.event_id
        })
    },
    methods: {
        ...mapActions({
            getDetail: 'event/getDetail',
            clearDetail: 'event/clearDetail',
        }),

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
