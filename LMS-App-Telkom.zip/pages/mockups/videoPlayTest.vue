<template>
    <div>
         <video ref="videoRef" src="" id="video-container" width="100%" controls></video>
    </div>
</template>

<script>
export default {
    mounted() {
        this.$refs.videoRef.src = "http://iandevlin.github.io/mdn/video-player/video/tears-of-steel-battle-clip-medium.mp4";
        this.$refs.videoRef.play();
    },
}
</script>

<style>

</style>
