<template>
    <div>
        <div class="container">
            <headerEventComponent/>
        </div>
        <div class="container">
            <headerBatchComponent/>
        </div>
        <div class="container">
            <headerSessionComponent/>
        </div>
        <div class="container">
            <headerQuizComponent/>
        </div>
        <div class="container page-section pt-0">
            <span class="d-flex justify-content-between align-items-center">
                <h2 class="m-3"> <i class="material-icons text-info">access_time</i> Feedback Question</h2>               
            </span>
            <div class="card">
                <table class="table table-hover table-flush table-responsive">
                    <thead class="thead">
                        <tr>
                            <th>No</th>
                            <th>Company</th>
                            <th>Title</th>
                            <th>Text</th>
                            <th>Type</th>
                            <th>Category</th>
                            <th>Purpose</th>
                            <th>Choices</th>
                        </tr>
                    </thead>
                    <tbody v-if="relation">
                        <tr v-for="(item , index) in relation.list" :key="index">
                            <td>{{index +1}}</td>
                            <td>{{item.id.business_code.company_name}}</td>
                            <td @click="getDetail(item.object_identifier); $router.push('/mockups/feedback-result-detail?type='+type)" style="cursor:pointer;">
                                <strong>{{item.id.quesioner_title}}</strong>
                            </td>
                            <td>{{item.id.quesioner_text}}</td>
                            <td>{{item.id.quesioner_type.value}}</td>
                            <td>{{item.id.quesioner_category.value}}</td>
                            <td>{{item.id.quesioner_purpose.value}}</td>
                            <td>{{item.id.number_of_choice}}</td>                            
                        </tr>
                        <tr v-if="relation.isLoading" >
                            <td colspan="10">
                                <div class="row">
                                    <div class="col d-flex justify-content-center">
                                        <div class="loader loader-accent text-center"></div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="card-footer">
                    <paginationBar :state='relation' :storeModuleName="'relation'" />
                </div>
            </div>           
        </div>
    </div>
</template>

<script>
import moment from 'moment'

import paginationBar from '@@/components/paginationBar'
import headerEventComponent from '@@/components/headerEventComponent'
import headerBatchComponent from '@@/components/headerBatchComponent'
import headerSessionComponent from '@@/components/headerSessionComponent'
import headerQuizComponent from '@@/components/headerQuizComponent'
import {mapState, mapActions} from 'vuex'

export default {
    layout : 'result-feedback',
    components : {paginationBar, headerEventComponent, headerBatchComponent, headerSessionComponent, headerQuizComponent },
    middleware: ({ store, redirect }) => {
        if (!store.state.schedule_templateQuestioner.detail.relation_quesioner_id) return redirect('/event/event')
    },
    data() {
        return {
            type : this.$route.query.type
        }
    },
    created() {
        this.$store.dispatch('relation/getAll',{'object[]':this.schedule_templateQuestioner.template_code.id,'table_code[]':'QUESN','relation[]':'Q001','otype[]':'TPLCD'})
        console.log(this.relation.list)
        console.log(this.schedule_templateQuestioner)
    },
    computed: {
        ...mapState({
            schedule_templateQuestioner : state => state.schedule_templateQuestioner.detail,
            relation : state => state.relation,
        }),
    },
    methods: {
        ...mapActions({
            getDetail: 'relation/getDetail'            
        }),       

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        },

        formatDay(date) {
            return moment(date).format('dddd, DD MMM YYYY')
        }
    },

}
</script>

