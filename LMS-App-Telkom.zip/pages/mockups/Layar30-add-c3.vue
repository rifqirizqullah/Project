<template>
        <div class="page-section bg-white border-bottom-2">
            <div class="container page__container">
                <div class="container card bg-info">
                    <div class="card-header bg-info">
                        <span class="h2 text-white">In Class Learning (Event Participant)</span>
                    </div>
                    <div class="card-body">
                        <h3 class="card-title text-white">Nama Event<!-- {{event.event_name}} --></h3>
                        <p class="card-subtitle text-white">
                            ID <code> <!-- {{event.event_id}} --> </code>
                            Identifier <code> <!-- {{event.object_identifier}} --> </code>
                        </p>
                        <div class="card-subtitle text-white">
                            <small>Begin/End Date</small>
                            <p><!-- {{formatDate(event.begin_date)}} - {{formatDate(event.end_date)}} --></p>
                        </div>
                    </div>
                </div>
                <div class="container card">
                    <div class="card-header d-flex align-items-end">
                        <div class="flex">
                            <h4 class="card-title">Event Participant</h4>
                        </div>
                        <button class="btn btn-sm btn-success" @click="$bvModal.show('eventParticipantForm')" >+ Add Event Participant</button>
                        <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info" v-b-toggle.collapse-a>
                            <span class="btn-label"><i class="fa fa-search"></i> Search</span>
                        </b-button>



                        <!-- <div class="">
                            <div class="text-right">
                                // Elements to collapse
                                <b-collapse id="collapse-a" class="mt-2">
                                    <br>
                                    <form action="" class="p-2">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <input v-model="filters.participant_name" type="text" class="form-control" id="name" placeholder="Name">
                                                    <small>Participant Name</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-6 col-lg-3">
                                                <div class="form-group">
                                                    <select v-model="filters.cycle" class="form-control" name="cycle" id="cycle">
                                                        <option v-for="(item, index) in CYCLE.list" :key="index" :value="item.id">{{item.value}}</option>
                                                    </select>
                                                    <small>Cycle</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-6 col-lg-3">
                                                <div class="form-group">
                                                    <select v-model="filters.activity_type" class="form-control" name="activity_type" id="activity_type">
                                                        <option v-for="(item, index) in ACTTY.list" :key="index" :value="item.id">{{item.value}}</option>
                                                    </select>
                                                    <small>Activity Type</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-6 col-lg-3">
                                                <div class="form-group">
                                                    <select v-model="filters.flag_online" class="form-control" name="flag_online" id="flag_online">
                                                        <option :value="true">Online</option>
                                                        <option :value="false">Offline</option>
                                                    </select>
                                                    <small>Flag Online</small>
                                                </div>
                                            </div>
                                            <div class="col-12 col-md-12">
                                                <div class="form-group text-right">
                                                    <b-button @click="filters = {}; runFilter()" variant="secondary" >Clear Filter</b-button>
                                                    <b-button @click="runFilter" variant="info" >
                                                        <span class="btn-label"><i class="fa fa-search"></i> Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div> -->
                    </div>    
                    <div class="">
                        <div class=" text-right">
                            <div>
                                <b-collapse id="collapse-a" class="mt-2">
                                    <form class="p-2">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <input v-model="filters.participant_name" type="text" class="form-control" id="name" placeholder="Name">
                                                    <small>Participant Name</small>
                                                </div>
                                            </div>
                                            <!-- <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <input type="text" class="form-control"
                                                        id="exampleFormControlInput1" placeholder="Session Name">
                                                    <small class="form-text text-muted">Session Name</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <select class="form-control" name="learning_activity"
                                                        id="learning_activity">
                                                        <option></option>
                                                    </select>
                                                    <small class="form-text text-muted">learning Activity</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr v-model="begin_date" :config="{dateFormat: 'Y-m-d'}"
                                                        class="form-control" placeholder="Select start date"
                                                        name="begin_date" id="begin_date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.begin_date')}"
                                                        v-validate="'required'" data-vv-scope="collection" />
                                                    <small class="form-text text-muted">Start Date</small>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-3">
                                                <div class="form-group">
                                                    <flat-pickr v-model="end_date"
                                                        :config="{dateFormat: 'Y-m-d', minDate: begin_date}"
                                                        class="form-control" placeholder="Select end date"
                                                        name="end_date" id="end_date"
                                                        v-bind:class="{ 'is-danger': errors.has('collection.end_date')}"
                                                        v-validate="'required'" data-vv-scope="collection" />
                                                    <small class="form-text text-muted">End Date</small>
                                                </div>
                                            </div> -->

                                            <div class="col-sm-12 col-md-12">
                                                <div class="form-group text-right">
                                                    <b-button type="button"
                                                        class="ml-3 btn btn-sm btn-labeled btn-secondary"
                                                        v-b-toggle.collapse-a>
                                                        <span class="btn-label">
                                                            Clear Search</span>
                                                    </b-button>
                                                    <b-button type="button" class="ml-3 btn btn-sm btn-labeled btn-info"
                                                        v-b-toggle.collapse-a>
                                                        <span class="btn-label">
                                                            Filter</span>
                                                    </b-button>
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </b-collapse>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-responsive">
                            <thead class="thead-light">
                                <tr>
                                    <th>No</th>
                                    <th>Participant</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item, index) in currentEventParticipant" :key="index" >
                                    <td> {{ index+1 }} </td>
                                    <td>
                                        {{ item.participant.complete_name }} <br/>
                                        <small class="text-muted">{{ item.participant.business_code.company_name }}</small>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button class="btn btn-secondary dropdown-toggle" type="button" id="triggerId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></button>
                                            <div class="dropdown-menu" aria-labelledby="triggerId">
                                                <button class="dropdown-item" @click="editData(data.object_identifier)">Edit</button>
                                                <button class="dropdown-item" @click="deleteData(data.object_identifier, index)">Delete</button>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr v-if="eventParticipant.isLoading" >
                                    <td colspan="6">
                                        <div class="row">
                                            <div class="col d-flex justify-content-center">
                                                <div class="loader loader-accent text-center"></div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </tfoot>

                        </table>
                    </div>
                </div>
                <b-modal v-model="modalShow" ref="eventParticipantForm" hide-footer hide-header id="eventParticipantForm" size="lg" @hide='clearDetail'>
                    <eventParticipantForm v-if="modalShow" />
                </b-modal>

                <!-- <b-modal v-model="modalDelimitShow" id="modalDelimit" centered title="Delimit Data" size="sm">
                    <div class="form-group">
                        <label for="end_date">End Date</label>
                        <flat-pickr v-model="end_date" :config="{dateFormat : 'Y-m-d'}" class="form-control"
                            placeholder="Select end date" name="date" v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}"
                            v-validate="'required'" data-vv-scope="delimit"> </flat-pickr>
                            <p v-show="errors.has('delimit.end_date')" class="help is-danger"> {{ errors.first('delimit.end_date') }}</p>
                    </div>
                    <div slot="modal-footer">
                        <button type="button" class="btn btn-secondary" @click="$bvModal.hide('modalDelimit')">Cancel</button>
                        <button type="button" class="btn btn-primary" @click="delimitData">Save</button>
                    </div>
                </b-modal> -->

            </div>
        </div>

</template>

<script>
import moment from 'moment'
import {mapState, mapActions} from 'vuex'

import eventParticipantForm from '@@/components/forms/eventParticipantForm'

export default {
     layout: 'batch',
    components : { 
        eventParticipantForm 
    },
    fetch ({ store, params }) {
        store.dispatch('event/getAll');
    },
    data() {
        return {
            modalShow: false,
            modalDelimitShow : false,

            end_date: null,
            filters: {
                participant_name : null,
            }
        }
    },
    computed: {
        ...mapState({
            eventParticipant : state => state.eventParticipant,
            event_id : state => state.event.detail.event_id,
            event: state => state.event.detail
        }),

        currentEventParticipant() {
            return this.eventParticipant.list.filter(item => {
                return item.event.event_id == this.event_id
            })
        },

    },
    methods: {
        ...mapActions({
            getDetail: 'eventParticipant/getDetail',
            clearDetail: 'eventParticipant/clearDetail',
            deleteOne: 'eventParticipant/deleteOne'
        }),

        runFilter(){
            let params = {}
            if (this.filters.participant_name)
                params["participant_name[]"] = this.filters.participant_name
            // if (this.filters.cycle)
            //     params["cycle[]"] = this.filters.cycle
            // if (this.filters.flag_online !== null)
            //     params["flag_online[]"] = this.filters.flag_online
            this.getAll(params)

            // -------------- API get learningactivity ngirim parameter activity_type[] ga jalan ??
        },
        clearFilters(){
            this.filters = {
                participant_name : null,
                // cycle : null,
                // flag_online : null,
            }

        },
        showUpdateForm(object_identifier) {
            this.getDetail(object_identifier)
            this.$bvModal.show('eventParticipantForm')
        },

        async showDelimitForm(object_identifier) {
            await this.getDetail(object_identifier)
            this.end_date = this.eventParticipant.detail.end_date
            this.$bvModal.show('modalDelimit')
        },

        deleteData(id, index) {
            this.$swal({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
            })
            .then((result) => {
                if (result.value) {
                    this.$axios.delete('lms/api/eventparticipant?object_identifier=' + id)
                    .then(response => {
                        return this.$swal( 'Deleted!', response.data.message, 'success')
                    })
                    .then((result) => {
                        this.deleteOne(index)
                    })
                    .catch(e => {
                        console.log(e.response);
                    })
                }
            });
        },

        delimitData() {
            this.$validator.validateAll('delimit').then(async result => {
                if (!result) return;
                this.$axios.patch('lms/api/eventparticipant', {}, {
                    params : {
                        object_identifier : this.eventParticipant.detail.object_identifier,
                        end_date : this.end_date,
                    }
                })
                .then(response => {
                    this.$store.dispatch('eventParticipant/getAll');
                    this.$bvModal.hide('modalDelimit')
                    this.$swal(
                        'Saved!',
                        'Successfully saved data.',
                        'success'
                    )
                })
                .catch(e => {
                    console.log(e.response);
                });
            });

        },

        formatDate(date) {
            return moment(date).format('DD MMM YYYY')
        }
    },

}
</script>
