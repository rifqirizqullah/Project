import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const log = console // on server-side, consola will catch all console.log
const VUEX_PROPERTIES = ['state', 'getters', 'actions', 'mutations']
let store = {}

void (function updateModules() {
  store = normalizeRoot(require('@/store/index.js'), 'store/index.js')

  // If store is an exported method = classic mode (deprecated)

  if (typeof store === 'function') {
    return log.warn('Classic mode for store/ is deprecated and will be removed in Nuxt 3.')
  }

  // Enforce store modules
  store.modules = store.modules || {}

  resolveStoreModules(require('@/store/NATIO.js'), 'NATIO.js')
  resolveStoreModules(require('@/store/ACDCD.js'), 'ACDCD.js')
  resolveStoreModules(require('@/store/ADDTY.js'), 'ADDTY.js')
  resolveStoreModules(require('@/store/ATDST.js'), 'ATDST.js')
  resolveStoreModules(require('@/store/attendance.js'), 'attendance.js')
  resolveStoreModules(require('@/store/batch.js'), 'batch.js')
  resolveStoreModules(require('@/store/batchBudget.js'), 'batchBudget.js')
  resolveStoreModules(require('@/store/batchParticipant.js'), 'batchParticipant.js')
  resolveStoreModules(require('@/store/BTYPE.js'), 'BTYPE.js')
  resolveStoreModules(require('@/store/building.js'), 'building.js')
  resolveStoreModules(require('@/store/CMPTY.js'), 'CMPTY.js')
  resolveStoreModules(require('@/store/company.js'), 'company.js')
  resolveStoreModules(require('@/store/companyRelation.js'), 'companyRelation.js')
  resolveStoreModules(require('@/store/competence_activity.js'), 'competence_activity.js')
  resolveStoreModules(require('@/store/COMTY.js'), 'COMTY.js')
  resolveStoreModules(require('@/store/CONTR.js'), 'CONTR.js')
  resolveStoreModules(require('@/store/CURID.js'), 'CURID.js')
  resolveStoreModules(require('@/store/curriculum.js'), 'curriculum.js')
  resolveStoreModules(require('@/store/curriculumRequest.js'), 'curriculumRequest.js')
  resolveStoreModules(require('@/store/CYCLE.js'), 'CYCLE.js')
  resolveStoreModules(require('@/store/EMPCL.js'), 'EMPCL.js')
  resolveStoreModules(require('@/store/event.js'), 'event.js')
  resolveStoreModules(require('@/store/eventActivity.js'), 'eventActivity.js')
  resolveStoreModules(require('@/store/eventBudget.js'), 'eventBudget.js')
  resolveStoreModules(require('@/store/eventParticipant.js'), 'eventParticipant.js')
  resolveStoreModules(require('@/store/eventPlan.js'), 'eventPlan.js')
  resolveStoreModules(require('@/store/eventPlanBatch.js'), 'eventPlanBatch.js')
  resolveStoreModules(require('@/store/eventPlanStrategy.js'), 'eventPlanStrategy.js')
  resolveStoreModules(require('@/store/EVNST.js'), 'EVNST.js')
  resolveStoreModules(require('@/store/EVNTY.js'), 'EVNTY.js')
  resolveStoreModules(require('@/store/FACCD.js'), 'FACCD.js')
  resolveStoreModules(require('@/store/forum_comment.js'), 'forum_comment.js')
  resolveStoreModules(require('@/store/forum_like.js'), 'forum_like.js')
  resolveStoreModules(require('@/store/forum.js'), 'forum.js')
  resolveStoreModules(require('@/store/GENDR.js'), 'GENDR.js')
  resolveStoreModules(require('@/store/insight.js'), 'insight.js')
  resolveStoreModules(require('@/store/LANGU.js'), 'LANGU.js')
  resolveStoreModules(require('@/store/learningActivity.js'), 'learningActivity.js')
  resolveStoreModules(require('@/store/learningPath.js'), 'learningPath.js')
  resolveStoreModules(require('@/store/learningStrategy.js'), 'learningStrategy.js')
  resolveStoreModules(require('@/store/LEVST.js'), 'LEVST.js')
  resolveStoreModules(require('@/store/LFCOD.js'), 'LFCOD.js')
  resolveStoreModules(require('@/store/LOCID.js'), 'LOCID.js')
  resolveStoreModules(require('@/store/LOSID.js'), 'LOSID.js')
  resolveStoreModules(require('@/store/LPTID.js'), 'LPTID.js')
  resolveStoreModules(require('@/store/masterLearningPlan.js'), 'masterLearningPlan.js')
  resolveStoreModules(require('@/store/materi.js'), 'materi.js')
  resolveStoreModules(require('@/store/MATTY.js'), 'MATTY.js')
  resolveStoreModules(require('@/store/mentor.js'), 'mentor.js')
  resolveStoreModules(require('@/store/mentorAddress.js'), 'mentorAddress.js')
  resolveStoreModules(require('@/store/mentorCommunication.js'), 'mentorCommunication.js')
  resolveStoreModules(require('@/store/mentoring.js'), 'mentoring.js')
  resolveStoreModules(require('@/store/mentoringChat.js'), 'mentoringChat.js')
  resolveStoreModules(require('@/store/mentoringMentee.js'), 'mentoringMentee.js')
  resolveStoreModules(require('@/store/mentoringMentor.js'), 'mentoringMentor.js')
  resolveStoreModules(require('@/store/mentoringParticipant.js'), 'mentoringParticipant.js')
  resolveStoreModules(require('@/store/mentorJob.js'), 'mentorJob.js')
  resolveStoreModules(require('@/store/MENTY.js'), 'MENTY.js')
  resolveStoreModules(require('@/store/myBatch.js'), 'myBatch.js')
  resolveStoreModules(require('@/store/mySchedule.js'), 'mySchedule.js')
  resolveStoreModules(require('@/store/ACTTY.js'), 'ACTTY.js')
  resolveStoreModules(require('@/store/object.js'), 'object.js')
  resolveStoreModules(require('@/store/OBJECTISSUE.js'), 'OBJECTISSUE.js')
  resolveStoreModules(require('@/store/organizationData.js'), 'organizationData.js')
  resolveStoreModules(require('@/store/otype.js'), 'otype.js')
  resolveStoreModules(require('@/store/OTYPEISSUE.js'), 'OTYPEISSUE.js')
  resolveStoreModules(require('@/store/participant.js'), 'participant.js')
  resolveStoreModules(require('@/store/participantAddress.js'), 'participantAddress.js')
  resolveStoreModules(require('@/store/participantCommunication.js'), 'participantCommunication.js')
  resolveStoreModules(require('@/store/participantJob.js'), 'participantJob.js')
  resolveStoreModules(require('@/store/PARTY.js'), 'PARTY.js')
  resolveStoreModules(require('@/store/penyelenggaraanEvent.js'), 'penyelenggaraanEvent.js')
  resolveStoreModules(require('@/store/PERNR.js'), 'PERNR.js')
  resolveStoreModules(require('@/store/personals.js'), 'personals.js')
  resolveStoreModules(require('@/store/plan.js'), 'plan.js')
  resolveStoreModules(require('@/store/PLCOD.js'), 'PLCOD.js')
  resolveStoreModules(require('@/store/PRFIS.js'), 'PRFIS.js')
  resolveStoreModules(require('@/store/PRVNC_CITY.js'), 'PRVNC_CITY.js')
  resolveStoreModules(require('@/store/PRVNC.js'), 'PRVNC.js')
  resolveStoreModules(require('@/store/QSNTY.js'), 'QSNTY.js')
  resolveStoreModules(require('@/store/QSTCT.js'), 'QSTCT.js')
  resolveStoreModules(require('@/store/QSTPR.js'), 'QSTPR.js')
  resolveStoreModules(require('@/store/QSTTY.js'), 'QSTTY.js')
  resolveStoreModules(require('@/store/quesioner_choice.js'), 'quesioner_choice.js')
  resolveStoreModules(require('@/store/quesionerParticipantChoice.js'), 'quesionerParticipantChoice.js')
  resolveStoreModules(require('@/store/questioner.js'), 'questioner.js')
  resolveStoreModules(require('@/store/relation.js'), 'relation.js')
  resolveStoreModules(require('@/store/relationId.js'), 'relationId.js')
  resolveStoreModules(require('@/store/RELIG.js'), 'RELIG.js')
  resolveStoreModules(require('@/store/REQTY.js'), 'REQTY.js')
  resolveStoreModules(require('@/store/room.js'), 'room.js')
  resolveStoreModules(require('@/store/RQSTY.js'), 'RQSTY.js')
  resolveStoreModules(require('@/store/saranaRequest.js'), 'saranaRequest.js')
  resolveStoreModules(require('@/store/schedule_materi.js'), 'schedule_materi.js')
  resolveStoreModules(require('@/store/schedule_room.js'), 'schedule_room.js')
  resolveStoreModules(require('@/store/schedule_templateQuestioner.js'), 'schedule_templateQuestioner.js')
  resolveStoreModules(require('@/store/schedule_templateTest.js'), 'schedule_templateTest.js')
  resolveStoreModules(require('@/store/schedule_trainer_approoved.js'), 'schedule_trainer_approoved.js')
  resolveStoreModules(require('@/store/schedule_trainer.js'), 'schedule_trainer.js')
  resolveStoreModules(require('@/store/schedule.js'), 'schedule.js')
  resolveStoreModules(require('@/store/scheduleActivity.js'), 'scheduleActivity.js')
  resolveStoreModules(require('@/store/session.js'), 'session.js')
  resolveStoreModules(require('@/store/STTAR.js'), 'STTAR.js')
  resolveStoreModules(require('@/store/TAXTY.js'), 'TAXTY.js')
  resolveStoreModules(require('@/store/TCMTD.js'), 'TCMTD.js')
  resolveStoreModules(require('@/store/templateQuestioner.js'), 'templateQuestioner.js')
  resolveStoreModules(require('@/store/test_question_choice.js'), 'test_question_choice.js')
  resolveStoreModules(require('@/store/test_templateTest.js'), 'test_templateTest.js')
  resolveStoreModules(require('@/store/testquestionbank.js'), 'testquestionbank.js')
  resolveStoreModules(require('@/store/TPLCD.js'), 'TPLCD.js')
  resolveStoreModules(require('@/store/TPLTY.js'), 'TPLTY.js')
  resolveStoreModules(require('@/store/trainer.js'), 'trainer.js')
  resolveStoreModules(require('@/store/trainerAddress.js'), 'trainerAddress.js')
  resolveStoreModules(require('@/store/trainerCommunication.js'), 'trainerCommunication.js')
  resolveStoreModules(require('@/store/trainerJob.js'), 'trainerJob.js')
  resolveStoreModules(require('@/store/TRIBE.js'), 'TRIBE.js')
  resolveStoreModules(require('@/store/TSTCD.js'), 'TSTCD.js')
  resolveStoreModules(require('@/store/TSTTY.js'), 'TSTTY.js')
  resolveStoreModules(require('@/store/unit.js'), 'unit.js')
  resolveStoreModules(require('@/store/wage.js'), 'wage.js')
  resolveStoreModules(require('@/store/WGERF.js'), 'WGERF.js')

  // If the environment supports hot reloading...

  if (process.client && module.hot) {
    // Whenever any Vuex module is updated...
    module.hot.accept([
      '@/store/NATIO.js',
      '@/store/ACDCD.js',
      '@/store/ADDTY.js',
      '@/store/ATDST.js',
      '@/store/attendance.js',
      '@/store/batch.js',
      '@/store/batchBudget.js',
      '@/store/batchParticipant.js',
      '@/store/BTYPE.js',
      '@/store/building.js',
      '@/store/CMPTY.js',
      '@/store/company.js',
      '@/store/companyRelation.js',
      '@/store/competence_activity.js',
      '@/store/COMTY.js',
      '@/store/CONTR.js',
      '@/store/CURID.js',
      '@/store/curriculum.js',
      '@/store/curriculumRequest.js',
      '@/store/CYCLE.js',
      '@/store/EMPCL.js',
      '@/store/event.js',
      '@/store/eventActivity.js',
      '@/store/eventBudget.js',
      '@/store/eventParticipant.js',
      '@/store/eventPlan.js',
      '@/store/eventPlanBatch.js',
      '@/store/eventPlanStrategy.js',
      '@/store/EVNST.js',
      '@/store/EVNTY.js',
      '@/store/FACCD.js',
      '@/store/forum_comment.js',
      '@/store/forum_like.js',
      '@/store/forum.js',
      '@/store/GENDR.js',
      '@/store/index.js',
      '@/store/insight.js',
      '@/store/LANGU.js',
      '@/store/learningActivity.js',
      '@/store/learningPath.js',
      '@/store/learningStrategy.js',
      '@/store/LEVST.js',
      '@/store/LFCOD.js',
      '@/store/LOCID.js',
      '@/store/LOSID.js',
      '@/store/LPTID.js',
      '@/store/masterLearningPlan.js',
      '@/store/materi.js',
      '@/store/MATTY.js',
      '@/store/mentor.js',
      '@/store/mentorAddress.js',
      '@/store/mentorCommunication.js',
      '@/store/mentoring.js',
      '@/store/mentoringChat.js',
      '@/store/mentoringMentee.js',
      '@/store/mentoringMentor.js',
      '@/store/mentoringParticipant.js',
      '@/store/mentorJob.js',
      '@/store/MENTY.js',
      '@/store/myBatch.js',
      '@/store/mySchedule.js',
      '@/store/ACTTY.js',
      '@/store/object.js',
      '@/store/OBJECTISSUE.js',
      '@/store/organizationData.js',
      '@/store/otype.js',
      '@/store/OTYPEISSUE.js',
      '@/store/participant.js',
      '@/store/participantAddress.js',
      '@/store/participantCommunication.js',
      '@/store/participantJob.js',
      '@/store/PARTY.js',
      '@/store/penyelenggaraanEvent.js',
      '@/store/PERNR.js',
      '@/store/personals.js',
      '@/store/plan.js',
      '@/store/PLCOD.js',
      '@/store/PRFIS.js',
      '@/store/PRVNC_CITY.js',
      '@/store/PRVNC.js',
      '@/store/QSNTY.js',
      '@/store/QSTCT.js',
      '@/store/QSTPR.js',
      '@/store/QSTTY.js',
      '@/store/quesioner_choice.js',
      '@/store/quesionerParticipantChoice.js',
      '@/store/questioner.js',
      '@/store/relation.js',
      '@/store/relationId.js',
      '@/store/RELIG.js',
      '@/store/REQTY.js',
      '@/store/room.js',
      '@/store/RQSTY.js',
      '@/store/saranaRequest.js',
      '@/store/schedule_materi.js',
      '@/store/schedule_room.js',
      '@/store/schedule_templateQuestioner.js',
      '@/store/schedule_templateTest.js',
      '@/store/schedule_trainer_approoved.js',
      '@/store/schedule_trainer.js',
      '@/store/schedule.js',
      '@/store/scheduleActivity.js',
      '@/store/session.js',
      '@/store/STTAR.js',
      '@/store/TAXTY.js',
      '@/store/TCMTD.js',
      '@/store/templateQuestioner.js',
      '@/store/test_question_choice.js',
      '@/store/test_templateTest.js',
      '@/store/testquestionbank.js',
      '@/store/TPLCD.js',
      '@/store/TPLTY.js',
      '@/store/trainer.js',
      '@/store/trainerAddress.js',
      '@/store/trainerCommunication.js',
      '@/store/trainerJob.js',
      '@/store/TRIBE.js',
      '@/store/TSTCD.js',
      '@/store/TSTTY.js',
      '@/store/unit.js',
      '@/store/wage.js',
      '@/store/WGERF.js',
    ], () => {
      // Update `root.modules` with the latest definitions.
      updateModules()
      // Trigger a hot update in the store.
      window.$nuxt.$store.hotUpdate(store)
    })
  }
})()

// createStore
export const createStore = store instanceof Function ? store : () => {
  return new Vuex.Store(Object.assign({
    strict: (process.env.NODE_ENV !== 'production')
  }, store))
}

function resolveStoreModules(moduleData, filename) {
  moduleData = moduleData.default || moduleData
  // Remove store src + extension (./foo/index.js -> foo/index)
  const namespace = filename.replace(/\.(js|mjs|ts)$/, '')
  const namespaces = namespace.split('/')
  let moduleName = namespaces[namespaces.length - 1]
  const filePath = `store/${filename}`

  moduleData = moduleName === 'state'
    ? normalizeState(moduleData, filePath)
    : normalizeModule(moduleData, filePath)

  // If src is a known Vuex property
  if (VUEX_PROPERTIES.includes(moduleName)) {
    const property = moduleName
    const storeModule = getStoreModule(store, namespaces, { isProperty: true })

    // Replace state since it's a function
    mergeProperty(storeModule, moduleData, property)
    return
  }

  // If file is foo/index.js, it should be saved as foo
  const isIndexModule = (moduleName === 'index')
  if (isIndexModule) {
    namespaces.pop()
    moduleName = namespaces[namespaces.length - 1]
  }

  const storeModule = getStoreModule(store, namespaces)

  for (const property of VUEX_PROPERTIES) {
    mergeProperty(storeModule, moduleData[property], property)
  }

  if (moduleData.namespaced === false) {
    delete storeModule.namespaced
  }
}

function normalizeRoot(moduleData, filePath) {
  moduleData = moduleData.default || moduleData

  if (moduleData.commit) {
    throw new Error(`[nuxt] ${filePath} should export a method that returns a Vuex instance.`)
  }

  if (typeof moduleData !== 'function') {
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData)
  }
  return normalizeModule(moduleData, filePath)
}

function normalizeState(moduleData, filePath) {
  if (typeof moduleData !== 'function') {
    log.warn(`${filePath} should export a method that returns an object`)
    const state = Object.assign({}, moduleData)
    return () => state
  }
  return normalizeModule(moduleData, filePath)
}

function normalizeModule(moduleData, filePath) {
  if (moduleData.state && typeof moduleData.state !== 'function') {
    log.warn(`'state' should be a method that returns an object in ${filePath}`)
    const state = Object.assign({}, moduleData.state)
    // Avoid TypeError: setting a property that has only a getter when overwriting top level keys
    moduleData = Object.assign({}, moduleData, { state: () => state })
  }
  return moduleData
}

function getStoreModule(storeModule, namespaces, { isProperty = false } = {}) {
  // If ./mutations.js
  if (!namespaces.length || (isProperty && namespaces.length === 1)) {
    return storeModule
  }

  const namespace = namespaces.shift()

  storeModule.modules[namespace] = storeModule.modules[namespace] || {}
  storeModule.modules[namespace].namespaced = true
  storeModule.modules[namespace].modules = storeModule.modules[namespace].modules || {}

  return getStoreModule(storeModule.modules[namespace], namespaces, { isProperty })
}

function mergeProperty(storeModule, moduleData, property) {
  if (!moduleData) return

  if (property === 'state') {
    storeModule.state = moduleData || storeModule.state
  } else {
    storeModule[property] = Object.assign({}, storeModule[property], moduleData)
  }
}
