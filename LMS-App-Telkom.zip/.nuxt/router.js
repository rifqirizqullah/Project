import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _a6430362 = () => interopDefault(import('..\\pages\\admin-trainer\\index.vue' /* webpackChunkName: "pages_admin-trainer_index" */))
const _97a8955a = () => interopDefault(import('..\\pages\\curriculum\\index.vue' /* webpackChunkName: "pages_curriculum_index" */))
const _47db8a04 = () => interopDefault(import('..\\pages\\expert\\index.vue' /* webpackChunkName: "pages_expert_index" */))
const _19e12148 = () => interopDefault(import('..\\pages\\learning-activity\\index.vue' /* webpackChunkName: "pages_learning-activity_index" */))
const _d057eb38 = () => interopDefault(import('..\\pages\\learning-strategy\\index.vue' /* webpackChunkName: "pages_learning-strategy_index" */))
const _226c9905 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _869abfe6 = () => interopDefault(import('..\\pages\\mentor\\index.vue' /* webpackChunkName: "pages_mentor_index" */))
const _64c766ee = () => interopDefault(import('..\\pages\\peserta\\index.vue' /* webpackChunkName: "pages_peserta_index" */))
const _7ba30ca0 = () => interopDefault(import('..\\pages\\resource\\index.vue' /* webpackChunkName: "pages_resource_index" */))
const _699e04a0 = () => interopDefault(import('..\\pages\\curriculum\\detail.vue' /* webpackChunkName: "pages_curriculum_detail" */))
const _eed07016 = () => interopDefault(import('..\\pages\\curriculum\\learning-path.vue' /* webpackChunkName: "pages_curriculum_learning-path" */))
const _38383e59 = () => interopDefault(import('..\\pages\\curriculum\\learning-path-detail.vue' /* webpackChunkName: "pages_curriculum_learning-path-detail" */))
const _e8fd7b60 = () => interopDefault(import('..\\pages\\curriculum\\request.vue' /* webpackChunkName: "pages_curriculum_request" */))
const _099c779e = () => interopDefault(import('..\\pages\\curriculum\\request-detail.vue' /* webpackChunkName: "pages_curriculum_request-detail" */))
const _0be56f8e = () => interopDefault(import('..\\pages\\event\\batch\\index.vue' /* webpackChunkName: "pages_event_batch_index" */))
const _6f90f82e = () => interopDefault(import('..\\pages\\event\\event\\index.vue' /* webpackChunkName: "pages_event_event_index" */))
const _38195190 = () => interopDefault(import('..\\pages\\event\\event-plan\\index.vue' /* webpackChunkName: "pages_event_event-plan_index" */))
const _8f14c13a = () => interopDefault(import('..\\pages\\expert\\absensi.vue' /* webpackChunkName: "pages_expert_absensi" */))
const _40506f93 = () => interopDefault(import('..\\pages\\expert\\detail\\index.vue' /* webpackChunkName: "pages_expert_detail_index" */))
const _3abd3b62 = () => interopDefault(import('..\\pages\\expert\\forum\\index.vue' /* webpackChunkName: "pages_expert_forum_index" */))
const _0f13a1f8 = () => interopDefault(import('..\\pages\\expert\\insight\\index.vue' /* webpackChunkName: "pages_expert_insight_index" */))
const _756d326d = () => interopDefault(import('..\\pages\\learning-activity\\competency-activity\\index.vue' /* webpackChunkName: "pages_learning-activity_competency-activity_index" */))
const _8ad3d16a = () => interopDefault(import('..\\pages\\learning-activity\\detail.vue' /* webpackChunkName: "pages_learning-activity_detail" */))
const _09ff5ca2 = () => interopDefault(import('..\\pages\\learning-strategy\\detail.vue' /* webpackChunkName: "pages_learning-strategy_detail" */))
const _06196c9c = () => interopDefault(import('..\\pages\\mentor\\detail\\index.vue' /* webpackChunkName: "pages_mentor_detail_index" */))
const _5acdfeda = () => interopDefault(import('..\\pages\\mockups\\add-activity-set.vue' /* webpackChunkName: "pages_mockups_add-activity-set" */))
const _b68a0e20 = () => interopDefault(import('..\\pages\\mockups\\adminTrainer.vue' /* webpackChunkName: "pages_mockups_adminTrainer" */))
const _0031cbc9 = () => interopDefault(import('..\\pages\\mockups\\aproovedTrainer.vue' /* webpackChunkName: "pages_mockups_aproovedTrainer" */))
const _57611668 = () => interopDefault(import('..\\pages\\mockups\\dashboardLMS.vue' /* webpackChunkName: "pages_mockups_dashboardLMS" */))
const _f41fe1fc = () => interopDefault(import('..\\pages\\mockups\\event\\index.vue' /* webpackChunkName: "pages_mockups_event_index" */))
const _393bb34b = () => interopDefault(import('..\\pages\\mockups\\feedback-result.vue' /* webpackChunkName: "pages_mockups_feedback-result" */))
const _97e9f37a = () => interopDefault(import('..\\pages\\mockups\\feedback-result-detail.vue' /* webpackChunkName: "pages_mockups_feedback-result-detail" */))
const _db46e300 = () => interopDefault(import('..\\pages\\mockups\\Layar15-manage-question.vue' /* webpackChunkName: "pages_mockups_Layar15-manage-question" */))
const _6ed9adee = () => interopDefault(import('..\\pages\\mockups\\Layar16a&16b-manage-question.vue' /* webpackChunkName: "pages_mockups_Layar16a&16b-manage-question" */))
const _38c60e3e = () => interopDefault(import('..\\pages\\mockups\\Layar20a-manage-feedback-bank.vue' /* webpackChunkName: "pages_mockups_Layar20a-manage-feedback-bank" */))
const _55ed1efa = () => interopDefault(import('..\\pages\\mockups\\Layar20b-feedback-test-add.vue' /* webpackChunkName: "pages_mockups_Layar20b-feedback-test-add" */))
const _1d42082e = () => interopDefault(import('..\\pages\\mockups\\Layar23-manage-test-template.vue' /* webpackChunkName: "pages_mockups_Layar23-manage-test-template" */))
const _a64e683c = () => interopDefault(import('..\\pages\\mockups\\Layar24-manage-expert.vue' /* webpackChunkName: "pages_mockups_Layar24-manage-expert" */))
const _0b16e73a = () => interopDefault(import('..\\pages\\mockups\\Layar24-manage-feedback-template.vue' /* webpackChunkName: "pages_mockups_Layar24-manage-feedback-template" */))
const _138ec93a = () => interopDefault(import('..\\pages\\mockups\\Layar25-create-expert-update.vue' /* webpackChunkName: "pages_mockups_Layar25-create-expert-update" */))
const _031ef31a = () => interopDefault(import('..\\pages\\mockups\\Layar26-event-plan.vue' /* webpackChunkName: "pages_mockups_Layar26-event-plan" */))
const _a160bc6c = () => interopDefault(import('..\\pages\\mockups\\Layar26-expert-profile-detail.vue' /* webpackChunkName: "pages_mockups_Layar26-expert-profile-detail" */))
const _9c804866 = () => interopDefault(import('..\\pages\\mockups\\Layar27-event-plan-add.vue' /* webpackChunkName: "pages_mockups_Layar27-event-plan-add" */))
const _30e07436 = () => interopDefault(import('..\\pages\\mockups\\Layar28-add-c1.vue' /* webpackChunkName: "pages_mockups_Layar28-add-c1" */))
const _40194f58 = () => interopDefault(import('..\\pages\\mockups\\Layar28-recap-expert.vue' /* webpackChunkName: "pages_mockups_Layar28-recap-expert" */))
const _38a03116 = () => interopDefault(import('..\\pages\\mockups\\Layar29-add-c2.vue' /* webpackChunkName: "pages_mockups_Layar29-add-c2" */))
const _3c1b027e = () => interopDefault(import('..\\pages\\mockups\\Layar30-add-c3.vue' /* webpackChunkName: "pages_mockups_Layar30-add-c3" */))
const _2c9b88be = () => interopDefault(import('..\\pages\\mockups\\Layar31-add-c4.vue' /* webpackChunkName: "pages_mockups_Layar31-add-c4" */))
const _1d1c0efe = () => interopDefault(import('..\\pages\\mockups\\Layar32-add-c5.vue' /* webpackChunkName: "pages_mockups_Layar32-add-c5" */))
const _0d9c953e = () => interopDefault(import('..\\pages\\mockups\\Layar33-add-c6.vue' /* webpackChunkName: "pages_mockups_Layar33-add-c6" */))
const _b648707a = () => interopDefault(import('..\\pages\\mockups\\Layar34-add-c3-classroom.vue' /* webpackChunkName: "pages_mockups_Layar34-add-c3-classroom" */))
const _7bec6fc6 = () => interopDefault(import('..\\pages\\mockups\\Layar35-add-c3-budget.vue' /* webpackChunkName: "pages_mockups_Layar35-add-c3-budget" */))
const _3a0e9f6d = () => interopDefault(import('..\\pages\\mockups\\Layar36add-c3-expert.vue' /* webpackChunkName: "pages_mockups_Layar36add-c3-expert" */))
const _599d3fd6 = () => interopDefault(import('..\\pages\\mockups\\Layar39-add-c3-work.vue' /* webpackChunkName: "pages_mockups_Layar39-add-c3-work" */))
const _468f65cf = () => interopDefault(import('..\\pages\\mockups\\Layar40-add-c3-delivery.vue' /* webpackChunkName: "pages_mockups_Layar40-add-c3-delivery" */))
const _31dc20c6 = () => interopDefault(import('..\\pages\\mockups\\Layar41-index.vue' /* webpackChunkName: "pages_mockups_Layar41-index" */))
const _71994b26 = () => interopDefault(import('..\\pages\\mockups\\Layar41-manage-expert-assignment.vue' /* webpackChunkName: "pages_mockups_Layar41-manage-expert-assignment" */))
const _7bf6a25e = () => interopDefault(import('..\\pages\\mockups\\Layar42-index.vue' /* webpackChunkName: "pages_mockups_Layar42-index" */))
const _63bf3e70 = () => interopDefault(import('..\\pages\\mockups\\Layar42-update-expert-assignment.vue' /* webpackChunkName: "pages_mockups_Layar42-update-expert-assignment" */))
const _819dbe1c = () => interopDefault(import('..\\pages\\mockups\\Layar43-proposed-learning.vue' /* webpackChunkName: "pages_mockups_Layar43-proposed-learning" */))
const _501dacaf = () => interopDefault(import('..\\pages\\mockups\\Layar44-forum.vue' /* webpackChunkName: "pages_mockups_Layar44-forum" */))
const _535ac8a7 = () => interopDefault(import('..\\pages\\mockups\\Layar45-insight.vue' /* webpackChunkName: "pages_mockups_Layar45-insight" */))
const _64db879a = () => interopDefault(import('..\\pages\\mockups\\Layar46-cycle-1.vue' /* webpackChunkName: "pages_mockups_Layar46-cycle-1" */))
const _536ca59c = () => interopDefault(import('..\\pages\\mockups\\Layar47-cycle-2.vue' /* webpackChunkName: "pages_mockups_Layar47-cycle-2" */))
const _41fdc39e = () => interopDefault(import('..\\pages\\mockups\\Layar48-cycle-3.vue' /* webpackChunkName: "pages_mockups_Layar48-cycle-3" */))
const _308ee1a0 = () => interopDefault(import('..\\pages\\mockups\\Layar49-cycle-4.vue' /* webpackChunkName: "pages_mockups_Layar49-cycle-4" */))
const _a040ef92 = () => interopDefault(import('..\\pages\\mockups\\Layar50-cycle-5.vue' /* webpackChunkName: "pages_mockups_Layar50-cycle-5" */))
const _c31eb38e = () => interopDefault(import('..\\pages\\mockups\\Layar51-cycle-6.vue' /* webpackChunkName: "pages_mockups_Layar51-cycle-6" */))
const _2256c40a = () => interopDefault(import('..\\pages\\mockups\\Layar52-53-54-feedback_penyelenggara.vue' /* webpackChunkName: "pages_mockups_Layar52-53-54-feedback_penyelenggara" */))
const _96734bd2 = () => interopDefault(import('..\\pages\\mockups\\Layar55-quiz.vue' /* webpackChunkName: "pages_mockups_Layar55-quiz" */))
const _597a222c = () => interopDefault(import('..\\pages\\mockups\\Layar56-event-detail-4.vue' /* webpackChunkName: "pages_mockups_Layar56-event-detail-4" */))
const _7a5e112f = () => interopDefault(import('..\\pages\\mockups\\login_page.vue' /* webpackChunkName: "pages_mockups_login_page" */))
const _2baa16c8 = () => interopDefault(import('..\\pages\\mockups\\manage-template-quesioneire.vue' /* webpackChunkName: "pages_mockups_manage-template-quesioneire" */))
const _58ce4828 = () => interopDefault(import('..\\pages\\mockups\\materi-detail.vue' /* webpackChunkName: "pages_mockups_materi-detail" */))
const _577600e7 = () => interopDefault(import('..\\pages\\mockups\\videoPlayTest.vue' /* webpackChunkName: "pages_mockups_videoPlayTest" */))
const _d13c754a = () => interopDefault(import('..\\pages\\mockups\\videoPlayTest2.vue' /* webpackChunkName: "pages_mockups_videoPlayTest2" */))
const _e10b5802 = () => interopDefault(import('..\\pages\\peserta\\activity\\index.vue' /* webpackChunkName: "pages_peserta_activity_index" */))
const _248debb6 = () => interopDefault(import('..\\pages\\peserta\\forum\\index.vue' /* webpackChunkName: "pages_peserta_forum_index" */))
const _37a2abe3 = () => interopDefault(import('..\\pages\\peserta\\index_backup.vue' /* webpackChunkName: "pages_peserta_index_backup" */))
const _9a3ea764 = () => interopDefault(import('..\\pages\\peserta\\insight\\index.vue' /* webpackChunkName: "pages_peserta_insight_index" */))
const _6fc9adea = () => interopDefault(import('..\\pages\\resource\\detail-mentor.vue' /* webpackChunkName: "pages_resource_detail-mentor" */))
const _6fa757db = () => interopDefault(import('..\\pages\\resource\\detail-trainer.vue' /* webpackChunkName: "pages_resource_detail-trainer" */))
const _8d41cdc4 = () => interopDefault(import('..\\pages\\resource\\materi.vue' /* webpackChunkName: "pages_resource_materi" */))
const _685805e0 = () => interopDefault(import('..\\pages\\resource\\materi-detail.vue' /* webpackChunkName: "pages_resource_materi-detail" */))
const _9ff0eb3a = () => interopDefault(import('..\\pages\\resource\\mentor.vue' /* webpackChunkName: "pages_resource_mentor" */))
const _55208a81 = () => interopDefault(import('..\\pages\\resource\\object\\index.vue' /* webpackChunkName: "pages_resource_object_index" */))
const _c4a8f13e = () => interopDefault(import('..\\pages\\resource\\participant\\index.vue' /* webpackChunkName: "pages_resource_participant_index" */))
const _94a84096 = () => interopDefault(import('..\\pages\\resource\\questioner.vue' /* webpackChunkName: "pages_resource_questioner" */))
const _108dee99 = () => interopDefault(import('..\\pages\\resource\\questioner-detail.vue' /* webpackChunkName: "pages_resource_questioner-detail" */))
const _1a397606 = () => interopDefault(import('..\\pages\\resource\\room.vue' /* webpackChunkName: "pages_resource_room" */))
const _8e455598 = () => interopDefault(import('..\\pages\\resource\\test.vue' /* webpackChunkName: "pages_resource_test" */))
const _9317c78c = () => interopDefault(import('..\\pages\\resource\\test-detail.vue' /* webpackChunkName: "pages_resource_test-detail" */))
const _f571bcfa = () => interopDefault(import('..\\pages\\resource\\trainer.vue' /* webpackChunkName: "pages_resource_trainer" */))
const _7e2e099f = () => interopDefault(import('..\\pages\\resource\\trainer\\index.vue' /* webpackChunkName: "pages_resource_trainer_index" */))
const _40338c58 = () => interopDefault(import('..\\pages\\resource\\trainer\\detail.vue' /* webpackChunkName: "pages_resource_trainer_detail" */))
const _079a66ca = () => interopDefault(import('..\\pages\\resource\\wage.vue' /* webpackChunkName: "pages_resource_wage" */))
const _297829c2 = () => interopDefault(import('..\\pages\\event\\event-plan\\detail\\index.vue' /* webpackChunkName: "pages_event_event-plan_detail_index" */))
const _87089198 = () => interopDefault(import('..\\pages\\event\\event-plan\\eventPlanStrategy.vue' /* webpackChunkName: "pages_event_event-plan_eventPlanStrategy" */))
const _09ddf724 = () => interopDefault(import('..\\pages\\expert\\forum\\detail.vue' /* webpackChunkName: "pages_expert_forum_detail" */))
const _e0f1d2de = () => interopDefault(import('..\\pages\\mockups\\event\\detail\\index.vue' /* webpackChunkName: "pages_mockups_event_detail_index" */))
const _5e660a79 = () => interopDefault(import('..\\pages\\mockups\\event\\eventActivity.vue' /* webpackChunkName: "pages_mockups_event_eventActivity" */))
const _1c8841aa = () => interopDefault(import('..\\pages\\mockups\\event\\eventActivityDetail.vue' /* webpackChunkName: "pages_mockups_event_eventActivityDetail" */))
const _7908a82f = () => interopDefault(import('..\\pages\\mockups\\event\\eventBudget.vue' /* webpackChunkName: "pages_mockups_event_eventBudget" */))
const _efa6b4e6 = () => interopDefault(import('..\\pages\\mockups\\event\\penyelenggaraanEvent.vue' /* webpackChunkName: "pages_mockups_event_penyelenggaraanEvent" */))
const _f484534e = () => interopDefault(import('..\\pages\\mockups\\student\\event\\index.vue' /* webpackChunkName: "pages_mockups_student_event_index" */))
const _6b257024 = () => interopDefault(import('..\\pages\\peserta\\activity\\absensi\\index.vue' /* webpackChunkName: "pages_peserta_activity_absensi_index" */))
const _0c1c9b14 = () => interopDefault(import('..\\pages\\peserta\\activity\\mentoring\\index.vue' /* webpackChunkName: "pages_peserta_activity_mentoring_index" */))
const _7f14bb48 = () => interopDefault(import('..\\pages\\peserta\\activity\\schedule\\index.vue' /* webpackChunkName: "pages_peserta_activity_schedule_index" */))
const _61bb4a0e = () => interopDefault(import('..\\pages\\peserta\\forum\\detail.vue' /* webpackChunkName: "pages_peserta_forum_detail" */))
const _3178559c = () => interopDefault(import('..\\pages\\resource\\object\\detail.vue' /* webpackChunkName: "pages_resource_object_detail" */))
const _50ec7271 = () => interopDefault(import('..\\pages\\resource\\object\\template-quesioner.vue' /* webpackChunkName: "pages_resource_object_template-quesioner" */))
const _6e57df34 = () => interopDefault(import('..\\pages\\resource\\object\\template-test.vue' /* webpackChunkName: "pages_resource_object_template-test" */))
const _3844a2ce = () => interopDefault(import('..\\pages\\resource\\participant\\batch\\index.vue' /* webpackChunkName: "pages_resource_participant_batch_index" */))
const _9fcf175c = () => interopDefault(import('..\\pages\\resource\\participant\\detail.vue' /* webpackChunkName: "pages_resource_participant_detail" */))
const _058aebea = () => interopDefault(import('..\\pages\\resource\\participant\\roadmap.vue' /* webpackChunkName: "pages_resource_participant_roadmap" */))
const _e2d975ec = () => interopDefault(import('..\\pages\\event\\batch\\detail\\budget.vue' /* webpackChunkName: "pages_event_batch_detail_budget" */))
const _a02512c4 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\classroom.vue' /* webpackChunkName: "pages_event_batch_detail_classroom" */))
const _9ffa7594 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\mentoring\\index.vue' /* webpackChunkName: "pages_event_batch_detail_mentoring_index" */))
const _38b57284 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\participant.vue' /* webpackChunkName: "pages_event_batch_detail_participant" */))
const _4a8fc4e6 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\index.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_index" */))
const _0dcfcb52 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\work-order.vue' /* webpackChunkName: "pages_event_batch_detail_work-order" */))
const _d02e2bcc = () => interopDefault(import('..\\pages\\event\\event-plan\\detail\\eventPlanBatch.vue' /* webpackChunkName: "pages_event_event-plan_detail_eventPlanBatch" */))
const _ea8d1b7a = () => interopDefault(import('..\\pages\\event\\event-plan\\detail\\eventPlanStrategy.vue' /* webpackChunkName: "pages_event_event-plan_detail_eventPlanStrategy" */))
const _686f52f6 = () => interopDefault(import('..\\pages\\mockups\\event\\detail\\eventActivityComponent.vue' /* webpackChunkName: "pages_mockups_event_detail_eventActivityComponent" */))
const _a1c6b462 = () => interopDefault(import('..\\pages\\mockups\\event\\detail\\eventBudgetComponent.vue' /* webpackChunkName: "pages_mockups_event_detail_eventBudgetComponent" */))
const _2af7cffa = () => interopDefault(import('..\\pages\\mockups\\event\\detail\\eventParticipantComponent.vue' /* webpackChunkName: "pages_mockups_event_detail_eventParticipantComponent" */))
const _0fc9d6ff = () => interopDefault(import('..\\pages\\peserta\\activity\\mentoring\\detail.vue' /* webpackChunkName: "pages_peserta_activity_mentoring_detail" */))
const _0854856a = () => interopDefault(import('..\\pages\\peserta\\activity\\schedule\\detail.vue' /* webpackChunkName: "pages_peserta_activity_schedule_detail" */))
const _a1175b46 = () => interopDefault(import('..\\pages\\peserta\\activity\\schedule\\takeMateri.vue' /* webpackChunkName: "pages_peserta_activity_schedule_takeMateri" */))
const _79bbd314 = () => interopDefault(import('..\\pages\\peserta\\activity\\schedule\\takeQuiz.vue' /* webpackChunkName: "pages_peserta_activity_schedule_takeQuiz" */))
const _85c45b9a = () => interopDefault(import('..\\pages\\peserta\\activity\\schedule\\takeTest.vue' /* webpackChunkName: "pages_peserta_activity_schedule_takeTest" */))
const _e324705e = () => interopDefault(import('..\\pages\\event\\batch\\detail\\mentoring\\detail-mentoring.vue' /* webpackChunkName: "pages_event_batch_detail_mentoring_detail-mentoring" */))
const _96d6af16 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\detail\\index.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_detail_index" */))
const _44bc18bf = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\detail\\generate_test.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_detail_generate_test" */))
const _3eb31d8f = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\detail\\hasil-test.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_detail_hasil-test" */))
const _c2be102e = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\detail\\materi.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_detail_materi" */))
const _55fb6100 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\detail\\questioner.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_detail_questioner" */))
const _60145a88 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\detail\\room.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_detail_room" */))
const _260e6abf = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\detail\\test.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_detail_test" */))
const _48411c18 = () => interopDefault(import('..\\pages\\event\\batch\\detail\\schedule\\detail\\trainer.vue' /* webpackChunkName: "pages_event_batch_detail_schedule_detail_trainer" */))
const _4cd5099e = () => interopDefault(import('..\\pages\\mockups\\student\\event\\_event_id\\batch\\index.vue' /* webpackChunkName: "pages_mockups_student_event__event_id_batch_index" */))
const _4ab2d58c = () => interopDefault(import('..\\pages\\mockups\\student\\event\\_event_id\\batch\\_batch_id\\activity.vue' /* webpackChunkName: "pages_mockups_student_event__event_id_batch__batch_id_activity" */))
const _58c4f5ee = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

if (process.client) {
  if ('scrollRestoration' in window.history) {
    window.history.scrollRestoration = 'manual'

    // reset scrollRestoration to auto when leaving page, allowing page reload
    // and back-navigation from other pages to use the browser to restore the
    // scrolling position.
    window.addEventListener('beforeunload', () => {
      window.history.scrollRestoration = 'auto'
    })

    // Setting scrollRestoration to manual again when returning to this page.
    window.addEventListener('load', () => {
      window.history.scrollRestoration = 'manual'
    })
  }
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: decodeURI('/'),
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/admin-trainer",
      component: _a6430362,
      name: "admin-trainer"
    }, {
      path: "/curriculum",
      component: _97a8955a,
      name: "curriculum"
    }, {
      path: "/expert",
      component: _47db8a04,
      name: "expert"
    }, {
      path: "/learning-activity",
      component: _19e12148,
      name: "learning-activity"
    }, {
      path: "/learning-strategy",
      component: _d057eb38,
      name: "learning-strategy"
    }, {
      path: "/login",
      component: _226c9905,
      name: "login"
    }, {
      path: "/mentor",
      component: _869abfe6,
      name: "mentor"
    }, {
      path: "/peserta",
      component: _64c766ee,
      name: "peserta"
    }, {
      path: "/resource",
      component: _7ba30ca0,
      name: "resource"
    }, {
      path: "/curriculum/detail",
      component: _699e04a0,
      name: "curriculum-detail"
    }, {
      path: "/curriculum/learning-path",
      component: _eed07016,
      name: "curriculum-learning-path"
    }, {
      path: "/curriculum/learning-path-detail",
      component: _38383e59,
      name: "curriculum-learning-path-detail"
    }, {
      path: "/curriculum/request",
      component: _e8fd7b60,
      name: "curriculum-request"
    }, {
      path: "/curriculum/request-detail",
      component: _099c779e,
      name: "curriculum-request-detail"
    }, {
      path: "/event/batch",
      component: _0be56f8e,
      name: "event-batch"
    }, {
      path: "/event/event",
      component: _6f90f82e,
      name: "event-event"
    }, {
      path: "/event/event-plan",
      component: _38195190,
      name: "event-event-plan"
    }, {
      path: "/expert/absensi",
      component: _8f14c13a,
      name: "expert-absensi"
    }, {
      path: "/expert/detail",
      component: _40506f93,
      name: "expert-detail"
    }, {
      path: "/expert/forum",
      component: _3abd3b62,
      name: "expert-forum"
    }, {
      path: "/expert/insight",
      component: _0f13a1f8,
      name: "expert-insight"
    }, {
      path: "/learning-activity/competency-activity",
      component: _756d326d,
      name: "learning-activity-competency-activity"
    }, {
      path: "/learning-activity/detail",
      component: _8ad3d16a,
      name: "learning-activity-detail"
    }, {
      path: "/learning-strategy/detail",
      component: _09ff5ca2,
      name: "learning-strategy-detail"
    }, {
      path: "/mentor/detail",
      component: _06196c9c,
      name: "mentor-detail"
    }, {
      path: "/mockups/add-activity-set",
      component: _5acdfeda,
      name: "mockups-add-activity-set"
    }, {
      path: "/mockups/adminTrainer",
      component: _b68a0e20,
      name: "mockups-adminTrainer"
    }, {
      path: "/mockups/aproovedTrainer",
      component: _0031cbc9,
      name: "mockups-aproovedTrainer"
    }, {
      path: "/mockups/dashboardLMS",
      component: _57611668,
      name: "mockups-dashboardLMS"
    }, {
      path: "/mockups/event",
      component: _f41fe1fc,
      name: "mockups-event"
    }, {
      path: "/mockups/feedback-result",
      component: _393bb34b,
      name: "mockups-feedback-result"
    }, {
      path: "/mockups/feedback-result-detail",
      component: _97e9f37a,
      name: "mockups-feedback-result-detail"
    }, {
      path: "/mockups/Layar15-manage-question",
      component: _db46e300,
      name: "mockups-Layar15-manage-question"
    }, {
      path: "/mockups/Layar16a&16b-manage-question",
      component: _6ed9adee,
      name: "mockups-Layar16a&16b-manage-question"
    }, {
      path: "/mockups/Layar20a-manage-feedback-bank",
      component: _38c60e3e,
      name: "mockups-Layar20a-manage-feedback-bank"
    }, {
      path: "/mockups/Layar20b-feedback-test-add",
      component: _55ed1efa,
      name: "mockups-Layar20b-feedback-test-add"
    }, {
      path: "/mockups/Layar23-manage-test-template",
      component: _1d42082e,
      name: "mockups-Layar23-manage-test-template"
    }, {
      path: "/mockups/Layar24-manage-expert",
      component: _a64e683c,
      name: "mockups-Layar24-manage-expert"
    }, {
      path: "/mockups/Layar24-manage-feedback-template",
      component: _0b16e73a,
      name: "mockups-Layar24-manage-feedback-template"
    }, {
      path: "/mockups/Layar25-create-expert-update",
      component: _138ec93a,
      name: "mockups-Layar25-create-expert-update"
    }, {
      path: "/mockups/Layar26-event-plan",
      component: _031ef31a,
      name: "mockups-Layar26-event-plan"
    }, {
      path: "/mockups/Layar26-expert-profile-detail",
      component: _a160bc6c,
      name: "mockups-Layar26-expert-profile-detail"
    }, {
      path: "/mockups/Layar27-event-plan-add",
      component: _9c804866,
      name: "mockups-Layar27-event-plan-add"
    }, {
      path: "/mockups/Layar28-add-c1",
      component: _30e07436,
      name: "mockups-Layar28-add-c1"
    }, {
      path: "/mockups/Layar28-recap-expert",
      component: _40194f58,
      name: "mockups-Layar28-recap-expert"
    }, {
      path: "/mockups/Layar29-add-c2",
      component: _38a03116,
      name: "mockups-Layar29-add-c2"
    }, {
      path: "/mockups/Layar30-add-c3",
      component: _3c1b027e,
      name: "mockups-Layar30-add-c3"
    }, {
      path: "/mockups/Layar31-add-c4",
      component: _2c9b88be,
      name: "mockups-Layar31-add-c4"
    }, {
      path: "/mockups/Layar32-add-c5",
      component: _1d1c0efe,
      name: "mockups-Layar32-add-c5"
    }, {
      path: "/mockups/Layar33-add-c6",
      component: _0d9c953e,
      name: "mockups-Layar33-add-c6"
    }, {
      path: "/mockups/Layar34-add-c3-classroom",
      component: _b648707a,
      name: "mockups-Layar34-add-c3-classroom"
    }, {
      path: "/mockups/Layar35-add-c3-budget",
      component: _7bec6fc6,
      name: "mockups-Layar35-add-c3-budget"
    }, {
      path: "/mockups/Layar36add-c3-expert",
      component: _3a0e9f6d,
      name: "mockups-Layar36add-c3-expert"
    }, {
      path: "/mockups/Layar39-add-c3-work",
      component: _599d3fd6,
      name: "mockups-Layar39-add-c3-work"
    }, {
      path: "/mockups/Layar40-add-c3-delivery",
      component: _468f65cf,
      name: "mockups-Layar40-add-c3-delivery"
    }, {
      path: "/mockups/Layar41-index",
      component: _31dc20c6,
      name: "mockups-Layar41"
    }, {
      path: "/mockups/Layar41-manage-expert-assignment",
      component: _71994b26,
      name: "mockups-Layar41-manage-expert-assignment"
    }, {
      path: "/mockups/Layar42-index",
      component: _7bf6a25e,
      name: "mockups-Layar42"
    }, {
      path: "/mockups/Layar42-update-expert-assignment",
      component: _63bf3e70,
      name: "mockups-Layar42-update-expert-assignment"
    }, {
      path: "/mockups/Layar43-proposed-learning",
      component: _819dbe1c,
      name: "mockups-Layar43-proposed-learning"
    }, {
      path: "/mockups/Layar44-forum",
      component: _501dacaf,
      name: "mockups-Layar44-forum"
    }, {
      path: "/mockups/Layar45-insight",
      component: _535ac8a7,
      name: "mockups-Layar45-insight"
    }, {
      path: "/mockups/Layar46-cycle-1",
      component: _64db879a,
      name: "mockups-Layar46-cycle-1"
    }, {
      path: "/mockups/Layar47-cycle-2",
      component: _536ca59c,
      name: "mockups-Layar47-cycle-2"
    }, {
      path: "/mockups/Layar48-cycle-3",
      component: _41fdc39e,
      name: "mockups-Layar48-cycle-3"
    }, {
      path: "/mockups/Layar49-cycle-4",
      component: _308ee1a0,
      name: "mockups-Layar49-cycle-4"
    }, {
      path: "/mockups/Layar50-cycle-5",
      component: _a040ef92,
      name: "mockups-Layar50-cycle-5"
    }, {
      path: "/mockups/Layar51-cycle-6",
      component: _c31eb38e,
      name: "mockups-Layar51-cycle-6"
    }, {
      path: "/mockups/Layar52-53-54-feedback_penyelenggara",
      component: _2256c40a,
      name: "mockups-Layar52-53-54-feedback_penyelenggara"
    }, {
      path: "/mockups/Layar55-quiz",
      component: _96734bd2,
      name: "mockups-Layar55-quiz"
    }, {
      path: "/mockups/Layar56-event-detail-4",
      component: _597a222c,
      name: "mockups-Layar56-event-detail-4"
    }, {
      path: "/mockups/login_page",
      component: _7a5e112f,
      name: "mockups-login_page"
    }, {
      path: "/mockups/manage-template-quesioneire",
      component: _2baa16c8,
      name: "mockups-manage-template-quesioneire"
    }, {
      path: "/mockups/materi-detail",
      component: _58ce4828,
      name: "mockups-materi-detail"
    }, {
      path: "/mockups/videoPlayTest",
      component: _577600e7,
      name: "mockups-videoPlayTest"
    }, {
      path: "/mockups/videoPlayTest2",
      component: _d13c754a,
      name: "mockups-videoPlayTest2"
    }, {
      path: "/peserta/activity",
      component: _e10b5802,
      name: "peserta-activity"
    }, {
      path: "/peserta/forum",
      component: _248debb6,
      name: "peserta-forum"
    }, {
      path: "/peserta/index_backup",
      component: _37a2abe3,
      name: "peserta-index_backup"
    }, {
      path: "/peserta/insight",
      component: _9a3ea764,
      name: "peserta-insight"
    }, {
      path: "/resource/detail-mentor",
      component: _6fc9adea,
      name: "resource-detail-mentor"
    }, {
      path: "/resource/detail-trainer",
      component: _6fa757db,
      name: "resource-detail-trainer"
    }, {
      path: "/resource/materi",
      component: _8d41cdc4,
      name: "resource-materi"
    }, {
      path: "/resource/materi-detail",
      component: _685805e0,
      name: "resource-materi-detail"
    }, {
      path: "/resource/mentor",
      component: _9ff0eb3a,
      name: "resource-mentor"
    }, {
      path: "/resource/object",
      component: _55208a81,
      name: "resource-object"
    }, {
      path: "/resource/participant",
      component: _c4a8f13e,
      name: "resource-participant"
    }, {
      path: "/resource/questioner",
      component: _94a84096,
      name: "resource-questioner"
    }, {
      path: "/resource/questioner-detail",
      component: _108dee99,
      name: "resource-questioner-detail"
    }, {
      path: "/resource/room",
      component: _1a397606,
      name: "resource-room"
    }, {
      path: "/resource/test",
      component: _8e455598,
      name: "resource-test"
    }, {
      path: "/resource/test-detail",
      component: _9317c78c,
      name: "resource-test-detail"
    }, {
      path: "/resource/trainer",
      component: _f571bcfa,
      children: [{
        path: "",
        component: _7e2e099f,
        name: "resource-trainer"
      }, {
        path: "detail",
        component: _40338c58,
        name: "resource-trainer-detail"
      }]
    }, {
      path: "/resource/wage",
      component: _079a66ca,
      name: "resource-wage"
    }, {
      path: "/event/event-plan/detail",
      component: _297829c2,
      name: "event-event-plan-detail"
    }, {
      path: "/event/event-plan/eventPlanStrategy",
      component: _87089198,
      name: "event-event-plan-eventPlanStrategy"
    }, {
      path: "/expert/forum/detail",
      component: _09ddf724,
      name: "expert-forum-detail"
    }, {
      path: "/mockups/event/detail",
      component: _e0f1d2de,
      name: "mockups-event-detail"
    }, {
      path: "/mockups/event/eventActivity",
      component: _5e660a79,
      name: "mockups-event-eventActivity"
    }, {
      path: "/mockups/event/eventActivityDetail",
      component: _1c8841aa,
      name: "mockups-event-eventActivityDetail"
    }, {
      path: "/mockups/event/eventBudget",
      component: _7908a82f,
      name: "mockups-event-eventBudget"
    }, {
      path: "/mockups/event/penyelenggaraanEvent",
      component: _efa6b4e6,
      name: "mockups-event-penyelenggaraanEvent"
    }, {
      path: "/mockups/student/event",
      component: _f484534e,
      name: "mockups-student-event"
    }, {
      path: "/peserta/activity/absensi",
      component: _6b257024,
      name: "peserta-activity-absensi"
    }, {
      path: "/peserta/activity/mentoring",
      component: _0c1c9b14,
      name: "peserta-activity-mentoring"
    }, {
      path: "/peserta/activity/schedule",
      component: _7f14bb48,
      name: "peserta-activity-schedule"
    }, {
      path: "/peserta/forum/detail",
      component: _61bb4a0e,
      name: "peserta-forum-detail"
    }, {
      path: "/resource/object/detail",
      component: _3178559c,
      name: "resource-object-detail"
    }, {
      path: "/resource/object/template-quesioner",
      component: _50ec7271,
      name: "resource-object-template-quesioner"
    }, {
      path: "/resource/object/template-test",
      component: _6e57df34,
      name: "resource-object-template-test"
    }, {
      path: "/resource/participant/batch",
      component: _3844a2ce,
      name: "resource-participant-batch"
    }, {
      path: "/resource/participant/detail",
      component: _9fcf175c,
      name: "resource-participant-detail"
    }, {
      path: "/resource/participant/roadmap",
      component: _058aebea,
      name: "resource-participant-roadmap"
    }, {
      path: "/event/batch/detail/budget",
      component: _e2d975ec,
      name: "event-batch-detail-budget"
    }, {
      path: "/event/batch/detail/classroom",
      component: _a02512c4,
      name: "event-batch-detail-classroom"
    }, {
      path: "/event/batch/detail/mentoring",
      component: _9ffa7594,
      name: "event-batch-detail-mentoring"
    }, {
      path: "/event/batch/detail/participant",
      component: _38b57284,
      name: "event-batch-detail-participant"
    }, {
      path: "/event/batch/detail/schedule",
      component: _4a8fc4e6,
      name: "event-batch-detail-schedule"
    }, {
      path: "/event/batch/detail/work-order",
      component: _0dcfcb52,
      name: "event-batch-detail-work-order"
    }, {
      path: "/event/event-plan/detail/eventPlanBatch",
      component: _d02e2bcc,
      name: "event-event-plan-detail-eventPlanBatch"
    }, {
      path: "/event/event-plan/detail/eventPlanStrategy",
      component: _ea8d1b7a,
      name: "event-event-plan-detail-eventPlanStrategy"
    }, {
      path: "/mockups/event/detail/eventActivityComponent",
      component: _686f52f6,
      name: "mockups-event-detail-eventActivityComponent"
    }, {
      path: "/mockups/event/detail/eventBudgetComponent",
      component: _a1c6b462,
      name: "mockups-event-detail-eventBudgetComponent"
    }, {
      path: "/mockups/event/detail/eventParticipantComponent",
      component: _2af7cffa,
      name: "mockups-event-detail-eventParticipantComponent"
    }, {
      path: "/peserta/activity/mentoring/detail",
      component: _0fc9d6ff,
      name: "peserta-activity-mentoring-detail"
    }, {
      path: "/peserta/activity/schedule/detail",
      component: _0854856a,
      name: "peserta-activity-schedule-detail"
    }, {
      path: "/peserta/activity/schedule/takeMateri",
      component: _a1175b46,
      name: "peserta-activity-schedule-takeMateri"
    }, {
      path: "/peserta/activity/schedule/takeQuiz",
      component: _79bbd314,
      name: "peserta-activity-schedule-takeQuiz"
    }, {
      path: "/peserta/activity/schedule/takeTest",
      component: _85c45b9a,
      name: "peserta-activity-schedule-takeTest"
    }, {
      path: "/event/batch/detail/mentoring/detail-mentoring",
      component: _e324705e,
      name: "event-batch-detail-mentoring-detail-mentoring"
    }, {
      path: "/event/batch/detail/schedule/detail",
      component: _96d6af16,
      name: "event-batch-detail-schedule-detail"
    }, {
      path: "/event/batch/detail/schedule/detail/generate_test",
      component: _44bc18bf,
      name: "event-batch-detail-schedule-detail-generate_test"
    }, {
      path: "/event/batch/detail/schedule/detail/hasil-test",
      component: _3eb31d8f,
      name: "event-batch-detail-schedule-detail-hasil-test"
    }, {
      path: "/event/batch/detail/schedule/detail/materi",
      component: _c2be102e,
      name: "event-batch-detail-schedule-detail-materi"
    }, {
      path: "/event/batch/detail/schedule/detail/questioner",
      component: _55fb6100,
      name: "event-batch-detail-schedule-detail-questioner"
    }, {
      path: "/event/batch/detail/schedule/detail/room",
      component: _60145a88,
      name: "event-batch-detail-schedule-detail-room"
    }, {
      path: "/event/batch/detail/schedule/detail/test",
      component: _260e6abf,
      name: "event-batch-detail-schedule-detail-test"
    }, {
      path: "/event/batch/detail/schedule/detail/trainer",
      component: _48411c18,
      name: "event-batch-detail-schedule-detail-trainer"
    }, {
      path: "/mockups/student/event/:event_id/batch",
      component: _4cd5099e,
      name: "mockups-student-event-event_id-batch"
    }, {
      path: "/mockups/student/event/:event_id/batch/:batch_id/activity",
      component: _4ab2d58c,
      name: "mockups-student-event-event_id-batch-batch_id-activity"
    }, {
      path: "/",
      component: _58c4f5ee,
      name: "index"
    }],

    fallback: false
  })
}
