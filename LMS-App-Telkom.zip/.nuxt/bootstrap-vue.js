import Vue from 'vue'

import BootstrapVue from 'bootstrap-vue/es'

Vue.use(BootstrapVue, {})
