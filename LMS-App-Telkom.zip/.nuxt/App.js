import Vue from 'vue'
import NuxtLoading from './components/nuxt-loading.vue'

import '..\\node_modules\\bootstrap\\dist\\css\\bootstrap.css'

import '..\\node_modules\\bootstrap-vue\\dist\\bootstrap-vue.css'

import '..\\assets\\css\\add.css'

import '..\\assets\\css\\app.css'

import '..\\assets\\css\\animate.css'

import '..\\assets\\css\\bootstrap-touchspin.css'

import '..\\assets\\css\\flatpickr.css'

import '..\\assets\\css\\flatpickr-airbnb.css'

import '..\\assets\\css\\fontawesome.css'

import '..\\assets\\css\\input-spinner.css'

import '..\\assets\\css\\main.css'

import '..\\assets\\css\\material-icons.css'

import '..\\assets\\css\\quill.css'

import '..\\assets\\css\\select2.css'

import '..\\assets\\css\\slider-input.css'

import '..\\assets\\css\\tab.css'

import '..\\assets\\css\\tabs.css'

import '..\\assets\\css\\theme.css'

import '..\\assets\\css\\tree-view.css'

import '..\\assets\\css\\util.css'

import '..\\assets\\css\\prettyJSON.css'

import _2d217e9e from '..\\layouts\\auth.vue'
import _77135504 from '..\\layouts\\batch.vue'
import _1588564e from '..\\layouts\\batchindex.vue'
import _2b6da69e from '..\\layouts\\curriculum.vue'
import _6f6c098b from '..\\layouts\\default.vue'
import _4839891d from '..\\layouts\\event_peserta.vue'
import _ce39cc4c from '..\\layouts\\event-detail.vue'
import _7746f064 from '..\\layouts\\event.vue'
import _add375c4 from '..\\layouts\\expert-detail.vue'
import _71b829a0 from '..\\layouts\\expert.vue'
import _af6458d0 from '..\\layouts\\hasil-test.vue'
import _c90878b0 from '..\\layouts\\learning-activity.vue'
import _18e2df7c from '..\\layouts\\learning-plan.vue'
import _68bf740c from '..\\layouts\\learning-strategy.vue'
import _7e527f37 from '..\\layouts\\mentor.vue'
import _4243b94b from '..\\layouts\\mentoring.vue'
import _dbfa92b8 from '..\\layouts\\noouter.vue'
import _fce04296 from '..\\layouts\\object.vue'
import _04e05428 from '..\\layouts\\participant-roadmap.vue'
import _b0512506 from '..\\layouts\\participant.vue'
import _75ed3aef from '..\\layouts\\peserta-batch.vue'
import _2a206d7c from '..\\layouts\\peserta.vue'
import _27e546ef from '..\\layouts\\resources.vue'
import _08dfc07f from '..\\layouts\\result-feedback.vue'
import _5ea52846 from '..\\layouts\\schedule_peserta.vue'
import _9b3b1cde from '..\\layouts\\schedule-detail.vue'
import _2e14c88d from '..\\layouts\\schedule.vue'

const layouts = { "_auth": _2d217e9e,"_batch": _77135504,"_batchindex": _1588564e,"_curriculum": _2b6da69e,"_default": _6f6c098b,"_event_peserta": _4839891d,"_event-detail": _ce39cc4c,"_event": _7746f064,"_expert-detail": _add375c4,"_expert": _71b829a0,"_hasil-test": _af6458d0,"_learning-activity": _c90878b0,"_learning-plan": _18e2df7c,"_learning-strategy": _68bf740c,"_mentor": _7e527f37,"_mentoring": _4243b94b,"_noouter": _dbfa92b8,"_object": _fce04296,"_participant-roadmap": _04e05428,"_participant": _b0512506,"_peserta-batch": _75ed3aef,"_peserta": _2a206d7c,"_resources": _27e546ef,"_result-feedback": _08dfc07f,"_schedule_peserta": _5ea52846,"_schedule-detail": _9b3b1cde,"_schedule": _2e14c88d }

export default {
  head: {"title":"lmsclient","meta":[{"charset":"utf-8"},{"name":"viewport","content":"width=device-width, initial-scale=1"},{"hid":"description","name":"description","content":"lms client"},{"hid":"mobile-web-app-capable","name":"mobile-web-app-capable","content":"yes"},{"hid":"apple-mobile-web-app-title","name":"apple-mobile-web-app-title","content":"lmsclient"},{"hid":"author","name":"author","content":"Telkom"},{"hid":"theme-color","name":"theme-color","content":"#fff"},{"hid":"og:type","name":"og:type","property":"og:type","content":"website"},{"hid":"og:title","name":"og:title","property":"og:title","content":"lmsclient"},{"hid":"og:site_name","name":"og:site_name","property":"og:site_name","content":"lmsclient"},{"hid":"og:description","name":"og:description","property":"og:description","content":"lms client"}],"link":[{"rel":"icon","type":"image\u002Fx-icon","href":"\u002Ffavicon.ico"},{"rel":"manifest","href":"\u002F_nuxt\u002Fmanifest.5063bac6.json"},{"rel":"shortcut icon","href":"\u002F_nuxt\u002Ficons\u002Ficon_64.9mld2VBMsQ$.png"},{"rel":"apple-touch-icon","href":"\u002F_nuxt\u002Ficons\u002Ficon_512.9mld2VBMsQ$.png","sizes":"512x512"}],"script":[{"src":"https:\u002F\u002Fcdnjs.cloudflare.com\u002Fajax\u002Flibs\u002Fjquery\u002F3.1.1\u002Fjquery.min.js"}],"style":[],"htmlAttrs":{"lang":"en"}},

  render(h, props) {
    const loadingEl = h('NuxtLoading', { ref: 'loading' })
    const layoutEl = h(this.layout || 'nuxt')
    const templateEl = h('div', {
      domProps: {
        id: '__layout'
      },
      key: this.layoutName
    }, [ layoutEl ])

    const transitionEl = h('transition', {
      props: {
        name: 'layout',
        mode: 'out-in'
      },
      on: {
        beforeEnter(el) {
          // Ensure to trigger scroll event after calling scrollBehavior
          window.$nuxt.$nextTick(() => {
            window.$nuxt.$emit('triggerScroll')
          })
        }
      }
    }, [ templateEl ])

    return h('div', {
      domProps: {
        id: '__nuxt'
      }
    }, [
      loadingEl,
      transitionEl
    ])
  },
  data: () => ({
    isOnline: true,
    layout: null,
    layoutName: ''
  }),
  beforeCreate() {
    Vue.util.defineReactive(this, 'nuxt', this.$options.nuxt)
  },
  created() {
    // Add this.$nuxt in child instances
    Vue.prototype.$nuxt = this
    // add to window so we can listen when ready
    if (process.client) {
      window.$nuxt = this
      this.refreshOnlineStatus()
      // Setup the listeners
      window.addEventListener('online', this.refreshOnlineStatus)
      window.addEventListener('offline', this.refreshOnlineStatus)
    }
    // Add $nuxt.error()
    this.error = this.nuxt.error
  },

  mounted() {
    this.$loading = this.$refs.loading
  },
  watch: {
    'nuxt.err': 'errorChanged'
  },

  computed: {
    isOffline() {
      return !this.isOnline
    }
  },
  methods: {
    refreshOnlineStatus() {
      if (process.client) {
        if (typeof window.navigator.onLine === 'undefined') {
          // If the browser doesn't support connection status reports
          // assume that we are online because most apps' only react
          // when they now that the connection has been interrupted
          this.isOnline = true
        } else {
          this.isOnline = window.navigator.onLine
        }
      }
    },

    errorChanged() {
      if (this.nuxt.err && this.$loading) {
        if (this.$loading.fail) this.$loading.fail()
        if (this.$loading.finish) this.$loading.finish()
      }
    },

    setLayout(layout) {
      if(layout && typeof layout !== 'string') throw new Error('[nuxt] Avoid using non-string value as layout property.')

      if (!layout || !layouts['_' + layout]) {
        layout = 'default'
      }
      this.layoutName = layout
      this.layout = layouts['_' + layout]
      return this.layout
    },
    loadLayout(layout) {
      if (!layout || !layouts['_' + layout]) {
        layout = 'default'
      }
      return Promise.resolve(layouts['_' + layout])
    }
  },
  components: {
    NuxtLoading
  }
}
