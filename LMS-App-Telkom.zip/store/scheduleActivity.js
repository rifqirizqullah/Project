import moment from 'moment'

export const state = () => ({
    list: [],
    detail : null,
    pagination : null,
    api : 'lms/api/scheduleactivity',
    isLoading : false,
    error : null,
});

export const mutations = {
    storeAll(state, data) {
        state.list = data.data ;
        state.pagination = data.meta.pagination ;
    },

    clearAll(state, data) {
        state.list = []
        state.detail = null
        state.pagination = null
    },

    storeDetail(state, data) {
        state.detail = data ;
    },

    clearDetail(state) {
        state.detail = null
    },

    deleteOne(state, index) {
        state.list.splice(index, 1)
    },

    setLoading(state, value) {
        state.isLoading = value
    }
}

export const actions = {

    async getAll(store, params = {}) {
        if(store.rootState.eventActivity.detail){
            params["event_activity[]"]=store.rootState.eventActivity.detail.event_activity_id
        }
        store.commit('setLoading', true)
        let res = await this.$axios.get(store.state.api, {
            params : {
                begin_date_lte : moment(new Date()).format("YYYY-MM-DD"),
                end_date_gte : moment(new Date()).format("YYYY-MM-DD"),
                "order[BEGDA]" : 'asc',
                // "event[]": 1,
                ...params
            }
        })
        store.commit('storeAll', res.data)
        store.commit('setLoading', false)
    },

    async clearAll(store) {
        await store.commit('clearAll')
    },

    async add(store, body) {
        let res = await this.$axios.post(store.state.api, {...body})
        store.dispatch('getAll')
    },

    async getDetail(store, object_identifier) {
        let data = await store.state.list.find(item => item.object_identifier == object_identifier);
        store.commit('storeDetail', data)
    },

    async clearDetail(store) {
        await store.commit('clearDetail')
    },

    async deleteOne(store, index) {
        store.commit('deleteOne', index)
    },
}
