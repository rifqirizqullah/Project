//  Competency

import moment from "moment"

export const state = () => ({
    list: []
});

export const mutations = {
    storeAll(state, data) {
        state.list = data ;
    }
}

export const actions = {
    async getAll(store) {
        //if(!store.state.list.length) {
            let res = await this.$axios.get('ldap/api/otypes', {
                params: {
                    begin_date_lte : moment(new Date()).format("YYYY-MM-DD"),
                    end_date_gte : moment(new Date()).format("YYYY-MM-DD"),
                    object_type: ['BSSIS','PRFIS','CMPTY'],
                    "order[OTYPE]" : "asc"
                }
            })
            store.commit('storeAll', res.data.data)
        //}
    }
}
