import moment from 'moment'

export const state = () => ({
    list: [],
    detail : null,
    pagination : null,
    api : 'lms/api/event',
    isLoading : false,
    error : null,

    Upcoming : null,
    Ongoing : null,
    Done : null,
});

export const mutations = {
    storeAll(state, data) {
        state.list = data.data ;
        state.pagination = data.meta.pagination ;
    },

    storeOne(state, data) {
        state.detail = data.data[0]
    },

    clearAll(state, data) {
        state.list = []
        state.detail = null
        state.pagination = null
    },

    storeDetail(state, data) {
        state.detail = data ;
    },

    clearDetail(state) {
        state.detail = null
    },

    deleteOne(state, index) {
        state.list.splice(index, 1)
    },

    setLoading(state, value) {
        state.isLoading = value
    },

    storeStatus(state, {Ongoing, Upcoming, Done}) {
        state.Ongoing = Ongoing
        state.Upcoming = Upcoming
        state.Done = Done
    }
}

export const actions = {

    async getAll(store, params = {}) {
        store.commit('setLoading', true)
        let res = await this.$axios.get(store.state.api, {
            params : {
                "order[oid]" : 'asc',
                "event_situation[]" : '2',
                ...params
            }
        })
        store.commit('storeAll', res.data)
        store.commit('setLoading', false)
    },

    async getOne(store, params = {}) {

        if(!params.data) {
            store.commit('setLoading', true)
            let res = await this.$axios.get(store.state.api, {
                params : {
                    ...params
                }
            })
            store.commit('storeOne', res.data)
            store.commit('setLoading', false)
        } else {
            store.commit('storeDetail', params.data)
        }
    },

    async clearAll(store) {
        await store.commit('clearAll')
    },

    async add(store, body) {
        let res = await this.$axios.post(store.state.api, {...body})
        store.dispatch('getAll')
    },

    async getDetail(store, object_identifier) {
        let data = await store.state.list.find(item => item.object_identifier == object_identifier);
        store.commit('storeDetail', data)
    },

    async clearDetail(store) {
        await store.commit('clearDetail')
    },

    async deleteOne(store, index) {
        store.commit('deleteOne', index)
    },

    async getAllStatus(store, index) {
        let Ongoing = await this.$axios.get(store.state.api, {
            params : { "event_status[]" : '01',
                       "event_situation[]" : '2',
                    }
        })
        let Upcoming = await this.$axios.get(store.state.api, {
            params : { "event_status[]" : '02',
                       "event_situation[]" : '2', }
        })
        let Done = await this.$axios.get(store.state.api, {
            params : { "event_status[]" : '03',
                       "event_situation[]" : '2', }
        })

        store.commit('storeStatus', {
            Ongoing : Ongoing.data.meta.pagination,
            Upcoming : Upcoming.data.meta.pagination,
            Done : Done.data.meta.pagination
        })
    },

}
