import moment from 'moment'

export const state = () => ({
  list: [],
  detail: null,
  pagination: null,
  api: 'lms/api/participantaddress',
});

export const mutations = {
  storeAll(state, data) {
    state.list = data.data;
    state.pagination = data.meta.pagination;
  },

  storeDetail(state, data) {
    state.detail = data;
  },

  clearDetail(state) {
    state.detail = null
  },

  deleteOne(state, index) {
    state.list.splice(index, 1)
  },
}

export const actions = {
  async getAll(store, params) {
    let res = await this.$axios.get(store.state.api, {
      params: {
        begin_date_lte: moment(new Date()).format("YYYY-MM-DD"),
        end_date_gte: moment(new Date()).format("YYYY-MM-DD"),
        "order[BEGDA]": 'asc',
        "per_page": '5',
        "participant[]": store.rootState.participant.detail.participant_id,
        ...params
      }
    })
    store.commit('storeAll', res.data)
  },

  async add(store, body) {
    let res = await this.$axios.post(store.state.api, { ...body })
    store.dispatch('getAll')
  },

  async getDetail(store, object_identifier) {
    let data = await store.state.list.find(item => item.object_identifier == object_identifier);
    store.commit('storeDetail', data)
  },

  async clearDetail(store) {
    await store.commit('clearDetail')
  },

  async deleteOne(store, index) {
    store.commit('deleteOne', index)
  },
}
