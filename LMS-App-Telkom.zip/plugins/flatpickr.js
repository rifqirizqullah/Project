import Vue from 'vue'
import flatPicker from "vue-flatpickr-component";
Vue.use(flatPicker);
