import Vue from 'vue';
import VeeValidate from 'vee-validate';
import attributesPtBr from 'vee-validate/dist/locale/pt_BR';

Vue.use(VeeValidate);
