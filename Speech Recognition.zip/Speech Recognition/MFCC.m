function varargout = MFCC(varargin)
% MFCC M-file for MFCC.fig
%      MFCC, by itself, creates a new MFCC or raises the existing
%      singleton*.
%
%      H = MFCC returns the handle to a new MFCC or the handle to
%      the existing singleton*.
%
%      MFCC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MFCC.M with the given input arguments.
%
%      MFCC('Property','Value',...) creates a new MFCC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MFCC_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MFCC_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MFCC

% Last Modified by GUIDE v2.5 16-May-2008 15:31:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MFCC_OpeningFcn, ...
                   'gui_OutputFcn',  @MFCC_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MFCC is made visible.
function MFCC_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MFCC (see VARARGIN)

% Choose default command line output for MFCC
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MFCC wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MFCC_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
name = get(handles.edtName,'string');
[namafile, formatfile] = uigetfile({'*.png'},'membuka gambar');
image = imread([formatfile, namafile]);
axes(handles.axes4);
imshow(image);

fget = getframe(handles.axes4);
wrfoto = frame2im(fget);
nmfoto = sprintf('%s.png',name);
imwrite(wrfoto,nmfoto);
for i = 1:10
    file = sprintf('%s%d.wav',name,i);
    set(handles.txtPertanyaan,'string','Ready...');
    pause(1);
    for t = 1:3
        string = sprintf(' %d', t);
        set(handles.txtPertanyaan,'string',string);
        pause(1);
    end
    set(handles.txtPertanyaan,'string','GO!!!');
    pause(300/1000);
    y = wavrecord(88200,44100); 
    sound(y,44100); 
    wavwrite(y,44100,file);
    set(handles.txtLatih,'string',i);
end
set(handles.txtPertanyaan,'string','Completed..!');



function edtName_Callback(hObject, eventdata, handles)
% hObject    handle to edtName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edtName as text
%        str2double(get(hObject,'String')) returns contents of edtName as a double


% --- Executes during object creation, after setting all properties.
function edtName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edtName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
'(* ::Package:: *)'
 % File Name : project.m
%Voice Recognition Project
 
% Inisialisasi Nama
name = get(handles.srcName,'string');
ytemp = zeros (88200,20);
% Memotong rekaman sehingga hanya memuat suara dan kemudian %disimpan dalam sebuah matriks 88200x20 .
r = zeros (10,1);
for j = 1:10
    file = sprintf ('%s%d.wav',name,j);
    [t, fs] = wavread (file);
    s = abs (t);
    start = 1;
    last = 88200;
for i = 1:88200
        if s (i) >=.1 && i <=7000
         start = 1;
         break
        end
        if s (i) >=.1 && i > 7000 
         start = i-7000;
         break
        end
    end
    for i = 1:88200
        k = 88201-i;
        if s (k)>=.1 && k>=81200
            last = 88200;
            break
        end
        if s (k)>= .1 && k <81200
         last = k + 7000;
         break
        end
    end
r (j) = last-start;
    ytemp (1: last - start + 1,2 * j) = t (start:last);
    ytemp (1: last - start + 1,(2*j - 1)) = t (start:last);
end

% Baris Matriks diperkecil.
y = zeros (min (r),20);
for i = 1:20
    y (:,i) = ytemp (1:min (r),i);
end
% Mengubah ke dalam bentuk domain frekuensi dengan menggunakan Fast Fourier Transform (FFT) dan kemudian mengambil nilai modulus
 
fy = fft (y);
fy = fy.*conj (fy);
 
% Menormalkan nilai spektrum setiap rekaman dan menempatkannya pada matriks fn.
%hanya frekuensi yang lebih dari 600 Hz yang dibutuhkan untuk merepresentasikan suara manusia.

fn = zeros (600,20);
for i = 1:20
    fn (1:600,i) = fy (1:600,i)/sqrt(sum (abs (fy (1:600,i)).^2));
end
% menghitung rata-rata suara referensi 
pu = zeros (600,1);
for i = 1:20
    pu = pu + fn (1:600,i);
end
pu = pu/20;
 
% Menghitung nilai centroid
tn = pu/sqrt(sum (abs (pu).^2));
 
% menghitung probabilitas suatu referensi yaitu dengan standar deviasi
std = 0;
for i = 1:20
    std = std + sum (abs (fn (1:600,i)-tn).^2);
end
std = sqrt (std/20);
% Proses verifikasi
% % Merekam suara user (suara sampel)
set(handles.txtCount,'string','Ready...');
pause(1);
for t = 1:3
    string = sprintf(' %d', t);
    set(handles.txtCount,'string',string);
    pause(1);
end
set(handles.txtCount,'string','GO!!!');
pause(300/1000); 
usertemp = wavrecord (88200,44100);
sound (usertemp,44100);
%rec = input ('Are you happy with this recording? \nPress 1 to record again or just press enter to proceed--> ');
%while rec == 1
%    rec = 0;
%    input ('You will have 2 seconds to say your name.  Press enter when ready')
%    usertemp = wavrecord (88200,44100);
%    sound (usertemp,44100);
%    rec = input ('Are you happy with this recording? \nPress 1 to record again or just press enter to proceed--> ');
%end
% Memotong rekaman suara sampel sehingga hanya berisi  suara
s = abs (usertemp);
start = 1;
last = 88200;
for i = 1:88200
    if s (i) >=.1 && i <=5000
       start = 1;
       break
    end
    if s (i) >=.1 && i > 5000 
        start = i-5000;
        break
    end
end
for i = 1:88200
    k = 88201-i;
    if s (k)>=.1 && k>=83200
        last = 88200;
        break
    end
    if s (k)>= .1 && k <83200
        last = k + 5000;
        break
    end
end
 
 
% Mengubah suara sampel ke dalam bentuk FFT.
user = usertemp (start:last);
userftemp = fft (user);
userftemp = userftemp.*conj (userftemp);
userf = userftemp (1:600);
userfn = userf/sqrt(sum (abs (userf).^2));
% Plot spektrum suara dari rekaman sampel dan rata-rata suara referensi.
hold on;
axes(handles.axes1);
plot (userfn)
title ('Normalized Frequency Spectra Of Recording')
axes(handles.axes2);
plot (tn);
title ('Normalized Frequency Spectra of Average')
% Pengecekan sesuai Threshold, apakah suara dikenali atau tidak.
s = sqrt (sum (abs (userfn - tn).^2))
threshold = 1,2 *std
set(handles.txtThres,'string',threshold);
set(handles.txtS,'string',s);
if (s <= threshold)
    string = sprintf('Hello %s :)', name);
    set(handles.txtCount,'string',string);
    nmfoto = sprintf('%s.png',name);
    foto = imread(nmfoto);
    axes(handles.axes3);
    imshow(foto);
else
    string = sprintf('You Are Not %s !!!', name);
    set(handles.txtCount,'string',string);
end




% --- Executes during object creation, after setting all properties.
function pushbutton3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function srcName_Callback(hObject, eventdata, handles)
% hObject    handle to srcName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of srcName as text
%        str2double(get(hObject,'String')) returns contents of srcName as a double


% --- Executes during object creation, after setting all properties.
function srcName_CreateFcn(hObject, eventdata, handles)
% hObject    handle to srcName (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


