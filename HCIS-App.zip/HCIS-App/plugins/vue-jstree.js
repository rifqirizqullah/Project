import Vue from 'vue';
import VJStree from 'vue-jstree';
    
Vue.component('v-jstree', VJStree);