import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'

const _36782499 = () => interopDefault(import('..\\pages\\award\\index.vue' /* webpackChunkName: "pages_award_index" */))
const _6574ca41 = () => interopDefault(import('..\\pages\\competency\\index.vue' /* webpackChunkName: "pages_competency_index" */))
const _d92b73fc = () => interopDefault(import('..\\pages\\dashboard\\index.vue' /* webpackChunkName: "pages_dashboard_index" */))
const _4cec019a = () => interopDefault(import('..\\pages\\dynamicSearch.vue' /* webpackChunkName: "pages_dynamicSearch" */))
const _e2c64310 = () => interopDefault(import('..\\pages\\grievance\\index.vue' /* webpackChunkName: "pages_grievance_index" */))
const _53f9d0c4 = () => interopDefault(import('..\\pages\\kontrak.vue' /* webpackChunkName: "pages_kontrak" */))
const _cedbca56 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages_login" */))
const _79c8e92d = () => interopDefault(import('..\\pages\\login2.vue' /* webpackChunkName: "pages_login2" */))
const _16fb0033 = () => interopDefault(import('..\\pages\\mutasi\\index.vue' /* webpackChunkName: "pages_mutasi_index" */))
const _20be5e2b = () => interopDefault(import('..\\pages\\organization\\index.vue' /* webpackChunkName: "pages_organization_index" */))
const _2bfe2aec = () => interopDefault(import('..\\pages\\report\\index.vue' /* webpackChunkName: "pages_report_index" */))
const _0feb1d70 = () => interopDefault(import('..\\pages\\Slip-gaji\\index.vue' /* webpackChunkName: "pages_Slip-gaji_index" */))
const _712349f3 = () => interopDefault(import('..\\pages\\tambah-menu\\index.vue' /* webpackChunkName: "pages_tambah-menu_index" */))
const _57f0c0c6 = () => interopDefault(import('..\\pages\\upload\\index.vue' /* webpackChunkName: "pages_upload_index" */))
const _b82c9758 = () => interopDefault(import('..\\pages\\admission\\admission-assigment.vue' /* webpackChunkName: "pages_admission_admission-assigment" */))
const _216c1c8f = () => interopDefault(import('..\\pages\\admission\\admission-basiclevel.vue' /* webpackChunkName: "pages_admission_admission-basiclevel" */))
const _099c8073 = () => interopDefault(import('..\\pages\\admission\\admission-basicpay.vue' /* webpackChunkName: "pages_admission_admission-basicpay" */))
const _2e688a60 = () => interopDefault(import('..\\pages\\admission\\admission-bpjs.vue' /* webpackChunkName: "pages_admission_admission-bpjs" */))
const _1353adf9 = () => interopDefault(import('..\\pages\\admission\\admission-personal.vue' /* webpackChunkName: "pages_admission_admission-personal" */))
const _542c3f02 = () => interopDefault(import('..\\pages\\admission\\admission-tax.vue' /* webpackChunkName: "pages_admission_admission-tax" */))
const _990c76be = () => interopDefault(import('..\\pages\\award\\award-search.vue' /* webpackChunkName: "pages_award_award-search" */))
const _fb57b082 = () => interopDefault(import('..\\pages\\competency\\certificate-search.vue' /* webpackChunkName: "pages_competency_certificate-search" */))
const _4cae09ae = () => interopDefault(import('..\\pages\\competency\\certification.vue' /* webpackChunkName: "pages_competency_certification" */))
const _69bedb08 = () => interopDefault(import('..\\pages\\competency\\certification-search.vue' /* webpackChunkName: "pages_competency_certification-search" */))
const _6787d987 = () => interopDefault(import('..\\pages\\competency\\competency-search.vue' /* webpackChunkName: "pages_competency_competency-search" */))
const _05702ad2 = () => interopDefault(import('..\\pages\\competency\\education.vue' /* webpackChunkName: "pages_competency_education" */))
const _20e0a4fb = () => interopDefault(import('..\\pages\\competency\\masterpiece.vue' /* webpackChunkName: "pages_competency_masterpiece" */))
const _255f986a = () => interopDefault(import('..\\pages\\competency\\masterpiece-search.vue' /* webpackChunkName: "pages_competency_masterpiece-search" */))
const _7bb1198a = () => interopDefault(import('..\\pages\\competency\\training.vue' /* webpackChunkName: "pages_competency_training" */))
const _2f29a848 = () => interopDefault(import('..\\pages\\competency\\training_search.vue' /* webpackChunkName: "pages_competency_training_search" */))
const _587f7bac = () => interopDefault(import('..\\pages\\competency\\training-search.vue' /* webpackChunkName: "pages_competency_training-search" */))
const _723189d1 = () => interopDefault(import('..\\pages\\dashboard\\detail.vue' /* webpackChunkName: "pages_dashboard_detail" */))
const _38856f9a = () => interopDefault(import('..\\pages\\employee-data\\address\\index.vue' /* webpackChunkName: "pages_employee-data_address_index" */))
const _273870a1 = () => interopDefault(import('..\\pages\\employee-data\\band-individu\\index.vue' /* webpackChunkName: "pages_employee-data_band-individu_index" */))
const _5a080204 = () => interopDefault(import('..\\pages\\employee-data\\band-posisi\\index.vue' /* webpackChunkName: "pages_employee-data_band-posisi_index" */))
const _00aa6531 = () => interopDefault(import('..\\pages\\employee-data\\bank-account.vue' /* webpackChunkName: "pages_employee-data_bank-account" */))
const _6c9d4f74 = () => interopDefault(import('..\\pages\\employee-data\\bank-account-search.vue' /* webpackChunkName: "pages_employee-data_bank-account-search" */))
const _7bae0e78 = () => interopDefault(import('..\\pages\\employee-data\\basic-pay.vue' /* webpackChunkName: "pages_employee-data_basic-pay" */))
const _d71fbefe = () => interopDefault(import('..\\pages\\employee-data\\basic-pay-search.vue' /* webpackChunkName: "pages_employee-data_basic-pay-search" */))
const _2ea98f7b = () => interopDefault(import('..\\pages\\employee-data\\bpjs-kesehatan.vue' /* webpackChunkName: "pages_employee-data_bpjs-kesehatan" */))
const _4a31ddea = () => interopDefault(import('..\\pages\\employee-data\\bpjs-kesehatan-search.vue' /* webpackChunkName: "pages_employee-data_bpjs-kesehatan-search" */))
const _43de0371 = () => interopDefault(import('..\\pages\\employee-data\\bpjs-tenaga-kerja.vue' /* webpackChunkName: "pages_employee-data_bpjs-tenaga-kerja" */))
const _a7f1ad98 = () => interopDefault(import('..\\pages\\employee-data\\bpjs-tenaga-kerja-search.vue' /* webpackChunkName: "pages_employee-data_bpjs-tenaga-kerja-search" */))
const _4e079a94 = () => interopDefault(import('..\\pages\\employee-data\\communication-search.vue' /* webpackChunkName: "pages_employee-data_communication-search" */))
const _f74f2520 = () => interopDefault(import('..\\pages\\employee-data\\communication-social-media.vue' /* webpackChunkName: "pages_employee-data_communication-social-media" */))
const _b9ff5b56 = () => interopDefault(import('..\\pages\\employee-data\\communication-social-media-search.vue' /* webpackChunkName: "pages_employee-data_communication-social-media-search" */))
const _a9c44ee4 = () => interopDefault(import('..\\pages\\employee-data\\diffable\\index.vue' /* webpackChunkName: "pages_employee-data_diffable_index" */))
const _60bf8663 = () => interopDefault(import('..\\pages\\employee-data\\education.vue' /* webpackChunkName: "pages_employee-data_education" */))
const _0babd202 = () => interopDefault(import('..\\pages\\employee-data\\education-search.vue' /* webpackChunkName: "pages_employee-data_education-search" */))
const _ab153d42 = () => interopDefault(import('..\\pages\\employee-data\\employee\\index.vue' /* webpackChunkName: "pages_employee-data_employee_index" */))
const _3c6b4a38 = () => interopDefault(import('..\\pages\\employee-data\\employee-identity.vue' /* webpackChunkName: "pages_employee-data_employee-identity" */))
const _85adf6e6 = () => interopDefault(import('..\\pages\\employee-data\\employee-identity-search.vue' /* webpackChunkName: "pages_employee-data_employee-identity-search" */))
const _fd1046d6 = () => interopDefault(import('..\\pages\\employee-data\\insurance.vue' /* webpackChunkName: "pages_employee-data_insurance" */))
const _1b017f90 = () => interopDefault(import('..\\pages\\employee-data\\insurance-search.vue' /* webpackChunkName: "pages_employee-data_insurance-search" */))
const _04eee5c2 = () => interopDefault(import('..\\pages\\employee-data\\itemTemplate.vue' /* webpackChunkName: "pages_employee-data_itemTemplate" */))
const _822c4764 = () => interopDefault(import('..\\pages\\employee-data\\onesheet.vue' /* webpackChunkName: "pages_employee-data_onesheet" */))
const _08b97dfe = () => interopDefault(import('..\\pages\\employee-data\\onesheet_2.vue' /* webpackChunkName: "pages_employee-data_onesheet_2" */))
const _0118128b = () => interopDefault(import('..\\pages\\employee-data\\organizational-assignment\\index.vue' /* webpackChunkName: "pages_employee-data_organizational-assignment_index" */))
const _424be921 = () => interopDefault(import('..\\pages\\employee-data\\specific-date-search.vue' /* webpackChunkName: "pages_employee-data_specific-date-search" */))
const _4bd43e14 = () => interopDefault(import('..\\pages\\employee-data\\spesific-date.vue' /* webpackChunkName: "pages_employee-data_spesific-date" */))
const _13329dfd = () => interopDefault(import('..\\pages\\employee-data\\spesific-date_backup.vue' /* webpackChunkName: "pages_employee-data_spesific-date_backup" */))
const _839a3ac8 = () => interopDefault(import('..\\pages\\employee-data\\tax\\index.vue' /* webpackChunkName: "pages_employee-data_tax_index" */))
const _3719f9c3 = () => interopDefault(import('..\\pages\\family-data\\family.vue' /* webpackChunkName: "pages_family-data_family" */))
const _6e5c326a = () => interopDefault(import('..\\pages\\family-data\\family-address.vue' /* webpackChunkName: "pages_family-data_family-address" */))
const _50443fca = () => interopDefault(import('..\\pages\\family-data\\family-address-search.vue' /* webpackChunkName: "pages_family-data_family-address-search" */))
const _98377268 = () => interopDefault(import('..\\pages\\family-data\\family-communication.vue' /* webpackChunkName: "pages_family-data_family-communication" */))
const _250a7979 = () => interopDefault(import('..\\pages\\family-data\\family-communication-search.vue' /* webpackChunkName: "pages_family-data_family-communication-search" */))
const _48d75238 = () => interopDefault(import('..\\pages\\family-data\\family-identity.vue' /* webpackChunkName: "pages_family-data_family-identity" */))
const _28a3fc8d = () => interopDefault(import('..\\pages\\family-data\\family-identity-search.vue' /* webpackChunkName: "pages_family-data_family-identity-search" */))
const _57aad2a2 = () => interopDefault(import('..\\pages\\family-data\\family-search.vue' /* webpackChunkName: "pages_family-data_family-search" */))
const _9fef6e7e = () => interopDefault(import('..\\pages\\grievance\\grievance-search.vue' /* webpackChunkName: "pages_grievance_grievance-search" */))
const _ba4f3096 = () => interopDefault(import('..\\pages\\manajemen\\account-assignment\\index.vue' /* webpackChunkName: "pages_manajemen_account-assignment_index" */))
const _72b82e86 = () => interopDefault(import('..\\pages\\manajemen\\bank\\index.vue' /* webpackChunkName: "pages_manajemen_bank_index" */))
const _fc0689e4 = () => interopDefault(import('..\\pages\\manajemen\\building\\index.vue' /* webpackChunkName: "pages_manajemen_building_index" */))
const _7bd8b216 = () => interopDefault(import('..\\pages\\manajemen\\building-management\\index.vue' /* webpackChunkName: "pages_manajemen_building-management_index" */))
const _1ba40016 = () => interopDefault(import('..\\pages\\manajemen\\company\\index.vue' /* webpackChunkName: "pages_manajemen_company_index" */))
const _0f042d14 = () => interopDefault(import('..\\pages\\manajemen\\company-relation\\index.vue' /* webpackChunkName: "pages_manajemen_company-relation_index" */))
const _344d09c6 = () => interopDefault(import('..\\pages\\manajemen\\cost-center\\index.vue' /* webpackChunkName: "pages_manajemen_cost-center_index" */))
const _5e382348 = () => interopDefault(import('..\\pages\\manajemen\\master-object\\index.vue' /* webpackChunkName: "pages_manajemen_master-object_index" */))
const _40a75a26 = () => interopDefault(import('..\\pages\\manajemen\\payroll-area\\index.vue' /* webpackChunkName: "pages_manajemen_payroll-area_index" */))
const _5c6c349f = () => interopDefault(import('..\\pages\\manajemen\\planned-compensation\\index.vue' /* webpackChunkName: "pages_manajemen_planned-compensation_index" */))
const _79017486 = () => interopDefault(import('..\\pages\\manajemen\\relat\\index.vue' /* webpackChunkName: "pages_manajemen_relat_index" */))
const _23f2a3ec = () => interopDefault(import('..\\pages\\manajemen\\Role\\index.vue' /* webpackChunkName: "pages_manajemen_Role_index" */))
const _5a4cecd2 = () => interopDefault(import('..\\pages\\manajemen\\user\\index.vue' /* webpackChunkName: "pages_manajemen_user_index" */))
const _219bfc73 = () => interopDefault(import('..\\pages\\manajemen\\wage-type\\index.vue' /* webpackChunkName: "pages_manajemen_wage-type_index" */))
const _1d4e2613 = () => interopDefault(import('..\\pages\\organization\\organization-manajement.vue' /* webpackChunkName: "pages_organization_organization-manajement" */))
const _0295ef55 = () => interopDefault(import('..\\pages\\organization\\tree.vue' /* webpackChunkName: "pages_organization_tree" */))
const _54471271 = () => interopDefault(import('..\\pages\\payroll\\additional-payment\\index.vue' /* webpackChunkName: "pages_payroll_additional-payment_index" */))
const _22a66bae = () => interopDefault(import('..\\pages\\payroll\\management\\index.vue' /* webpackChunkName: "pages_payroll_management_index" */))
const _12688dca = () => interopDefault(import('..\\pages\\payroll\\off-cycle\\index.vue' /* webpackChunkName: "pages_payroll_off-cycle_index" */))
const _8a8f67c8 = () => interopDefault(import('..\\pages\\payroll\\payroll-exception\\index.vue' /* webpackChunkName: "pages_payroll_payroll-exception_index" */))
const _f8f86a36 = () => interopDefault(import('..\\pages\\payroll\\payroll-formula\\index.vue' /* webpackChunkName: "pages_payroll_payroll-formula_index" */))
const _3c3fce26 = () => interopDefault(import('..\\pages\\payroll\\recurring\\index.vue' /* webpackChunkName: "pages_payroll_recurring_index" */))
const _21d579a8 = () => interopDefault(import('..\\pages\\payroll\\tax-range\\index.vue' /* webpackChunkName: "pages_payroll_tax-range_index" */))
const _f355e7d6 = () => interopDefault(import('..\\pages\\employee-data\\address\\address.vue' /* webpackChunkName: "pages_employee-data_address_address" */))
const _c9503fe0 = () => interopDefault(import('..\\pages\\employee-data\\address\\address-search.vue' /* webpackChunkName: "pages_employee-data_address_address-search" */))
const _0c355ad0 = () => interopDefault(import('..\\pages\\employee-data\\band-individu\\band-individu-search.vue' /* webpackChunkName: "pages_employee-data_band-individu_band-individu-search" */))
const _e0dd82a0 = () => interopDefault(import('..\\pages\\employee-data\\band-posisi\\band-posisi-search.vue' /* webpackChunkName: "pages_employee-data_band-posisi_band-posisi-search" */))
const _326fa6a8 = () => interopDefault(import('..\\pages\\employee-data\\contract\\contract-search.vue' /* webpackChunkName: "pages_employee-data_contract_contract-search" */))
const _b41ffddc = () => interopDefault(import('..\\pages\\employee-data\\diffable\\diffable-search.vue' /* webpackChunkName: "pages_employee-data_diffable_diffable-search" */))
const _9ce9fd18 = () => interopDefault(import('..\\pages\\employee-data\\employee\\employee-search.vue' /* webpackChunkName: "pages_employee-data_employee_employee-search" */))
const _7f54e94e = () => interopDefault(import('..\\pages\\employee-data\\organizational-assignment\\backup.vue' /* webpackChunkName: "pages_employee-data_organizational-assignment_backup" */))
const _1a137690 = () => interopDefault(import('..\\pages\\employee-data\\organizational-assignment\\organizational-assignment-search.vue' /* webpackChunkName: "pages_employee-data_organizational-assignment_organizational-assignment-search" */))
const _d48f52a0 = () => interopDefault(import('..\\pages\\employee-data\\tax\\tax-search.vue' /* webpackChunkName: "pages_employee-data_tax_tax-search" */))
const _4c679216 = () => interopDefault(import('..\\pages\\manajemen\\account-assignment\\account-search.vue' /* webpackChunkName: "pages_manajemen_account-assignment_account-search" */))
const _b92abb36 = () => interopDefault(import('..\\pages\\manajemen\\company\\company-search.vue' /* webpackChunkName: "pages_manajemen_company_company-search" */))
const _5ee2d69a = () => interopDefault(import('..\\pages\\manajemen\\cost-center\\cost-search.vue' /* webpackChunkName: "pages_manajemen_cost-center_cost-search" */))
const _011f554b = () => interopDefault(import('..\\pages\\manajemen\\master-object\\detail.vue' /* webpackChunkName: "pages_manajemen_master-object_detail" */))
const _22cf4cc5 = () => interopDefault(import('..\\pages\\manajemen\\payroll-area\\payroll-search.vue' /* webpackChunkName: "pages_manajemen_payroll-area_payroll-search" */))
const _07ed239b = () => interopDefault(import('..\\pages\\manajemen\\Role\\role-edit.vue' /* webpackChunkName: "pages_manajemen_Role_role-edit" */))
const _f50af564 = () => interopDefault(import('..\\pages\\manajemen\\wage-type\\wage-search.vue' /* webpackChunkName: "pages_manajemen_wage-type_wage-search" */))
const _34c0fc92 = () => interopDefault(import('..\\pages\\payroll\\additional-payment\\index3.vue' /* webpackChunkName: "pages_payroll_additional-payment_index3" */))
const _2f0f70d4 = () => interopDefault(import('..\\pages\\payroll\\off-cycle\\off-cycle-search.vue' /* webpackChunkName: "pages_payroll_off-cycle_off-cycle-search" */))
const _040eae61 = () => interopDefault(import('..\\pages\\payroll\\payroll-formula\\tambah-data.vue' /* webpackChunkName: "pages_payroll_payroll-formula_tambah-data" */))
const _347b2818 = () => interopDefault(import('..\\pages\\payroll\\recurring\\recurring-search.vue' /* webpackChunkName: "pages_payroll_recurring_recurring-search" */))
const _622b1084 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

Vue.use(Router)

if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected and scrollToTop is not explicitly disabled
  if (
    to.matched.length < 2 &&
    to.matched.every(r => r.components.default.options.scrollToTop !== false)
  ) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some(r => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise((resolve) => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}

export function createRouter() {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,

    routes: [{
      path: "/award",
      component: _36782499,
      name: "award"
    }, {
      path: "/competency",
      component: _6574ca41,
      name: "competency"
    }, {
      path: "/dashboard",
      component: _d92b73fc,
      name: "dashboard"
    }, {
      path: "/dynamicSearch",
      component: _4cec019a,
      name: "dynamicSearch"
    }, {
      path: "/grievance",
      component: _e2c64310,
      name: "grievance"
    }, {
      path: "/kontrak",
      component: _53f9d0c4,
      name: "kontrak"
    }, {
      path: "/login",
      component: _cedbca56,
      name: "login"
    }, {
      path: "/login2",
      component: _79c8e92d,
      name: "login2"
    }, {
      path: "/mutasi",
      component: _16fb0033,
      name: "mutasi"
    }, {
      path: "/organization",
      component: _20be5e2b,
      name: "organization"
    }, {
      path: "/report",
      component: _2bfe2aec,
      name: "report"
    }, {
      path: "/Slip-gaji",
      component: _0feb1d70,
      name: "Slip-gaji"
    }, {
      path: "/tambah-menu",
      component: _712349f3,
      name: "tambah-menu"
    }, {
      path: "/upload",
      component: _57f0c0c6,
      name: "upload"
    }, {
      path: "/admission/admission-assigment",
      component: _b82c9758,
      name: "admission-admission-assigment"
    }, {
      path: "/admission/admission-basiclevel",
      component: _216c1c8f,
      name: "admission-admission-basiclevel"
    }, {
      path: "/admission/admission-basicpay",
      component: _099c8073,
      name: "admission-admission-basicpay"
    }, {
      path: "/admission/admission-bpjs",
      component: _2e688a60,
      name: "admission-admission-bpjs"
    }, {
      path: "/admission/admission-personal",
      component: _1353adf9,
      name: "admission-admission-personal"
    }, {
      path: "/admission/admission-tax",
      component: _542c3f02,
      name: "admission-admission-tax"
    }, {
      path: "/award/award-search",
      component: _990c76be,
      name: "award-award-search"
    }, {
      path: "/competency/certificate-search",
      component: _fb57b082,
      name: "competency-certificate-search"
    }, {
      path: "/competency/certification",
      component: _4cae09ae,
      name: "competency-certification"
    }, {
      path: "/competency/certification-search",
      component: _69bedb08,
      name: "competency-certification-search"
    }, {
      path: "/competency/competency-search",
      component: _6787d987,
      name: "competency-competency-search"
    }, {
      path: "/competency/education",
      component: _05702ad2,
      name: "competency-education"
    }, {
      path: "/competency/masterpiece",
      component: _20e0a4fb,
      name: "competency-masterpiece"
    }, {
      path: "/competency/masterpiece-search",
      component: _255f986a,
      name: "competency-masterpiece-search"
    }, {
      path: "/competency/training",
      component: _7bb1198a,
      name: "competency-training"
    }, {
      path: "/competency/training_search",
      component: _2f29a848,
      name: "competency-training_search"
    }, {
      path: "/competency/training-search",
      component: _587f7bac,
      name: "competency-training-search"
    }, {
      path: "/dashboard/detail",
      component: _723189d1,
      name: "dashboard-detail"
    }, {
      path: "/employee-data/address",
      component: _38856f9a,
      name: "employee-data-address"
    }, {
      path: "/employee-data/band-individu",
      component: _273870a1,
      name: "employee-data-band-individu"
    }, {
      path: "/employee-data/band-posisi",
      component: _5a080204,
      name: "employee-data-band-posisi"
    }, {
      path: "/employee-data/bank-account",
      component: _00aa6531,
      name: "employee-data-bank-account"
    }, {
      path: "/employee-data/bank-account-search",
      component: _6c9d4f74,
      name: "employee-data-bank-account-search"
    }, {
      path: "/employee-data/basic-pay",
      component: _7bae0e78,
      name: "employee-data-basic-pay"
    }, {
      path: "/employee-data/basic-pay-search",
      component: _d71fbefe,
      name: "employee-data-basic-pay-search"
    }, {
      path: "/employee-data/bpjs-kesehatan",
      component: _2ea98f7b,
      name: "employee-data-bpjs-kesehatan"
    }, {
      path: "/employee-data/bpjs-kesehatan-search",
      component: _4a31ddea,
      name: "employee-data-bpjs-kesehatan-search"
    }, {
      path: "/employee-data/bpjs-tenaga-kerja",
      component: _43de0371,
      name: "employee-data-bpjs-tenaga-kerja"
    }, {
      path: "/employee-data/bpjs-tenaga-kerja-search",
      component: _a7f1ad98,
      name: "employee-data-bpjs-tenaga-kerja-search"
    }, {
      path: "/employee-data/communication-search",
      component: _4e079a94,
      name: "employee-data-communication-search"
    }, {
      path: "/employee-data/communication-social-media",
      component: _f74f2520,
      name: "employee-data-communication-social-media"
    }, {
      path: "/employee-data/communication-social-media-search",
      component: _b9ff5b56,
      name: "employee-data-communication-social-media-search"
    }, {
      path: "/employee-data/diffable",
      component: _a9c44ee4,
      name: "employee-data-diffable"
    }, {
      path: "/employee-data/education",
      component: _60bf8663,
      name: "employee-data-education"
    }, {
      path: "/employee-data/education-search",
      component: _0babd202,
      name: "employee-data-education-search"
    }, {
      path: "/employee-data/employee",
      component: _ab153d42,
      name: "employee-data-employee"
    }, {
      path: "/employee-data/employee-identity",
      component: _3c6b4a38,
      name: "employee-data-employee-identity"
    }, {
      path: "/employee-data/employee-identity-search",
      component: _85adf6e6,
      name: "employee-data-employee-identity-search"
    }, {
      path: "/employee-data/insurance",
      component: _fd1046d6,
      name: "employee-data-insurance"
    }, {
      path: "/employee-data/insurance-search",
      component: _1b017f90,
      name: "employee-data-insurance-search"
    }, {
      path: "/employee-data/itemTemplate",
      component: _04eee5c2,
      name: "employee-data-itemTemplate"
    }, {
      path: "/employee-data/onesheet",
      component: _822c4764,
      name: "employee-data-onesheet"
    }, {
      path: "/employee-data/onesheet_2",
      component: _08b97dfe,
      name: "employee-data-onesheet_2"
    }, {
      path: "/employee-data/organizational-assignment",
      component: _0118128b,
      name: "employee-data-organizational-assignment"
    }, {
      path: "/employee-data/specific-date-search",
      component: _424be921,
      name: "employee-data-specific-date-search"
    }, {
      path: "/employee-data/spesific-date",
      component: _4bd43e14,
      name: "employee-data-spesific-date"
    }, {
      path: "/employee-data/spesific-date_backup",
      component: _13329dfd,
      name: "employee-data-spesific-date_backup"
    }, {
      path: "/employee-data/tax",
      component: _839a3ac8,
      name: "employee-data-tax"
    }, {
      path: "/family-data/family",
      component: _3719f9c3,
      name: "family-data-family"
    }, {
      path: "/family-data/family-address",
      component: _6e5c326a,
      name: "family-data-family-address"
    }, {
      path: "/family-data/family-address-search",
      component: _50443fca,
      name: "family-data-family-address-search"
    }, {
      path: "/family-data/family-communication",
      component: _98377268,
      name: "family-data-family-communication"
    }, {
      path: "/family-data/family-communication-search",
      component: _250a7979,
      name: "family-data-family-communication-search"
    }, {
      path: "/family-data/family-identity",
      component: _48d75238,
      name: "family-data-family-identity"
    }, {
      path: "/family-data/family-identity-search",
      component: _28a3fc8d,
      name: "family-data-family-identity-search"
    }, {
      path: "/family-data/family-search",
      component: _57aad2a2,
      name: "family-data-family-search"
    }, {
      path: "/grievance/grievance-search",
      component: _9fef6e7e,
      name: "grievance-grievance-search"
    }, {
      path: "/manajemen/account-assignment",
      component: _ba4f3096,
      name: "manajemen-account-assignment"
    }, {
      path: "/manajemen/bank",
      component: _72b82e86,
      name: "manajemen-bank"
    }, {
      path: "/manajemen/building",
      component: _fc0689e4,
      name: "manajemen-building"
    }, {
      path: "/manajemen/building-management",
      component: _7bd8b216,
      name: "manajemen-building-management"
    }, {
      path: "/manajemen/company",
      component: _1ba40016,
      name: "manajemen-company"
    }, {
      path: "/manajemen/company-relation",
      component: _0f042d14,
      name: "manajemen-company-relation"
    }, {
      path: "/manajemen/cost-center",
      component: _344d09c6,
      name: "manajemen-cost-center"
    }, {
      path: "/manajemen/master-object",
      component: _5e382348,
      name: "manajemen-master-object"
    }, {
      path: "/manajemen/payroll-area",
      component: _40a75a26,
      name: "manajemen-payroll-area"
    }, {
      path: "/manajemen/planned-compensation",
      component: _5c6c349f,
      name: "manajemen-planned-compensation"
    }, {
      path: "/manajemen/relat",
      component: _79017486,
      name: "manajemen-relat"
    }, {
      path: "/manajemen/Role",
      component: _23f2a3ec,
      name: "manajemen-Role"
    }, {
      path: "/manajemen/user",
      component: _5a4cecd2,
      name: "manajemen-user"
    }, {
      path: "/manajemen/wage-type",
      component: _219bfc73,
      name: "manajemen-wage-type"
    }, {
      path: "/organization/organization-manajement",
      component: _1d4e2613,
      name: "organization-organization-manajement"
    }, {
      path: "/organization/tree",
      component: _0295ef55,
      name: "organization-tree"
    }, {
      path: "/payroll/additional-payment",
      component: _54471271,
      name: "payroll-additional-payment"
    }, {
      path: "/payroll/management",
      component: _22a66bae,
      name: "payroll-management"
    }, {
      path: "/payroll/off-cycle",
      component: _12688dca,
      name: "payroll-off-cycle"
    }, {
      path: "/payroll/payroll-exception",
      component: _8a8f67c8,
      name: "payroll-payroll-exception"
    }, {
      path: "/payroll/payroll-formula",
      component: _f8f86a36,
      name: "payroll-payroll-formula"
    }, {
      path: "/payroll/recurring",
      component: _3c3fce26,
      name: "payroll-recurring"
    }, {
      path: "/payroll/tax-range",
      component: _21d579a8,
      name: "payroll-tax-range"
    }, {
      path: "/employee-data/address/address",
      component: _f355e7d6,
      name: "employee-data-address-address"
    }, {
      path: "/employee-data/address/address-search",
      component: _c9503fe0,
      name: "employee-data-address-address-search"
    }, {
      path: "/employee-data/band-individu/band-individu-search",
      component: _0c355ad0,
      name: "employee-data-band-individu-band-individu-search"
    }, {
      path: "/employee-data/band-posisi/band-posisi-search",
      component: _e0dd82a0,
      name: "employee-data-band-posisi-band-posisi-search"
    }, {
      path: "/employee-data/contract/contract-search",
      component: _326fa6a8,
      name: "employee-data-contract-contract-search"
    }, {
      path: "/employee-data/diffable/diffable-search",
      component: _b41ffddc,
      name: "employee-data-diffable-diffable-search"
    }, {
      path: "/employee-data/employee/employee-search",
      component: _9ce9fd18,
      name: "employee-data-employee-employee-search"
    }, {
      path: "/employee-data/organizational-assignment/backup",
      component: _7f54e94e,
      name: "employee-data-organizational-assignment-backup"
    }, {
      path: "/employee-data/organizational-assignment/organizational-assignment-search",
      component: _1a137690,
      name: "employee-data-organizational-assignment-organizational-assignment-search"
    }, {
      path: "/employee-data/tax/tax-search",
      component: _d48f52a0,
      name: "employee-data-tax-tax-search"
    }, {
      path: "/manajemen/account-assignment/account-search",
      component: _4c679216,
      name: "manajemen-account-assignment-account-search"
    }, {
      path: "/manajemen/company/company-search",
      component: _b92abb36,
      name: "manajemen-company-company-search"
    }, {
      path: "/manajemen/cost-center/cost-search",
      component: _5ee2d69a,
      name: "manajemen-cost-center-cost-search"
    }, {
      path: "/manajemen/master-object/detail",
      component: _011f554b,
      name: "manajemen-master-object-detail"
    }, {
      path: "/manajemen/payroll-area/payroll-search",
      component: _22cf4cc5,
      name: "manajemen-payroll-area-payroll-search"
    }, {
      path: "/manajemen/Role/role-edit",
      component: _07ed239b,
      name: "manajemen-Role-role-edit"
    }, {
      path: "/manajemen/wage-type/wage-search",
      component: _f50af564,
      name: "manajemen-wage-type-wage-search"
    }, {
      path: "/payroll/additional-payment/index3",
      component: _34c0fc92,
      name: "payroll-additional-payment-index3"
    }, {
      path: "/payroll/off-cycle/off-cycle-search",
      component: _2f0f70d4,
      name: "payroll-off-cycle-off-cycle-search"
    }, {
      path: "/payroll/payroll-formula/tambah-data",
      component: _040eae61,
      name: "payroll-payroll-formula-tambah-data"
    }, {
      path: "/payroll/recurring/recurring-search",
      component: _347b2818,
      name: "payroll-recurring-recurring-search"
    }, {
      path: "/",
      component: _622b1084,
      name: "index"
    }],

    fallback: false
  })
}
