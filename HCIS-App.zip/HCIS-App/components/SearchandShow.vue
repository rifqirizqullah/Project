<template>
        <div class="columns">        
        <div class="column is-narrow">
            <div class="field">
              <div class="select">
                <select v-model="otype" @change="getObject">            
                  <option v-for="(level, index) in otypes" :key="index" :value="level.id">Band {{level.name}}</option>                                      
                </select>
              </div>
            </div>   
        </div>
        <div class="column is-narrow">
            <div class="field">
              <div class="select">
                <select v-model="jobFunction" @change="getPerPage">
                  <option :value="''">All Job Function </option>
                  <option v-for="(jobFunction, index) in jobFunctions" :key="index" :value="jobFunction.id">{{jobFunction.name}}</option>                  
                </select>
              </div>
            </div> 
        </div>
        <div class="column">
          <div class="field">
            <div class="control has-icons-right">
              <input class="input" type="text" placeholder=" " v-model="searchs" @input="getPerPage">
              <span class="icon is-right">
                <i class="fa fa-search"></i>
              </span>
            </div>
          </div>
        </div>
      </div>
</template>
<script>
  export default {        
     data() {
      return {        
        object:'',
        otype:'',
        objects:[],
        otypes:[]
      }
    },
    
    created(){
      this.getOtype();      
    },
    methods: {
      getPerPage(){        
          this.$parent.otype_search = this.otype;
          this.$parent.object_search = this.object;
          this.$parent.getRelat()                
      },
      getOtype() {
        this.$axios.get('/users/otype')
          .then(response => {
            this.otypes = [];
            response.data.data.forEach(async (jobFunction, key) => {
              await this.otypes.push({
                id: jobFunction.otype_code,
                name: jobFunction.otype_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getObject() {
        this.$axios.get('/users/otype/'+this.otype+'/object')
          .then(response => {
            this.objects = [];
            response.data.data.forEach(async (jobFunction, key) => {
              await this.objects.push({
                id: jobFunction.object_code,
                name: jobFunction.object_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
    }
  }

</script>