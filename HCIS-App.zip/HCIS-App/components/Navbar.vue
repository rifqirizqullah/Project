<template>
  <nav class="navbar nav-backround" role="navigation" aria-label="main navigation">
    <div class="navbar-brand">
      <a class="navbar-item" href="">
        <img src="/img/hcis-logo.png" width="112" height="28">
      </a>

      <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false"
        data-target="navbarBasicExample">
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
        <span aria-hidden="true"></span>
      </a>
    </div>

    <div id="navbarBasicExample" class="navbar-menu">
      <div class="navbar-start is-active-navbar-color">
        <nuxt-link to="/" class="navbar-item has-text-white">
          Beranda
        </nuxt-link>

        <nuxt-link to="/dashboard" class="navbar-item has-text-white">
          Dashboard
        </nuxt-link>

        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link has-text-white">
            Aksi
          </a>

          <div class="navbar-dropdown">
            <nuxt-link to="/tambah-menu" class="navbar-item">
              Tambah Menu
            </nuxt-link>



          </div>
        </div>

        <!-- <nuxt-link to="/mutasi" class="navbar-item">
          Mutation
        </nuxt-link> -->

        <div class="navbar-item has-dropdown is-hoverable dropdown-color">
          <a class="navbar-link has-text-white">
            Organisasi
          </a>

          <div class="navbar-dropdown">
            <nuxt-link to="/organization" class="navbar-item ">
              Manajemen
            </nuxt-link>
          </div>
        </div>

        <div class="navbar-item has-dropdown is-hoverable ">
          <a class="navbar-link has-text-white">
            Karyawan
          </a>

          <div class="navbar-dropdown">
            <nuxt-link to="/employee-data/employee/employee-search" class="navbar-item">
              Karyawan
            </nuxt-link>

            <nuxt-link to="/employee-data/organizational-assignment/organizational-assignment-search" class="navbar-item">
              Penempatan Kerja
            </nuxt-link>

            <nuxt-link to="/employee-data/basic-pay-search" class="navbar-item">
              Renumerasi Dasar
            </nuxt-link>

            <nuxt-link to="/employee-data/bank-account-search" class="navbar-item">
              Rekening Bank
            </nuxt-link>

            <nuxt-link to="/employee-data/education-search" class="navbar-item">
              Pendidikan
            </nuxt-link>

            <nuxt-link to="/employee-data/tax/tax-search" class="navbar-item">
              Pajak
            </nuxt-link>

            <nuxt-link to="/employee-data/bpjs-tenaga-kerja-search" class="navbar-item">
              BPJS Tenaga Kerja
            </nuxt-link>

            <nuxt-link to="/employee-data/insurance-search" class="navbar-item">
              Asuransi
            </nuxt-link>

            <nuxt-link to="/employee-data/band-posisi/band-posisi-search" class="navbar-item">
              Band Posisi
            </nuxt-link>

            <nuxt-link to="/employee-data/band-individu/band-individu-search" class="navbar-item">
              Band Individu
            </nuxt-link>

            <!-- <nuxt-link to="/employee-data/basic-pay" class="navbar-item">
              Basic Pay
            </nuxt-link> -->

            <nuxt-link to="/employee-data/employee-identity-search" class="navbar-item">
              Identitas
            </nuxt-link>

            <nuxt-link to="/employee-data/address/address-search" class="navbar-item">
              Alamat
            </nuxt-link>

            <nuxt-link to="/employee-data/communication-social-media-search" class="navbar-item">
              Alat Komunikasi
            </nuxt-link>

            <nuxt-link to="/employee-data/diffable/diffable-search" class="navbar-item">
              Disabilitas
            </nuxt-link>

            <nuxt-link to="/grievance/grievance-search" class="navbar-item">
              Pembinaan
            </nuxt-link>

            <nuxt-link to="/award/award-search" class="navbar-item">
              Penghargaan
            </nuxt-link>

            <nuxt-link to="/employee-data/specific-date-search" class="navbar-item">
              Tanggal Penting
            </nuxt-link>

            <nuxt-link to="/employee-data/contract/contract-search" class="navbar-item">
              Kontrak
            </nuxt-link>

          </div>
        </div>

        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link has-text-white">
            Kualifikasi
          </a>

          <div class="navbar-dropdown">
            <nuxt-link to="/competency/competency-search" class="navbar-item">
              Kompetensi
            </nuxt-link>

            <nuxt-link to="/competency/certification-search" class="navbar-item">
              Sertifikasi
            </nuxt-link>

            <nuxt-link to="/competency/training_search" class="navbar-item">
              Pelatihan
            </nuxt-link>
            <nuxt-link to="/competency/masterpiece-search" class="navbar-item">
              Mahakarya
            </nuxt-link>

          </div>
        </div>

        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link has-text-white">
            Payroll
          </a>

          <div class="navbar-dropdown">
            <nuxt-link to="/payroll/recurring/recurring-search" class="navbar-item">
              Bulanan
            </nuxt-link>

            <nuxt-link to="/payroll/additional-payment" class="navbar-item">
              Pembayaran Insidental
            </nuxt-link>

            <nuxt-link to="/payroll/off-cycle/off-cycle-search" class="navbar-item">
              Off Cycle
            </nuxt-link>

            <nuxt-link to="/payroll/payroll-formula" class="navbar-item">
              Formula Payroll
            </nuxt-link>

            <nuxt-link to="/payroll/payroll-exception" class="navbar-item">
              Pengecualian Payroll
            </nuxt-link>

            <nuxt-link to="/payroll/management" class="navbar-item">
              Manajemen Payroll
            </nuxt-link>

            <nuxt-link to="/payroll/tax-range" class="navbar-item">
              Rentang Pajak
            </nuxt-link>

          </div>
        </div>


        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link has-text-white">
            Keluarga
          </a>

          <div class="navbar-dropdown">
            <nuxt-link to="/family-data/family-search" class="navbar-item">
              Keluarga
            </nuxt-link>

            <nuxt-link to="/family-data/family-address-search" class="navbar-item">
              Alamat Keluarga
            </nuxt-link>

            <nuxt-link to="/family-data/family-identity-search" class="navbar-item">
              Identitas Keluarga
            </nuxt-link>

            <nuxt-link to="/family-data/family-communication-search" class="navbar-item">
              Komunikasi Keluarga
            </nuxt-link>
          </div>
        </div>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link has-text-white">
            Laporan
          </a>

          <div class="navbar-dropdown">
            <nuxt-link to="/dynamicSearch" class="navbar-item">
              Pencarian Dinamis
            </nuxt-link>

          </div>
        </div>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link has-text-white">
            Upload
          </a>

          <div class="navbar-dropdown">
            <nuxt-link to="/upload" class="navbar-item">
              Upload Data
            </nuxt-link>
          </div>
        </div>
        <div class="navbar-item has-dropdown is-hoverable">
          <a class="navbar-link has-text-white">
            Manajemen
          </a>
          <div class="navbar-dropdown">
            <nuxt-link to="/manajemen/user" class="navbar-item">
              Pengguna
            </nuxt-link>
            <nuxt-link to="/manajemen/role" class="navbar-item">
              Hak Akses
            </nuxt-link>
            <nuxt-link to="/manajemen/payroll-area/payroll-search" class="navbar-item">
              Area Payroll
            </nuxt-link>
            <nuxt-link to="/manajemen/account-assignment/account-search" class="navbar-item">
              Area Bisnis
            </nuxt-link>
            <nuxt-link to="/manajemen/wage-type/wage-search" class="navbar-item">
              Komponen Penghasilan
            </nuxt-link>
            <nuxt-link to="/manajemen/company/company-search" class="navbar-item">
              Perusahaan
            </nuxt-link>
            <nuxt-link to="/manajemen/bank" class="navbar-item">
              Bank
            </nuxt-link>
            <nuxt-link to="/manajemen/building" class="navbar-item">
              Gedung
            </nuxt-link>
            <nuxt-link to="/manajemen/planned-compensation" class="navbar-item">
              Rencana Renumerasi
            </nuxt-link>
            <nuxt-link to="/manajemen/master-object" class="navbar-item">
              Obyek
            </nuxt-link>
            <nuxt-link to="/manajemen/relat" class="navbar-item">
              Relasi
            </nuxt-link>
            <nuxt-link to="/manajemen/building-management" class="navbar-item">
              Manajemen Gedung
            </nuxt-link>
            <nuxt-link to="/manajemen/company-relation" class="navbar-item">
              Hubungan Perusahaan
            </nuxt-link>
          </div>
        </div>
      </div>
      <div class="navbar-item" style="padding: 0">
        <figure class="image is-32x32">
          <img class="is-rounded" src="https://bulma.io/images/placeholders/128x128.png">
        </figure>
      </div>
      <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link has-text-white">
          Admin
        </a>
        <div class="navbar-dropdown is-boxed">


          <a class="navbar-item" @click="logout">Logout</a>
        </div>
      </div>
    </div>
  </nav>
</template>

<script>
  export default {
    components: {

    },
    data() {
      return {
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Employee Data'
          },
          {
            name: 'Basic Level'
          },
        ]
      }
    },
    methods: {
      async logout() {
        await this.$auth.logout();
        this.$router.push('/login')
      },
    }
  }

</script>

<style>
  .nav-backround {
    background-color: #4B2981;
  }

  .is-active-navbar-color a:hover {
    background-color: rgb(121, 86, 176);
  }

  .navbar-item.has-dropdown:hover .navbar-link,
  .navbar-item.has-dropdown.is-active .navbar-link {
    background-color: rgb(121, 86, 176);
  }

  .navbar-link:not(.is-arrowless)::after {
    border-color: #fffefe;
    margin-top: -0.375em;
    right: 1.125em;
  }

  .button.is-primary {
    background-color: rgb(121, 86, 176);
    border-color: transparent;
    color: #fffefe;
  }

  a.navbar-item,
  .navbar-link {
    cursor: pointer;
    font-size: 14px;
  }

</style>