<template>
  <section>
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Mahakarya</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                    v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                    class="is-link">Ubah</a></label>
                <div class="control" v-if="employee == null">
                  <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                    @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                    v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                  </vue-autosuggest>
                </div>
                <div class="control" v-else>
                  <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                    v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                    v-validate="'required'" disabled>
                </div>
                <p v-show="errors.has('personnel_number')" class="help is-danger">
                  {{ errors.first('personnel_number') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama</label>
                <div class="control">
                  <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                    v-validate="'required'" disabled>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Posisi Saat Ini</label>
                <div class="control">
                  <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                    v-model="empolyeePosition" v-validate="'required'" disabled>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Unit Saat Ini</label>
                <div class="control">
                  <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                    v-validate="'required'" disabled>
                </div>
              </div>
            </div>
          </div>
          <hr>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Dikeluarkan</label>
                <div class="control">
                  <input id="masterpiece_start" data-display-mode="dialog" class="input" name="masterpiece_start"
                    type="date" placeholder="e.g 10-11-2018" v-model="masterpieceStart" data-vv-as="Masterpiece Start"
                    v-bind:class="{ 'is-danger': errors.has('masterpiece_start')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('masterpiece_start')" class="help is-danger">
                  {{ errors.first('masterpiece_start') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Kadaluarsa</label>
                <div class="control">
                  <input id="masterpiece_finish" data-display-mode="dialog" class="input" name="masterpiece_finish"
                    type="date" placeholder="e.g 10-11-2018" v-model="masterpieceFinish" data-vv-as="Masterpiece Finish"
                    v-bind:class="{ 'is-danger': errors.has('masterpiece_finish')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('masterpiece_finish')" class="help is-danger">
                  {{ errors.first('masterpiece_finish') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tipe Mahakarya</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('masterpieceType') }">
                    <select name="masterpieceType" class="select" v-model="masterpieceType" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in MSTTY.list" :key="key" :value="item.object_code">
                        {{ item.object_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('masterpieceType')" class="help is-danger">
                    {{ errors.first('masterpieceType') }}
                  </p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Unit</label>
                <div class="control">
                  <input name="unit" class="input" placeholder="Unit" type="text" v-model="unit"
                    v-bind:class="{ 'is-danger': errors.has('unit')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('unit')" class="help is-danger">{{ errors.first('unit') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Posisi</label>
                <div class="control">
                  <input name="position" class="input" placeholder="Posisi" type="text" v-model="position"
                    v-bind:class="{ 'is-danger': errors.has('position')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('position')" class="help is-danger">{{ errors.first('position') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama Acara</label>
                <div class="control">
                  <input name="event_name" class="input" placeholder="Nama Acara" type="text" v-model="eventName"
                    v-bind:class="{ 'is-danger': errors.has('event_name')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('event_name')" class="help is-danger">{{ errors.first('event_name') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Lokasi</label>
                <div class="control">
                  <input name="location" class="input" placeholder="Lokasi" type="text" v-model="location"
                    v-bind:class="{ 'is-danger': errors.has('location')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('location')" class="help is-danger">{{ errors.first('location') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Deskripsi</label>
                <div class="control">
                  <input name="description" class="input" placeholder="Deskripsi" type="text" v-model="description"
                    v-bind:class="{ 'is-danger': errors.has('description')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('description')" class="help is-danger">{{ errors.first('description') }}</p>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import {
    VueAutosuggest
  } from "vue-autosuggest";
  import moment from "moment";

  export default {
    components: {
      VueAutosuggest
    },
    data() {
      return {
        objecIdentifier: null,
        company: null,
        employee: null,
        empolyeeName: '',
        empolyeePosition: '',
        empolyeeUnit: '',
        startDate: null,
        endDate: null,
        masterpieceStart: null,
        masterpieceFinish: null,
        masterpieceType: null,
        unit: "",
        position: "",
        eventName: "",
        location: "",
        description: "",

        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,
      }
    },
    created() {
      if (this.masterpiece.detail) this.getData()
      this.getParam();
    },
    computed: {
      ...mapState(['companies', 'masterpiece', 'MSTTY'])
    },
    methods: {
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployeeData(nik) {
        this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      clearEmployee() {
        if (this.employee != null) {
          this.$refs.reference = '';
        }
        this.filterEmployee = []
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeeUnit = '';
        this.empolyeePosition = '';

        this.$nextTick(() => this.$validator.reset());
      },

      getData() {
        this.objecIdentifier = this.masterpiece.detail.object_identifier;

        this.startDate = this.masterpiece.detail.begin_date;
        this.endDate = this.masterpiece.detail.end_date;
        this.masterpieceStart = this.masterpiece.detail.masterpiece_start;
        this.masterpieceFinish = this.masterpiece.detail.masterpiece_finish;
        this.masterpieceType = this.masterpiece.detail.masterpiece_type.object_code;
        this.unit = this.masterpiece.detail.unit;
        this.position = this.masterpiece.detail.position;
        this.eventName = this.masterpiece.detail.event_name;
        this.location = this.masterpiece.detail.location;
        this.description = this.masterpiece.detail.description;

        this.company = this.masterpiece.detail.business_code.business_code;
        this.employee = this.masterpiece.detail.personnel_number;

        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.$store.dispatch('MSTTY/getAll', {
          business_code: ['*', this.company]
        });
      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('hcis/api/masterpiece', {
            begin_date: this.startDate,
            end_date: this.endDate,
            masterpiece_type: this.masterpieceType,
            position: this.position,
            event_name: this.eventName,
            unit: this.unit,
            location: this.location,
            masterpiece_start: this.masterpieceStart,
            masterpiece_finish: this.masterpieceFinish,
            description: this.description,

            business_code: this.company,
            personnel_number: this.employee
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('masterpiece/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('hcis/api/masterpiece', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            masterpiece_type: this.masterpieceType,
            position: this.position,
            event_name: this.eventName,
            unit: this.unit,
            location: this.location,
            masterpiece_start: this.masterpieceStart,
            masterpiece_finish: this.masterpieceFinish,
            description: this.description,

            business_code: this.company,
            personnel_number: this.employee
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('masterpiece/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.masterpiece.detail.object_identifier;

        this.startDate = this.masterpiece.detail.begin_date;
        this.endDate = this.masterpiece.detail.end_date;
        this.masterpieceStart = this.masterpiece.detail.masterpiece_start;
        this.masterpieceFinish = this.masterpiece.detail.masterpiece_finish;
        this.masterpieceType = this.masterpiece.detail.masterpiece_type.id;
        this.unit = this.masterpiece.detail.unit;
        this.position = this.masterpiece.detail.position;
        this.eventName = this.masterpiece.detail.event_name;
        this.location = this.masterpiece.detail.location;
        this.description = this.masterpiece.detail.description;

        this.company = this.masterpiece.detail.business_code.business_code;
        this.employee = this.masterpiece.detail.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);

        this.$validator.reset('form')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
