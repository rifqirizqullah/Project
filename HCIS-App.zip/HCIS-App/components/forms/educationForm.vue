<template>
    <div class="">
        <div class="modal-background"></div>            
        <div class="modal-card">
          <header class="modal-card-head">
            <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Pendidikan</p>
            <button @click="closeFormModal()" class="delete" aria-label="close"></button>
          </header>
          <section class="modal-card-body">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nama Perusahaan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                      <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                        v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                          {{ company.company_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                  </div>                  
                </div>
              </div>
            </div>
            <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee= null">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      :on-selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="columns">
            <div class="column is-5">
                <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                    <input class="input" id="begin_date" type="date" placeholder="10-10-2017" name="begin_date"
                    v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('form.begin_date')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
                </div>
            </div>
            <div class="column is-5">
                <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                    <input id="end_date" class="input" name="end_date" type="date" placeholder="10-10-2017" v-model="endDate"
                    data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
                </div>
            </div>
            </div>
            <div class="columns">
                <div class="column is-5">
                <div class="field">
                    <label class="label">Tanggal Mulai Pendidikan</label>
                    <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date_edu" type="date"
                        placeholder="e.g 10-11-2018" v-model="startEdu" data-vv-as="start date education"
                        v-bind:class="{ 'is-danger': errors.has('form.begin_date_edu')}" v-validate="'required'"
                        data-vv-scope="form">
                    </div>
                    <p v-show="errors.has('form.begin_date_edu')" class="help is-danger">
                    {{ errors.first('form.begin_date_edu') }}</p>
                </div>
                </div>
                <div class="column is-5">
                <div class="field">
                    <label class="label">Tanggal Selesai Pendidikan</label>
                    <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date_edu" type="date"
                        placeholder="e.g 10-11-2018" v-model="endEdu" data-vv-as="End date education"
                        v-bind:class="{ 'is-danger': errors.has('form.end_date_edu')}" v-validate="'required'"
                        data-vv-scope="form">
                    </div>
                    <p v-show="errors.has('form.end_date_edu')" class="help is-danger">{{ errors.first('form.end_date_edu') }}
                    </p>
                </div>
                </div>
            </div>
            <div class="columns">
                <div class="column is-5">
                <div class="field">
                    <label class="label">Level Pendidikan</label>
                    <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.education_level') }">
                        <select name="education_level" class="select" v-model="educationLevel" data-vv-as="education level"
                        v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(educationLevel, key) in EDULV.list" :key="key" :value="educationLevel.id">{{
                            educationLevel.value
                            }}</option>
                        </select>
                    </div>
                    <p v-show="errors.has('form.education_level')" class="help is-danger">{{errors.first('form.education_level')
                        }}</p>
                    </div>
                </div>
                </div>   
                <div class="column is-5">
                <div class="field">
                    <label class="label">Institusi</label>
                    <div class="control">
                    <div class="select  is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.institution') }">
                        <select name="institution" class="select" v-model="institution" v-validate="'required'"
                        data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(institution, key) in EDUIN.list" :key="key" :value="institution.id">{{
                            institution.value
                            }}</option>
                        </select>
                    </div>
                    <p v-show="errors.has('form.institution')" class="help is-danger">{{errors.first('form.institution')
                        }}</p>
                    </div>
                </div>
                </div>
                             
            </div>
            <div class="columns">
                <div class="column is-5">
                <div class="field">
                    <label class="label">Fakultas</label>
                    <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.faculty') }">
                        <select name="faculty" class="select" v-model="faculty" data-vv-as="faculty" v-validate="'required'"
                        data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(faculty, key) in EDUFC.list" :key="key" :value="faculty.id">{{
                            faculty.value
                            }}</option>
                        </select>
                    </div>
                    <p v-show="errors.has('form.faculty')" class="help is-danger">{{errors.first('form.faculty')
                        }}</p>
                    </div>
                </div>
                </div>
                <div class="column is-5">
                <div class="field">
                    <label class="label">Jurusan</label>
                    <div class="control">
                    <div class="select  is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.major') }">
                        <select name="major" class="select" v-model="major" data-vv-as="major" v-validate="'required'"
                        data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(major, key) in EDUBR.list" :key="key" :value="major.id">{{
                            major.value
                            }}</option>
                        </select>
                    </div>
                    <p v-show="errors.has('form.major')" class="help is-danger">{{errors.first('form.major')
                        }}</p>
                    </div>
                </div>
                </div>
                
            </div>
            <div class="columns">
                <div class="column is-5">
                <div class="field">
                    <label class="label">Keahlian</label>
                    <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.sub_major') }">
                        <select name="sub_major" class="select" v-model="subMajor" data-vv-as="sub major"
                        v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(subMajor, key) in EDUMR.list" :key="key" :value="subMajor.id">{{
                            subMajor.value
                            }}</option>
                        </select>
                    </div>
                    <p v-show="errors.has('form.sub_major')" class="help is-danger">{{errors.first('form.sub_major')
                        }}</p>
                    </div>
                </div>
                </div>
                <div class="column is-5">
                <div class="field">
                    <label class="label">Pendanaan</label>
                    <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.pendanaan') }">
                        <select name="pendanaan" class="select" v-model="funding" data-vv-as="pendanaan" v-validate="'required'"
                        data-vv-scope="form">
                        <option value="1">Personal</option>
                        <option value="2">Agency</option>
                        </select>
                    </div>
                    <p v-show="errors.has('form.pendanaan')" class="help is-danger">{{errors.first('form.pendanaan')
                        }}</p>
                    </div>
                </div>
                </div>
            </div>
            <div class="columns">
                <div class="column is-2">
                <label for="checkbox" class="checkbox">
                    <input type="checkbox" id="certificate" v-model="certificate">
                    Sertifikat
                </label>
                </div>
                <div class="column is-3">
                <label for="checkbox" class="checkbox">
                    <input type="checkbox" id="recognition" v-model="recognition">
                    Pengakuan
                </label>
                </div>
                <div class="column is-5" v-show="recognition">
                <div class="field">
                    <label class="label">Tanggal Pengakuan</label>
                    <div class="control">
                    <input id="recognition_date" data-display-mode="dialog" class="input" name="recognition_date" type="date"
                        placeholder="e.g 10-11-2018" v-model="recognitionDate" data-vv-as="recognition date"
                        v-bind:class="{ 'is-danger': errors.has('form.recognition_date')}" 
                        data-vv-scope="form">
                    </div>
                    <p v-show="errors.has('form.recognition_date')" class="help is-danger">
                    {{ errors.first('form.recognition_date') }}</p>
                </div>
                </div>                
            </div>
            </span>
            </section>
            <footer class="modal-card-foot">
                <div class="control  ">
                <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
                <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
                <button class="button is-danger" @click="closeFormModal()">Batal</button>
                </div>
            </footer>
            </div>    
    </div>
</template>
<script>
import { mapState } from 'vuex';
import VueAutosuggest from "vue-autosuggest";
import Vue from 'vue';
Vue.use(VueAutosuggest);
import moment from "moment";
export default {
    data() {
        return {
            objecIdentifier : null,
            company: null,            
            employee: null,          
            empolyeeName: '',
            empolyeePosition: '',
            empolyeeUnit: '',
            startDate: null,
            endDate: null,
            startEdu: null,
            endEdu: null,
            educationLevel: null,
            institution: null,
            faculty: null,
            major: null,
            subMajor: null,
            funding: null,
            certificate: null,
            recognition: null,
            recognitionDate: null,
            options: [{
                data: []
            }],
            filterEmployee: [],
            inputEmployee: {
                id: "autosuggest__input",
                name: "personnel_number",
                class: "input",
                onInputChange: this.getEmployee,
                placeholder: "Nomor Induk Karyawan"
            },
        }
    },
    created() {
        if(this.education.detail) this.getData()
        this.getParam();  
        

    },
    computed: {
        ...mapState(['EDUFC','EDUBR', 'EDUIN', 'EDULV', 'EDUMR','companies','education'])
    },    
    methods: {
        closeFormModal() {
            this.$parent.closeFormModal()
        },
        clearEmployee() {
          if (this.employee != null) {
            this.$refs.reference = '';
          }          
          this.filterEmployee = []
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';

          this.$nextTick(() => this.$validator.reset());
        },
        getParam(){
            this.$store.dispatch('EDUBR/getAll', {business_code:['*', this.company]});            
            this.$store.dispatch('EDUFC/getAll', {business_code:['*', this.company]});            
            this.$store.dispatch('EDUIN/getAll', {business_code:['*', this.company]});            
            this.$store.dispatch('EDULV/getAll', {business_code:['*', this.company]});            
            this.$store.dispatch('EDUMR/getAll', {business_code:['*', this.company]});                        
        },     
        getEmployee(text) {
          if (text === '' || text === undefined) {
            return;
          }
          this.$axios
            .get(
              "hcis/api/personals?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&business_code[]=" + this.company
            )
            .then(response => {
              this.options[0].data = [];
              response.data.data.forEach(async (employee, key) => {
                await this.options[0].data.push(
                  employee.personnel_number,
                );
              });

              const filteredData = this.options[0].data.filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

              this.filterEmployee = [{
                data: filteredData
              }];
            })
            .catch(e => {
              console.log(e);
            });
        },
        selectEmployee(option) {
          if (option == null) {
            this.employee = null;
            this.empolyeeName = '';
            this.empolyeeUnit = '';
            this.empolyeePosition = '';
          } else {
            this.employee = option.item;
            if (this.company == null) {
              swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
            } else {
              this.selfData(option.item);              
            }
          }
        },
        selfData(nik){
          this.$axios
                .get(
                  "hcis/api/organization-assignment?begin_date_lte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&end_date_gte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&personnel_number[]=" +
                  nik + "&business_code[]=" +this.company
                )
                .then(async response => {
                  this.empolyeeName = response.data.data[0].personnel_number.complete_name;
                  this.empolyeePosition = response.data.data[0].position.organization_name;
                  this.empolyeeUnit = response.data.data[0].unit.organization_name;
                })
                .catch(e => {
                  console.log(e);
                });
        },   
        getData() {
            this.objecIdentifier = this.education.detail.object_identifier                        
            this.startDate = this.education.detail.begin_date
            this.endDate = this.education.detail.end_date
            this.startEdu = this.education.detail.education_start
            this.endEdu = this.education.detail.education_end
            this.educationLevel = this.education.detail.level.id
            this.institution = this.education.detail.institution.id
            this.faculty = this.education.detail.faculty.id
            this.major = this.education.detail.department.id
            this.subMajor = this.education.detail.sub_department.id
            this.funding = this.education.detail.funding;
            (this.education.detail.certificate == 'y') ? this.certificate = true: null;
            (this.education.detail.recognition == 'y') ? this.recognition = true: null;         
            this.recognitionDate =this.education.detail.recognition_date
          
            this.company = this.education.detail.business_code.business_code
            this.employee = this.education.detail.personnel_number.personnel_number;
          
            this.selfData(this.employee)      
        },

        async storeData() {
            //alert('a')
            let isValid = await this.$validator.validateAll('form')
            if (!isValid) return false
            if (this.recognition == true) {
                this.recognition = 'y';
            } else {
                this.recognition = 'n';
            }
            if (this.certificate == true) {
                this.certificate = 'y';
            } else {
                this.certificate = 'n';
            }
            this.$axios.post('hcis/api/educations', {
                begin_date: this.startDate,
                end_date: this.endDate,
                business_code: this.company,
                personnel_number: this.employee,
                level: this.educationLevel,
                department: this.major,
                sub_department: this.subMajor,
                faculty: this.faculty,
                institution: this.institution,
                certificate: this.certificate,
                funding: this.funding,
                recognition: this.recognition,
                recognition_date: this.recognitionDate ||'9999-12-30',
                education_start: this.startEdu,
                education_end: this.endEdu
            })
            .then(() => {
                swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                //this.resetForm()
                this.closeFormModal()
                this.$store.dispatch('education/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll('form')
            if (!isValid) return false
            if (this.recognition == true) {
                this.recognition = 'y';
            } else {
                this.recognition = 'n';
            }
            if (this.certificate == true) {
                this.certificate = 'y';
            } else {
                this.certificate = 'n';
            }
            this.$axios.put('hcis/api/educations', {
                object_identifier: this.objecIdentifier,
                begin_date: this.startDate,
                end_date: this.endDate,
                business_code: this.company,
                personnel_number: this.employee,
                level: this.educationLevel,
                department: this.major,
                sub_department: this.subMajor,
                faculty: this.faculty,
                institution: this.institution,
                certificate: this.certificate,
                funding: this.funding,
                recognition: this.recognition,
                recognition_date: this.recognitionDate ||'9999-12-30',
                education_start: this.startEdu,
                education_end: this.endEdu
            })
            .then(() => {
                swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                //this.resetForm()
                this.closeFormModal();
                this.$store.dispatch('education/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },
     
    },
}

</script>
 <style>
    .has-background-danger {
      background-color: #6D6D6D !important;
    }

    .button.is-danger {
      background-color: #CE1000;
      border-color: transparent;
      color: #fff;
    }

    .autosuggest__results-container {
      position: relative;
      width: 100%;
    }

    .autosuggest__results {
      font-weight: 300;
      margin: 0;
      position: absolute;
      z-index: 10000001;
      width: 100%;
      border: 1px solid #e0e0e0;
      border-bottom-left-radius: 4px;
      border-bottom-right-radius: 4px;
      background: white;
      padding: 0px;
      overflow: scroll;
      max-height: 200px;
    }

    .autosuggest__results ul {
      list-style: none;
      padding-left: 0;
      margin: 0;
    }

    .autosuggest__results .autosuggest__results_item {
      cursor: pointer;
      padding: 15px;
    }

    #autosuggest ul:nth-child(1)>.autosuggest__results_title {
      border-top: none;
    }

    .autosuggest__results .autosuggest__results_title {
      color: gray;
      font-size: 11px;
      margin-left: 0;
      padding: 15px 13px 5px;
      border-top: 1px solid lightgray;
    }

    .autosuggest__results .autosuggest__results_item:active,
    .autosuggest__results .autosuggest__results_item:hover,
    .autosuggest__results .autosuggest__results_item:focus,
    .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
      background-color: #ddd;
    }

  </style>