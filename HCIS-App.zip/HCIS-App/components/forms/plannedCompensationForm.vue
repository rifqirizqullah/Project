<template>
  <section>
    <div class="modal-background" @click="closeFormModal()"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Rencana Renumerasi</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="getParam()" v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
              </div>
            </div>
          </div>
          <!-- <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Plan Version</label>
                <div class="control">
                  <input name="plan_version" class="input " placeholder="Plan Version" type="text" v-model="planVersion"
                    @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('form.plan_version')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.plan_version')" class="help is-danger">
                  {{ errors.first('form.plan_version') }}
                </p>
              </div>
            </div>
          </div> -->
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tipe Organisasi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.organization_type') }">
                    <select name="organization_type" v-model="organizationType" v-validate="'required'"
                      @change="getOrganization()" data-vv-as="organization type" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in ORGTY.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>

                    </select>
                  </div>
                  <p v-show="errors.has('form.organization_type')" class="help is-danger">{{errors.first('form.organization_type')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Organisasi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.short_text') }">
                    <select name="short_text" v-model="shortText" v-validate="'required'" data-vv-as="short text"
                      data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in organizationData.list" :key="i" :value="item.organization_code">
                        {{item.organization_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.short_text')" class="help is-danger">{{errors.first('form.short_text')
                    }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Personal Type</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personal_type') }">
                    <select name="personal_type" v-model="personalType" v-validate="'required'"
                      data-vv-as="personal type" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in PSTYP.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.personal_type')" class="help is-danger">{{errors.first('form.personal_type')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Personal Area</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personal_area') }">
                    <select name="personal_area" v-model="personalArea" v-validate="'required'"
                      data-vv-as="personal area" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in PSARE.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.personal_area')" class="help is-danger">{{errors.first('form.personal_area')
                    }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Personal Group 01</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personal_group1') }">
                    <select name="personal_group1" v-model="personalGroup01" v-validate="'required'"
                      data-vv-as="personal group 01" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in PRGRP.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.personal_group1')" class="help is-danger">{{errors.first('form.personal_group1')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Personal Group 02</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personal_group2') }">
                    <select name="personal_group2" v-model="personalGroup02" v-validate="'required'"
                      data-vv-as="personal group 02" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in PRGRP.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.personal_group2')" class="help is-danger">{{errors.first('form.personal_group2')
                    }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Personal Level 01</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personal_level1') }">
                    <select name="personal_level1" v-model="personalLevel01" v-validate="'required'"
                      data-vv-as="personal level 01" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in PSLVL.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.personal_level1')" class="help is-danger">{{errors.first('form.personal_level1')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Personal Level 02</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personal_level2') }">
                    <select name="personal_level2" v-model="personalLevel02" v-validate="'required'"
                      data-vv-as="personal level 02" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in PSLVL.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.personal_level2')" class="help is-danger">{{errors.first('form.personal_level2')
                    }}</p>
                </div>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  import moment from "moment";

  export default {
    data() {
      return {
        objecIdentifier: null,
        company: null,
        startDate: null,
        endDate: null,
        planVersion: null,
        organizationType: null,
        shortText: null,
        personalType: null,
        personalArea: null,
        personalGroup01: null,
        personalGroup02: null,
        personalLevel01: null,
        personalLevel02: null,
      }
    },
    created() {
      if (this.plannedCompensation.detail) this.getData()
      this.getParam();
      this.getOrganization();
    },
    computed: {
      ...mapState(['companies', 'plannedCompensation', 'ORGTY', 'organizationData', 'PSTYP', 'PSARE', 'PRGRP',
        'PSLVL'
      ])
    },
    methods: {
      getData() {
        this.objecIdentifier = this.plannedCompensation.detail.object_identifier;

        this.startDate = this.plannedCompensation.detail.begin_date;
        this.endDate = this.plannedCompensation.detail.end_date;
        this.planVersion = this.plannedCompensation.detail.plan_version;
        this.organizationType = this.plannedCompensation.detail.organization_type;
        this.shortText = this.plannedCompensation.detail.short_text;
        this.personalType = this.plannedCompensation.detail.personal_type;
        this.personalArea = this.plannedCompensation.detail.personal_area;
        this.personalGroup01 = this.plannedCompensation.detail.personal_group1;
        this.personalGroup02 = this.plannedCompensation.detail.personal_group2;
        this.personalLevel01 = this.plannedCompensation.detail.personal_level1;
        this.personalLevel02 = this.plannedCompensation.detail.personal_level2;

        this.company = this.plannedCompensation.detail.business_code.business_code;
      },
      getParam() {
        this.$store.dispatch('ORGTY/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('organizationData/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('PSTYP/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('PSARE/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('PRGRP/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('PSLVL/getAll', {
          business_code: ['*', this.company]
        });
      },
      getOrganization() {
        this.$store.dispatch('organizationData/getAll', {
          business_code: ['*', this.company],
          organization_type: [this.organizationType]
        });
      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('hcis/api/plannedcompensation', {
            begin_date: this.startDate,
            end_date: this.endDate,
            // plan_version: this.planVersion,
            plan_version: '01',
            organization_type: this.organizationType,
            short_text: this.shortText,
            personal_type: this.personalType,
            personal_area: this.personalArea,
            personal_group1: this.personalGroup01,
            personal_group2: this.personalGroup02,
            personal_level1: this.personalLevel01,
            personal_level2: this.personalLevel02,

            business_code: this.company,
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('plannedCompensation/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('hcis/api/plannedcompensation', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            // plan_version: this.planVersion,
            plan_version: '01',
            organization_type: this.organizationType,
            short_text: this.shortText,
            personal_type: this.personalType,
            personal_area: this.personalArea,
            personal_group1: this.personalGroup01,
            personal_group2: this.personalGroup02,
            personal_level1: this.personalLevel01,
            personal_level2: this.personalLevel02,

            business_code: this.company,
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('plannedCompensation/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.plannedCompensation.detail.object_identifier
        this.startDate = this.plannedCompensation.detail.begin_date;
        this.endDate = this.plannedCompensation.detail.end_date;
        this.planVersion = this.plannedCompensation.detail.plan_version;
        this.organizationType = this.plannedCompensation.detail.organization_type;
        this.shortText = this.plannedCompensation.detail.short_text.organization_code;
        this.personalType = this.plannedCompensation.detail.personal_type;
        this.personalArea = this.plannedCompensation.detail.personal_area;
        this.personalGroup01 = this.plannedCompensation.detail.personal_group1;
        this.personalGroup02 = this.plannedCompensation.detail.personal_group2;
        this.personalLevel01 = this.plannedCompensation.detail.personal_level1;
        this.personalLevel02 = this.plannedCompensation.detail.personal_level2;

        this.$validator.reset('form')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
