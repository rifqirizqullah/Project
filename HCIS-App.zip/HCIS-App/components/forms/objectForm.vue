<template>
  <section>
    <div class="modal-background" @click="closeFormModal()"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Objek</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="getParam()" v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
              </div>
            </div>
          </div>
          <!-- <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Plan Version</label>
                <div class="control">
                  <input name="plan_version" class="input " placeholder="Plan Version" type="text" v-model="planVersion"
                    @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('form.plan_version')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.plan_version')" class="help is-danger">
                  {{ errors.first('form.plan_version') }}
                </p>
              </div>
            </div>
          </div> -->
          <div class="columns">
            <div class="column" v-if="objecIdentifier == null">
              <div class="field">
                <label class="label">Objek ID</label>
                <div class="control">
                  <input name="short_text" class="input " placeholder="Objek ID" type="text" v-model="shortText"
                    v-bind:class="{ 'is-danger': errors.has('form.short_text')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.short_text')" class="help is-danger">
                  {{ errors.first('form.short_text') }}
                </p>
              </div>
            </div>
            <div class="column" v-else>
              <div class="field">
                <label class="label">Objek ID</label>
                <div class="control">
                  <input name="short_text" class="input " placeholder="Objek ID" type="text" v-model="shortText"
                    v-bind:class="{ 'is-danger': errors.has('form.short_text')}" v-validate="'required'"
                    data-vv-scope="form" disabled>
                </div>
                <p v-show="errors.has('form.short_text')" class="help is-danger">
                  {{ errors.first('form.short_text') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama Objek</label>
                <div class="control">
                  <input name="long_text" class="input " placeholder="Nama Objek" type="text" v-model="longText"
                    v-bind:class="{ 'is-danger': errors.has('form.long_text')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.long_text')" class="help is-danger">
                  {{ errors.first('form.long_text') }}
                </p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Deskripsi</label>
                <div class="control">
                  <textarea name="object_description" class="textarea" placeholder="Deskripsi" rows="5"
                    v-model="objectDescription" v-bind:class="{ 'is-danger': errors.has('object_description')}"
                    v-validate="'required'"></textarea>
                </div>
                <p v-show="errors.has('object_description')" class="help is-danger">
                  {{ errors.first('object_description')}}</p>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  import moment from "moment";

  export default {
    data() {
      return {
        objecIdentifier: null,
        company: null,
        startDate: null,
        endDate: null,
        planVersion: null,
        objectType: this.$route.query.otype,
        shortText: null,
        longText: '',
        objectDescription: '',
      }
    },
    created() {
      if (this.object.detail) this.getData()
      this.getParam();
    },
    computed: {
      ...mapState(['companies', 'object'])
    },
    methods: {
      getData() {
        this.objecIdentifier = this.object.detail.object_identifier;

        this.startDate = this.object.detail.begin_date;
        this.endDate = this.object.detail.end_date;
        this.planVersion = this.object.detail.plan_version;
        this.shortText = this.object.detail.id;
        this.longText = this.object.detail.value;
        this.objectDescription = this.object.detail.object_description;

        this.company = this.object.detail.business_code.business_code;
      },
      getParam() {

      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('ldap/api/objects', {
            begin_date: this.startDate,
            end_date: this.endDate,
            // plan_version: this.planVersion,
            plan_version: '01',
            object_type: this.objectType,
            short_text: this.shortText,
            long_text: this.longText,
            object_description: this.objectDescription,

            business_code: this.company,
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('object/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('ldap/api/objects', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            // plan_version: this.planVersion,
            plan_version: '01',
            object_type: this.objectType,
            short_text: this.shortText,
            long_text: this.longText,
            object_description: this.objectDescription,

            business_code: this.company,
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('object/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.object.detail.object_identifier;
        this.startDate = this.object.detail.begin_date;
        this.endDate = this.object.detail.end_date;
        this.planVersion = this.object.detail.plan_version;
        this.shortText = this.object.detail.id;
        this.longText = this.object.detail.value;
        this.objectDescription = this.object.detail.object_description;

        this.$validator.reset('form')
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
