<template>
  <section>
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Komponen Penghasilan</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="getParam()" v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tipe Komponen Penghasilan</label>
                <div class="control">
                  <input name="wage_type" class="input " placeholder="Tipe Komponen Penghasilan" type="text"
                    v-model="wageType" v-bind:class="{ 'is-danger': errors.has('form.wage_type')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.wage_type')" class="help is-danger"> {{ errors.first('form.wage_type') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama Komponen Penghasilan</label>
                <div class="control">
                  <input name="wage_name" class="input " placeholder="Nama Komponen Penghasilan" type="text"
                    v-model="wageName" v-bind:class="{ 'is-danger': errors.has('form.wage_name')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.wage_name')" class="help is-danger"> {{ errors.first('form.wage_name') }}
                </p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tipe Pajak</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.tax_type') }">
                    <select name="tax_type" class="select" v-model="taxType" data-vv-as="tax_type"
                      v-validate="'required'" data-vv-scope="form">
                      <option disabled selected>Choose</option>
                      <option v-for="(taxType, key) in TAXTY.list" :key="key" :value="taxType.object_code">{{
                            taxType.object_name
                            }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.tax_type')" class="help is-danger">{{errors.first('form.tax_type')
                        }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Referensi Tabel</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.reference_table') }">
                    <select name="reference_table" class="select" v-model="referenceTable" data-vv-as="reference_table"
                      v-validate="'required'" data-vv-scope="form">
                      <option disabled selected>Choose</option>
                      <option v-for="(referenceTable, key) in WGERF.list" :key="key" :value="referenceTable.object_code">{{
                            referenceTable.object_code
                            }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.reference_table')" class="help is-danger">{{errors.first('form.reference_table')
                        }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-4">
              <div class="field">
                <label for="checkbox" class="checkbox">
                  <input type="checkbox" name="flag_taxable" v-model="flagTaxable">
                  Flag Taxable
                </label>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label for="checkbox" class="checkbox">
                  <input type="checkbox" name="flag_deductible" v-model="flagDeductible">
                  Flag Deductible
                </label>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label for="checkbox" class="checkbox">
                  <input type="checkbox" name="flag_proportional" v-model="flagProportional">
                  Flag Propotional
                </label>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    data() {
      return {
        objecIdentifier: null,
        company: null,
        startDate: null,
        endDate: null,
        wageType: '',
        wageName: '',
        taxType: null,
        referenceTable: null,
        flagTaxable: null,
        flagDeductible: null,
        flagProportional: null
      }
    },
    created() {
      if (this.wage.detail) this.getData()
      this.getParam();
    },
    computed: {
      ...mapState(['companies', 'wage', 'TAXTY', 'WGERF'])
    },
    methods: {
      getData() {
        this.objecIdentifier = this.wage.detail.object_identifier;
        this.startDate = this.wage.detail.begin_date;
        this.endDate = this.wage.detail.end_date;
        this.wageType = this.wage.detail.wage_type;
        this.wageName = this.wage.detail.wage_name;
        this.taxType = this.wage.detail.tax_type.object_code;
        this.referenceTable = this.wage.detail.reference_table;
        (this.wage.detail.flag_taxable == 'y') ?
        this.flagTaxable = true: '';
        (this.wage.detail.flag_deductible == 'y') ? this.flagDeductible = true: '';
        (this.wage.detail.flag_proportional == 'y') ? this.flagProportional = true: '';
        this.company = this.wage.detail.business_code.business_code;
      },
      getParam() {
        this.$store.dispatch('TAXTY/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('WGERF/getAll', {
          business_code: ['*', this.company]
        });
      },
      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        if (this.flagTaxable == true) {
          this.flagTaxable = 'y';
        } else {
          this.flagTaxable = 'n';
        }
        if (this.flagDeductible == true) {
          this.flagDeductible = 'y';
        } else {
          this.flagDeductible = 'n';
        }
        if (this.flagProportional == true) {
          this.flagProportional = 'y';
        } else {
          this.flagProportional = 'n';
        }
        this.$axios.post('hcis/api/wage', {
            begin_date: this.startDate,
            end_date: this.endDate,
            wage_type: this.wageType,
            wage_name: this.wageName,
            tax_type: this.taxType,
            reference_table: this.referenceTable,
            flag_taxable: this.flagTaxable,
            flag_deductible: this.flagDeductible,
            flag_proportional: this.flagProportional,
            business_code: this.company,
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('wage/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        if (this.flagTaxable == true) {
          this.flagTaxable = 'y';
        } else {
          this.flagTaxable = 'n';
        }
        if (this.flagDeductible == true) {
          this.flagDeductible = 'y';
        } else {
          this.flagDeductible = 'n';
        }
        if (this.flagProportional == true) {
          this.flagProportional = 'y';
        } else {
          this.flagProportional = 'n';
        }
        this.$axios.put('hcis/api/wage', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            wage_type: this.wageType,
            wage_name: this.wageName,
            tax_type: this.taxType,
            reference_table: this.referenceTable,
            flag_taxable: this.flagTaxable,
            flag_deductible: this.flagDeductible,
            flag_proportional: this.flagProportional,
            business_code: this.company,
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('wage/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.wage.detail.object_identifier
        this.startDate = this.wage.detail.begin_date
        this.endDate = this.wage.detail.end_date
        this.wageType = this.wage.detail.wage_type
        this.wageName = this.wage.detail.wage_name
        this.taxType = this.wage.detail.tax_type.id
        this.referenceTable = this.wage.detail.reference_table
        this.flagTaxable = this.wage.detail.flag_taxable
        this.flagDeductible = this.wage.detail.flag_deductible
        this.flagProportional = this.wage.detail.flag_proportional
        this.$validator.reset('form')
      },
    },
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }
  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }
  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }
  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }
  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }
  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }
  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }
  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }
  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }
</style>
