<template>
  <section>
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Identitas Keluarga Karyawan</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                    v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                    class="is-link">Ubah</a></label>
                <div class="control" v-if="employee == null">
                  <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                    @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                    v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                  </vue-autosuggest>
                </div>
                <div class="control" v-else>
                  <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                    v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                    v-validate="'required'" disabled>
                </div>
                <p v-show="errors.has('personnel_number')" class="help is-danger">
                  {{ errors.first('personnel_number') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama</label>
                <div class="control">
                  <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                    v-validate="'required'" disabled>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Posisi Saat Ini</label>
                <div class="control">
                  <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                    v-model="empolyeePosition" v-validate="'required'" disabled>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Unit Saat Ini</label>
                <div class="control">
                  <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                    v-validate="'required'" disabled>
                </div>
              </div>
            </div>
          </div>
          <hr>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Hubungan Keluarga</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_type') }">
                    <select name="family_type" class="select" v-model="familyType" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in FAMTY.list" :key="key" :value="item.object_code">
                        {{ item.object_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('family_type')" class="help is-danger">{{ errors.first('family_type') }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Urutan Keluarga</label>
                <div class="control">
                  <input name="familyNumber" class="input" placeholder="Urutan Keluarga" type="text"
                    v-model="familyNumber" @keypress="onlyNumber"
                    v-bind:class="{ 'is-danger': errors.has('familyNumber')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('familyNumber')" class="help is-danger">{{ errors.first('familyNumber') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tipe Identitas</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('identificationType') }">
                    <select name="identificationType" class="select" v-model="identificationType"
                      v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in IDTYP.list" :key="key" :value="item.object_code">{{ item.object_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('identificationType')" class="help is-danger">
                    {{ errors.first('identificationType') }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nomor Identitas</label>
                <div class="control">
                  <input name="identification_number" class="input" placeholder="Nomor Identitas" type="text"
                    v-model="identificationNumber" @keypress="onlyNumber"
                    v-bind:class="{ 'is-danger': errors.has('identification_number')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('identification_number')" class="help is-danger">
                  {{ errors.first('identification_number') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Terbit Identitas</label>
                <div class="control">
                  <input id="date_issue" data-display-mode="dialog" class="input" name="date_issue" type="date"
                    placeholder="e.g 10-11-2018" v-model="dateIssue" data-vv-as="Issue date"
                    v-bind:class="{ 'is-danger': errors.has('date_issue')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('date_issue')" class="help is-danger">{{ errors.first('date_issue') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Berakhir Identitas</label>
                <div class="control">
                  <input id="expire_date" data-display-mode="dialog" class="input" name="expire_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="expireDate" data-vv-as="Expire date"
                    v-bind:class="{ 'is-danger': errors.has('expire_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('expire_date')" class="help is-danger">{{ errors.first('expire_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tempat Dikeluarkan Identitas</label>
                <div class="control">
                  <input name="place_issue" class="input" placeholder="Tempat Dikeluarkan Identitas" type="text"
                    v-model="placeIssue" v-bind:class="{ 'is-danger': errors.has('place_issue')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('place_issue')" class="help is-danger">{{ errors.first('place_issue') }}</p>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import {
    VueAutosuggest
  } from "vue-autosuggest";
  import moment from "moment";

  export default {
    components: {
      VueAutosuggest
    },
    data() {
      return {
        objecIdentifier: null,
        company: null,
        employee: null,
        empolyeeName: '',
        empolyeePosition: '',
        empolyeeUnit: '',
        startDate: null,
        endDate: null,
        familyType: null,
        familyNumber: null,
        identificationType: null,
        identificationNumber: null,
        dateIssue: null,
        expireDate: null,
        placeIssue: "",

        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,
      }
    },
    created() {
      if (this.familyIdentity.detail) this.getData()
      this.getParam();
    },
    computed: {
      ...mapState(['companies', 'familyIdentity', 'FAMTY', 'IDTYP'])
    },
    methods: {
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployeeData(nik) {
        this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      clearEmployee() {
        if (this.employee != null) {
          this.$refs.reference = '';
        }
        this.filterEmployee = []
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeeUnit = '';
        this.empolyeePosition = '';

        this.$nextTick(() => this.$validator.reset());
      },

      getData() {
        this.objecIdentifier = this.familyIdentity.detail.object_identifier;

        this.startDate = this.familyIdentity.detail.begin_date;
        this.endDate = this.familyIdentity.detail.end_date;
        this.familyType = this.familyIdentity.detail.family_type.id;
        this.familyNumber = this.familyIdentity.detail.family_number;
        this.identificationType = this.familyIdentity.detail.identification_type.id;
        this.identificationNumber = this.familyIdentity.detail.identification_number;
        this.dateIssue = this.familyIdentity.detail.date_issue;
        this.expireDate = this.familyIdentity.detail.expire_date;
        this.placeIssue = this.familyIdentity.detail.place_issue;

        this.company = this.familyIdentity.detail.business_code.business_code;
        this.employee = this.familyIdentity.detail.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.$store.dispatch('FAMTY/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('IDTYP/getAll', {
          business_code: ['*', this.company]
        });
      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('hcis/api/familyidentification', {
            begin_date: this.startDate,
            end_date: this.endDate,
            family_type: this.familyType,
            family_number: this.familyNumber,
            identification_type: this.identificationType,
            identification_number: this.identificationNumber,
            date_issue: this.dateIssue,
            expire_date: this.expireDate,
            place_issue: this.placeIssue,

            business_code: this.company,
            personnel_number: this.employee
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('familyIdentity/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('hcis/api/familyidentification', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            family_type: this.familyType,
            family_number: this.familyNumber,
            identification_type: this.identificationType,
            identification_number: this.identificationNumber,
            date_issue: this.dateIssue,
            expire_date: this.expireDate,
            place_issue: this.placeIssue,

            business_code: this.company,
            personnel_number: this.employee
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('familyIdentity/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.familyIdentity.detail.object_identifier;

        this.startDate = this.familyIdentity.detail.begin_date;
        this.endDate = this.familyIdentity.detail.end_date;
        this.familyType = this.familyIdentity.detail.family_type.id;
        this.familyNumber = this.familyIdentity.detail.family_number;
        this.communicationType = this.familyIdentity.detail.communication_type.id;
        this.serialNumber = this.familyIdentity.detail.serial_number;
        this.communicationNumber = this.familyIdentity.detail.communication_number;

        this.company = this.familyIdentity.detail.business_code.business_code;
        this.employee = this.familyIdentity.detail.personnel_number.personnel_number;

        this.$validator.reset('form')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
