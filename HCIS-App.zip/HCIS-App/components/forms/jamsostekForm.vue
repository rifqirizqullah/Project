<template>
    <div class="">
        <div class="modal-background"></div>            
        <div class="modal-card">
          <header class="modal-card-head">
            <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Jamsostek</p>
            <button @click="closeFormModal()" class="delete" aria-label="close"></button>
          </header>
          <section class="modal-card-body">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nama Perusahaan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                      <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                        v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                          {{ company.company_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                  </div>                  
                </div>
              </div>
            </div>
            <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                      class="is-link">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
                <div class="column is-4">
                <div class="field">
                    <label class="label">Nomor BPJS Tenaga Kerja</label>
                    <div class="control">
                    <input name="bpjs_number" class="input " placeholder="" type="text" v-model="bpjsNumber"
                        v-bind:class="{ 'is-danger': errors.has('bpjs_number')}" v-validate="'required'">
                    </div>
                    <p v-show="errors.has('bpjs_number')" class="help is-danger"> {{ errors.first('bpjs_number')
                    }}</p>
                </div>
                </div>
                <div class="column is-4">
                <div class="field">
                    <label class="label">Tanggal BPJS</label>
                    <div class="control">
                    <input id="bpjs_date" data-display-mode="dialog" class="input" name="bpjs_date" type="date"
                        placeholder="e.g 10-11-2018" v-model="bpjsDate" data-vv-as="bpjs date"
                        v-bind:class="{ 'is-danger': errors.has('bpjs_date')}" v-validate="'required'">
                    </div>
                    <p v-show="errors.has('bpjs_date')" class="help is-danger">{{ errors.first('bpjs_date') }}</p>
                </div>
                </div>
                <div class="column is-4">
                <br>
                <label for="checkbox" class="checkbox">
                    <input type="checkbox" id="recognition" v-model="flagMarried">
                    Sudah menikah
                </label>
                </div>
            </div>
          </span>
            </section>
            <footer class="modal-card-foot">
                <div class="control  ">
                <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
                <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
                <button class="button is-danger" @click="closeFormModal()">Batal</button>
                </div>
            </footer>
            </div>    
    </div>
</template>
<script>
import { mapState } from 'vuex';
import VueAutosuggest from "vue-autosuggest";
import Vue from 'vue';
Vue.use(VueAutosuggest);
import moment from "moment";
export default {
    data() {
        return {
            objecIdentifier : null,
            company: null,            
            employee: null,          
            empolyeeName: '',
            empolyeePosition: '',
            empolyeeUnit: '',
            startDate: null,
            endDate: null,
            bpjsNumber: null,
            bpjsDate: null,
            flagMarried: null,            
            options: [{
                data: []
            }],
            filterEmployee: [],
            inputEmployee: {
                id: "autosuggest__input",
                name: "personnel_number",
                class: "input",
                onInputChange: this.getEmployee,
                placeholder: "Nomor Induk Karyawan"
            },
        }
    },
    created() {
        if(this.jamsostek.detail) this.getData()  
        this.getParam();      
    },
    computed: {
        ...mapState(['companies','jamsostek'])
    },    
    methods: {
        closeFormModal() {
            this.$parent.closeFormModal()
        },
        clearEmployee() {
          if (this.employee != null) {
            this.$refs.reference = '';
          }          
          this.filterEmployee = []
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';

          this.$nextTick(() => this.$validator.reset());
        },        
        getParam(){
            // this.$store.dispatch('INSTY/getAll', {business_code:['*', this.company]});            
        },   
        getEmployee(text) {
          if (text === '' || text === undefined) {
            return;
          }
          this.$axios
            .get(
              "hcis/api/personals?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&business_code[]=" + this.company
            )
            .then(response => {
              this.options[0].data = [];
              response.data.data.forEach(async (employee, key) => {
                await this.options[0].data.push(
                  employee.personnel_number,
                );
              });

              const filteredData = this.options[0].data.filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

              this.filterEmployee = [{
                data: filteredData
              }];
            })
            .catch(e => {
              console.log(e);
            });
        },
        selectEmployee(option) {
          if (option == null) {
            this.employee = null;
            this.empolyeeName = '';
            this.empolyeeUnit = '';
            this.empolyeePosition = '';
          } else {
            this.employee = option.item;
            if (this.company == null) {
              swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
            } else {
              this.selfData(option.item);              
            }
          }
        },
        selfData(nik){
          this.$axios
                .get(
                  "hcis/api/organization-assignment?begin_date_lte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&end_date_gte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&personnel_number[]=" +
                  nik + "&business_code[]=" +this.company
                )
                .then(async response => {
                  this.empolyeeName = response.data.data[0].personnel_number.complete_name;
                  this.empolyeePosition = response.data.data[0].position.organization_name;
                  this.empolyeeUnit = response.data.data[0].unit.organization_name;
                })
                .catch(e => {
                  console.log(e);
                });
        },   
        getData() {
            this.objecIdentifier = this.jamsostek.detail.object_identifier                        
            this.startDate = this.jamsostek.detail.begin_date
            this.endDate = this.jamsostek.detail.end_date
            this.bpjsNumber= this.jamsostek.detail.id
            this.bpjsDate= this.jamsostek.detail.issue_date;
            (this.jamsostek.detail.jamsostek_married_status == 'y') ? this.flagMarried = true: '';
            this.company = this.jamsostek.detail.business_code.business_code
            this.employee = this.jamsostek.detail.personnel_number.personnel_number;
          
            this.selfData(this.employee)        
        },

        async storeData() {
            let isValid = await this.$validator.validateAll()
            if (!isValid) return false
            if (this.flagMarried == true) {
                this.flagMarried = 'y';
            } else {
                this.flagMarried = 'n';
            }
            this.$axios.post('hcis/api/jamsosteks', {
                begin_date: this.startDate,
                end_date: this.endDate,
                business_code: this.company,
                personnel_number: this.employee,
                id: this.bpjsNumber,
                issue_date: this.bpjsDate,
                jamsostek_married_status: this.flagMarried,
            })
            .then(() => {
                swal(
                    'Saved!',
                    'Successfully saved data.',
                    'success'
                )
                //this.resetForm()
                this.closeFormModal()
                this.$store.dispatch('jamsostek/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        async updateData() {
            let isValid = await this.$validator.validateAll()
            if (!isValid) return false
            if (this.flagMarried == true) {
                this.flagMarried = 'y';
            } else {
                this.flagMarried = 'n';
            }
            this.$axios.put('hcis/api/jamsosteks', {
                object_identifier: this.objecIdentifier,
                begin_date: this.startDate,
                end_date: this.endDate,
                business_code: this.company,
                personnel_number: this.employee,
                id: this.bpjsNumber,
                issue_date: this.bpjsDate,
                jamsostek_married_status: this.flagMarried,
            })
            .then(() => {
                swal(
                    'Updated!',
                    'Successfully update data.',
                    'success'
                )
                //this.resetForm()
                this.closeFormModal();
                this.$store.dispatch('jamsostek/getAll');
            })
            .catch(err => {
                console.log(err.response);
            })
        },

        resetForm() {
            this.objecIdentifier = this.asuransi.detail.object_identifier                        
            this.startDate = this.asuransi.detail.begin_date
            this.endDate = this.asuransi.detail.end_date
            this.insuranceType= this.asuransi.detail.insurance_type.id
            this.insuranceNumber= this.asuransi.detail.insurance_number
            this.insuranceCompany= this.asuransi.detail.insurance_company
            this.amountEmployer= this.asuransi.detail.amount_paid_employer.substring(0 ,this.asuransi.detail.amount_paid_employer.length -3);
            this.amountEmployee= this.asuransi.detail.amount_paid_employee.substring(0 ,this.asuransi.detail.amount_paid_employee.length -3);
            this.percentEmployer= this.asuransi.detail.percent_paid_employer.substring(0 ,this.asuransi.detail.percent_paid_employer.length -3);
            this.percentEmployee= this.asuransi.detail.percent_paid_employee.substring(0 ,this.asuransi.detail.percent_paid_employee.length -3);

            this.$validator.reset('form')
        },


    },
}

</script>
 <style>
    .has-background-danger {
      background-color: #6D6D6D !important;
    }

    .button.is-danger {
      background-color: #CE1000;
      border-color: transparent;
      color: #fff;
    }

    .autosuggest__results-container {
      position: relative;
      width: 100%;
    }

    .autosuggest__results {
      font-weight: 300;
      margin: 0;
      position: absolute;
      z-index: 10000001;
      width: 100%;
      border: 1px solid #e0e0e0;
      border-bottom-left-radius: 4px;
      border-bottom-right-radius: 4px;
      background: white;
      padding: 0px;
      overflow: scroll;
      max-height: 200px;
    }

    .autosuggest__results ul {
      list-style: none;
      padding-left: 0;
      margin: 0;
    }

    .autosuggest__results .autosuggest__results_item {
      cursor: pointer;
      padding: 15px;
    }

    #autosuggest ul:nth-child(1)>.autosuggest__results_title {
      border-top: none;
    }

    .autosuggest__results .autosuggest__results_title {
      color: gray;
      font-size: 11px;
      margin-left: 0;
      padding: 15px 13px 5px;
      border-top: 1px solid lightgray;
    }

    .autosuggest__results .autosuggest__results_item:active,
    .autosuggest__results .autosuggest__results_item:hover,
    .autosuggest__results .autosuggest__results_item:focus,
    .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
      background-color: #ddd;
    }

  </style>