<template>
  <section>
    <div class="modal-background" @click="closeFormModal()"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Area Bisnis</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="getParam()" v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
              </div>
            </div>
          </div>
          <!-- <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Plan Version</label>
                <div class="control">
                  <input name="plan_version" class="input " placeholder="Plan Version" type="text" v-model="planVersion"
                    @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('form.plan_version')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.plan_version')" class="help is-danger">
                  {{ errors.first('form.plan_version') }}
                </p>
              </div>
            </div>
          </div> -->
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tipe Organisasi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.organization_type') }">
                    <select name="organization_type" v-model="organizationType" v-validate="'required'"
                      @change="getOrganization()" data-vv-as="organization type" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in ORGTY.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.organization_type')" class="help is-danger">{{errors.first('form.organization_type')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Organisasi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.organization') }">
                    <select name="organization" v-model="organizationName" v-validate="'required'"
                      data-vv-as="organization" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in organizationData.list" :key="i" :value="item.organization_code">
                        {{item.organization_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.organization')" class="help is-danger">{{errors.first('form.organization')
                    }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Payroll Area</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.payroll_area') }">
                    <select name="payroll_area" v-model="payrollNumber" v-validate="'required'"
                      data-vv-as="payroll area" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in payrollArea.list" :key="i" :value="item.payroll_area">
                        {{item.payroll_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.payroll_area')" class="help is-danger">{{errors.first('form.payroll_area')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Bisnis Area</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.business_area') }">
                    <select name="business_area" v-model="businessArea" v-validate="'required'"
                      data-vv-as="business area" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in BUSAR.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.business_area')" class="help is-danger">{{errors.first('form.business_area')
                    }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Personal Area</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personnel_area') }">
                    <select name="personnel_area" v-model="personnelArea" v-validate="'required'"
                      data-vv-as="personnel area" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in PRSAR.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.personnel_area')" class="help is-danger">{{errors.first('form.personnel_area')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Personal Sub Area</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personnel_subarea') }">
                    <select name="personnel_subarea" v-model="personnelSubArea" v-validate="'required'"
                      data-vv-as="personnel sub area" data-vv-scope="form">
                      <option disabled="disabled" selected>Choose</option>
                      <option v-for="(item, i) in CITY.list" :key="i" :value="item.object_code">
                        {{item.object_name}}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.personnel_subarea')" class="help is-danger">{{errors.first('form.personnel_subarea')
                    }}</p>
                </div>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import {
    VueAutosuggest
  } from "vue-autosuggest";
  import moment from "moment";

  export default {
    components: {
      VueAutosuggest
    },
    data() {
      return {
        objecIdentifier: null,
        company: null,
        startDate: null,
        endDate: null,
        planVersion: null,
        organizationType: null,
        organizationName: null,
        payrollNumber: null,
        businessArea: null,
        personnelArea: null,
        personnelSubArea: null
      }
    },
    created() {
      if (this.accountAssignment.detail) this.getData()
      this.getParam();
      this.getOrganization();
    },
    computed: {
      ...mapState(['companies', 'accountAssignment', 'ORGTY', 'organizationData', 'payrollArea', 'BUSAR', 'PRSAR',
        'CITY'
      ])
    },
    methods: {
      getData() {
        this.objecIdentifier = this.accountAssignment.detail.object_identifier;

        this.startDate = this.accountAssignment.detail.begin_date;
        this.endDate = this.accountAssignment.detail.end_date;
        this.planVersion = this.accountAssignment.detail.plan_version;
        this.organizationType = this.accountAssignment.detail.organization_type;
        this.organizationName = this.accountAssignment.detail.organization;
        this.payrollNumber = this.accountAssignment.detail.payroll_area;
        this.businessArea = this.accountAssignment.detail.business_area;
        this.personnelArea = this.accountAssignment.detail.personnel_area;
        this.personnelSubArea = this.accountAssignment.detail.personnel_subarea;

        this.company = this.accountAssignment.detail.business_code.business_code;
      },
      getParam() {
        this.$store.dispatch('ORGTY/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('organizationData/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('payrollArea/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('BUSAR/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('PRSAR/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('CITY/getAll', {
          business_code: ['*', this.company]
        });
      },
      getOrganization() {
        this.$store.dispatch('organizationData/getAll', {
          business_code: ['*', this.company],
          organization_type: [this.organizationType]
        });
      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('hcis/api/accountassignment', {
            begin_date: this.startDate,
            end_date: this.endDate,
            // plan_version: this.planVersion,
            plan_version: '01',
            organization_type: this.organizationType,
            organization: this.organizationName,
            payroll_area: this.payrollNumber,
            business_area: this.businessArea,
            personnel_area: this.personnelArea,
            personnel_subarea: this.personnelSubArea,

            business_code: this.company,
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('accountAssignment/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('hcis/api/accountassignment', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            // plan_version: this.planVersion,
            plan_version: '01',
            organization_type: this.organizationType,
            organization: this.organizationName,
            payroll_area: this.payrollNumber,
            business_area: this.businessArea,
            personnel_area: this.personnelArea,
            personnel_subarea: this.personnelSubArea,

            business_code: this.company,
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('accountAssignment/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.accountAssignment.detail.object_identifier
        this.startDate = this.accountAssignment.detail.begin_date;
        this.endDate = this.accountAssignment.detail.end_date;
        this.planVersion = this.accountAssignment.detail.plan_version;
        this.organizationType = this.accountAssignment.detail.organization_type.object_code;
        this.organizationName = this.accountAssignment.detail.organization;
        this.payrollNumber = this.accountAssignment.detail.payroll_area.payroll_area;
        this.businessArea = this.accountAssignment.detail.business_area.object_code;
        this.personnelArea = this.accountAssignment.detail.personnel_area.object_code;
        this.personnelSubArea = this.accountAssignment.detail.personnel_subarea.object_code;

        this.$validator.reset('form')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
