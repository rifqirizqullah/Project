<template>
  <section>
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Sertifikasi</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                    v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                    class="is-link">Ubah</a></label>
                <div class="control" v-if="employee == null">
                  <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                    @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                    v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                  </vue-autosuggest>
                </div>
                <div class="control" v-else>
                  <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                    v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                    v-validate="'required'" disabled>
                </div>
                <p v-show="errors.has('personnel_number')" class="help is-danger">
                  {{ errors.first('personnel_number') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama</label>
                <div class="control">
                  <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                    v-validate="'required'" disabled>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Posisi Saat Ini</label>
                <div class="control">
                  <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                    v-model="empolyeePosition" v-validate="'required'" disabled>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Unit Saat Ini</label>
                <div class="control">
                  <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                    v-validate="'required'" disabled>
                </div>
              </div>
            </div>
          </div>
          <hr>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Dikeluarkan</label>
                <div class="control">
                  <input id="date_issue" data-display-mode="dialog" class="input" name="date_issue" type="date"
                    placeholder="e.g 10-11-2018" v-model="certificationStart" data-vv-as="Certification Date"
                    v-bind:class="{ 'is-danger': errors.has('date_issue')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('date_issue')" class="help is-danger">
                  {{ errors.first('date_issue') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Kadaluarsa</label>
                <div class="control">
                  <input id="expire_date" data-display-mode="dialog" class="input" name="expire_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="certificationFinish" data-vv-as="Expire Date"
                    v-bind:class="{ 'is-danger': errors.has('expire_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('expire_date')" class="help is-danger">
                  {{ errors.first('expire_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-4">
              <div class="field">
                <label class="label">Nomor Sertifikat</label>
                <div class="control">
                  <input name="certificate_number" class="input " placeholder="Nomor Sertifikat" type="text"
                    v-model="certificateNumber" @keypress="onlyNumber"
                    v-bind:class="{ 'is-danger': errors.has('certificate_number')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('certificate_number')" class="help is-danger">
                  {{ errors.first('certificate_number') }}
                </p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Nama Sertifikat</label>
                <div class="control">
                  <input name="certificate_name" class="input " placeholder="Nama Sertifikat" type="text"
                    v-model="certificateName" v-bind:class="{ 'is-danger': errors.has('certificate_name')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('certificate_name')" class="help is-danger">
                  {{ errors.first('certificate_name') }}
                </p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Tipe Sertifikat</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('certificateType') }">
                    <select name="certificateType" class="select" v-model="certificateType" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in CRTTY.list" :key="key" :value="item.object_code">
                        {{ item.object_name }}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('certificateType')" class="help is-danger">
                    {{ errors.first('certificateType') }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-4">
              <div class="field">
                <label class="label">Nama/Badan Sertifikasi</label>
                <div class="control">
                  <input name="institution" class="input " placeholder="Nama/ Badan Sertifikasi" type="text"
                    v-model="institution" v-bind:class="{ 'is-danger': errors.has('institution')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('institution')" class="help is-danger">
                  {{ errors.first('institution') }}
                </p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Kelas</label>
                <div class="control">
                  <input name="certificate_class" class="input " placeholder="Kelas" type="text"
                    v-model="certificateClass" v-bind:class="{ 'is-danger': errors.has('certificate_class')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('certificate_class')" class="help is-danger">
                  {{ errors.first('certificate_class') }}
                </p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Stream</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('stream') }">
                    <select name="stream" class="select" v-model="stream" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in STREM.list" :key="key" :value="item.object_code">
                        {{ item.object_name }}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('stream')" class="help is-danger">
                    {{ errors.first('stream') }}</p>
                </div>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import {
    VueAutosuggest
  } from "vue-autosuggest";
  import moment from "moment";

  export default {
    components: {
      VueAutosuggest
    },
    data() {
      return {
        objecIdentifier: null,
        company: null,
        employee: null,
        empolyeeName: '',
        empolyeePosition: '',
        empolyeeUnit: '',
        startDate: null,
        endDate: null,
        certificationStart: null,
        certificationFinish: null,
        certificateNumber: null,
        certificateName: '',
        certificateType: null,
        institution: '',
        certificateClass: '',
        stream: null,

        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,
      }
    },
    created() {
      if (this.certification.detail) this.getData()
      this.getParam();
    },
    computed: {
      ...mapState(['companies', 'certification', 'CRTTY', 'STREM'])
    },
    methods: {
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployeeData(nik) {
        this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      clearEmployee() {
        if (this.employee != null) {
          this.$refs.reference = '';
        }
        this.filterEmployee = []
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeeUnit = '';
        this.empolyeePosition = '';

        this.$nextTick(() => this.$validator.reset());
      },

      getData() {
        this.objecIdentifier = this.certification.detail.object_identifier;

        this.startDate = this.certification.detail.begin_date;
        this.endDate = this.certification.detail.end_date;
        this.certificationStart = this.certification.detail.date_issue;
        this.certificationFinish = this.certification.detail.expire_date;
        this.certificateNumber = this.certification.detail.certificate_number;
        this.certificateName = this.certification.detail.certificate_name;
        this.certificateType = this.certification.detail.certificate_type.object_code;
        this.institution = this.certification.detail.institution;
        this.certificateClass = this.certification.detail.certificate_class;
        this.stream = this.certification.detail.stream.object_code;

        this.company = this.certification.detail.business_code.business_code;
        this.employee = this.certification.detail.personnel_number;

        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.$store.dispatch('CRTTY/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('STREM/getAll', {
          business_code: ['*', this.company]
        });
      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('hcis/api/sertifikasi', {
            begin_date: this.startDate,
            end_date: this.endDate,
            date_issue: this.certificationStart,
            expire_date: this.certificationFinish,
            certificate_number: this.certificateNumber,
            certificate_name: this.certificateName,
            certificate_type: this.certificateType,
            institution: this.institution,
            certificate_class: this.certificateClass,
            stream: this.stream,

            business_code: this.company,
            personnel_number: this.employee
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('certification/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('hcis/api/sertifikasi', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            date_issue: this.certificationStart,
            expire_date: this.certificationFinish,
            certificate_number: this.certificateNumber,
            certificate_name: this.certificateName,
            certificate_type: this.certificateType,
            institution: this.institution,
            certificate_class: this.certificateClass,
            stream: this.stream,

            business_code: this.company,
            personnel_number: this.employee
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('certification/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.certification.detail.object_identifier;

        this.startDate = this.certification.detail.begin_date;
        this.endDate = this.certification.detail.end_date;
        this.certificationStart = this.certification.detail.date_issue;
        this.certificationFinish = this.certification.detail.expire_date;
        this.certificateNumber = this.certification.detail.certificate_number;
        this.certificateName = this.certification.detail.certificate_name;
        this.certificateType = this.certification.detail.certificate_type.id;
        this.institution = this.certification.detail.institution;
        this.certificateClass = this.certification.detail.certificate_class;
        this.stream = this.certification.detail.stream.id;

        this.company = this.certification.detail.business_code.business_code;
        this.employee = this.certification.detail.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);

        this.$validator.reset('form')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
