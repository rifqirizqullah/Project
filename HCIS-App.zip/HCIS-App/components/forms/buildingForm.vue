<template>
  <section>
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Gedung</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="getParam()" v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Kode Gedung</label>
                <div class="control">
                  <input name="build_code" class="input " placeholder="Kode Gedung" type="text" v-model="buildCode"
                    v-bind:class="{ 'is-danger': errors.has('form.build_code')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.build_code')" class="help is-danger"> {{ errors.first('form.build_code') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama Gedung</label>
                <div class="control">
                  <input name="build_name" class="input " placeholder="Nama Gedung" type="text" v-model="buildName"
                    v-bind:class="{ 'is-danger': errors.has('form.build_name')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.build_name')" class="help is-danger"> {{ errors.first('form.build_name') }}
                </p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Alamat</label>
                <div class="control">
                  <textarea name="street" class="textarea" placeholder="Alamat Lengkap" rows="5" v-model="street"
                    v-bind:class="{ 'is-danger': errors.has('form.street')}" v-validate="'required'"
                    data-vv-scope="form"></textarea>
                </div>
                <p v-show="errors.has('form.street')" class="help is-danger"> {{ errors.first('form.street')}}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Lokasi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.location') }">
                    <select name="location" class="select" v-model="location" data-vv-as="location"
                      v-validate="'required'" data-vv-scope="form">
                      <option disabled selected>Choose</option>
                      <option v-for="(location, key) in LOCID.list" :key="key" :value="location.object_code">{{
                            location.object_name
                            }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.location')" class="help is-danger">{{errors.first('form.location')
                        }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Negara <a v-if="country != null" @click="country = null"
                    class="is-link">Ubah</a></label>
                <div class="control" v-if="country == null">
                  <vue-autosuggest name="country" :suggestions="filterCountry" @selected="selectCountry" :limit="10"
                    :get-suggestion-value="getSuggestionValue" :input-props="inputCountry"
                    v-bind:class="{ 'is-danger': errors.has('form.country')}" v-validate="'required'"
                    data-vv-scope="form">
                    <div slot-scope="{suggestion}" style="display: flex; align-items: center;">
                      <div style="{ display: 'flex', color: 'navyblue'}">{{suggestion.item.value}}</div>
                    </div>
                  </vue-autosuggest>
                </div>
                <div class="control" v-else>
                  <input name="country" class="input" placeholder="Negara" type="text" v-model="country"
                    v-bind:class="{ 'is-danger': errors.has('form.country')}" v-validate="'required'"
                    data-vv-scope="form" disabled>
                </div>
                <p v-show="errors.has('form.country')" class="help is-danger">{{ errors.first('form.country') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Provinsi <a v-if="province != null" @click="province = null"
                    class="is-link">Ubah</a></label>
                <div class="control" v-if="province == null">
                  <vue-autosuggest name="province" :suggestions="filterProvince" @selected="selectProvince" :limit="10"
                    :input-props="inputProvince" v-bind:class="{ 'is-danger': errors.has('form.province')}"
                    v-validate="'required'" data-vv-scope="form">
                  </vue-autosuggest>
                </div>
                <div class="control" v-else>
                  <input name="province" class="input" placeholder="Provinsi" type="text" v-model="province"
                    v-bind:class="{ 'is-danger': errors.has('form.province')}" v-validate="'required'"
                    data-vv-scope="form" disabled>
                </div>
                <p v-show="errors.has('form.province')" class="help is-danger">{{ errors.first('form.province') }}
                </p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Kota <a v-if="city != null" @click="city = null" class="is-link">Ubah</a></label>
                <div class="control" v-if="city == null">
                  <vue-autosuggest name="city" :suggestions="filterCity" @selected="selectCity" :limit="10"
                    :input-props="inputCity" v-bind:class="{ 'is-danger': errors.has('form.city')}"
                    v-validate="'required'" data-vv-scope="form">
                  </vue-autosuggest>
                </div>
                <div class="control" v-else>
                  <input name="city" class="input" placeholder="Kota" type="text" v-model="city"
                    v-bind:class="{ 'is-danger': errors.has('form.city')}" v-validate="'required'" data-vv-scope="form"
                    disabled>
                </div>
                <p v-show="errors.has('form.city')" class="help is-danger">{{ errors.first('form.city') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Kode Pos</label>
                <div class="control">
                  <input name="postal_code" class="input" placeholder="Kode Pos" type="text" v-model="postalCode"
                    @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('form.postal_code')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.postal_code')" class="help is-danger">{{ errors.first('form.postal_code') }}
                </p>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import {
    VueAutosuggest
  } from "vue-autosuggest";;
  import moment from "moment";

  export default {
    components: {
      VueAutosuggest
    },
    data() {
      return {
        objecIdentifier: null,
        company: null,
        startDate: null,
        endDate: null,
        buildCode: '',
        buildName: '',
        street: '',
        location: null,
        country: null,
        province: null,
        city: null,
        postalCode: null,

        options: [{
          data: []
        }],
        filterCountry: [],
        inputCountry: {
          id: "autosuggest__input",
          name: "country",
          class: "input",
          onInputChange: this.getCountry,
          placeholder: "Negara"
        },
        filterProvince: [],
        inputProvince: {
          id: "autosuggest__input",
          name: "province",
          class: "input",
          onInputChange: this.getProvince,
          placeholder: "Provinsi"
        },
        filterCity: [],
        inputCity: {
          id: "autosuggest__input",
          name: "city",
          class: "input",
          onInputChange: this.getCity,
          placeholder: "Kota"
        },
        limit: 10,
      }
    },
    created() {
      if (this.building.detail) this.getData()
      this.getParam();
    },
    computed: {
      ...mapState(['companies', 'building', 'LOCID']),
    },
    methods: {
      getCountry(text) {
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=CONTR" +
            "&per_page=9999" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (country, key) => {
              await this.options[0].data.push(
                country.id,
              );
            });

            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filterCountry = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectCountry(option) {
        if (option == null) {
          this.country = null;
        } else {
          this.country = option.item;
        }
      },
      getSuggestionValue(suggestion) {
        return suggestion.item.value;
      },
      getProvince(text) {
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=PRVNC" +
            "&per_page=9999" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (province, key) => {
              await this.options[0].data.push(
                province.value,
              );
            });

            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filterProvince = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectProvince(option) {
        if (option == null) {
          this.province = null;
        } else {
          this.province = option.item;
        }
      },
      getCity(text) {
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=CITY" +
            "&per_page=9999" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (city, key) => {
              await this.options[0].data.push(
                city.value,
              );
            });

            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filterCity = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectCity(option) {
        if (option == null) {
          this.city = null;
        } else {
          this.city = option.item;
        }
      },

      getData() {
        this.objecIdentifier = this.building.detail.object_identifier

        this.startDate = this.building.detail.begin_date
        this.endDate = this.building.detail.end_date
        this.buildCode = this.building.detail.build_code
        this.buildName = this.building.detail.build_name
        this.street = this.building.detail.street
        this.location = this.building.detail.location
        this.country = this.building.detail.country
        this.province = this.building.detail.province
        this.city = this.building.detail.city
        this.postalCode = this.building.detail.postal_code

        this.company = this.building.detail.business_code.business_code
      },
      getParam() {
        this.$store.dispatch('LOCID/getAll', {
          business_code: ['*', this.company]
        });
      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('hcis/api/building', {
            begin_date: this.startDate,
            end_date: this.endDate,
            business_code: this.company,
            build_code: this.buildCode,
            build_name: this.buildName,
            street: this.street,
            location: this.location,
            country: this.country,
            province: this.province,
            city: this.city,
            postal_code: this.postalCode,
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('building/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('hcis/api/building', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            business_code: this.company,
            build_code: this.buildCode,
            build_name: this.buildName,
            street: this.street,
            location: this.location,
            country: this.country,
            province: this.province,
            city: this.city,
            postal_code: this.postalCode,
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('building/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.building.detail.object_identifier
        this.startDate = this.building.detail.begin_date
        this.endDate = this.building.detail.end_date
        this.buildCode = this.building.detail.build_code
        this.buildName = this.building.detail.build_name
        this.street = this.building.detail.street
        this.location = this.building.detail.end_date
        this.country = this.building.detail.country
        this.province = this.building.detail.province
        this.city = this.building.detail.city
        this.postalCode = this.building.detail.postal_code

        this.$validator.reset('form')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
