<template>
  <section>
    <div class="modal-background" @click="closeFormModal()"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Area Payroll</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="getParam()" v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Area Payroll</label>
                <div class="control">
                  <input name="payroll_area" class="input " placeholder="Area Payroll" type="text"
                    v-model="payrollNumber" @keypress="onlyNumber"
                    v-bind:class="{ 'is-danger': errors.has('form.payroll_area')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.payroll_area')" class="help is-danger">
                  {{ errors.first('form.payroll_area') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama Payroll</label>
                <div class="control">
                  <input name="payroll_name" class="input " placeholder="Nama Payroll" type="text" v-model="payrollName"
                    v-bind:class="{ 'is-danger': errors.has('form.payroll_name')}" v-validate="'required'"
                    data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.payroll_name')" class="help is-danger">
                  {{ errors.first('form.payroll_name') }}
                </p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Siklus Awal</label>
                <div class="control">
                  <input name="begin_cycle" class="input " placeholder="Siklus Awal" type="text" v-model="beginCycle"
                    @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('form.begin_cycle')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.begin_cycle')" class="help is-danger">
                  {{ errors.first('form.begin_cycle') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Siklus Akhir</label>
                <div class="control">
                  <input name="end_cycle" class="input " placeholder="Siklus Akhir" type="text" v-model="endCycle"
                    @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('form.end_cycle')}"
                    v-validate="'required'" data-vv-scope="form">
                </div>
                <p v-show="errors.has('form.end_cycle')" class="help is-danger">
                  {{ errors.first('form.end_cycle') }}
                </p>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  import moment from "moment";

  export default {
    data() {
      return {
        objecIdentifier: null,
        company: null,
        startDate: null,
        endDate: null,
        payrollNumber: null,
        payrollName: '',
        beginCycle: null,
        endCycle: null,
      }
    },
    created() {
      if (this.payrollArea.detail) this.getData()
      this.getParam();
    },
    computed: {
      ...mapState(['companies', 'payrollArea'])
    },
    methods: {
      getData() {
        this.objecIdentifier = this.payrollArea.detail.object_identifier;

        this.startDate = this.payrollArea.detail.begin_date;
        this.endDate = this.payrollArea.detail.end_date;
        this.payrollNumber = this.payrollArea.detail.payroll_area;
        this.payrollName = this.payrollArea.detail.payroll_name;
        this.beginCycle = this.payrollArea.detail.begin_cycle;
        this.endCycle = this.payrollArea.detail.end_cycle;

        this.company = this.payrollArea.detail.business_code.business_code;
      },

      getParam() {

      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('hcis/api/payrollarea', {
            begin_date: this.startDate,
            end_date: this.endDate,
            payroll_area: this.payrollNumber,
            payroll_name: this.payrollName,
            begin_cycle: this.beginCycle,
            end_cycle: this.endCycle,

            business_code: this.company,
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('payrollArea/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('hcis/api/payrollarea', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            payroll_area: this.payrollNumber,
            payroll_name: this.payrollName,
            begin_cycle: this.beginCycle,
            end_cycle: this.endCycle,

            business_code: this.company,
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('payrollArea/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.payrollArea.detail.object_identifier
        this.startDate = this.payrollArea.detail.begin_date;
        this.endDate = this.payrollArea.detail.end_date;
        this.payrollNumber = this.payrollArea.detail.payroll_area;
        this.payrollName = this.payrollArea.detail.payroll_name;
        this.beginCycle = this.payrollArea.detail.begin_cycle;
        this.endCycle = this.payrollArea.detail.end_cycle;

        this.$validator.reset('form')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
