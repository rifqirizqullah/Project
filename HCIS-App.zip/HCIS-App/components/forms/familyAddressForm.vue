<template>
  <section>
    <div class="modal-background"></div>
    <div class="modal-card">
      <header class="modal-card-head">
        <p class="modal-card-title">{{objecIdentifier ? 'Update' : 'Create'}} Alamat Keluarga Karyawan</p>
        <button @click="closeFormModal()" class="delete" aria-label="close"></button>
      </header>
      <section class="modal-card-body">
        <div class="columns">
          <div class="column">
            <div class="field">
              <label class="label">Nama Perusahaan</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                  <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                    v-validate="'required'">
                    <option disabled selected>Choose</option>
                    <option v-for="(company, key) in companies.list" :key="key" :value="company.business_code">
                      {{ company.company_name }}</option>
                  </select>
                </div>
                <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
              </div>
            </div>
          </div>
        </div>

        <span v-show="company">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                    class="is-link">Ubah</a></label>
                <div class="control" v-if="employee == null">
                  <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                    @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                    v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                  </vue-autosuggest>
                </div>
                <div class="control" v-else>
                  <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                    v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                    v-validate="'required'" disabled>
                </div>
                <p v-show="errors.has('personnel_number')" class="help is-danger">
                  {{ errors.first('personnel_number') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Nama</label>
                <div class="control">
                  <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                    v-validate="'required'" disabled>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Posisi Saat Ini</label>
                <div class="control">
                  <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                    v-model="empolyeePosition" v-validate="'required'" disabled>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Unit Saat Ini</label>
                <div class="control">
                  <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                    v-validate="'required'" disabled>
                </div>
              </div>
            </div>
          </div>
          <hr>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Hubungan Keluarga</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_type') }">
                    <select name="family_type" class="select" v-model="familyType" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in FAMTY.list" :key="key" :value="item.obejct_code">
                        {{ item.object_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('family_type')" class="help is-danger">{{ errors.first('family_type') }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Urutan Keluarga</label>
                <div class="control">
                  <input name="family_number" class="input" placeholder="Urutan Keluarga" type="text"
                    v-model="familyNumber" @keypress="onlyNumber"
                    v-bind:class="{ 'is-danger': errors.has('family_number')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('family_number')" class="help is-danger">{{ errors.first('family_number') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tipe Alamat</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('address_type') }">
                    <select name="address_type" class="select" v-model="addressType" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in ADDTY.list" :key="key" :value="item.object_code">
                        {{ item.object_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('address_type')" class="help is-danger">{{ errors.first('address_type') }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Alamat</label>
                <div class="control">
                  <textarea name="street" class="textarea" placeholder="Alamat Lengkap" rows="5" v-model="street"
                    v-bind:class="{ 'is-danger': errors.has('street')}" v-validate="'required'"></textarea>
                </div>
                <p v-show="errors.has('street')" class="help is-danger"> {{ errors.first('street')}}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nomor Rumah</label>
                <div class="control">
                  <input name="address_number" class="input" placeholder="Kode Pos" type="text" v-model="addressNumber"
                    v-bind:class="{ 'is-danger': errors.has('address_number')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('address_number')" class="help is-danger">{{ errors.first('address_number') }}
                </p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Kode Pos</label>
                <div class="control">
                  <input name="postal_code" class="input" placeholder="Kode Pos" type="text" v-model="postalCode"
                    @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('postal_code')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('postal_code')" class="help is-danger">{{ errors.first('postal_code') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Negara</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('country') }">
                    <select name="country" class="select" v-model="country" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in CONTR.list" :key="key" :value="item.object_code">
                        {{ item.object_name }}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('country')" class="help is-danger">{{ errors.first('country') }}
                  </p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Provinsi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('province') }">
                    <select name="province" class="select" v-model="province" v-validate="'required'"
                      @change="getCity()">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in PRVNC.list" :key="key" :value="item.object_code">
                        {{ item.object_name }}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('province')" class="help is-danger">{{ errors.first('province') }}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Kota</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('city') }">
                    <select name="city" class="select" v-model="city" v-validate="'required'" @change="getDistrict()">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in PRVNC_CITY.list" :key="key" :value="item.child.object_code">
                        {{ item.child.object_name }}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('city')" class="help is-danger">{{ errors.first('city') }}
                  </p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Kecamatan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('district') }">
                    <select name="district" class="select" v-model="district" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(item, key) in CITY_DSTRC.list" :key="key" :value="item.child.object_code">
                        {{ item.child.object_name }}
                      </option>
                    </select>
                  </div>
                  <p v-show="errors.has('district')" class="help is-danger">{{ errors.first('district') }}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </span>

      </section>
      <footer class="modal-card-foot">
        <div class="control  ">
          <button v-if="!objecIdentifier" class="button is-success" @click="storeData">Save</button>
          <button v-if="objecIdentifier" class="button is-warning" @click="updateData">Update</button>
          <button class="button is-danger" @click="closeFormModal()">Batal</button>
        </div>
      </footer>
    </div>
  </section>
</template>

<script>
  import {
    mapState
  } from 'vuex';
  import {
    VueAutosuggest
  } from "vue-autosuggest";
  import moment from "moment";

  export default {
    components: {
      VueAutosuggest
    },
    data() {
      return {
        objecIdentifier: null,
        company: null,
        employee: null,
        empolyeeName: '',
        empolyeePosition: '',
        empolyeeUnit: '',
        startDate: null,
        endDate: null,
        familyType: null,
        familyNumber: null,
        addressType: null,
        street: '',
        addressNumber: null,
        postalCode: null,
        country: null,
        province: null,
        city: null,
        district: null,

        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,
      }
    },
    created() {
      if (this.familyAddress.detail) this.getData()
      this.getParam();
      this.getCity();
      this.getDistrict();
    },
    computed: {
      ...mapState(['companies', 'familyAddress', 'FAMTY', 'ADDTY', 'CONTR', 'PRVNC', 'PRVNC_CITY', 'CITY_DSTRC'])
    },
    methods: {
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployeeData(nik) {
        this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      clearEmployee() {
        if (this.employee != null) {
          this.$refs.reference = '';
        }
        this.filterEmployee = []
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeeUnit = '';
        this.empolyeePosition = '';

        this.$nextTick(() => this.$validator.reset());
      },

      getData() {
        this.objecIdentifier = this.familyAddress.detail.object_identifier;

        this.startDate = this.familyAddress.detail.begin_date;
        this.endDate = this.familyAddress.detail.end_date;
        this.familyType = this.familyAddress.detail.family_type;
        this.familyNumber = this.familyAddress.detail.family_number;
        this.street = this.familyAddress.detail.street;
        this.addressType = this.familyAddress.detail.address_type;
        this.addressNumber = this.familyAddress.detail.address_number;
        this.postalCode = this.familyAddress.detail.postal_code;
        this.country = this.familyAddress.detail.country;
        this.province = this.familyAddress.detail.province;
        this.city = this.familyAddress.detail.city;
        this.district = this.familyAddress.detail.district;

        this.company = this.familyAddress.detail.business_code.business_code;
        this.employee = this.familyAddress.detail.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.$store.dispatch('FAMTY/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('ADDTY/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('CONTR/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('PRVNC/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('PRVNC_CITY/getAll', {
          business_code: ['*', this.company]
        });
        this.$store.dispatch('CITY_DSTRC/getAll', {
          business_code: ['*', this.company]
        });
      },
      getCity() {
        this.$store.dispatch('PRVNC_CITY/getAll', {
          business_code: ['*', this.company],
          parent: [this.province],
        });
      },
      getDistrict() {
        this.$store.dispatch('CITY_DSTRC/getAll', {
          business_code: ['*', this.company],
          parent: [this.city],
        });
      },

      async storeData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.post('hcis/api/familyaddress', {
            begin_date: this.startDate,
            end_date: this.endDate,
            family_type: this.familyType,
            family_number: this.familyNumber,
            address_type: this.addressType,
            street: this.street,
            address_number: this.addressNumber,
            postal_code: this.postalCode,
            country: this.country,
            province: this.province,
            city: this.city,
            district: this.district,

            business_code: this.company,
            personnel_number: this.employee
          })
          .then(() => {
            swal(
              'Saved!',
              'Successfully saved data.',
              'success'
            )
            this.closeFormModal()
            this.$store.dispatch('familyAddress/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },
      async updateData() {
        let isValid = await this.$validator.validateAll('form')
        if (!isValid) return false
        this.$axios.put('hcis/api/familyaddress', {
            object_identifier: this.objecIdentifier,
            begin_date: this.startDate,
            end_date: this.endDate,
            family_type: this.familyType,
            family_number: this.familyNumber,
            address_type: this.addressType,
            street: this.street,
            address_number: this.addressNumber,
            postal_code: this.postalCode,
            country: this.country,
            province: this.province,
            city: this.city,
            district: this.district,

            business_code: this.company,
            personnel_number: this.employee
          })
          .then(() => {
            swal(
              'Updated!',
              'Successfully update data.',
              'success'
            )
            this.closeFormModal();
            this.$store.dispatch('familyAddress/getAll');
          })
          .catch(err => {
            console.log(err.response);
          })
      },

      closeFormModal() {
        this.$parent.closeFormModal()
      },
      resetForm() {
        this.objecIdentifier = this.familyAddress.detail.object_identifier;

        this.startDate = this.familyAddress.detail.begin_date;
        this.endDate = this.familyAddress.detail.end_date;
        this.familyType = this.familyAddress.detail.family_type;
        this.familyNumber = this.familyAddress.detail.family_number;
        this.street = this.familyAddress.detail.street;
        this.addressType = this.familyAddress.detail.address_type;
        this.addressNumber = this.familyAddress.detail.address_number;
        this.postalCode = this.familyAddress.detail.postal_code;
        this.country = this.familyAddress.detail.country;
        this.province = this.familyAddress.detail.province;
        this.city = this.familyAddress.detail.city;
        this.district = this.familyAddress.detail.district;

        this.company = this.familyAddress.detail.business_code.business_code;
        this.employee = this.familyAddress.detail.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);

        this.$validator.reset('form')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .button.is-warning {
    background-color: #decc43;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
