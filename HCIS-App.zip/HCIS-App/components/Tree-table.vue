<template>
  
    <v-jstree :data="data" show-checkbox multiple allow-batch whole-row @item-click="itemClick">

      
    </v-jstree>

</template>

<script>
export default {
  
}
</script>

