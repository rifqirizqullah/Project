<template>
    <nav class="pagination is-centered is-rounded" role="navigation" aria-label="pagination" v-if="state && state.pagination">
        <a class="pagination-previous" @click="callPage({page: 1})" :disabled="state.pagination.current_page <= 1">First page</a>
        <a class="pagination-previous" @click="callPage({page: state.pagination.current_page-1})" :disabled="state.pagination.current_page <= 1">Previous</a>
        <a class="pagination-next" @click="callPage({page : state.pagination.current_page+1})" :disabled="state.pagination.current_page >= state.pagination.total_pages">Next page</a>
        <a class="pagination-next" @click="callPage({page : state.pagination.total_pages})" :disabled="state.pagination.current_page >= state.pagination.total_pages">Last page</a>
        <ul class="pagination-list">
            <li v-for="(page, index) in pages" :key="index">
                <a class="pagination-link" :class="isCurrentPage(page) ? 'is-current' : ''" @click="callPage({page : page})">{{ page }}</a>
            </li>
        </ul>
    </nav>
    
</template>

<script>
import { mapState, mapActions } from "vuex";
export default {
    props : ['state','storeModuleName','offset'],
    computed: {
      pages() {
        let pages = [];
        let from = this.state.pagination.current_page - Math.floor(this.offset / 2);
        if (from < 1) {
          from = 1;
        }
        let to = from + this.offset - 1;
        if (to > this.state.pagination.total_pages) {
          to = this.state.pagination.total_pages;
        }
        while (from <= to) {
          pages.push(from);
          from++;
        }
        return pages;
      }
    },
    mounted() {
    },
    methods: {
        isCurrentPage(page) {
            return this.state.pagination.current_page === page;
        },
        callPage(page) {
            let params = {
                ...this.$route.query,
                ...page,
            }
            this.$store.dispatch(`${this.storeModuleName}/getAll`, params)
        }
    },

}
</script>

<style>

</style>
