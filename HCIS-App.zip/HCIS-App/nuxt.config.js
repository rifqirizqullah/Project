const pkg = require('./package');
require('dotenv').config();

module.exports = {
  mode: 'spa',
  auth: {
    strategies: {
      local: {
        endpoints: {
          login: { url: 'ldap/api/auth', method: 'post', propertyName: 'access_token' },
          user: { url: 'ldap/api/account', method: 'get', propertyName: 'data' },
          logout: false
        },

      }
    }
  },

  axios: {
    baseURL: process.env.API_BASE_URL
  },

  /*
  ** Headers of the page
  */
  head: {
    title: pkg.name,
    meta: [
      { charset: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { hid: 'description', name: 'description', content: pkg.description }
    ],
    link: [
      { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' }
    ]
  },

  /*
  ** Customize the progress-bar color
  */
  loading: { color: '#fff' },

  /*
  ** Global CSS
  */
  css: [
    '@/assets/css/app.css',
    '@/node_modules/bulma-extensions/bulma-steps/dist/css/bulma-steps.min.css',
    // '@/node_modules/bulma-carousel/dist/css/bulma-carousel.min.css',
    // '@/node_modules/bulma-steps/dist/css/bulma-steps.min.css',
    // '@/node_modules/bulma-divider/dist/css/bulma-divider.min.css',
    // '@/node_modules/bulma-pricingtable/dist/css/bulma-pricingtable.min.css',
    // '@/node_modules/bulma-badge/dist/css/bulma-badge.min.css'
  ],

  /*
  ** Plugins to load before mounting the App
  */
  plugins: [
    '~/plugins/axios',
    '~/plugins/vue-jstree'
  ],

  server: {
    host: process.env.APP_URL,
    port: process.env.PORT
  },

  /*
  ** Nuxt.js modules
  */
  modules: [
    // Doc: https://github.com/nuxt-community/axios-module#usage
    '@nuxtjs/axios',
    '@nuxtjs/auth',
    // Doc:https://github.com/nuxt-community/modules/tree/master/packages/bulma
    '@nuxtjs/bulma',
    '@nuxtjs/font-awesome',
    '@nuxtjs/dotenv',
  ],

  /*
  ** Build configuration
  */
  build: {
    // publicPath: '/_source/',
    // plugins: [
    //   new webpack.ProvidePlugin({
    //     $: 'jquery',
    //     jQuery: 'jquery',
    //     'window.jquery': 'jquery',
    //     _: 'lodash',
    //     moment: 'moment'
    //   })
    // ],
    postcss: {
      preset: {
        features: {
          customProperties: false
        }
      }
    },
    vendor: [

      'bulma-steps',

    ],
    /*
    ** You can extend webpack config here
    */
    extend(config, ctx) {

    },

    server: {
      host: process.env.APP_URL,
      port: process.env.PORT
    },
  }
}