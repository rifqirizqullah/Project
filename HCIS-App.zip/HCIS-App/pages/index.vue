<template>
  <section>
    <div class="relative">
    <div class="bg1">
      <img src="../assets/bg1.png" alt="">
    </div>
    <div class="bg2">
     <img src="../assets/bg2.png" alt="">
    </div>
    <div class="columns is-vertical-center">
        <div class="column is-6 ">
            <h1 class="title is-1 ">Selamat Datang</h1>

            <h3 class="subtitle is-3">Pengelolaan Data Karyawan BUMN</h3>
            <h5 class="abc">Merupakan aplikasi pengelolaan data karyawan BUMN yang dimaksudkan agar semua data karyawan maupun talent BUMN dapat terpelihara dengan baik dan integtratable untuk dapat digunakan di aplikasi lain yang memakai data tersebut dan dapat menghasilkan data (people) analytic yang sesuai dan memadai.</h5>
            <br>
            <a class="button is-success is-rounded">Informasi Selengkapnya</a>
        </div>

    </div>
    </div>
  </section>
</template>

<script>
  export default {
    layout: 'home',

    data(){
      return{

      }
    },
    methods:{

    },
    middleware: ['auth']

  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .home.is-fullheight {
    height: 100vh;
  }

  /* .home {
    background: red;
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    background-color: #999;
    background-image: url('../assets/hc.png');
  } */

  h3.abc {
    text-align: justify;
}

.is-vertical-center {
  display: flex;
  align-items: center;
  padding: 180px
}

.relative{
  position: relative;
  height: 100vh;
}

.bg1{
  position: absolute;
  right: 0;
  bottom: 0;
  width: 70%
}

.bg2{
  position: absolute;
  left: 0;
  top: 0;

}



</style>
