<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <!-- <hr> -->
    <h3 class="subtitle is-3">
      <i class="fa fa-upload" aria-hidden="true"></i> Upload Data
    </h3>
    <div class="columns">
      <div class="column is-10">
        <div class="field">
          <p>
            <!-- <nuxt-link to="#" class="navbar-item">
              Download Format Upload Data
            </nuxt-link> -->
            <a :href="'/FilesTemplate/masgih/' + this.fileName" download>Download Format Upload Data</a>
            <br>
            <label>1.Buat Template excel dengan header kolom pada row pertama excel dengan isi tabel pada row kedua dan
              seterusnya.</label>
            <br>
            <label>2.Urutan kolom header sesuai dengan urutan baris pada penjelasan data dictionary di setiap tabelnya.</label>
            <br>
            <label>3.Nama Sheet pada excel harus sesuai dengan nama tabel.</label>
            <br>
            <label>4.Simpan Excel pada directory tertentu.</label>
            <br>
            <label>5.Lakukan upload pada menu upload > Upload Data, dengan menyertakan file excel yang telah disiapkan
              dan disimpan pada directory anda.</label>
            <br>
            <label>6.Apabila berhasil upload maka akan muncul pesan sukses atau berhasil upload data.</label>
            <br>
          </p>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Upload File
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tabel</label>
            <div class="control">
              <div class="select is-fullwidth" >
                <select v-model="tableCode" name="tableCode" v-validate="'required'" v-bind:class="{'is-danger':errors.has('table')}" @change="getFileName()">
                  <option value="">Pilih</option>
                  <option v-for="(table, key) in allTables" :key="key" :value="table.table_code">
                    {{ table.table_code }}
                  </option>
                </select>
              </div>
              <p v-show="errors.has('table')" class="help is-danger">{{errors.first('table')}}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="control">
              <div class="select is-fullwidth" >
                <select v-model="companyCode" name="companyCode" v-validate="'required'" v-bind:class="{'is-danger':errors.has('company')}">
                  <option value="">Pilih</option>
                  <option v-for="(company, key) in allCompanies" :key="key" :value="company.business_code">
                    {{ company.company_name }}
                  </option>
                </select>
              </div>
              <p v-show="errors.has('company')" class="help is-danger">{{errors.first('company')}}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-1">
          <div class="field">
            <label>Upload File</label>
          </div>
        </div>
        <div class="column is-5">
          <div class="field">
            <div class="file has-name">
              <label class="file-label">
                <input type="file" id="file" ref="file" v-on:change="handleFileUpload()" name="fileExcel"
                  v-validate="'required'" v-bind:class="{'is-danger':errors.has('file')}" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet">
                <!--span class="file-cta">
                  <span class="file-icon">
                    <i class="fa fa-upload"></i>
                  </span>
                  <span class="file-label">
                    Upload File
                  </span>
                </span>
                <span class="file-name">
                  Tidak Ada File yang Dipilih
                </span-->
              </label>
            </div>
            <p v-show="errors.has('file')" class="help is-danger">{{errors.first('file')}}</p>
          </div>
        </div>
      </div>
    </div>
    <!-- <a class="button is-success is-rounded">Save</a>
    <a class="button is-danger is-rounded">Reset</a> -->
    <a class="button is-link is-rounded" @click="saveUpload()">Simpan</a>
    <a class="button is-danger is-rounded">Reset</a>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Admission'
          },
          {
            name: 'Personal'
          },
        ],
        tableCode: '',
        fileExcel: '',
        allTables: [],
        allCompanies: [],
        table: '',
        company: '',
        companyCode: '',
        key: null,
        fileName: null,
      }
    },
    created() {
      this.getAllTable();
      this.getAllCompanies();
    },
    methods: {
      getFileName(){
        if (this.tableCode == 'Award') {
          this.fileName = 'Award.xlsx'
        } else {
          this.fileName = 'test'     
        }
      },
      getAllTable() {
        this.$axios.get('/objects/alltable')
          .then(response => {
            this.allTables = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getAllCompanies() {
        this.$axios.get('/objects/companytoken')
          .then(response => {
            this.allCompanies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      handleFileUpload() {
        this.fileExcel = this.$refs.file.files[0];
      },
      resetForm() {
        this.tableCode = '';
        this.companyCode = '';
        this.$refs.file.value = null;
        this.$nextTick(() => this.$validator.reset())
      },
      saveUpload(){
        this.storeUpload();
      },
      storeUpload() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          let formData = new FormData();
          formData.append('table_code', this.tableCode);
          formData.append('buscd', this.companyCode);
          formData.append('myfile', this.fileExcel);
          // console.log(formData);
          this.$axios.post('users/upload',
              formData, {
                headers: {
                  'Content-Type': 'multipart/form-data'
                }
              })
            .then(response => {
              console.log(response.data.status);
              if (response.data.status == 404) {
                swal(
                  'Gagal upload!',
                  'Format data salah. ',
                  'warning'
                )
                this.$refs.file.value = null;
              } else {
                this.resetForm();
                swal(
                  'Tersimpan!',
                  'Data berhasil diupload.',
                  'success'
                )
              }
            })
            .catch(e => {
              console.log(e);
            });
        });
      }
    }
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
