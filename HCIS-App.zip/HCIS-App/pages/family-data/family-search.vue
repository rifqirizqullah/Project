<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-users" aria-hidden="true"></i> Data Keluarga Karyawan
    </h3>
    <div class="box has-text-white has-background-danger">
      Filter Search
    </div>
    <div class="box">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{column.column_name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{logic.name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{condition.name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column">
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded" @click="addNewFormSearch()">
                <i class="fa fa-plus" aria-hidden="true"></i>
              </a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded" @click="deleteFormSearch(key)">
                <i class="fa fa-trash" aria-hidden="true"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded" @click="getSearchDynamic()">Cari</a>
    <!-- <nuxt-link to="/family-data/family"><a class="button is-link is-rounded">Tambah Data</a>
    </nuxt-link>-->
    <a class="button is-link is-rounded" @click="openFormModal()">
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data
      </span>
    </a>
    <br><br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nama</th>
          <th>Nomer Induk Karyawan</th>
          <th>Status Pernikahan</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(family, key) in families" :key="key">
          <td>{{ key + 1 }}</td>
          <td>{{ family.business_code.company_name }}</td>
          <td>{{ family.family_name }}</td>
          <td>{{ family.personnel_number.personnel_number }}</td>
          <td>{{ family.marital_status }}</td>
          <td>{{ formatDate(family.begin_date) }}</td>
          <td>{{ formatDate(family.end_date) }}</td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded" @click="editFamily(family.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="family.object_identifier ? deleteFamily(key, family.object_identifier) : removeFamily(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitFamily(family.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>

    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getFamilies()">
    </pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Keluarga</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                    <select name="company" class="select" v-model="company" @change="getParam()"
                      v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                        {{ company.company_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                </div>
              </div>
            </div>
          </div>

          <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                      class="is-link">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Hubungan Keluarga</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_type') }">
                      <select name="family_type" class="select" v-model="familyType" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(familyType, key) in familyTypes" :key="key" :value="familyType.object_code">
                          {{ familyType.object_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('family_type')" class="help is-danger">{{ errors.first('family_type') }}</p>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Urutan Keluarga</label>
                  <div class="control">
                    <input name="family_number" class="input" placeholder="Urutan Keluarga" type="text"
                      v-model="familyNumber" @keypress="onlyNumber"
                      v-bind:class="{ 'is-danger': errors.has('family_number')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('family_number')" class="help is-danger">{{ errors.first('family_number') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nama Lengkap</label>
                  <div class="control">
                    <input name="family_name" class="input" placeholder="Nama Lengkap" type="text" v-model="familyName"
                      v-bind:class="{ 'is-danger': errors.has('family_name')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('family_name')" class="help is-danger">{{ errors.first('family_name') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama Panggilan</label>
                  <div class="control">
                    <input name="nickname" class="input" placeholder="Nama Panggilan" type="text" v-model="nickname"
                      v-bind:class="{ 'is-danger': errors.has('nickname')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('nickname')" class="help is-danger">{{ errors.first('nickname') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tempat Lahir</label>
                  <div class="control">
                    <input name="birth_place" class="input" placeholder="Tempat Lahir" type="text" v-model="birthPlace"
                      v-bind:class="{ 'is-danger': errors.has('birth_place')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('birth_place')" class="help is-danger">{{ errors.first('birth_place') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Lahir</label>
                  <div class="control">
                    <input id="birth_date" data-display-mode="dialog" class="input" name="birth_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="birthDate" data-vv-as="Birth date"
                      v-bind:class="{ 'is-danger': errors.has('birth_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('birth_date')" class="help is-danger">{{ errors.first('birth_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Jenis Kelamin</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('gender') }">
                      <select name="gender" class="select" v-model="gender" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(gender, key) in genders" :key="key" :value="gender.object_code">
                          {{ gender.object_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('gender')" class="help is-danger">{{ errors.first('gender') }}</p>
                  </div>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Agama</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('religion') }">
                      <select name="religion" class="select" v-model="religion" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(religion, key) in religions" :key="key" :value="religion.object_code">
                          {{ religion.object_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('religion')" class="help is-danger">{{ errors.first('religion') }}</p>
                  </div>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Status</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_status') }">
                      <select name="family_status" class="select" v-model="familyStatus" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(familyStatus, key) in familyStatuses" :key="key" :value="familyStatus.object_code">
                          {{ familyStatus.object_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('family_status')" class="help is-danger">{{ errors.first('family_status') }}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Status keluarga</label>
                  <div class="control">
                    <input id="family_status_date" data-display-mode="dialog" class="input" name="family_status_date"
                      type="date" placeholder="e.g 10-11-2018" v-model="familyStatusDate"
                      data-vv-as="Family Status Date" v-bind:class="{ 'is-danger': errors.has('family_status_date')}"
                      v-validate="'required'">
                  </div>
                  <p v-show="errors.has('family_status_date')" class="help is-danger">
                    {{ errors.first('family_status_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Lapor</label>
                  <div class="control">
                    <input id="report_date" data-display-mode="dialog" class="input" name="report_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="reportDate" data-vv-as="Report Date"
                      v-bind:class="{ 'is-danger': errors.has('report_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('report_date')" class="help is-danger">{{ errors.first('report_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi</label>
                  <div class="control">
                    <input name="job_title_family" class="input" placeholder="Posisi" type="text"
                      v-model="jobTitleFamily" v-bind:class="{ 'is-danger': errors.has('job_title_family')}"
                      v-validate="'required'">
                  </div>
                  <p v-show="errors.has('job_title_family')" class="help is-danger">
                    {{ errors.first('job_title_family') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Instansi</label>
                  <div class="control">
                    <input name="family_work" class="input" placeholder="Instansi" type="text" v-model="familyWork"
                      v-bind:class="{ 'is-danger': errors.has('family_work')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('family_work')" class="help is-danger">{{ errors.first('family_work') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Status Pernikahan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('marital_status') }">
                      <select name="marital_status" class="select" v-model="maritalStatus" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(maritalStatus, key) in maritalStatuses" :key="key" :value="maritalStatus.object_code">
                          {{ maritalStatus.object_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('marital_status')" class="help is-danger">{{ errors.first('marital_status') }}
                    </p>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Pernikahan</label>
                  <div class="control">
                    <input id="marital_date" data-display-mode="dialog" class="input" name="marital_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="maritalDate" data-vv-as="Marital Date"
                      v-bind:class="{ 'is-danger': errors.has('marital_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('marital_date')" class="help is-danger">{{ errors.first('marital_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label for="checkbox" class="checkbox">
                    <input type="checkbox" name="tax_flag" v-model="taxFlag">
                    Tanggungan Pajak
                  </label>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label for="checkbox" class="checkbox">
                    <input type="checkbox" name="med_flag" v-model="medFlag">
                    Tanggungan Kesehatan
                  </label>
                </div>
              </div>
            </div>
          </span>

        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveFamily()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Delimit Data Pelatihan</p>
          <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                    data-vv-scope="delimit" disabled>
                </div>
                <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                  {{ errors.first('delimit.begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                    data-vv-scope="delimit">
                </div>
                <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                </p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="delimitFamily()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from "~/components/Breadcrumb";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  import VueAutosuggest from "vue-autosuggest";
  Vue.use(VueAutosuggest);
  import moment from "moment";

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        // nikAuth: this.$auth.user.nik,
        // key: null,

        families: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        familyType: null,
        familyTypes: [],
        familyNumber: null,
        familyName: '',
        nickname: '',
        birthPlace: null,
        birthDate: null,
        gender: null,
        genders: [],
        religion: null,
        religions: [],
        taxFlag: null,
        medFlag: null,
        familyStatus: null,
        familyStatuses: [],
        familyStatusDate: null,
        reportDate: null,
        jobTitleFamily: '',
        familyWork: null,
        maritalDate: null,
        maritalStatus: null,
        maritalStatuses: [],

        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: '',
        empolyeePosition: '',
        empolyeeUnit: '',

        perPage: 5,
        search: '',
        pagination: {
          'current_page': 1
        },

        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,

        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Keluarga'
          },
          {
            name: 'Keluarga'
          }
        ],
        isActiveForm: false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getFamilies();
      this.getCompany();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
    },
    methods: {
      getCompany() {
        this.$axios
          .get(
            'hcis/api/company?begin_date_lte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&end_date_gte=' +
            moment(new Date()).format('YYYY-MM-DD')
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getEmployeeData(nik) {
        await this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      getFamilyType() {
        this.$axios
          .get(
            'ldap/api/object?begin_date_lte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&end_date_gte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&object_type=FAMTY' +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.familyTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getGender() {
        this.$axios
          .get(
            'ldap/api/object?begin_date_lte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&end_date_gte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&object_type=GENDR' +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.genders = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getReligion() {
        this.$axios
          .get(
            'ldap/api/object?begin_date_lte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&end_date_gte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&object_type=RELIG' +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.religions = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getFamilyStatus() {
        this.$axios
          .get(
            'ldap/api/object?begin_date_lte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&end_date_gte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&object_type=FAMST'
          )
          .then(response => {
            this.familyStatuses = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getMaritalStatus() {
        this.$axios
          .get(
            'ldap/api/object?begin_date_lte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&end_date_gte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&object_type=MRTST'
          )
          .then(response => {
            this.maritalStatuses = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getFamilies() {
        this.$axios
          .get('hcis/api/datafamily?include=business_code&include=personnel_number&begin_date_lte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&end_date_gte=' +
            moment(new Date()).format('YYYY-MM-DD') +
            '&page=' + this.pagination.current_page +
            '&per_page=' + this.perPage
          )
          // .get('hcis/api/datafamily')
          .then(response => {
            this.families = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getFamily(objectIdentifier) {
        let family = await this.families.find(
          family => family.object_identifier == objectIdentifier
        );
        this.objectIdentifier = family.object_identifier;
        this.startDate = family.begin_date;
        this.endDate = family.end_date;
        this.familyType = family.family_type;
        this.familyNumber = family.family_number;
        this.familyName = family.family_name;
        this.nickname = family.nickname;
        this.birthPlace = family.birth_place;
        this.birthDate = family.birth_date;
        this.gender = family.gender;
        this.religion = family.religion;
        (family.tax_flag == 'y') ? this.taxFlag = true: 'n';
        (family.med_flag == 'y') ? this.medFlag = true: 'n';
        this.familyStatus = family.family_status;
        this.familyStatusDate = family.family_status_date;
        this.reportDate = family.report_date;
        this.jobTitleFamily = family.job_title_family;
        this.familyWork = family.family_work;
        this.maritalDate = family.marital_date;
        this.maritalStatus = family.marital_status;

        this.company = family.business_code.business_code;
        this.employee = family.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.getFamilyType();
        this.getGender();
        this.getReligion();
        this.getFamilyStatus();
        this.getMaritalStatus();
      },

      openFormModal() {
        this.isActiveForm = true;
        this.getFamilyType();
        this.getGender();
        this.getReligion();
        this.getFamilyStatus();
        this.getMaritalStatus();
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.familyType = null;
        this.familyNumber = null;
        this.familyName = '';
        this.nickname = '';
        this.birthPlace = '';
        this.birthDate = null;
        this.gender = null;
        this.religion = null;
        this.taxFlag = null;
        this.medFlag = null;
        this.familyStatus = null;
        this.familyStatusDate = null;
        this.reportDate = null;
        this.jobTitleFamily = '';
        this.familyWork = '';
        this.maritalDate = null;
        this.maritalStatus = null;

        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = "";
        this.empolyeeUnit = "";

        this.$nextTick(() => this.$validator.reset())
      },
      storeFamily() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;

          if (this.taxFlag == true) {
            this.taxFlag = 'y';
          } else {
            this.taxFlag = 'n';
          }

          if (this.medFlag == true) {
            this.medFlag = 'y';
          } else {
            this.medFlag = 'n';
          }

          this.$axios
            .post('hcis/api/datafamily', {
              begin_date: this.startDate,
              end_date: this.endDate,
              family_type: this.familyType,
              family_number: this.familyNumber,
              family_name: this.familyName,
              nickname: this.nickname,
              birth_place: this.birthPlace,
              birth_date: this.birthDate,
              gender: this.gender,
              religion: this.religion,
              tax_flag: this.taxFlag,
              med_flag: this.medFlag,
              family_status: this.familyStatus,
              family_status_date: this.familyStatusDate,
              report_date: this.reportDate,
              job_title_family: this.jobTitleFamily,
              family_work: this.familyWork,
              marital_date: this.maritalDate,
              marital_status: this.maritalStatus,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getFamilies();
              this.closeFormModal();
              swal(
                'Saved!',
                'Successfully saved data keluarga.',
                'success'
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      async editFamily(objectIdentifier) {
        await this.getFamily(objectIdentifier);
        this.openFormModal();
      },
      updateFamily() {
        this.$validator.validateAll('datafamily').then(async result => {
          if (!result) return;

          if (this.taxFlag == true) {
            this.taxFlag = 'y';
          } else {
            this.taxFlag = 'n';
          }

          if (this.medFlag == true) {
            this.medFlag = 'y';
          } else {
            this.medFlag = 'n';
          }

          this.$axios
            .put('hcis/api/datafamily', {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              family_type: this.familyType,
              family_number: this.familyNumber,
              family_name: this.familyName,
              nickname: this.nickname,
              birth_place: this.birthPlace,
              birth_date: this.birthDate,
              gender: this.gender,
              religion: this.religion,
              tax_flag: this.taxFlag,
              med_flag: this.medFlag,
              family_status: this.familyStatus,
              family_status_date: this.familyStatusDate,
              report_date: this.reportDate,
              job_title_family: this.jobTitleFamily,
              family_work: this.familyWork,
              marital_date: this.maritalDate,
              marital_status: this.maritalStatus,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getFamilies();
              this.closeFormModal();
              swal(
                'Updated!',
                'Successfully updated data keluarga.',
                'success'
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveFamily() {
        this.objectIdentifier ? this.updateFamily() : this.storeFamily();
      },

      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitFamily(objectIdentifier) {
        this.openFormModalDelimit();
        let family = await this.families.find(
          family => family.object_identifier == objectIdentifier
        );
        this.objectIdentifier = family.object_identifier;
        this.startDate = family.begin_date;
        this.endDate = family.end_date;
      },
      delimitFamily() {
        this.$validator.validateAll('delimit').then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              'hcis/api/datafamily', {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getFamilies();
              this.closeFormModalDelimit();
              swal(
                'Delimited!',
                response.data.message,
                'success'
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },

      deleteFamily(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/datafamily?object_identifier=" + objectIdentifier
              )
              .then(response => {
                swal(
                  "Deleted!",
                  response.data.message,
                  "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeFamily(key);
              });
          }
        });
      },
      removeFamily(key) {
        this.families.splice(key, 1);
      },
      formatDate(date) {
        return moment(date).format('DD/MM/YYYY')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      },

      // getFamily() {
      //   this.$axios.get('users/datafamily?per_page=20')
      //     .then(response => {
      //       this.familys = [];
      //       response.data.data.forEach(async (family, key) => {
      //         await this.familys.push({
      //           startDate: family.begin_date,
      //           endDate: family.end_date,
      //           personalNumber: family.personal_number,
      //           buscd: family.business_code
      //         })
      //       });
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // //  closeFormModal() {
      // //   this.buscd = '';
      // //   this.fullName = '';
      // //   this.$nextTick(() => this.$validator.reset())
      // // },
      // getColumn() {
      //   this.$axios.get('/objects/alltable/DataFamily/column')
      //     .then(response => {
      //       this.columns = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getLogic() {
      //   this.$axios.get('/objects/oprationsql')
      //     .then(response => {
      //       this.logics = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getCondition() {
      //   this.$axios.get('/objects/conditionsql')
      //     .then(response => {
      //       this.conditions = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getSearchDynamic() {
      //   this.paramsearchforms = {
      //     table: "DataFamily", //harcode sesuai form *referensi table_code*
      //     column: this.columns_model,
      //     query: this.logics_model,
      //     value: this.filters_model,
      //     andor: this.conditions_model
      //   }
      //   console.log(this.paramsearchforms)
      //   this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
      //     .then(response => {

      //       this.familys = [];
      //       response.data.data.forEach(async (family, key) => {
      //         await this.familys.push({
      //           startDate: family.begin_date,
      //           endDate: family.end_date,
      //           personalNumber: family.personal_number,
      //           buscd: family.business_code
      //         })
      //       });
      //       console.log(this.familys);
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // // editFamily(personalNumber) {
      // //   this.openFormModal();
      // //   this.getFamilys(personalNumber);
      // // },
      // // async getFamilys(personalNumber) {
      // //   let family = await this.familys.find(family => family.personalNumber == personalNumber);
      // //   this.startDate = family.startDate;
      // //   this.endDate = family.endDate;
      // //   this.personalNumber = family.personalNumber;
      // // },
      // // getCompany() {
      // //   this.$axios.get('/objects/companytoken/')
      // //     .then(response => {
      // //       this.companies = response.data.data;
      // //     })
      // //     .catch(e => {
      // //       console.log(e)
      // //     });
      // // },
      // addNewFormSearch() {
      //   this.searchforms.push({
      //     column: '',
      //     logic: '',
      //     filter: '',
      //     condition: ''
      //   })
      // },
      // deleteFormSearch(key) {
      //   this.searchforms.splice(key, 1)
      // }
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
