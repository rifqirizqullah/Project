<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/family-data/family-search" class="button is-success is-rounded is-pulled-right"><span> <i class="fa fa-search"
          aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-users" aria-hidden="true"></i> DATA KELUARGA
    </h3>
    <div class="box has-text-white has-background-danger">
      Data Keluarga
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearpersonalNumber">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" v-model="personalNumber_query" disabled>
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
      
      
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
    
        <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Formulir Data Keluarga
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date" placeholder="e.g 10-11-2018"
                v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('begin_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date" placeholder="e.g 10-11-2018"
                v-model="endDate" data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Hubungan Keluarga</label>
            <div class="control">
              <div class="select" v-bind:class="{ 'is-danger': errors.has('family_type') }">
                <select name="family_type" class="select" v-model="familyType" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(familyType, key) in familyTypes" :key="key" :value="familyType.object_code">{{
                    familyType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('family_type')" class="help is-danger">{{errors.first('family_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Urut</label>
            <div class="control">
              <input name="family_number" class="input " placeholder="e.g. 1" type="text" v-model="familyNumber"
                v-bind:class="{ 'is-danger': errors.has('family_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('family_number')" class="help is-danger"> {{ errors.first('family_number')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Lengkap</label>
            <div class="control">
              <input name="full_name" class="input " placeholder="e.g. Dino Perdana" type="text" v-model="fullName"
                v-bind:class="{ 'is-danger': errors.has('full_name')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('full_name')" class="help is-danger"> {{ errors.first('full_name')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Panggilan</label>
            <div class="control">
              <input name="nickname" class="input " placeholder="e.g. Dino" type="text" v-model="nickName" v-bind:class="{ 'is-danger': errors.has('nickname')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname')
              }}</p>
          </div>
        </div>
      </div>
      <div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Tempat Lahir</label>
              <div class="control">
                <input name="place_birth" class="input " placeholder="e.g. Tangerang" type="text" v-model="bornCity"
                  v-bind:class="{ 'is-danger': errors.has('place_birth')}" v-validate="'required'">
              </div>
              <p v-show="errors.has('place_birth')" class="help is-danger"> {{ errors.first('place_birth')
                }}</p>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Lahir</label>
              <div class="control">
                <input id="birth_date" data-display-mode="dialog" class="input" name="birth_date" type="date"
                  placeholder="e.g 10-11-2018" v-model="bornDate" data-vv-as="birth date" v-bind:class="{ 'is-danger': errors.has('birth_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('birth_date')" class="help is-danger">{{ errors.first('birth_date') }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Jenis Kelamin</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('gender') }">
                  <select name="gender" class="select" v-model="gender" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(gender, key) in genders" :key="key" :value="gender.object_code">{{
                      gender.object_name
                      }}</option>
                  </select>
                </div>
                <p v-show="errors.has('gender')" class="help is-danger">{{ errors.first('gender') }}</p>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Agama</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('religion') }">
                  <select name="religion" class="select" v-model="religion" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(religion, key) in religions" :key="key" :value="religion.object_code">{{
                      religion.object_name
                      }}</option>
                  </select>
                </div>
                <p v-show="errors.has('religion')" class="help is-danger">{{ errors.first('religion') }}</p>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Status</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_status') }">
                  <select name="family_status" class="select" v-model="familyStatus" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(familyStatus, key) in familiesStatus" :key="key" :value="familyStatus.object_code">{{
                      familyStatus.object_name
                      }}</option>
                  </select>
                </div>
                <p v-show="errors.has('family_status')" class="help is-danger">{{ errors.first('family_status') }}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Status keluarga</label>
              <div class="control">
                <input id="family_status_date" data-display-mode="dialog" class="input" name="family_status_date" type="date"
                  placeholder="e.g 10-11-2018" v-model="familyStatusDate" data-vv-as="family status date" v-bind:class="{ 'is-danger': errors.has('family_status_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('family_status_date')" class="help is-danger">{{ errors.first('family_status_date')
                }}</p>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Lapor</label>
              <div class="control">
                <input id="report_date" data-display-mode="dialog" class="input" name="report_date" type="date"
                  placeholder="e.g 10-11-2018" v-model="reportDate" data-vv-as="report date" v-bind:class="{ 'is-danger': errors.has('family_status_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('report_date')" class="help is-danger">{{ errors.first('report_date') }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Posisi</label>
              <div class="control">
                <input name="position" class="input " placeholder="e.g. Manager " type="text" v-model="position"
                  v-bind:class="{ 'is-danger': errors.has('position')}" v-validate="'required'">
              </div>
              <p v-show="errors.has('position')" class="help is-danger"> {{ errors.first('position')
                }}</p>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Instansi</label>
              <div class="control">
                <input name="company_name" class="input " placeholder="e.g. Telkomsigma " type="text" v-model="companyName"
                  v-bind:class="{ 'is-danger': errors.has('company_name')}" v-validate="'required'">
              </div>
              <p v-show="errors.has('company_name')" class="help is-danger"> {{ errors.first('company_name')
                }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Status Pernikahan</label>
              <div class="control">
                <div class="select " v-bind:class="{ 'is-danger': errors.has('marital_status') }">
                  <select name="marital_status" class="select" v-model="maritalStatus" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(maritalStatus, key) in maritalsStatus" :key="key" :value="maritalStatus.object_code">{{
                      maritalStatus.object_name
                      }}</option>
                  </select>
                </div>
                <p v-show="errors.has('marital_status')" class="help is-danger">{{ errors.first('marital_status') }}</p>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Pernikahan</label>
              <div class="control">
                <input id="marital_date" data-display-mode="dialog" class="input" name="marital date" type="date"
                  placeholder="e.g 10-11-2018" v-model="maritalDate" data-vv-as="Marital date" v-bind:class="{ 'is-danger': errors.has('marital_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('marital_date')" class="help is-danger">{{ errors.first('marital_date') }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column">
            <label for="checkbox" class="checkbox">
              <input type="checkbox" id="recognition" v-model="taxFlag">
              Tanggungan Pajak
            </label>
          </div>
        </div>
        <div class="columns">
          <div class="column">
            <label for="checkbox" class="checkbox">
              <input type="checkbox" id="recognition" v-model="medicalFlag">
              Tanggungan Kesehatan
            </label>
          </div>
          <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
        </div>
        
      </div>
    </div>
    <div class="box" v-for="(component, key) in components" :key="key">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date" placeholder="e.g 10-11-2018"
                v-model="startDate_form[key]" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('begin_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date" placeholder="e.g 10-11-2018"
                v-model="endDate_form[key]" data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Hubungan Keluarga</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_type') }">
                <select name="family_type" class="select" v-model="familyType_form[key]" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(familyType, key) in familyTypes" :key="key" :value="familyType.object_code">{{
                    familyType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('family_type')" class="help is-danger">{{errors.first('family_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Urut</label>
            <div class="control">
              <input name="family_number" class="input " placeholder="e.g. 1" type="text" v-model="familyNumber_form[key]"
                v-bind:class="{ 'is-danger': errors.has('family_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('family_number')" class="help is-danger"> {{ errors.first('family_number')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Lengkap</label>
            <div class="control">
              <input name="full_name" class="input " placeholder="e.g. Dino Perdana" type="text" v-model="fullName_form[key]"
                v-bind:class="{ 'is-danger': errors.has('full_name')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('full_name')" class="help is-danger"> {{ errors.first('full_name')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Panggilan</label>
            <div class="control">
              <input name="nickname" class="input " placeholder="e.g. Dino" type="text" v-model="nickName_form[key]" v-bind:class="{ 'is-danger': errors.has('nickname')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname')
              }}</p>
          </div>
        </div>
      </div>
      <div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Tempat Lahir</label>
              <div class="control">
                <input name="place_birth" class="input " placeholder="e.g. Tangerang" type="text" v-model="bornCity_form[key]"
                  v-bind:class="{ 'is-danger': errors.has('place_birth')}" v-validate="'required'">
              </div>
              <p v-show="errors.has('place_birth')" class="help is-danger"> {{ errors.first('place_birth')
                }}</p>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Lahir</label>
              <div class="control">
                <input id="birth_date" data-display-mode="dialog" class="input" name="birth_date" type="date"
                  placeholder="e.g 10-11-2018" v-model="bornDate_form[key]" data-vv-as="birth date" v-bind:class="{ 'is-danger': errors.has('birth_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('birth_date')" class="help is-danger">{{ errors.first('birth_date') }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Jenis Kelamin</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('gender') }">
                  <select name="gender" class="select" v-model="gender_form[key]" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(gender, key) in genders" :key="key" :value="gender.object_code">{{
                      gender.object_name
                      }}</option>
                  </select>
                </div>
                <p v-show="errors.has('gender')" class="help is-danger">{{ errors.first('gender') }}</p>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Agama</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('religion') }">
                  <select name="religion" class="select" v-model="religion_form[key]" v-validate="'required|included:01,02,03,04,05,06'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(religion, key) in religions" :key="key" :value="religion.object_code">{{
                      religion.object_name
                      }}</option>
                  </select>
                </div>
                <p v-show="errors.has('religion')" class="help is-danger">{{ errors.first('religion') }}</p>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Status</label>
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_status') }">
                  <select name="family_status" class="select" v-model="familyStatus_form[key]" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(familyStatus, key) in familiesStatus" :key="key" :value="familyStatus.object_code">{{
                      familyStatus.object_name
                      }}</option>
                  </select>
                </div>
                <p v-show="errors.has('family_status')" class="help is-danger">{{ errors.first('family_status') }}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Status keluarga</label>
              <div class="control">
                <input id="family_status_date" data-display-mode="dialog" class="input" name="family_status_date" type="date"
                  placeholder="e.g 10-11-2018" v-model="familyStatusDate_form[key]" data-vv-as="family status date" v-bind:class="{ 'is-danger': errors.has('family_status_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('family_status_date')" class="help is-danger">{{ errors.first('family_status_date')
                }}</p>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Lapor</label>
              <div class="control">
                <input id="report_date" data-display-mode="dialog" class="input" name="report_date" type="date"
                  placeholder="e.g 10-11-2018" v-model="reportDate_form[key]" data-vv-as="report date" v-bind:class="{ 'is-danger': errors.has('family_status_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('report_date')" class="help is-danger">{{ errors.first('report_date') }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Posisi</label>
              <div class="control">
                <input name="position" class="input " placeholder="e.g. Manager " type="text" v-model="position_form[key]"
                  v-bind:class="{ 'is-danger': errors.has('position')}" v-validate="'required'">
              </div>
              <p v-show="errors.has('position')" class="help is-danger"> {{ errors.first('position')
                }}</p>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Instansi</label>
              <div class="control">
                <input name="company_name" class="input " placeholder="e.g. Telkomsigma " type="text" v-model="companyName_form[key]"
                  v-bind:class="{ 'is-danger': errors.has('company_name')}" v-validate="'required'">
              </div>
              <p v-show="errors.has('company_name')" class="help is-danger"> {{ errors.first('company_name')
                }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Status Pernikahan</label>
              <div class="control">
                <div class="select " v-bind:class="{ 'is-danger': errors.has('marital_status') }">
                  <select name="marital_status" class="select" v-model="maritalStatus_form[key]" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(maritalStatus, key) in maritalsStatus" :key="key" :value="maritalStatus.object_code">{{
                      maritalStatus.object_name
                      }}</option>
                  </select>
                </div>
                <p v-show="errors.has('marital_status')" class="help is-danger">{{ errors.first('marital_status') }}</p>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Pernikahan</label>
              <div class="control">
                <input id="marital_date" data-display-mode="dialog" class="input" name="marital date" type="date"
                  placeholder="e.g 10-11-2018" v-model="maritalDate_form[key]" data-vv-as="Marital date" v-bind:class="{ 'is-danger': errors.has('marital_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('marital_date')" class="help is-danger">{{ errors.first('marital_date') }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column">
            <label for="checkbox" class="checkbox">
              <input type="checkbox" id="recognition" v-model="taxFlag_form[key]">
              Tanggungan Pajak
            </label>
          </div>
        </div>
        <div class="columns">
          <div class="column">
            <label for="checkbox" class="checkbox">
              <input type="checkbox" id="recognition" v-model="medicalFlag_form[key]">
              Tanggungan Kesehatan
            </label>
          </div>
        </div>
        <a class="button is-danger is-rounded" @click="deleteComponents(key)">Hapus</a> 
      </div>
    </div>
    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Batal</a>
    <a class="button is-link is-rounded">Kembali</a> -->
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        key: null,
        buscd: '',
        name: '',
        personalNumber: null,
        cUnit: '',
        cPosition: '',

        startDate: '',
        endDate: '',
        familyType: '',
        familyNumber: '',
        fullName: '',
        nickName: '',
        bornCity: '',
        bornDate: '',
        gender: '',
        religion: '',
        familyStatus: '',
        familyStatusDate: '',
        reportDate: '',
        position: '',
        companyName: '',
        taxFlag: '',
        medicalFlag: '',
        maritalStatus: '',
        maritalDate: '',

        startDate_form: [],
        endDate_form: [],
        familyType_form: [],
        familyNumber_form: [],
        fullName_form: [],
        nickName_form: [],
        bornCity_form: [],
        bornDate_form: [],
        gender_form: [],
        religion_form: [],
        familyStatus_form: [],
        familyStatusDate_form: [],
        reportDate_form: [],
        position_form: [],
        companyName_form: [],
        taxFlag_form: [],
        medicalFlag_form: [],
        maritalStatus_form: [],
        maritalDate_form: [],

        buscds: [],
        components: [],
        familyTypes: [],
        genders: [],
        religions: [],
        familiesStatus: [],
        maritalsStatus: [],
        families: [],

        personalNumber_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,

        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: "S001257"
        },
        limit: 10,

        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Keluarga'
          },
          {
            name: 'Keluarga'
          },
        ]
      }
    },
    created() {
      this.getGender();
      this.getfamilyTypes();
      this.getReligions();
      this.getFamilyStatus();
      this.getMaritalStatus();
      this.getBUSCD();
      if (this.personalNumber_query != null) {
        this.getData();
      }
    },
    methods: {
      getData() {
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('users/' + this.buscd + '/datafamily/' + this.personalNumber)
          .then(response => {
            this.components = [];
            response.data.data.forEach(async (family, key) => {
              this.components.push({
                begin_date: family.begin_date,
                end_date: family.end_date,
                personal_number: family.personal_number,
                business_code: family.business_code,
                family_type: family.family_type[0].object_id,
                family_number: family.family_number,
                 company_name: family.company_name,
                full_name: family.full_name,
                nickname: family.nickname,
                born_city: family.born_city,
                born_date: family.born_date,
                gender: family.gender[0].object_id,
                religion: family.religion[0].object_id,
                family_status: family.family_status[0].object_id,
                family_status_date: family.family_status_date,
                report_date: family.report_date,
                position: family.position,
                marital_status: family.marital_status[0].object_id,
                marital_date: family.marital_date,
               
                medical_flag: family.medical_flag,
                tax_flag: family.tax_flag,
              });
              this.key = key;
              this.taxFlag_form[this.key] = null;
              this.medicalFlag_form[this.key] = null;
              this.companyName_form[this.key] = family.company_name;
              this.startDate_form[this.key] = family.begin_date;
              this.endDate_form[this.key] = family.end_date;
              this.familyType_form[this.key] = family.family_type[0].object_id;
              this.familyNumber_form[this.key] = family.family_number;
              this.fullName_form[this.key] = family.full_name;
              this.nickName_form[this.key] = family.nickname;
              this.bornCity_form[this.key] = family.born_city;
              this.bornDate_form[this.key] = family.born_date;
              this.gender_form[this.key] = family.gender[0].object_id;
              this.religion_form[this.key] = family.religion[0].object_id;
              this.familyStatus_form[this.key] = family.family_status[0].object_id;
              this.familyStatusDate_form[this.key] = family.family_status_date;
              this.reportDate_form[this.key] = family.report_date;
              this.position_form[this.key] = family.position;
              this.maritalStatus_form[this.key] = family.marital_status[0].object_id;
              this.maritalDate_form[this.key] = family.marital_date;
              (family.tax_flag == 'y') ? this.taxFlag_form[this.key] = true: '';
              (family.medical_flag == 'y') ? this.medicalFlag_form[this.key] = true: '';
              
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('users/' + this.buscd + '/datafamily/' + option.item)
              .then(response => {
                this.components = [];
                response.data.data.forEach((family, key) => {
                  this.components.push({
                    begin_date: family.begin_date,
                    end_date: family.end_date,
                    personal_number: family.personal_number,
                    business_code: family.business_code,
                    family_type: family.family_type[0].object_id,
                    family_number: family.family_number,
                    full_name: family.full_name,
                    nickname: family.nickname,
                    born_city: family.born_city,
                    born_date: family.born_date,
                    gender: family.gender[0].object_id,
                    religion: family.religion[0].object_id,
                    family_status: family.family_status[0].object_id,
                    family_status_date: family.family_status_date,
                    report_date: family.report_date,
                    position: family.position,
                    marital_status: family.marital_status[0].object_id,
                    marital_date: family.marital_date,
                    company_name: family.company_name,
                    medical_flag: family.medical_flag,
                    tax_flag: family.tax_flag,
                  });
                  this.key = key;
                  this.taxFlag_form[this.key] = null;
                  this.medicalFlag_form[this.key] = null;
                  this.startDate_form[this.key] = family.begin_date;
                  this.endDate_form[this.key] = family.end_date;
                  this.familyType_form[this.key] = family.family_type[0].object_id;
                  this.familyNumber_form[this.key] = family.family_number;
                  this.fullName_form[this.key] = family.full_name;
                  this.nickName_form[this.key] = family.nickname;
                  this.bornCity_form[this.key] = family.born_city;
                  this.bornDate_form[this.key] = family.born_date;
                  this.gender_form[this.key] = family.gender[0].object_id;
                  this.religion_form[this.key] = family.religion[0].object_id;
                  this.familyStatus_form[this.key] = family.family_status[0].object_id;
                  this.familyStatusDate_form[this.key] = family.family_status_date;
                  this.reportDate_form[this.key] = family.report_date;
                  this.position_form[this.key] = family.position;
                  this.maritalStatus_form[this.key] = family.marital_status[0].object_id;
                  this.maritalDate_form[this.key] = family.marital_date;
                  (family.tax_flag == 'y') ? this.taxFlag_form[this.key] = true: '';
                  (family.medical_flag == 'y') ? this.medicalFlag_form[this.key] = true: '';
                  this.companyName_form[this.key] = family.company_name;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/'+text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,                
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);
            
            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })
          
          .catch(e => {
            console.log(e);
          }); 
        /* Full control over filtering. Maybe fetch from API?! Up to you!!! */
        
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;


          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            // if (this.components.length > 0) {
            //   var nomor_urut = parseInt(this.familyNumber_form[this.components.length -1])+ 1;
            // } else {
            //   var nomor_urut = 1;
            // }
            if (this.medicalFlag == true) {
              this.medicalFlag = 'y';
            } else {
              this.medicalFlag = '';
            }

            if (this.taxFlag == true) {
              this.taxFlag = 'y';
            } else {
              this.taxFlag = '';
            }             
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              personal_number: this.personalNumber,
              business_code: this.buscd,
              family_type: this.familyType,
              family_number: this.familyNumber,
              full_name: this.fullName,
              nickname: this.nickName,
              born_city: this.bornCity,
              born_date: this.bornDate,
              gender: this.gender,
              religion: this.religion,
              family_status: this.familyStatus,
              family_status_date: this.familyStatusDate,
              report_date: this.reportDate,
              position: this.position,
              marital_status: this.maritalStatus,
              marital_date: this.maritalDate,
              company_name: this.companyName,
              medical_flag: this.medicalFlag,
              tax_flag: this.taxFlag,
            });
            this.components.forEach((family, key) => {
              this.key = key;
              this.taxFlag_form[this.key] = null;
              this.medicalFlag_form[this.key] = null;
              this.startDate_form[this.key] = family.begin_date;
              this.endDate_form[this.key] = family.end_date;
              this.familyType_form[this.key] = family.family_type;
              this.familyNumber_form[this.key] = family.family_number;
              this.fullName_form[this.key] = family.full_name;
              this.nickName_form[this.key] = family.nickname;
              this.bornCity_form[this.key] = family.born_city;
              this.bornDate_form[this.key] = family.born_date;
              this.gender_form[this.key] = family.gender;
              this.religion_form[this.key] = family.religion;
              this.familyStatus_form[this.key] = family.family_status;
              this.familyStatusDate_form[this.key] = family.family_status_date;
              this.reportDate_form[this.key] = family.report_date;
              this.position_form[this.key] = family.position;
              this.maritalStatus_form[this.key] = family.marital_status;
              this.maritalDate_form[this.key] = family.marital_date;
              // this.taxFlag_form[this.key] = family.tax_flag;
              // this.medicalFlag_form[this.key] = family.medical_flag;
              (family.tax_flag == 'y') ? this.taxFlag_form[this.key] = true: '';
              (family.medical_flag == 'y') ? this.medicalFlag_form[this.key] = true: '';
              this.companyName_form[this.key] = family.company_name;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.personalNumber_query == null) {
            if(this.name ==  ''){
              alert('data nik tidak ada');            
            }else{   
              this.components.forEach((childrens, index1) => {

                if (this.taxFlag_form[index1] == true) {
                  this.taxFlag_form[index1] = 'y';
                } else {
                  this.taxFlag_form[index1] = 'n';
                }

                if (this.medicalFlag_form[index1] == true) {
                  this.medicalFlag_form[index1] = 'y';
                } else {
                  this.medicalFlag_form[index1] = 'n';
                }
                Object.assign(this.components[index1], {
                  begin_date: this.startDate_form[index1],
                  end_date: this.endDate_form[index1],
                  family_type: this.familyType_form[index1],
                  family_number: this.familyNumber_form[index1],
                  full_name: this.fullName_form[index1],
                  nickname: this.nickName_form[index1],
                  born_city: this.bornCity_form[index1],
                  born_date: this.bornDate_form[index1],
                  gender: this.gender_form[index1],
                  religion: this.religion_form[index1],
                  family_status: this.familyStatus_form[index1],
                  family_status_date: this.familyStatusDate_form[index1],
                  report_date: this.reportDate_form[index1],
                  position: this.position_form[index1],
                  marital_status: this.maritalStatus_form[index1],
                  marital_date: this.maritalDate_form[index1],
                  company_name: this.companyName_form[index1],
                  medical_flag: this.medicalFlag_form[index1],
                  tax_flag: this.taxFlag_form[index1],
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/datafamily/' + this.personalNumber, this.components)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data Komunikasi.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              if (this.taxFlag_form[index1] == true) {
                  this.taxFlag_form[index1] = 'y';
                } else {
                  this.taxFlag_form[index1] = 'n';
                }

                if (this.medicalFlag_form[index1] == true) {
                  this.medicalFlag_form[index1] = 'y';
                } else {
                  this.medicalFlag_form[index1] = 'n';
                }
              Object.assign(this.components[index1], {
                begin_date: this.startDate_form[index1],
                end_date: this.endDate_form[index1],
                family_type: this.familyType_form[index1],
                family_number: this.familyNumber_form[index1],
                full_name: this.fullName_form[index1],
                nickname: this.nickName_form[index1],
                born_city: this.bornCity_form[index1],
                born_date: this.bornDate_form[index1],
                gender: this.gender_form[index1],
                religion: this.religion_form[index1],
                family_status: this.familyStatus_form[index1],
                family_status_date: this.familyStatusDate_form[index1],
                report_date: this.reportDate_form[index1],
                position: this.position_form[index1],
                marital_status: this.maritalStatus_form[index1],
                marital_date: this.maritalDate_form[index1],
                company_name: this.companyName_form[index1],
                medical_flag: this.medicalFlag_form[index1],
                tax_flag: this.taxFlag_form[index1],
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/datafamily/' + this.personalNumber, this.components)
                  .then(response => {
                    swal(
                      'Saved!',
                      'Successfully saved basic pay.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearpersonalNumber()
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        // var x = 1
        this.components.forEach((family, key) => {
              this.key = key;
              this.taxFlag_form[this.key] = null;
              this.medicalFlag_form[this.key] = null;
              this.startDate_form[this.key] = family.begin_date;
              this.endDate_form[this.key] = family.end_date;
              this.familyType_form[this.key] = family.family_type;
              // family.family_number = x;
              this.familyNumber_form[this.key] = family.family_number;
              this.fullName_form[this.key] = family.full_name;
              this.nickName_form[this.key] = family.nickname;
              this.bornCity_form[this.key] = family.born_city;
              this.bornDate_form[this.key] = family.born_date;
              this.gender_form[this.key] = family.gender;
              this.religion_form[this.key] = family.religion;
              this.familyStatus_form[this.key] = family.family_status;
              this.familyStatusDate_form[this.key] = family.family_status_date;
              this.reportDate_form[this.key] = family.report_date;
              this.position_form[this.key] = family.position;
              this.maritalStatus_form[this.key] = family.marital_status;
              this.maritalDate_form[this.key] = family.marital_date;
              // this.taxFlag_form[this.key] = family.tax_flag;
              // this.medicalFlag_form[this.key] = family.medical_flag;
              (family.tax_flag == 'y') ? this.taxFlag_form[this.key] = true: '';
              (family.medical_flag == 'y') ? this.medicalFlag_form[this.key] = true: '';
              this.companyName_form[this.key] = family.company_name;
              // x++;
            })

      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.startDate = '';
        this.endDate = '';
        this.familyType = '';
        this.familyNumber = '';
        this.fullName = '';
        this.nickName = '';
        this.bornCity = '';
        this.bornDate = '';
        this.gender = '';
        this.religion = '';
        this.familyStatus = '';
        this.familyStatusDate = '';
        this.reportDate = '';
        this.position = '';
        this.companyName = '';
        this.taxFlag = '';
        this.medicalFlag = '';
        this.maritalStatus = '';
        this.maritalDate = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getpersonalNumber() {
        this.$axios.get('/users/personal')
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/DATFM')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },

      getfamilyTypes() {
        this.$axios.get('/users/otype/FAMTY/object')
          .then(response => {
            this.familyTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getGender() {
        this.$axios.get('/users/otype/GENDR/object')
          .then(response => {
            this.genders = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getFamilyStatus() {
        this.$axios.get('/users/otype/FAMST/object')
          .then(response => {
            this.familiesStatus = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getReligions() {
        this.$axios.get('/users/otype/RELIG/object')
          .then(response => {
            this.religions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getMaritalStatus() {
        this.$axios.get('/users/otype/MRTST/object')
          .then(response => {
            this.maritalsStatus = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }
</style>
