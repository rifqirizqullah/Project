<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/family-data/family-communication-search" class="button is-success is-rounded is-pulled-right"><span>  <i class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-phone" aria-hidden="true"></i> Komunikasi / Social Media Keluarga Karyawan
    </h3>
    <div class="box has-text-white has-background-danger">
      Data Karyawan
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearpersonalNumber">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>        
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" v-model="personalNumber_query" disabled>
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Form Komunikasi Keluarga
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date" placeholder="e.g 10-11-2018"
                v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('form.begin_date')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date" placeholder="e.g 10-11-2018"
                v-model="endDate" data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('form.end_date')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Hubungan Keluarga</label>
            <div class="control">
              <div class="select" v-bind:class="{ 'is-danger': errors.has('form.family_type') }">
                <select name="family_type" class="select" v-model="familyType" v-validate="'required'" 
                data-vv-as="family type" data-vv-scope="form" @change="getfamilyNumber()">
                  <option disabled selected>Pilih</option>
                  <option v-for="(familyType, key) in familyTypes" :key="key" :value="familyType.object_code">{{
                    familyType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.family_type')" class="help is-danger">{{errors.first('form.family_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Keluarga</label>
            <div class="control">
              <div class="select " v-bind:class="{ 'is-danger': errors.has('form.family_number') }">
                <select name="family_number" class="select" v-model="familyNumber" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(familyNumber, key) in familyNumbers" :key="key" :value="familyNumber.id">{{
                    familyNumber.name
                    }}</option>
                </select>
              </div>
              
            </div>
            <p v-show="errors.has('form.family_number')" class="help is-danger"> {{ errors.first('form.family_number')
              }}</p>
          </div> 
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Alat Komunikasi</label>
            <div class="control">
              <div class="select " v-bind:class="{ 'is-danger': errors.has('form.communication_type') }">
                <select name="communication_type" class="select" v-model="communicationType" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(communicationType, key) in communicationTypes" :key="key" :value="communicationType.objectId">{{
                    communicationType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.communication_type')" class="help is-danger">{{
                errors.first('form.communication_type')
                }}</p>
            </div>
          </div>
        </div>
        <!-- <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Alat Komunikasi</label>
            <div class="control">
              <input name="serial_number" class="input " placeholder="e.g.1" type="number" v-model="serialNumber"
                v-bind:class="{ 'is-danger': errors.has('serial_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('serial_number')" class="help is-danger"> {{ errors.first('serial_number') }}</p>
          </div>
        </div> -->
      <!-- </div> -->
      <!-- <div class="columns"> -->
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Komunikasi</label>
            <div class="control">
              <input name="communication_number" class="input " placeholder="e.g.0857********" type="text" v-model="communicationNumber"
                v-bind:class="{ 'is-danger': errors.has('form.communication_number')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.communication_number')" class="help is-danger"> {{
              errors.first('form.communication_number') }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
      
    </div>
    <div class="columns">
      <div class="column">
        <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
          <thead>
            <tr>
              <th>Nomor Urut Komunikasi</th>
              <th>Hubungan Keluarga</th>
              <th>Nama Keluarga</th>
              <th>Tipe Alat Komunikasi</th>
              <th>Nomor Komunikasi</th>
              <th>Tanggal Awal Berlaku</th>
              <th>Tanggal Akhir Berlaku</th>
              <th>Aksi</th>
            </tr>
            <tr v-for="(component, key) in components" :key="key">
              <th>
                <input class="input" type="text" placeholder="1" v-model="serial_number_table[key]" disabled>
              </th>
              <th>
                <select name="family_type" class="select" v-model="family_type_input[key]" 
                @change="getFamNumTampung(key,family_type_input[key])">
                  <option disabled selected>Pilih</option>
                  <option v-for="(familyType, key) in familyTypes" :key="key" :value="familyType.object_code">{{
                    familyType.object_name
                    }}</option>
                </select>
              </th>
              <th>              
                <select name="family_number" class="select" v-model="family_number_input[key]">
                  <option disabled selected>Pilih</option>
                  <option v-for="(familyNumber, key) in familyNumbers_tampung[key]" :key="key" :value="familyNumber.family_number">{{
                    familyNumber.full_name
                    }}</option>
                </select>
              </th>
              
              <th>
                <select class="select is-fullwidth" v-model="communication_type_table[key]">
                  <option v-for="(communicationType, key) in communicationTypes" :key="key" :value="communicationType.objectId">{{
                    communicationType.name
                    }}</option>
                </select>
              </th>
              <th>
                <input class="input" type="text" v-model="communication_number_table[key]">
              </th>
              <th>
                <input class="input" type="date" v-model="start_table[key]">
              </th>
              <th>
                <input class="input" type="date" v-model="end_table[key]">
              </th>
              <th><a class="button is-danger is-small is-rounded is-outlined tombolhapus" @click="deleteComponents(key)"><i
                    class="fa fa-trash" aria-hidden="true"></i></a></th>
            </tr>
          </thead>
        </table>
      </div>
    </div>

    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Reset</a>
    <a class="button is-link is-rounded">Kembali</a> -->
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VeeValidate from 'vee-validate';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  import swal from 'sweetalert';

  Vue.use(VeeValidate);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        key: null,

        //untuk data diri
        buscd: '',
        name: '',
        personalNumber: null,
        cUnit: '',
        cPosition: '',
        //

        //v-model form input
        startDate: '',
        endDate: '',
        communicationType: '',
        serialNumber: '',
        communicationNumber: '',
        familyType: '',
        familyNumber: '',
        //

        components: [], //nampung data ditabel/form edit
        communicationTypes: [], //nampung data select
        buscds: [], //nampung data nama perusahaan
        familyTypes:[],
        familyNumbers:[],
        familyNumbers_tampung:[],

        //untuk saat edit diluar
        personalNumber_query: this.$route.query.nik, 
        buscd_query: this.$route.query.buscd,
        //
        
        //variabel untuk tampung data ditabel (edit dalam)
        family_type_input: [],
        family_number_input: [],
        communication_type_table: [],
        communication_number_table: [],
        serial_number_table: [],
        start_table: [],
        end_table: [],
        //

        //bawaan vue suggest
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: "S001257"
        },
        limit: 10,
        //

        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Alat Komunikasi'
          },
        ]
      }
    },
    created() {
      this.getBUSCD();
      this.getfamilyTypes();
      this.getCommunicationTypes();
      if (this.personalNumber_query != null) { //cek jika edit luar
        this.getData();
      }
    },
    methods: {
      getData() {
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('users/' + this.buscd + '/familycommunication/' + this.personalNumber)
          .then(response => {
            this.components = [];
            response.data.data.forEach(async (communication, key) => {
              this.components.push({
                begin_date: communication.begin_date,
                end_date: communication.end_date,
                business_code: communication.business_code,
                personal_number: communication.personal_number,
                family_type : communication.family_type[0].object_id,
		        family_number : communication.family_number[0].family_number,
                communication_type: communication.communication_type[0].object_id,
                serial_number: communication.serial_number,
                communication_number: communication.communication_number,                
              });

              this.key = key,
              this.$axios.get('/users/'+this.buscd+'/selectfamily/'+this.personalNumber+'/type/'+ communication.family_type[0].object_id)
                .then(response => {
                  this.familyNumbers_tampung[key] = response.data.data;
                  this.$forceUpdate();
                })
              this.family_type_input[this.key] = communication.family_type[0].object_id;
              this.family_number_input[this.key] = communication.family_number[0].family_number;
              this.serial_number_table[this.key] = communication.serial_number;
              this.communication_type_table[this.key] = communication.communication_type[0].object_id;
              this.communication_number_table[this.key] = communication.communication_number;
              this.start_table[this.key] = communication.begin_date;
              this.end_table[this.key] = communication.end_date;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('users/' + this.buscd + '/familycommunication/' + option.item)
              .then(response => {
                this.components = [];
                response.data.data.forEach(async (communication, key) => {
                this.components.push({
                    begin_date: communication.begin_date,
                    end_date: communication.end_date,
                    business_code: communication.business_code,
                    personal_number: communication.personal_number,
                    family_type : communication.family_type[0].object_id,
                    family_number : communication.family_number[0].family_number,
                    communication_type: communication.communication_type[0].object_id,
                    serial_number: communication.serial_number,
                    communication_number: communication.communication_number,                
                });

                this.key = key,
                this.$axios.get('/users/'+this.buscd+'/selectfamily/'+this.personalNumber+'/type/'+ communication.family_type[0].object_id)
                    .then(response => {
                    this.familyNumbers_tampung[key] = response.data.data;
                    this.$forceUpdate();
                    })
                this.family_type_input[this.key] = communication.family_type[0].object_id;
                this.family_number_input[this.key] = communication.family_number[0].family_number;
                this.serial_number_table[this.key] = communication.serial_number;
                this.communication_type_table[this.key] = communication.communication_type[0].object_id;
                this.communication_number_table[this.key] = communication.communication_number;
                this.start_table[this.key] = communication.begin_date;
                this.end_table[this.key] = communication.end_date;
                });
            })
            .catch(e => {
                console.log(e);
            });
          }
        }
      },
      onInputChange(text) {
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }

        this.$axios.get('/users/searchlike/'+text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,                
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);
            
            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })
          
          .catch(e => {
            console.log(e);
          }); 
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;

          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            if (this.components.length > 0) {
              var address_num = parseInt(this.serial_number_table[this.components.length -1])+ 1;
            } else {
              var address_num = 1;
            }  
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.personalNumber,
              family_type : this.familyType,
		      family_number : this.familyNumber,
              communication_type: this.communicationType,
              serial_number: address_num,
              communication_number: this.communicationNumber,
            });
            this.components.forEach((user, key) => {
              this.key = key;
                this.$axios.get('/users/'+this.buscd+'/selectfamily/'+this.personalNumber+'/type/'+ user.family_type)
                    .then(response => {
                    this.familyNumbers_tampung[key] = response.data.data;
                    this.$forceUpdate();
                    })
              this.family_type_input[this.key] = user.family_type;
              this.family_number_input[this.key] = user.family_number;
              this.serial_number_table[this.key] = user.serial_number;
              this.communication_type_table[this.key] = user.communication_type;
              this.communication_number_table[this.key] = user.communication_number;
              this.start_table[this.key] = user.begin_date;
              this.end_table[this.key] = user.end_date;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if(this.personalNumber_query == null){            
            if(this.name ==  ''){
              alert('data nik tidak ada');            
            }else{ 
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  serial_number: this.serial_number_table[index1],
                  communication_type: this.communication_type_table[index1],
                  communication_number: this.communication_number_table[index1],
                  family_type : this.family_type_input[index1],
		          family_number : this.family_number_input[index1],
                  begin_date: this.start_table[index1],
                  end_date: this.end_table[index1]
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/familycommunication/' + this.personalNumber, this.components)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data Komunikasi.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              Object.assign(this.components[index1], {
                serial_number: this.serial_number_table[index1],
                communication_type: this.communication_type_table[index1],
                communication_number: this.communication_number_table[index1],
                family_type : this.family_type_input[index1],
		        family_number : this.family_number_input[index1],
                begin_date: this.start_table[index1],
                end_date: this.end_table[index1]
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/basicpay/' + this.personalNumber, this.components)
                  .then(response => {                                           
                    swal(
                      'Saved!',
                      'Successfully saved basic pay.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearpersonalNumber()
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        var x = 1
        this.components.forEach((user, key) => {
            
          this.key = key;
          this.serial_number_table[this.key] = x;
          this.communication_type_table[this.key] = user.communication_type;          
          this.communication_number_table[this.key] = user.communication_number;          
          this.family_type_input[this.key] = user.family_type;
          this.family_number_input[this.key] = user.family_number;
          user.serial_number = x;
          this.start_table[this.key] = user.begin_date;
          this.end_table[this.key] = user.end_date;
          x++;
        })
      },
      getCommunicationTypes() {
        this.$axios.get('/users/otype/COMTY/object')
          .then(response => {
            this.communicationTypes = [];
            response.data.data.forEach((communicationType, key) => {
              this.communicationTypes.push({
                objectId: communicationType.object_code,
                name: communicationType.object_name,
              });
            });
          })
          .catch(e => {
            console.log(e)
          });
      },
      getpersonalNumber() {
        this.$axios.get('/users/personal')
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/COMFM')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getfamilyTypes() {
        this.familyTypes =[];
        this.$axios.get('/users/otype/FAMTY/object')
          .then(response => {
            this.familyTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      async getFamNumTampung(key,famtype) {                   
               
        this.$axios.get('/users/'+this.buscd+'/selectfamily/'+this.personalNumber+'/type/'+ famtype)
          .then(response => {              
            
            this.familyNumbers_tampung[key] = response.data.data;            
            this.$forceUpdate()
            //console.log(familyNumbers_tampung[key])
          })          
          .catch(e => {
            console.log(e);
          });
        
      },
       getfamilyNumber(){
        this.$axios.get('/users/'+this.buscd+'/selectfamily/'+this.personalNumber+'/type/'+ this.familyType)
            .then(response => {
              this.familyNumbers = [];
              response.data.data.forEach((user, key) => {
                this.familyNumbers.push({
                  id: user.family_number, 
                  name: user.full_name,
                  
                });
              });
            })          
            .catch(e => {
              console.log(e);
            });
      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.personalNumber = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.familyType='';
        this.familyNumber='';
        this.communicationType = '';
        this.serialNumber = null;
        this.communicationNumber = null;
        this.$nextTick(() => this.$validator.reset());
      },
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }
</style>
