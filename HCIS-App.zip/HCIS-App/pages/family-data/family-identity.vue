<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="family-identity-search" class="button is-success is-rounded is-pulled-right"><span> <i class="fa fa-search"
          aria-hidden="true"></i> Pencarian </span></nuxt-link><h3 class="subtitle is-3">
      <i class="fa fa-users" aria-hidden="true"></i> Identitas Keluarga
    </h3>
    <div class="box has-text-white has-background-danger">
      Identitas Keluarga
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearpersonalNumber">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" v-model="personalNumber_query" disabled>
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
      
      
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
        <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Formulir Identitas Keluarga </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date" placeholder="10-10-2017"
                v-model="startDate" data-vv-as="start date" v-bind:class="{'is-danger': errors.has ('begin_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" name="end_date" class="input" type="date" placeholder="10-10-2017"
                v-model="endDate" data-vv-as="end date" v-bind:class="{'is-danger': errors.has ('end_date')}"
                v-validate="'required'">
            </div>
          </div>
          <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Hubungan Keluarga</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_type') }">
                <select name="family_type" class="select" v-model="familyType" v-validate="'required'" @change="getValueFamilyType()">
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option v-for="(familyType, key) in familyTypes" :key="key" :value="familyType.object_code">
                    {{familyType.object_name}}
                  </option>                  
                </select>
              </div>
              <p v-show="errors.has('family_type')" class="help is-danger">{{errors.first('family_type') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('name') }">
                <select name="name" class="select" v-model="familyNumber" v-validate="'required'">
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option v-for="(familyNumber, key) in valueFT" :key="key" :value="familyNumber.family_number">
                    {{familyNumber.full_name}}
                  </option>                  
                </select>
              </div>
              <p v-show="errors.has('name')" class="help is-danger">{{errors.first('name') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Identitas</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('identity_type') }">
                <select name="identity_type" class="select" v-model="identityType" v-validate="'required'">
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option v-for="(identityType, key) in identityTypes" :key="key" :value="identityType.object_code">
                    {{identityType.object_name}}
                  </option>
                </select>
              </div>
              <p v-show="errors.has('identity_type')" class="help is-danger">{{errors.first('identity_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Identitas</label>
            <div class="control">
              <input name="identity_number" class="input" type="text" v-model="identityNumber" placeholder="Nomor Identitas"
                v-bind:class="{'is-danger': errors.has('identity_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('identity_number')" class="help is-danger"> {{ errors.first('identity_number')
              }}</p>
          </div>
        </div>
      </div>
      <div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Terbit</label>
              <div class="control">
                <input id="date_publish" data-display-mode="dialog" name="date_publish" class="input" type="date"
                  placeholder="10-10-2017" v-model="datePublish" data-vv-as="date published" v-bind:class="{'is-danger':errors.has('begin_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('date_publish')" class="help is-danger">{{ errors.first('date_publish') }}</p>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal berakhir</label>
              <div class="control">
                <input id="expired" class="input" name="expired_date" v-model="expiredDate" data-vv-as="Expired date"
                  v-bind:class="{ 'is-danger': errors.has('expired_date')}" type="date" placeholder="10-10-2017"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('expired_date')" class="help is-danger">{{ errors.first('expired_date') }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-12">
            <div class="field">
              <label class="label">Tempat Pengeluaran</label>
              <div class="control">
                <input name="publish_place_identity" class="input" type="text" placeholder="Tempat Pengeluaran" v-model="publishPlaceIdentity"
                  data-vv-as="Identity Published Place" v-bind:class="{ 'is-danger': errors.has('publish_place_identity')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('publish_place_identity')" class="help is-danger"> {{
                errors.first('publish_place_identity')}}</p>
            </div>
          </div>
        </div>
        <a class="button is-success is-rounded" @click="tambahComponent()">Tambah</a>
      </div>
    </div>
    <div class="box" v-for="(component, key) in components" :key="key">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date" placeholder="10-10-2017"
                v-model="startDate_form[key]" data-vv-as="start date" v-bind:class="{'is-danger': errors.has ('begin_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" name="end_date" class="input" type="date" placeholder="10-10-2017"
                v-model="endDate_form[key]" data-vv-as="end date" v-bind:class="{'is-danger': errors.has ('end_date')}"
                v-validate="'required'">
            </div>
          </div>
          <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Hubungan Keluarga</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('family_type') }">
                <select name="family_type" class="select" v-model="familyType_form[key]" v-validate="'required'" @change="getValueFamilyType1(key,familyType_form[key])">
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option v-for="(familyType, key) in familyTypes" :key="key" :value="familyType.object_code">
                    {{familyType.object_name}}
                  </option>
                  <p v-show="errors.has('family_type')" class="help is-danger">{{errors.first('family_type') }}</p>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('name') }" v-if="component.famnum_if == 1">
                <select name="name" class="select" v-model="familyNumber_form[key]" v-validate="'required'">
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option v-for="(familyNumber, key) in valueFT1[key]" :key="key" :value="familyNumber.family_number">
                    {{familyNumber.full_name}}
                  </option>                  
                </select>
              </div>
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('name') }" v-else>
                <select name="name" class="select" v-model="familyNumber_form[key]" v-validate="'required'">
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option v-for="(familyNumber, key) in valueFT1_all" :key="key" :value="familyNumber.family_number">
                    {{familyNumber.full_name}}
                  </option>                  
                </select>
              </div>
              <p v-show="errors.has('name')" class="help is-danger">{{errors.first('name') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Identitas</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('identity_type') }">
                <select name="identity_type" class="select" v-model="identityType_form[key]" v-validate="'required'">
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option v-for="(identityType, key) in identityTypes" :key="key" :value="identityType.object_code">
                    {{identityType.object_name}}
                  </option>
                </select>
              </div>
              <p v-show="errors.has('identity_type')" class="help is-danger">{{errors.first('identity_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Identitas</label>
            <div class="control">
              <input name="identity_number" class="input" type="text" v-model="identityNumber_form[key]" placeholder="Nomor Identitas"
                v-bind:class="{'is-danger': errors.has('identity_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('identity_number')" class="help is-danger"> {{ errors.first('identity_number')
              }}</p>
          </div>
        </div>
      </div>
      <div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Terbit</label>
              <div class="control">
                <input id="date_publish" data-display-mode="dialog" name="date_publish" class="input" type="date"
                  placeholder="10-10-2017" v-model="datePublish_form[key]" data-vv-as="date published" v-bind:class="{'is-danger':errors.has('begin_date')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('date_publish')" class="help is-danger">{{ errors.first('date_publish') }}</p>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal berakhir</label>
              <div class="control">
                <input id="expired" class="input" name="expired_date" v-model="expiredDate_form[key]" data-vv-as="Expired date"
                  v-bind:class="{ 'is-danger': errors.has('expired_date')}" type="date" placeholder="10-10-2017"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('expired_date')" class="help is-danger">{{ errors.first('expired_date') }}</p>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-12">
            <div class="field">
              <label class="label">Tempat Pengeluaran</label>
              <div class="control">
                <input name="publish_place_identity" class="input" type="text" placeholder="Tempat Pengeluaran" v-model="publishPlaceIdentity_form[key]"
                  data-vv-as="Identity Published Place" v-bind:class="{ 'is-danger': errors.has('publish_place_identity')}"
                  v-validate="'required'">
              </div>
              <p v-show="errors.has('publish_place_identity')" class="help is-danger"> {{
                errors.first('publish_place_identity')}}</p>
            </div>
          </div>
        </div>
        <a class="button is-danger is-rounded" @click="deleteComponents(key)">Hapus</a>        
      </div>
    </div>    
    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Batal</a>
    <a class="button is-link is-rounded">Kembali</a> -->
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import Vue from 'vue';
  import VeeValidate from 'vee-validate';
  Vue.use(VeeValidate);
  import VueAutosuggest from "vue-autosuggest";
  Vue.use(VueAutosuggest);
  import swal from 'sweetalert';

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        key: null,
        buscd: '',
        name: '',
        personalNumber: null,
        cUnit: '',
        cPosition: '',

        startDate: '',
        endDate: '',
        familyType: '',
        familyNumber: '',
        identityType: '',
        //identityTypes: [], 
        identityNumber: '',
        datePublish: '',
        expiredDate: '',
        publishPlaceIdentity: '',

        startDate_form: [],
        endDate_form: [],
        familyType_form: [],
        familyNumber_form: [],
        identityType_form: [],
        identityNumber_form: [],
        datePublish_form: [],
        expiredDate_form: [],
        publishPlaceIdentity_form: [],

        buscds: [],
        components: [],
        components_input: [],
        familyTypes: [],
        identityTypes: [],
        familyIdentities: [],
        valueFT:[],
        valueFT1:[],
        valueFT1_all:[],

        personalNumber_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,

        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: "S001257"
        },
        limit: 10,

        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Data Keluarga'
          },
          {
            name: 'Identitas Keluarga'
          },
        ]
      }
    },
    created() {
      this.getIdentityTypes();
      this.getFamilyTypes();
      this.getBUSCD();
      
      if (this.personalNumber_query != null) {
        this.getData();
      }
    },
    methods: {
      getAllFamNum(){
        this.$axios.get('/users/'+this.buscd+'/datafamily/'+this.personalNumber)
            .then(response => {
              this.valueFT = response.data.data;              
              
              this.valueFT1_all = response.data.data;
            })          
            .catch(e => {
              console.log(e);
            });
      },
      getValueFamilyType() {
        this.$axios.get('users/' + this.buscd + '/selectfamily/' + this.personalNumber + '/type/' + this.familyType)
          .then(response => {
            this.valueFT = [];
            this.valueFT = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getValueFamilyType1(key,typefamily) {
        this.valueFT1[key] = null
        this.$axios.get('users/' + this.buscd + '/selectfamily/' + this.personalNumber + '/type/' + typefamily)
          .then(response => {
            this.components[key].famnum_if = 1;
            this.valueFT1[key] = response.data.data;
            this.$forceUpdate();
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.getAllFamNum();
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('users/' + this.buscd + '/familyidentification/' + this.personalNumber)
          .then(response => {            
            this.components = [];
            response.data.data.forEach(async (familyIdentity, key) => {
              this.components.push({
                begin_date: familyIdentity.begin_date,
                end_date: familyIdentity.end_date,
                personal_number: familyIdentity.personal_number,
                family_type: familyIdentity.family_type[0].object_id,
                family_number: familyIdentity.family_number[0].family_number,
                identification_type: familyIdentity.identification_type[0].object_id,
                identification_number: familyIdentity.identification_number,
                date_issue: familyIdentity.date_issue,
                expire_date: familyIdentity.expire_date,
                place_issue: familyIdentity.place_issue,
                business_code: familyIdentity.business_code,
                famnum_if : null
              });
              this.key = key;
              // this.$axios.get('users/' + this.buscd + '/selectfamily/' + this.personalNumber + '/type/' + familyIdentity.family_type[0].object_id)
              //   .then(response => {
              //     this.valueFT1[this.key] = response.data.data;
              //     this.$forceUpdate();
              //   })
              this.startDate_form[this.key] = familyIdentity.begin_date;
              this.endDate_form[this.key] = familyIdentity.end_date;
              this.familyType_form[this.key] = familyIdentity.family_type[0].object_id;
              this.familyNumber_form[this.key] = familyIdentity.family_number[0].family_number;
              this.identityType_form[this.key] = familyIdentity.identification_type[0].object_id;
              this.identityNumber_form[this.key] = familyIdentity.identification_number;
              this.datePublish_form[this.key] = familyIdentity.date_issue;
              this.expiredDate_form[this.key] = familyIdentity.expire_date;
              this.publishPlaceIdentity_form[this.key] = familyIdentity.place_issue;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.getAllFamNum();
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('users/' + this.buscd + '/familyidentification/' + option.item)
              .then(response => {
                this.components = [];
                response.data.data.forEach((familyIdentity, key) => {
                  this.components.push({
                    begin_date: familyIdentity.begin_date,
                    end_date: familyIdentity.end_date,
                    personal_number: familyIdentity.personal_number,
                    family_type: familyIdentity.family_type[0].object_id,
                    family_number: familyIdentity.family_number[0].family_number,
                    identification_type: familyIdentity.identification_type[0].object_id,
                    identification_number: familyIdentity.identification_number,
                    date_issue: familyIdentity.date_issue,
                    expire_date: familyIdentity.expire_date,
                    place_issue: familyIdentity.place_issue,
                    business_code: familyIdentity.business_code,
                    famnum_if:null
                  });
                  this.key = key;
                  // this.$axios.get('users/' + this.buscd + '/selectfamily/' + this.personalNumber + '/type/' + familyIdentity.family_type[0].object_id)
                  //   .then(response => {
                  //     this.valueFT1[this.key] = response.data.data;
                  //     this.$forceUpdate();
                  //   })
                  this.startDate_form[this.key] = familyIdentity.begin_date;
                  this.endDate_form[this.key] = familyIdentity.end_date;
                  this.familyType_form[this.key] = familyIdentity.family_type[0].object_id;
                  //this.getValueFamilyType1();
                  this.familyNumber_form[this.key] = familyIdentity.family_number[0].family_number;
                  this.identityType_form[this.key] = familyIdentity.identification_type[0].object_id;
                  this.identityNumber_form[this.key] = familyIdentity.identification_number;
                  this.datePublish_form[this.key] = familyIdentity.date_issue;
                  this.expiredDate_form[this.key] = familyIdentity.expire_date;
                  this.publishPlaceIdentity_form[this.key] = familyIdentity.place_issue;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/'+text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,                
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);
            
            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })
          
          .catch(e => {
            console.log(e);
          }); 
        /* Full control over filtering. Maybe fetch from API?! Up to you!!! */
        
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;


          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.personalNumber,
              family_type: this.familyType,
              family_number: this.familyNumber,
              identification_type: this.identityType,
              identification_number: this.identityNumber,
              date_issue: this.datePublish,
              expire_date: this.expiredDate,
              place_issue: this.publishPlaceIdentity,
              famnum_if : null
            });
            this.components.forEach((familyIdentity, key) => {
              this.key = key;
              // this.$axios.get('users/' + this.buscd + '/selectfamily/' + this.personalNumber + '/type/' + familyIdentity.family_type)
              //   .then(response => {
              //     this.valueFT1[this.key] = response.data.data;
              //     this.$forceUpdate();
              //   })
              this.startDate_form[this.key] = familyIdentity.begin_date;
              this.endDate_form[this.key] = familyIdentity.end_date;
              this.familyType_form[this.key] = familyIdentity.family_type;
              this.familyNumber_form[this.key] = familyIdentity.family_number;
              this.identityType_form[this.key] = familyIdentity.identification_type;
              this.identityNumber_form[this.key] = familyIdentity.identification_number;
              this.datePublish_form[this.key] = familyIdentity.date_issue;
              this.expiredDate_form[this.key] = familyIdentity.expire_date;
              this.publishPlaceIdentity_form[this.key] = familyIdentity.place_issue;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.personalNumber_query == null) {
            if(this.name ==  ''){
              alert('data nik tidak ada');            
            }else{  
              this.components_input=[];  
              this.components.forEach((childrens, index1) => {
                this.components_input.push(
                  {                                                                          
                  begin_date: this.startDate_form[index1],
                  end_date: this.endDate_form[index1],
                  personal_number: this.personalNumber,
                  business_code: this.buscd,
                  family_type: this.familyType_form[index1],
                  family_number: this.familyNumber_form[index1],
                  identification_type: this.identityType_form[index1],
                  identification_number: this.identityNumber_form[index1],
                  date_issue: this.datePublish_form[index1],
                  expire_date: this.expiredDate_form[index1],
                  place_issue: this.publishPlaceIdentity_form[index1],
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/familyidentification/' + this.personalNumber, this.components_input)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data identity keluarga.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components_input=[];  
              this.components.forEach((childrens, index1) => {
                this.components_input.push(
                  {                                                                          
                  begin_date: this.startDate_form[index1],
                  end_date: this.endDate_form[index1],
                  personal_number: this.personalNumber,
                  business_code: this.buscd,
                  family_type: this.familyType_form[index1],
                  family_number: this.familyNumber_form[index1],
                  identification_type: this.identityType_form[index1],
                  identification_number: this.identityNumber_form[index1],
                  date_issue: this.datePublish_form[index1],
                  expire_date: this.expiredDate_form[index1],
                  place_issue: this.publishPlaceIdentity_form[index1],
                });
              });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/familyidentification/' + this.personalNumber, this.components_input)
                  .then(response => {
                    swal(
                      'Saved!',
                      'Sukses menyimpan data identity keluarga.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearpersonalNumber()
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
         this.components.forEach((familyIdentity, key) => {
              this.key = key;             
              this.startDate_form[this.key] = familyIdentity.begin_date;
              this.endDate_form[this.key] = familyIdentity.end_date;
              this.familyType_form[this.key] = familyIdentity.family_type;
              this.familyNumber_form[this.key] = familyIdentity.family_number;
              this.identityType_form[this.key] = familyIdentity.identification_type;
              this.identityNumber_form[this.key] = familyIdentity.identification_number;
              this.datePublish_form[this.key] = familyIdentity.date_issue;
              this.expiredDate_form[this.key] = familyIdentity.expire_date;
              this.publishPlaceIdentity_form[this.key] = familyIdentity.place_issue;
            })
      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.startDate = '';
        this.endDate = '';
        this.personalNumber = null;
        this.familyType = '';
        this.identityType = '';
        this.identityNumber = '';
        this.familyNumber = '';
        this.datePublish = '';
        this.expiredDate = '';
        this.publishPlaceIdentity = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getpersonalNumber() {
        this.$axios.get('/users/personal')
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/IDNFM')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getIdentityTypes() {
        this.$axios.get('/users/otype/IDTYP/object')
          .then(response => {
            this.identityTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getFamilyTypes() {
        this.$axios.get('/users/otype/FAMTY/object')
          .then(response => {
            this.familyTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }
</style>
