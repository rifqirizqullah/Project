<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <a class="button is-link is-rounded is-pulled-right" @click="clearDetail();openFormModal()">
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data
      </span>
    </a>
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card" aria-hidden="true"></i> Data Alamat Keluarga Karyawan
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{column.column_name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{logic.name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{condition.name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column">
            <div v-if="key==0">
              <br>
              <a class="button is-success is-rounded is-outlined is-pulled-right" @click="addSearchForm()"><i
                  class="fa fa-plus"></i></a>
            </div>
            <div v-else>
              <br>
              <a class="button is-danger is-rounded is-outlined is-pulled-right" @click="deleteSearchForm(key)"><i
                  class="fa fa-trash"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-rounded is-success is-pulled-right" @click="getSearchDynamic()"><span><i
                class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Alamat</th>
          <th>Tipe Alamat</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(item, key) in familyAddress.list" :key="key">
          <td>{{ key + 1 }}</td>
          <td>{{ item.business_code.company_name }}</td>
          <td>{{ item.personnel_number.personnel_number }}</td>
          <td>{{ item.business_code.street }}</td>
          <td>{{ item.address_type.object_name }}</td>
          <td>{{ formatDate(item.begin_date) }}</td>
          <td>{{ formatDate(item.end_date) }}</td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="showUpdateForm(item.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="deleteData(item.object_identifier, key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitForm(item.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>

    <pagination :state="familyAddress" :offset="5" :storeModuleName="'familyAddress'" />

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <familyAddressForm :isActiveForm="isActiveForm" v-if="isActiveForm == true" />
    </div>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Delimit Data</p>
          <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="begin_date" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                    data-vv-scope="delimit" disabled>
                </div>
                <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                  {{ errors.first('delimit.begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="end_date" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                    data-vv-scope="delimit">
                </div>
                <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                  {{ errors.first('delimit.end_date') }}
                </p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="delimitData()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from "~/components/Breadcrumb";
  import {
    mapState,
    mapActions
  } from "vuex";
  import familyAddressForm from "@@/components/forms/familyAddressForm";
  import pagination from "@@/components/paginationBar";
  import moment from "moment";

  export default {
    components: {
      familyAddressForm,
      Breadcrumb,
      pagination
    },
    data() {
      return {
        begin_date: null,
        end_date: null,
        isActiveForm: false,
        isActiveFormDelimit: false,

        columns_model: [],
        logics_model: [],
        filters_model: [],
        conditions_model: [],
        columns: [],
        logics: [],
        conditions: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],

        breadcumbs: [{
            name: "Beranda"
          },
          {
            name: "Keluarga"
          },
          {
            name: "Alamat Keluarga"
          }
        ]
      };
    },
    created() {
      this.$store.dispatch("familyAddress/getAll");
      this.$store.dispatch("companies/getAll");
    },
    computed: {
      ...mapState(['familyAddress', 'companies'])
    },
    methods: {
      ...mapActions({
        getDetail: "familyAddress/getDetail",
        clearDetail: "familyAddress/clearDetail",
        deleteOne: "familyAddress/deleteOne",
        getAll: "familyAddress/getAll"
      }),
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false
      },

      showUpdateForm(object_identifier) {
        this.getDetail(object_identifier);
        this.openFormModal();
      },

      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
      },

      async showDelimitForm(object_identifier) {
        await this.getDetail(object_identifier);
        this.begin_date = this.familyAddress.detail.begin_date;
        this.end_date = this.familyAddress.detail.end_date;
        this.openFormModalDelimit();
      },
      delimitData() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/familyaddress", {}, {
                params: {
                  object_identifier: this.familyAddress.detail.object_identifier,
                  end_date: this.end_date
                }
              }
            )
            .then(response => {
              this.$store.dispatch("familyAddress/getAll");
              this.closeFormModalDelimit();
              swal("Delimited!", response.data.message, "success");
            })
            .catch(e => {
              console.log(e.response);
            });
        });
      },

      deleteData(id, index) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          buttons: true,
          dangerMode: true,
          showCancelButton: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete("hcis/api/familyaddress?object_identifier=" + id)
              .then(response => {
                swal(
                  "Deleted!",
                  response.data.message,
                  "success"
                );
                this.deleteOne(index);
              })
              .catch(e => {
                console.log(e.response);
              });
          }
        });
      },
      formatDate(date) {
        return moment(date).format('DD/MM/YYYY')
      }
    },
    middleware: ["auth"]
  };

</script>

<style>
  .has-background-danger {
    background-color: #6d6d6d !important;
  }

  .button.is-danger {
    background-color: #ce1000;
    border-color: transparent;
    color: #fff;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>

