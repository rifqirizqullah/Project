<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-random" aria-hidden="true"></i> Manajemen Hak Akses
    </h3>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                <select name="nama_perusahaan" class="select" v-model="company" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in companies" :key="key" :value="company.business_code">{{
                    company.company_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-6">
          <div class="field">
            <label class="label">Start Date</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-6">
          <div class="field">
            <label class="label">End Date</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-6">
          <div class="field">
            <label class="label">Nama Role Code</label>
            <div class="control">
              <input name="nickname" class="input " placeholder="" type="text" v-model="roleCode" v-bind:class="{ 'is-danger': errors.has('nickname')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname') }}</p>
          </div>
        </div>
        <div class="column is-6">
          <div class="field">
            <label class="label">Nama Role Name</label>
            <div class="control">
              <input name="nickname" class="input " placeholder="" type="text" v-model="roleName" v-bind:class="{ 'is-danger': errors.has('nickname')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname') }}</p>
          </div>
        </div>
      </div>
      <div class="box">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Menu</label>
              <div class="control">
                <div class="select">
                  <select v-model="menu[key]" @change="check(menu[key])">
                    <option v-for="(column, key) in roles" :key="key" :value="column.object_code">
                      {{ column.access }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <div class="select">
                  <select v-model="role[key]">
                    <option value="R">
                      Read
                    </option>
                    <option value="W">
                      Write
                    </option>
                    <option value="*">
                      Read and Write
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>          
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
      <!-- <table class="table is-striped is-narrow is-hoverable is-fullwidth">
        <thead>
          <tr>
            <th>No.</th>
            <th>Nama Menu</th>
            <th>Write(W)</th>
            <th>Read(R)</th>
            <th>All(*)</th>      
          </tr>
          <tr v-for="(role, key) in roles" :key="key">
            <input type="hidden" :value="role.object_code" :v-model="objectCode[key]">
            <td>{{key+1}}</td>
            <td>{{role.access}}</td>            
            <td>              
              <div class="control">
                <label class="radio">
                <input type="radio" v-model="acces[key]" value="W">
              </label>
              </div>
            </td>
            <td>
              <div class="control">
                <label class="radio">
                  <input type="radio" v-model="acces[key]" value="R">
                </label>
              </div>
            </td>
            <td>
              <div class="control">
                <label class="radio">
                  <input type="radio" v-model="acces[key]" value="*">
                </label>
              </div>
            </td>
            
          </tr>
        </thead>
      </table> -->
    </div>
    <a class="button is-success is-rounded" @click="storeEmployee()">Simpan</a>
    <nuxt-link to="/manajemen/role"><a class="button is-danger is-rounded">Kembali</a></nuxt-link>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {                
        startDate: '',
        endDate: '',
        roleCode:'',
        roleName:'',
        company:'',          
        code: this.$route.query.code,              
        roles: [],
        companies: [],
        menu: [],
        role:[],
        searchforms: [{
          object_code: '',
          action: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'Hak Akses'
          }
        ],        
      }
    },
    created() {
      this.getRole();
      this.getCompany();
      if(this.code != null){
        this.getData();
      }
    },
    methods: {      
        getData(){
          this.$axios.get('roles/management/'+this.code)
          .then(response => { 
            this.startDate = response.data.data[0].begin_date;           
            this.endDate = response.data.data[0].end_date;                       
            this.company = response.data.data[0].business_code;                       
            this.roleCode = response.data.data[0].role_code;                       
            this.roleName = response.data.data[0].role_name;                       
            response.data.data[0].access.forEach(async (role, key) => {
              this.menu[key] = role.object_type[0].object_code;
              this.role[key] = role.action;
            });
          this.searchforms =[];
          this.role.forEach((user, key) => {
            
            this.searchforms.push({
              object_type: this.menu[key],
              action: this.role[key]
            });
          })  

          })
          .catch(e => {
            console.log(e);
          });
        },
        storeEmployee() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.searchforms=[];
          this.role.forEach(async (role, key) => {
              await this.searchforms.push({
                object_type:this.menu[key],
                action:this.role[key]
              })
          });          
          if (this.code != null) {
            this.$axios.post('/roles/management/'+this.code,{
              begin_date: this.startDate,
              end_date: this.endDate,
              role_code: this.roleCode,
              role_name: this.roleName,
              application_id : "1",
              business_code: this.company,
              access: this.searchforms,
            })
            .then(response => {
              //this.resetForm();
              swal(
                'Saved!',
                'Successfully saved Data.',
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            });  
          } else {
            this.$axios.post('/roles/management',{
              begin_date: this.startDate,
              end_date: this.endDate,
              role_code: this.roleCode,
              role_name: this.roleName,
              application_id : "1",
              business_code: this.company,
              access: this.searchforms,
            })
            .then(response => {
              this.resetForm();
              swal(
                'Saved!',
                'Successfully saved Data.',
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            });
          }
          
        });
      },
      getRole() {
        this.$axios.get('objects/codemenu')
          .then(response => {
            this.roles = [];
            response.data.data.forEach(async (role, key) => {
              await this.roles.push({                
                object_code: role.object_code,
                access: role.table_name
              })
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getCompany() {
        this.$axios.get('/objects/companytoken/ROLMN')
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      check(value){        
        this.menu_filter = this.menu
        this.menu_filter.pop();
         var found = this.menu_filter.some(function (el) {
            return el === value;
          });      
        if (found) {
          alert('data sudah ada')
        } else {
          this.menu.push(
            value
          )
        }

      },
      addNewFormSearch() {        
        this.searchforms =[];                
        this.role.forEach((user, key) => {          
          this.searchforms.push({
            object_type: this.menu[key],
            action: this.role[key]
          });
        })
                
        this.searchforms.push({
          object_type: '',
          action: ''
        })  
        
        console.log(this.searchforms)
        console.log(this.role)
        console.log(this.menu)
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
        this.role.splice(key, 1)
        this.menu.splice(key, 1)        
        console.log(this.searchforms)
        console.log(this.role)
        console.log(this.menu)
        this.role.forEach((user, key) => {
          this.menu[key] = this.menu[key];
          this.role[key] = this.role[key];
        })
        
      },
      resetForm(){
        this.startDate = '',
        this.endDate = '',
        this.company = '',
        this.roleCode = '',
        this.roleName = '',
        this.searchforms = [{
          object_code: '',
          action: ''
        }],
        this.role = [],
        this.menu = [] 
        this.$nextTick(() => this.$validator.reset());
      }                  
    }
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
