<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-random" aria-hidden="true"></i> Manajemen Hak Akses 
    </h3>
    <nuxt-link to="/manajemen/role/role-edit"><a class="button is-link is-rounded">Tambah Data</a>
    </nuxt-link>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Kode Hak Akses</th>
          <th>Akses</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(role, key) in roles" :key="key">
          <td> {{key+1}} </td>
          <td> {{role.startDate}} </td>
          <td> {{role.endDate}} </td> 
          <td> {{role.roleCode}}</td>
          <td> <div v-for="(access, key) in role.access" :key="key">- {{access.object_type[0].table_name}} ( {{access.action}} ) </div> </td>
           <th>
            <nuxt-link :to="'role/role-edit?code='+role.roleCode">
              <a class="button is-success is-small is-outlined is-rounded"><i class="fa fa-pencil" aria-hidden="true"></i></a>
            </nuxt-link>
            <a class="button is-danger is-small is-outlined is-rounded" @click="role.roleCode ? deleteA(key, role.roleCode) : remove(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a>
          </th>
        </tr>
      </thead>
    </table>
    <!-- <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm}">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Edit Data</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Start Date</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('begin_date')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">End Date</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date" placeholder="e.g 10-11-2018"
                    v-model="endDate" data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                    <select name="nama_perusahaan" class="select" v-model="company" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">{{
                        company.company_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Object Type</label>
                <div class="control">
                  <input name="full_name" class="input " placeholder="Object Type" type="text" v-model="fullName"
                    v-bind:class="{ 'is-danger': errors.has('full_name')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('full_name')" class="help is-danger"> {{ errors.first('full_name') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Object Code</label>
                <div class="control">
                  <input name="nickname" class="input " placeholder="Object Code" type="text" v-model="nickName"
                    v-bind:class="{ 'is-danger': errors.has('nickname')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname') }}</p>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Business Area</label>
                <div class="control">
                  <input name="birth_place" class="input " placeholder="Business Area" type="text" v-model="birthPlace"
                    v-bind:class="{ 'is-danger': errors.has('birth_place')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('birth_place')" class="help is-danger"> {{ errors.first('birth_place') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
             <div class="column is-6">
              <div class="field">
                <label class="label">Personel Area</label> 
                <div class="control">
                  <input name="born_date" class="input " placeholder="Personel Area" type="text" v-model="birthDate"
                    v-bind:class="{ 'is-danger': errors.has('born_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('born_date')" class="help is-danger"> {{ errors.first('born_date') }}</p>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Personel Sub Area</label>
                <div class="control">
                  <input name="born_date" class="input " placeholder="Personel Sub Area" type="text" v-model="birthDate"
                    v-bind:class="{ 'is-danger': errors.has('born_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('born_date')" class="help is-danger"> {{ errors.first('born_date') }}</p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveEmployee()" class="button is-link">Save</button>
            <button class="button" @click="closeFormModal()">Cancel</button>
          </div>
        </footer>
      </div>
    </div> -->
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        nikAuth: this.$auth.user.nik,
        key: null,
        startDate: '',
        endDate: '',
        businessCode: '1000',
        personalNumber: '',
        businessarea:'',
        buscd:'',
        access:[],
        fullName: '',
        accounts: [],
        columns:[],
        roles:[],
        companies:[],
        logics:[],
        conditions:[],
        filters:[],
        paramsearchforms:'',
        columns_model:[],
        filters_model:[],
        conditions_model:[],
        logics_model:[],
        bankByCodes: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'Hak Akses'
          }
        ],
        isActiveForm:false,
      }
    },
    created() {
      this.getRole();
      // this.getCompany();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
    },
    methods: {
       openFormModal() {
        this.isActiveForm = true;
      },
      getRole() {
        this.$axios.get('roles/management')
          .then(response => {
            this.roles = [];
            response.data.data.forEach(async (role, key) => {
              await this.roles.push({
                startDate: role.begin_date,
                endDate: role.end_date,
                roleCode: role.role_code,
                access: role.access
              })
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      deleteA(key, id) {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.post('roles/management/' + id, null)
              .then(response => {
                swal(
                  'Deleted!',
                  response.data.message,
                  'success'
                )
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.remove(key);
              })
          }

        });
      },
      remove(key) {
        this.roles.splice(key, 1);
      }
    }
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>