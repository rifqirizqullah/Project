<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-money" aria-hidden="true"></i> Relasi
    </h3>
    
    <div class="columns">        
        <div class="column is-narrow">
            <div class="field">
              <div class="select">
                <select v-model="otype" @change="getObject">            
                  <option v-for="(otype, index) in otypes" :key="index" :value="otype.id">{{otype.name}}</option>                                      
                </select>
              </div>
            </div>   
        </div>
        <div class="column is-narrow">
            <div class="field">
              <div class="select">
                <select v-model="object" @change="getRelat">                  
                  <option v-for="(object, index) in objects" :key="index" :value="object.id">{{object.name}}</option>                  
                </select>
              </div>
            </div> 
        </div>
        
      </div>
      <a v-if="object != null" class="button is-pulled-left is-link is-rounded" @click="openFormModal()">Tambah Data</a>
    <br><br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Otype Parent</th>
          <th>Obyek Parent</th>
          <th>Kode Perusahaan</th>
          <th>Otype Child</th>
          <th>Obyek Child</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(relat, key) in relats" :key="key">
          <th> {{key+1}} </th>
          <th> {{relat.otype_code_parent}} </th>
          <th> {{relat.object_code_parent}} </th>
          <th> {{relat.business_code}}</th>
          <th> {{relat.object_code_child.otype_code}}</th>
          <th> {{relat.object_code_child.object_code}}</th>
          <td>
            <a class="button is-danger is-outlined is-rounded" @click="relat.object_code_child.object_code ? deleteRelat(key, relat.otype_code_parent,relat.object_code_parent,relat.object_code_child.otype_code,relat.object_code_child.object_code) : removeRelat(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a>
          </td>
        </tr>
      </thead>
    </table>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Form Data</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">          
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                    <select name="nama_perusahaan" class="select" v-model="business_code" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(buscd, key) in companies" :key="key" :value="buscd.business_code">{{
                        buscd.company_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan')
                    }}</p>
                </div>
              </div>
            </div>            
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Otype</label>
                <div class="control">
                  <div class="select " v-bind:class="{ 'is-danger': errors.has('country') }">
                    <select name="country" class="select" v-model="otype_child" v-validate="'required'" @change="getObjectChild">
                      
                      <option v-for="(buscd, key) in otypes" :key="key" :value="buscd.id">{{
                        buscd.name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('country')" class="help is-danger">{{ errors.first('country')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Object</label>
                <div class="control">
                  <div class="select " v-bind:class="{ 'is-danger': errors.has('Object') }">
                    <select name="Object" class="select" v-model="object_child" v-validate="'required'">                      
                      <option value="*">Semua</option>
                      <option v-for="(buscd, key) in objects_child" :key="key" :value="buscd.id">{{
                        buscd.name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('Object')" class="help is-danger">{{ errors.first('Object')
                    }}</p>
                </div>
              </div>
            </div>   
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="storeComponent()" class="button is-link">Save</button>
            <button class="button" @click="closeFormModal()">Cancel</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {               
        business_code: null,       
        otype:null,
        object:null,
        otype_child:null,
        object_child:null,
        otypes:[],
        objects:[],
        objects_child:[],
        relats:[],
        companies:[],
        plan_version:'01',
        relty:'A',
        relco:'001',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'Relasi'
          }
        ],
        isActiveForm: false,
      }
    },
    created() {
      this.getOtype();
      this.getCompany();            
    },
    methods: {
      getCompany() {
        this.$axios.get('/objects/companytoken/BUILD')
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getOtype() {
        this.$axios.get('/users/otype')
          .then(response => {
            this.otypes = [];
            response.data.data.forEach(async (jobFunction, key) => {
              await this.otypes.push({
                id: jobFunction.otype_code,
                name: jobFunction.otype_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getObject() {
        this.$axios.get('/users/otype/'+this.otype+'/object')
          .then(response => {
            this.objects = [];
            response.data.data.forEach(async (jobFunction, key) => {
              await this.objects.push({
                id: jobFunction.object_code,
                name: jobFunction.object_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getObjectChild() {
        this.$axios.get('/users/otype/'+this.otype_child+'/object')
          .then(response => {
            this.objects_child = [];
            response.data.data.forEach(async (jobFunction, key) => {
              await this.objects_child.push({
                id: jobFunction.object_code,
                name: jobFunction.object_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getRelat() {
        await this.$axios.get('users/otype/'+this.otype+'/object/'+this.object+'/relation')
          .then(response => {
            this.relats = [];
            response.data.data.forEach(async (relat, key) => {
              await this.relats.push({
                business_code: relat.business_code,
                otype_code_parent: relat.otype_code_parent,
                object_code_parent: relat.object_code_parent,                                
                object_code_child: relat.object_code_child                
              });
            });            
          })
          .catch(e => {
            console.log(e);
          });
      },
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.business_code =null;
        this.otype_child = null;
        this.object_child = null;        
        this.$nextTick(() => this.$validator.reset())
      },            
       storeComponent() {                                 
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {                  
                  this.$axios.post('users/otype/'+this.otype+'/object/'+this.object+'/relation',
                  {
                    business_code: this.business_code, 
                    plan_version: this.plan_version,
                    relty : this.relty,
                    relco : this.relco,
                    otype_code_child : this.otype_child,
                    object_code_child : this.object_child                    
                  })
                    .then(response => {                                                                                                
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                      this.closeFormModal();
                      this.getRelat()
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });            
            },                  
            
      deleteRelat(key,otype,object,otype_child,object_child) {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.post('users/otype/'+otype+'/object/'+object+'/relation/'+otype_child+'/object/'+object_child,null)
            .then(response => {
              swal(
                'Deleted!',
                response.data.message,
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            })
            .then(() => {
              this.removeRelat(key);
            })
          }
          
        });
      },
       removeRelat(key) {
        this.relats.splice(key, 1);
      },
    
  }
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
