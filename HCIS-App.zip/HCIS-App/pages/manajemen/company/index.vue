<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="company/company-search" class="button is-success is-rounded is-pulled-right"><span> <i class="fa fa-search"
          aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-building" aria-hidden="true"></i> Company
    </h3>
    <div class="box has-text-white has-background-danger">
      Data Karyawan BUMN
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="control">
              <div class="select " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                <select name="nama_perusahaan" class="select" v-model="company" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in companies" :key="key" :value="company.business_code">{{
                    company.company_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berlaku</label>
            <div class="control">
              <input class="input" type="text">
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berlaku</label>
            <div class="control">
              <input class="input" type="text">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">S.d</label>
            <div class="control">
              <input class="input" type="date">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Company
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Alamat Perusahaan</label>
            <div class="control">
              <input class="input" type="text" placeholder="Alamat Perusahaan">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kota</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('ps_area') }">
                <select name="ps_area" class="select" v-model="psArea" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(psArea, key) in psAreas" :key="key" :value="psArea.object_id">{{
                    psArea.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('ps_area')" class="help is-danger">{{errors.first('ps_area')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">State Id</label>
            <div class="control">
              <input class="input" type="text" placeholder="State Id">
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">City Id</label>
            <div class="control">
              <input class="input" type="number" placeholder="City Id">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kode Pos</label>
            <div class="control">
              <input class="input" type="text" placeholder="Kode Pos">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Telephone</label>
            <div class="control">
              <input class="input" type="number" placeholder="Nomor Telephone">
            </div>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded" @click="saveEmployeeLevel()">Simpan</a>
    <a class="button is-danger is-rounded">Reset</a>
    <a class="button is-link is-rounded">Kembali</a>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        nikAuth: this.$auth.user.nik,
        key: null,
        startDate: '',
        endDate: '',
        company: '',
        personalNumber: '',
        psType: '',
        psArea: '',
        psGroup: '',
        psLevel: '',
        psTypes: [],
        psAreas: [],
        psGroups: [],
        psLevels: [],
        employeeLevels: [],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'Company'
          },
        ]
      }
    },
    created() {
      this.getPsType();
      this.getPsArea();
      this.getPsGroup();
      this.getPsLevel();
      this.getCompany();
    },
    methods: {
      resetForm() {
        this.key = null;
        this.startDate = '';
        this.endDate = '';
        this.businessaCode = '';
        this.personalNumber = null;
        this.psType = '';
        this.psArea = '';
        this.psGroup = '';
        this.psLevel = '';
        this.$nextTick(() => this.$validator.reset())
      },
      getBasicLevel(personalNumber) {
        this.$axios.get('users/' + this.nikAuth + '/basiclevel/' + this.personalNumber)
          .then(response => {
            if (response.data.data.length > 0) {
              this.employeeLevels = [];
              response.data.data.forEach(async (employeeLevel, key) => {
                //console.log(employeeLevel.ps)
                await this.employeeLevels.push({
                  startDate: employeeLevel.begin_date,
                  endDate: employeeLevel.end_date,
                  personalNumber: employeeLevel.personal_number,
                  psType: employeeLevel.ps_type[0].object_id,
                  psArea: employeeLevel.ps_area[0].object_id,
                  psGroup: employeeLevel.ps_group[0].object_id,
                  psLevel: employeeLevel.ps_level[0].object_id,
                  nikAuth: employeeLevel.change_user,
                })
              })
              this.getbasic(personalNumber);
            } else {
              this.resetFormSearch();
            }

          })
          .catch(e => {
            console.log(e);
          });
      },
      async getbasic(personalNumber) {
        let employeeLevel = await this.employeeLevels.find(employeeLevel => employeeLevel.personalNumber ==
          personalNumber);
        this.startDate = employeeLevel.startDate;
        this.endDate = employeeLevel.endDate;
        this.personalNumber = employeeLevel.personalNumber;
        this.psType = employeeLevel.psType;
        this.psArea = employeeLevel.psArea;
        this.psGroup = employeeLevel.psGroup;
        this.psLevel = employeeLevel.psLevel;
        this.nikAuth = employeeLevel.nikAuth;
      },
      getPsType() {
        this.$axios.get('/objects/payscaletype')
          .then(response => {
            this.psTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPsArea() {
        this.$axios.get('/objects/payscalearea')
          .then(response => {
            this.psAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPsGroup() {
        this.$axios.get('/objects/payscalegroup')
          .then(response => {
            this.psGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPsLevel() {
        this.$axios.get('/objects/payscalelevel')
          .then(response => {
            this.psLevels = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCompany() {
        this.$axios.get('/objects/companytoken')
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      saveEmployeeLevel() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          if (this.key != null) {
            this.employeeLevels[this.key] = {
              key: this.key,
              startDate: this.startDate,
              endDate: this.endDate,
              company: this.company,
              personalNumber: this.personalNumber,
              psType: this.psType,
              psArea: this.psArea,
              psGroup: this.psGroup,
              psLevel: this.psLevel,
              //   nikAuth: this.nikAuth
            }
          } else {
            await this.employeeLevels.push({
              key: this.key,
              startDate: this.startDate,
              endDate: this.endDate,
              company: this.company,
              personalNumber: this.personalNumber,
              psType: this.psType,
              psArea: this.psArea,
              psGroup: this.psGroup,
              psLevel: this.psLevel,
              //   nikAuth: this.nikAuth
            })
          }
          this.storeEmployeeLevel(this.personalNumber);
          this.resetForm();
          swal(
            'Saved!',
            'Successfully saved tingakat karyawan.',
            'success'
          )
        });
      },
      async storeEmployeeLevel(personalNm) {
        let employeeLevels = await this.employeeLevels.map(employeeLevel => {
          return {
            begin_date: employeeLevel.startDate,
            end_date: employeeLevel.endDate,
            business_code: employeeLevel.businessCode,
            personal_number: employeeLevel.personalNumber,
            ps_type: employeeLevel.psType,
            ps_area: employeeLevel.psArea,
            ps_group: employeeLevel.psGroup,
            ps_level: employeeLevel.psLevel,
            // change_user: employeeLevel.nikAuth
          };
        });
        var employeebasic = [employeeLevels[employeeLevels.length - 1]]
        this.$axios.post('/users/' + this.company + '/basiclevel/' + personalNm, employeebasic)
          .then(response => {
            this.employeeLevels = [];
            response.data.data.forEach((employeeLevel, key) => {
              this.employeeLevels.push({
                key: key,
                startDate: employeeLevel.begin_date,
                endDate: employeeLevel.end_date,
                company: employeeLevel.business_code,
                personalNumber: employeeLevel.personal_number,
                psType: employeeLevel.ps_type,
                psArea: employeeLevel.ps_area,
                psGroup: employeeLevel.ps_group,
                psLevel: employeeLevel.ps_level,
                // nikAuth: employeeLevel.change_user
              });
            });
          })
          .catch(e => {
            console.log(e);
          })
      },
    }
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
