<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>

    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> 
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data 
        </span>
    </a>

    <h3 class="subtitle is-3">
      <i class="fa fa-bar-chart"></i> Pencarian Data Manajemen Perusahaan
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Nama Perusahaan</th>
          <th>Kode Perusahaan</th>
          <th>Alamat</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(comManage, key) in comManages" :key="key">
          <td> {{key+1}} </td>
          <td> {{comManage.company_name}}</td>
          <td> {{comManage.business_code}}</td>
          <td> {{comManage.street}}</td>
          <td> {{formatDate(comManage.begin_date)}} </td>
          <td> {{formatDate(comManage.end_date)}} </td>
          <td>
           <a class="button is-success is-small is-outlined is-rounded"
              @click="editcomManage(comManage.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="comManage.object_identifier ? deletecomManage(key, comManage.object_identifier) : removecomManage(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitcomManage(comManage.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>
    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getcomManages()"></pagination>

 <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Manajemen Perusahaan</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nama Perusahaan</label>
                  <div class="control">
                    <input name="company_name" class="input" placeholder="Nama Perusahaan" type="text" v-model="company"
                       v-bind:class="{ 'is-danger': errors.has('company_name')}"
                      v-validate="'required'">
                  </div>
                  <p v-show="errors.has('company_name')" class="help is-danger">{{ errors.first('company_name') }}</p>
                </div>
              </div>
              <div class="column">
                  <div class="field">
                    <label class="label">Kode Perusahaan</label>
                    <div class="control">
                      <input name="business_code" class="input" placeholder="Kode Perusahaan" type="text" v-model="buscd"
                        v-bind:class="{ 'is-danger': errors.has('business_code')}"
                        v-validate="'required'">
                    </div>
                    <p v-show="errors.has('business_code')" class="help is-danger">{{ errors.first('business_code') }}</p>
                  </div>
              </div>
             
          </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Telepon</label>
                  <div class="control">
                    <input name="phone" class="input" placeholder="Nomor Telepon" type="text" v-model="phoneNumber"
                      @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('phone')}"
                      v-validate="'required'">
                  </div>
                  <p v-show="errors.has('phone')" class="help is-danger">{{ errors.first('phone') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Negara</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('country') }">
                      <select name="country" class="select" v-model="country" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(country, key) in countries" :key="key" :value="country.object_code">{{
                          country.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('country')" class="help is-danger">{{errors.first('country') }}</p>
                  </div>
                </div>
              </div>
            <div class="column">
              <div class="field">
                <label class="label">Provinsi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('province') }">
                    <select name="province" class="select" v-model="province" v-validate="'required'"
                      @change="getCity()">
                      <option disabled selected>Choose</option>
                      <option v-for="(province, key) in provinces" :key="key" :value="province.object_code">{{
                        province.object_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('province')" class="help is-danger">{{ errors.first('province') }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Kota</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('city') }">
                    <select name="city" class="select" v-model="city" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(city, key) in cities" :key="key" :value="city.child.object_code">{{
                        city.child.object_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('city')" class="help is-danger">{{ errors.first('city') }}</p>
                </div>
              </div>
            </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Kode Pos</label>
                  <div class="control">
                    <input name="postal_code" class="input" placeholder="Kode Pos" type="text" v-model="postalCode"
                      @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('postal_code')}"
                      v-validate="'required'">
                  </div>
                  <p v-show="errors.has('postal_code')" class="help is-danger">{{ errors.first('postal_code') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Alamat</label>
                  <div class="control">
                    <textarea name="street" class="textarea" placeholder="Alamat Lengkap" v-model="street"
                      v-bind:class="{ 'is-danger': errors.has('street')}" v-validate="'required'"></textarea>
                  </div>
                  <p v-show="errors.has('street')" class="help is-danger"> {{ errors.first('street')}}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input class="input" id="begin_date" type="date" placeholder="10-10-2017" name="begin_date"
                      v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('form.begin_date')}"
                      v-validate="'required'" data-vv-scope="form">
                  </div>
                  <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" class="input" name="end_date" type="date" placeholder="10-10-2017" v-model="endDate"
                      data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                      data-vv-scope="form">
                  </div>
                  <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
                </div>
              </div>
            </div>
            
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="savecomManage()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
  </div>
  
  <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
            <div class="modal-background"></div>
            <div class="modal-card">
              <header class="modal-card-head">
                <p class="modal-card-title">Delimit Data Band Posisi</p>
                <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
              </header>
              <section class="modal-card-body">
                <div class="columns">
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Awal Berlaku</label>
                      <div class="control">
                        <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                          v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                          data-vv-scope="delimit" disabled>
                      </div>
                      <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                  </div>
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Akhir Berlaku</label>
                      <div class="control">
                        <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                          v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                          data-vv-scope="delimit">
                      </div>
                      <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                      </p>
                    </div>
                  </div>
                </div>
              </section>
              <footer class="modal-card-foot">
                <div class="control">
                  <button @click="delimitcomManage()" class="button is-success">Simpan</button>
                  <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
                </div>
              </footer>
            </div>
  </div>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  Vue.use(VueAutosuggest);
  import moment from "moment";export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        comManages: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        street: null,
        country: null,
        countries: [],
        province: null,
        provinces: [],
        city: null,
        cities: [],
        postalCode: null,
        phoneNumber: null,
        buscd: null,
        company: null,
        
        
        
        perPage:5,
        search:'',
        pagination: {
            'current_page': 1
          },
         options: [{
          data: []
        }],
       
        limit: 10,
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Perusahaan'
          },
        ],
        isActiveForm:false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getcomManages();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
      // this.getHakAkses();
      
    },
    methods: {
      
      getCountry() {
        this.$axios
          .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=CONTR"
            )
          .then(response => {
            this.countries = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getProvince() {
        this.$axios
          .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=PRVNC" + "&per_page=9999"
            )
          .then(response => {
            this.provinces = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getCity() {
        this.$axios
          .get(
              "ldap/api/relation?parent_type=PRVNC&parent="+ this.province +"&relation_type=A&relation_code=001&child_type=CITY&include=child&begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD")
            )
          .then(response => {
            this.cities = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getParam(){
        this.getCountry();
        this.getProvince();
        this.getCity();
      },
     
      openFormModal() {
        this.isActiveForm = true;
        this.getParam();
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.street = null;
        this.phoneNumber = null;
        this.postalCode = null;
        this.country = null;
        this.province = null;
        this.city = null;
        this.buscd = null;
        this.company = null;
        

        this.$nextTick(() => this.$validator.reset()); 
      },
      storecomManage() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/company", {
              begin_date: this.startDate,
              end_date: this.endDate,
              street: this.street,
              phone: this.phoneNumber,
              postal_code: this.postalCode,
              country: this.country,
              province: this.province,
              city: this.city,
              business_code: this.buscd,
              company_name: this.company,
            })
            .then(response => {
              this.getcomManages();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data Manajemen Perusahaan.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deletecomManage(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/company?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", 
                response.data.message, 
                "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removecomManage(key);
              });
          }
        });
      },
      removecomManage(key) {
        this.comManages.splice(key, 1);
      },
      editcomManage(objectIdentifier) {
        this.openFormModal();
        this.getcomManage(objectIdentifier);
      },
      updatecomManage() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/company", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              street: this.street,
              phone: this.phoneNumber,
              postal_code: this.postalCode,
              country: this.country,
              province: this.province,
              city: this.city,
              business_code: this.buscd,
              company_name: this.company,
            })
            .then(response => {
              this.getcomManages();
              this.closeFormModal();
              swal(
                "Updated!",
                "Successfully updated data Manajemen Perusahaan.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      savecomManage() {
        this.objectIdentifier ? this.updatecomManage() : this.storecomManage();
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;

        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitcomManage(objectIdentifier) {
        this.openFormModalDelimit();
        let comManage = await this.comManages.find(
          comManage => comManage.object_identifier == objectIdentifier
        );
        this.objectIdentifier = comManage.object_identifier;
        this.startDate = comManage.begin_date;
        this.endDate = comManage.end_date;
      },
      delimitcomManage() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/company", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getcomManages();
              this.closeFormModalDelimit();
              swal(
                "Delimited!", 
                response.data.message, 
                "success"
                );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      getcomManages() {
        this.$axios
          .get("hcis/api/company?include=city&include=province&include=country"+ 'page=' + this.pagination.current_page+'&per_page='+this.perPage)
          .then(response => {
            this.comManages = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getcomManage(objectIdentifier) {
        let comManage = await this.comManages.find(
          comManage => comManage.object_identifier == objectIdentifier
        );
        this.objectIdentifier = comManage.object_identifier;
        this.startDate = comManage.begin_date;
        this.endDate = comManage.end_date;
        this.street = comManage.street;
        this.company = comManage.company_name;
        this.postalCode = comManage.postal_code;
        this.country = comManage.country;
        this.province = comManage.province.object_code;
        this.city = comManage.city.object_code;
        this.phoneNumber = comManage.phone;
        this.buscd = comManage.business_code;
        this.getCity();
       
       },
      formatDate(date) {
        return moment(date).format("DD/MM/YYYY");
      },
      onlyNumber($event) {
          let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
          if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
            $event.preventDefault();
          }
      }, 
      getHakAkses() {
        this.$axios.get('/users/hakakses/BSCLV')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'R') {
              return this.$router.push('/employee-data/band-posisi/')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getColumn() {
        this.$axios.get('/objects/alltable/comManage/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getLogic() {
        this.$axios.get('/objects/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/objects/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = {
          table: "comManage", //harcode sesuai form *referensi table_code*
          column: this.columns_model,
          query: this.logics_model,
          value: this.filters_model,
          andor: this.conditions_model
        }
        console.log(this.paramsearchforms)
        this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
          .then(response => {
            this.comManages = [];
            response.data.data.forEach(async (comManage, key) => {
              await this.comManages.push({
                startDate: comManage.begin_date,
                endDate: comManage.end_date,
                personalNumber: comManage.personal_number,
                company: comManage.business_code
              })
            });
            console.log(this.levels);
          })
          .catch(e => {
            console.log(e);
          });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
