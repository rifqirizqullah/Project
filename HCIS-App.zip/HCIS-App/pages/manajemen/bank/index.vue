<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> 
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data 
        </span>
    </a>
    
    <h3 class="subtitle is-3">
      <i class="fa fa-bar-chart" aria-hidden="true"></i> Bank
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                    {{ column.column_name }}
                  </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div> 
    <table class="table is-striped is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Grup Bank</th>
          <th>Kode Bank</th>
          <th>Nama Bank</th>
          <th>Cabang</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(bank, key) in banks" :key="key">
          <td> {{key+1}} </td>
          <td> {{bank.bank_group.object_name}}</td>
          <td> {{bank.bank_code}}</td>
          <td> {{bank.bank_name}}</td>
          <td> {{bank.bank_branch}}</td>
          <td> {{formatDate(bank.begin_date)}} </td>
          <td> {{formatDate(bank.end_date)}} </td>
          <td>
            <a class="button is-success  is-small is-outlined is-rounded"
              @click="editBank(bank.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="bank.object_identifier ? deleteBank(key, bank.object_identifier) : removeBank(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitBank(bank.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>
    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getBanks()"></pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Bank</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-4">
              <div class="field">
                <label class="label">Grup Bank</label>
                <div class="control">
                  <div class="select " v-bind:class="{ 'is-danger': errors.has('form.bank_group') }">
                    <select name="bank group" class="select" v-model="bankGroup" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(bankGroup, key) in bankGroups" :key="key" :value="bankGroup.object_code">{{
                        bankGroup.object_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.bank_group')" class="help is-danger">{{ errors.first('form.bank_group')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Kode Bank</label>
                <div class="control">
                  <input name="bank code" class="input " placeholder="" type="text" v-model="bankCode"
                    v-bind:class="{ 'is-danger': errors.has('form.bank_code')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('form.bank_code')" class="help is-danger"> {{ errors.first('form.bank_code') }}</p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Nama Bank</label>
                <div class="control">
                  <input name="bank name" class="input " placeholder="" type="text" v-model="bankName"
                    v-bind:class="{ 'is-danger': errors.has('form.bank_name')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('form.bank_name')" class="help is-danger"> {{ errors.first('form.bank_name') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-4">
              <div class="field">
                <label class="label">Alamat Bank</label>
                <div class="control">
                  <input name="bank address" class="input " placeholder="" type="text" v-model="bankAddress"
                    v-bind:class="{ 'is-danger': errors.has('form.bank_address')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('form.bank_address')" class="help is-danger"> {{ errors.first('form.bank_address') }}</p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Provinsi</label>
                <div class="control">
                  <input name="bank address province" class="input " placeholder="" type="text" v-model="province"
                    v-bind:class="{ 'is-danger': errors.has('form.bank_address_province')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('form.bank_address_province')" class="help is-danger"> {{ errors.first('form.bank_address_province') }}</p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Negara</label>
                <div class="control">
                  <input name="bank address country" class="input " placeholder="" type="text" v-model="country"
                    v-bind:class="{ 'is-danger': errors.has('form.bank_address_country')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('form.bank_address_country')" class="help is-danger"> {{ errors.first('form.bank_address_country') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-4">
              <div class="field">
                <label class="label">Kota</label>
                <div class="control">
                  <input name="bank address city" class="input " placeholder="" type="text" v-model="city"
                    v-bind:class="{ 'is-danger': errors.has('form.bank_address_city')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('form.bank_address_city')" class="help is-danger"> {{ errors.first('form.bank_address_city') }}</p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Kode Pos</label>
                <div class="control">
                  <input name="postal code" class="input " placeholder="" type="number" v-model="postalCode"
                    v-bind:class="{ 'is-danger': errors.has('form.postal_code')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('form.postal_code')" class="help is-danger"> {{ errors.first('form.postal_code') }}</p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Cabang</label>
                <div class="control">
                  <input name="bank branch" class="input " placeholder="" type="text" v-model="bankBranch"
                    v-bind:class="{ 'is-danger': errors.has('form.bank_branch')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('form.bank_branch')" class="help is-danger"> {{ errors.first('form.bank_branch') }}</p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveBank()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
            <div class="modal-background"></div>
            <div class="modal-card">
              <header class="modal-card-head">
                <p class="modal-card-title">Delimit Data Identitas</p>
                <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
              </header>
              <section class="modal-card-body">
                <div class="columns">
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Awal Berlaku</label>
                      <div class="control">
                        <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                          v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                          data-vv-scope="delimit" disabled>
                      </div>
                      <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                  </div>
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Akhir Berlaku</label>
                      <div class="control">
                        <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                          v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                          data-vv-scope="delimit">
                      </div>
                      <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                      </p>
                    </div>
                  </div>
                </div>
              </section>
              <footer class="modal-card-foot">
                <div class="control">
                  <button @click="delimitBank()" class="button is-success">Simpan</button>
                  <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
                </div>
              </footer>
            </div>
    </div>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        objectIdentifier: null,
        banks: [],
        startDate: null,
        endDate: null,
        bankGroups: [],
        bankGroup: null,
        bankCode: null,
        bankName: null,
        bankAddress: null,
        province: null,
        country: null,
        city: null,
        postalCode: null,
        bankBranch: null,
        
        perPage:5,
        search:'',
        pagination: {
            'current_page': 1
          },
         options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit:10,
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        payrolinput: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'Bank'
          }
        ],
        isActiveForm:false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getBanks();
      this.getBankgroup();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
    },
    methods: {
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.bankGroup = null;
        this.bankCode = null;
        this.bankName = null;
        this.bankAddress = null;
        this.province = null;
        this.country = null;
        this.city = null;
        this.postalCode = null;
        this.bankBranch = null;
        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = '';
        this.empolyeeUnit = '';
        this.$nextTick(() => this.$validator.reset())
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.$nextTick(() => this.$validator.reset());
      },
      getParam(){
      this.getBankgroup();  
      },
      getBankgroup() {
        this.$axios
          .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=BANGR" + "&per_page= 999"
            )
          .then(response => {
            this.bankGroups = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBanks() {
        this.$axios
          .get("hcis/api/bank?include=bank_group" + '&page=' + this.pagination.current_page+'&per_page='+this.perPage)
          .then(response => {
            this.banks = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getBank(objectIdentifier) {
        let bank = await this.banks.find(
          bank => bank.object_identifier == objectIdentifier
        );
        this.objectIdentifier = bank.object_identifier;
        this.startDate = bank.begin_date;
        this.endDate = bank.end_date;
        this.bankGroup = bank.bank_group.object_code;
        this.bankCode = bank.bank_code;
        this.bankName = bank.bank_name;
        this.bankAddress = bank.bank_address;
        this.province= bank.bank_address_province;
        this.country= bank.bank_address_country;
        this.city= bank.bank_address_city;
        this.postalCode= bank.postal_code;
        this.bankBranch= bank.bank_branch;
        this.company = bank.business_code.business_code;
        this.employee = bank.personnel_number.personnel_number;
        this.empolyeeName = bank.personnel_number.complete_name;
        
        this.selfData(this.employee)
        this.getBankgroup();
       },
       storeBank() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/bank", {
              begin_date: this.startDate,
              end_date: this.endDate,
              bank_group: this.bankGroup,
              bank_code: this.bankCode,
              bank_name: this.bankName,
              bank_address: this.bankAddress,
              bank_address_province: this.province,
              bank_address_country: this.country,
              bank_address_city: this.city,
              postal_code: this.postalCode,
              bank_branch: this.bankBranch,
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getBanks();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data Bank.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deleteBank(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/bank?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", 
                response.data.message, 
                "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeBank(key);
              });
          }
        });
      },
      removeBank(key) {
        this.banks.splice(key, 1);
      },
      editBank(objectIdentifier) {
        this.openFormModal();
        this.getBank(objectIdentifier);
      },
      updateBank() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/bank", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              bank_group: this.bankGroup,
              bank_code: this.bankCode,
              bank_name: this.bankName,
              bank_address: this.bankAddress,
              bank_address_province: this.province,
              bank_address_country: this.country,
              bank_address_city: this.city,
              postal_code: this.postalCode,
              bank_branch: this.bankBranch,
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getBanks();
              this.closeFormModal();
              swal(
                "Updated!",
                "Successfully updated data Bank.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveBank() {
        this.objectIdentifier ? this.updateBank() : this.storeBank();
      },
      async showDelimitBank(objectIdentifier) {
        this.openFormModalDelimit();
        let bank = await this.banks.find(
          bank => bank.object_identifier == objectIdentifier
        );
        this.objectIdentifier = bank.object_identifier;
        this.startDate = bank.begin_date;
        this.endDate = bank.end_date;
      },
      delimitBank() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/bank", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getBanks();
              this.closeFormModalDelimit();
              swal(
                "Delimited!", 
                response.data.message, 
                "success"
                );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      formatDate(date) {
        return moment(date).format("DD/MM/YYYY");
      },
      onlyNumber($event) {
          let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
          if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
            $event.preventDefault();
          }
      },
      getHakAkses() {
        this.$axios.get('/users/hakakses/BNKEP')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if(this.hakAkses != '*' && this.hakAkses != 'R'){
              return this.$router.push('/employee-data/bank-account')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
        getColumn() {
        this.$axios.get('/users/bank/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
       getLogic() {
        this.$axios.get('/objects/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/objects/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = {
          table : "BankEmployee",//harcode sesuai form *referensi table_code*
          column : this.columns_model,
          query : this.logics_model,
          value : this.filters_model,
          andor : this.conditions_model
        }
        console.log(this.paramsearchforms)
         this.$axios.post('users/seachdinamis?per_page=10&page=1',this.paramsearchforms)
          .then(response => {
            this.banks = [];
            response.data.data.forEach(async (bank, key) => {
              await this.banks.push({
                startDate: bank.begin_date,
                endDate: bank.end_date,
                personalNumber: bank.personal_number,
                bscd: bank.business_code
              })
            });
            console.log(this.banks);
          })
          .catch(e => {
            console.log(e);
          });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
         this.searchforms.splice(key, 1)
      }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }
  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>