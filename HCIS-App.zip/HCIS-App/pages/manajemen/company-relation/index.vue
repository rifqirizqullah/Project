<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcrumbs"/>
    <hr>
    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> 
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data 
        </span>
    </a>

    <h3 class="subtitle is-3">
      <i class="fa fa-bar-chart"></i> Hubungan Perusahaan
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-stripped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan Satu</th>
          <th>Perusahaan Dua</th>
          <th>Relasi</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(relation, key) in companyRelations" :key="key">
          <td>{{key+1}}</td>
          <td> {{relation.parent_company.company_name}}</td>
          <td> {{relation.child_company.company_name}}</td>
          <td> {{relation.relation_code.object_name}}</td>
          <td> {{formatDate(relation.begin_date)}} </td>
          <td> {{formatDate(relation.end_date)}} </td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="editRelation(relation.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="relation.object_identifier ? deleteRelation(key, relation.object_identifier) : removeRelation(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitRelation(relation.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>
    
   <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getCompanyRelations()"></pagination>  
  
   <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Hubungan Perusahaan</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
         
          <div class="columns">
            <div class="column is-6">
                <div class="field">
                  <label class="label">Perusahaan Satu</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.parent_company') }">
                      <select name="parent company" class="select" v-model="parentCompany" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                          {{ company.company_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.parent_company')" class="help is-danger">{{errors.first('form.parent_company')
                      }}</p>
                  </div>
                </div>
              </div>
            <div class="column is-6">
                <div class="field">
                  <label class="label">Perusahaan Dua</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.child_company') }">
                      <select name="child company" class="select" v-model="childCompany" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                          {{ company.company_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.child_company')" class="help is-danger">{{errors.first('form.child_company')
                      }}</p>
                  </div>
                </div>
              </div>
          </div>
          <div class="columns">
            <div class="column is-6">
                <div class="field">
                  <label class="label">Kode Relasi</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.code_relation') }">
                      <select name="corelation" class="select" v-model="relationId" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(relationId, key) in coderelations" :key="key" :value="relationId.object_code">{{
                          relationId.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.code_relation')" class="help is-danger">{{errors.first('form.code_relation')
                      }}</p>
                  </div>
                </div>
              </div>
          </div>
         <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="saveRelation()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
            <div class="modal-background"></div>
            <div class="modal-card">
              <header class="modal-card-head">
                <p class="modal-card-title">Delimit Data Hubungan Perusahaan</p>
                <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
              </header>
              <section class="modal-card-body">
                <div class="columns">
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Awal Berlaku</label>
                      <div class="control">
                        <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                          v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                          data-vv-scope="delimit" disabled>
                      </div>
                      <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                  </div>
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Akhir Berlaku</label>
                      <div class="control">
                        <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                          v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                          data-vv-scope="delimit">
                      </div>
                      <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                      </p>
                    </div>
                  </div>
                </div>
              </section>
              <footer class="modal-card-foot">
                <div class="control">
                  <button @click="delimitRelation()" class="button is-success">Simpan</button>
                  <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
                </div>
              </footer>
            </div>
  </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    components: {
      Breadcrumb
    },
    data() {
      return {
        companyRelations: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        
        companies: [],
        parentCompany:null,
        childCompany: null,
        coderelations: [],
        relationId: null,
        
        perPage:5,
        search:'',
        pagination: {
            'current_page': 1
          },
         options: [{
          data: []
        }],
        limit: 10,
        columns: [],
        logics: [],
        
        
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        
        breadcrumbs: [
          {
            name: 'Beranda'
            },
          {
            name: 'Manajemen'
            },
          {
            name: 'Hubungan Perusahaan'
            },
        ],
        isActiveForm:false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getCompanyRelations();
      this.getCompany();
      this.getcoderelation();

    },
    methods: {
      editRelation(objectIdentifier) {
        this.openFormModal();
        this.getRelation(objectIdentifier);
      
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;

        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitRelation(objectIdentifier) {
        this.openFormModalDelimit();
        let relation = await this.companyRelations.find(
          relation => relation.object_identifier == objectIdentifier
        );
        this.objectIdentifier = relation.object_identifier;
        this.startDate = relation.begin_date;
        this.endDate = relation.end_date;
        
      },
     
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getcoderelation() {
        this.$axios
          .get(
              "ldap/api/object?object_type=CMRLC"
            )
          .then(response => {
            this.coderelations= response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getRelation(objectIdentifier) {
        let relation = await this.companyRelations.find(
          relation => relation.object_identifier == objectIdentifier
        );
        this.objectIdentifier = relation.object_identifier;
        this.startDate = relation.begin_date;
        this.endDate = relation.end_date;
        this.parentCompany = relation.parent_company.business_code;
        this.childCompany = relation.child_company.business_code;
        this.relationId = relation.relation_code.object_code;
              
       },
      formatDate(date) {
        return moment(date).format("DD/MM/YYYY");
      },
     
      //getHakAkses() {
        //this.$axios.get('/users/hakakses/IDNEP')
          //.then(response => {
            //this.hakAkses = response.data.data.access;
            //if (this.hakAkses != '*' && this.hakAkses != 'R') {
              //return this.$router.push('/employee-data/employee-identity')
           // }
          //})
          //.catch(e => {
           // console.log(e)
          //});
      //}, 
      openFormModal() {
        this.isActiveForm = true;
      },
      storeRelation() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/companyrelation", {
              begin_date: this.startDate,
              end_date: this.endDate,
              parent_company: this.parentCompany,
              child_company: this.childCompany,
              relation_code: this.relationId,
              
            })
            .then(response => {
              this.getCompanyRelations();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data identitas.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deleteRelation(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        })
        .then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/companyrelation?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", 
                response.data.message, 
                "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeRelation(key);
              });
          }
        });
      },
      removeRelation(key) {
        this.companyRelations.splice(key, 1);
      },
      updateRelation() {
        this.$validator.validateAll("companyrelations").then(async result => {
          if (!result) return;
          this.$axios.put("hcis/api/companyrelation", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              parent_company: this.parentCompany,
              child_company: this.childCompany,
              relation_code: this.relationId,
              
            })
            .then(response => {
              this.getCompanyRelations();
              this.closeFormModal();
              swal(
                "Updated!",
                "Successfully updated data Hubungan Perusahaan.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveRelation() {
        this.objectIdentifier ? this.updateRelation() : this.storeRelation();
      },
      getCompanyRelations() {
        this.$axios
          .get("hcis/api/companyrelation?order[oid]=asc&include=parent_company&include=child_company&include=relation_code" + '&page=' + this.pagination.current_page+'&per_page='+this.perPage)
          .then(response => {
            this.companyRelations = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      delimitRelation() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/companyrelation", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getCompanyRelations();
              this.closeFormModalDelimit();
              swal(
                "Delimited!", 
                response.data.message, 
                "success"
                );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      getColumn() {
        this.$axios.get('/users/identification/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getLogic() {
        this.$axios.get('/objects/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/objects/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = {
          table: "Identification", //harcode sesuai form *referensi table_code*
          column: this.columns_model,
          query: this.logics_model,
          value: this.filters_model,
          andor: this.conditions_model
        }
        //console.log(this.paramsearchforms)
        this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
          .then(response => {

            this.relation = [];
            response.data.data.forEach(async (relation, key) => {
              await this.companyRelations.push({
                startDate: relation.begin_date,
                endDate: relation.end_date,
                personalNumber: relation.personnel_number,
                company: relation.business_code
              })
            });
            //console.log(this.insurances);
          })
          .catch(e => {
            console.log(e);
          });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
    
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.childCompany = null;
        this.parentCompany = null;
        this.relationId = null;
        
        this.$nextTick(() => this.$validator.reset()); 
      } 
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
s
