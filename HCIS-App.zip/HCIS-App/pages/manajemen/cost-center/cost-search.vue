<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-money" aria-hidden="true"></i> Cost Center
    </h3>
    <!-- <div class="box has-text-white has-background-danger">
      Filter Search
    </div> -->
    <!-- <div class="box">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Column</label>
              <div class="control">
                <div class="select">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                    {{ column.column_name }}
                  </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logic</label>
              <div class="control">
                <div class="select">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column">
            <div class="field is-2">
              <label class="label">Condition</label>
              <div class="control">
                <div class="select">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded" @click="getSearchDynamic()">Cari</a>
    <br><br> -->
    <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Begin Date</th>
          <th>End Date</th>
          <th>Business Code</th>
          <th>Cost Center Id</th>
          <th>Action</th>
        </tr>
        <tr v-for="(cost, key) in costs" :key="key">
          <th> {{key+1}} </th>
          <th> {{cost.startDate}} </th>
          <th> {{cost.endDate}} </th>
          <th> {{cost.buscd}} </th>
          <th> {{cost.costid}} </th>
          <th>
            <a class="button is-success is-outlined is-rounded" @click="editCost(cost.key)"><i class="fa fa-pencil"
                aria-hidden="true"></i></a>
            <a class="button is-danger is-outlined is-rounded" @click="cost.key ? deleteEmployee(key, cost.key) : removeGroupSociometri(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a>
          </th>
        </tr>
      </thead>
    </table>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Edit Data</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column is-4">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                    <select name="nama_perusahaan" class="select" v-model="company" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">{{
                        company.company_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Tanggal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('begin_date')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">S.d</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date" placeholder="e.g 10-11-2018"
                    v-model="endDate" data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Organizational Type</label>
                <div class="control">
                  <input name="nickname" class="input " placeholder="Organizational Type" type="text" v-model="nickName"
                    v-bind:class="{ 'is-danger': errors.has('nickname')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname') }}</p>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Organizational Id</label>
                <div class="control">
                  <input name="nickname" class="input " placeholder="Organizational Id" type="text" v-model="nickName"
                    v-bind:class="{ 'is-danger': errors.has('nickname')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Porsi</label>
                <div class="control">
                  <input name="birth_place" class="input " placeholder="Porsi" type="text" v-model="birthPlace"
                    v-bind:class="{ 'is-danger': errors.has('birth_place')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('birth_place')" class="help is-danger"> {{ errors.first('birth_place') }}</p>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Cost Center Id</label>
                <div class="control">
                  <input name="born_date" class="input " placeholder="Cost Center Id" type="text" v-model="birthDate"
                    v-bind:class="{ 'is-danger': errors.has('born_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('born_date')" class="help is-danger"> {{ errors.first('born_date') }}</p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveEmployee()" class="button is-link">Save</button>
            <button class="button" @click="closeFormModal()">Cancel</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        nikAuth: this.$auth.user.nik,
        key: null,
        startDate: '',
        endDate: '',
        businessCode: '1000',
        personalNumber: '',
        buscd:'',
        costid:'',
        fullName: '',
        costs: [],
        columns:[],
        logics:[],
        companies:[],
        conditions:[],
        filters:[],
        paramsearchforms:'',
        columns_model:[],
        filters_model:[],
        conditions_model:[],
        logics_model:[],
        bankByCodes: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'Cost Center'
          }
        ],
        isActiveForm:false,
      }
    },
    created() {
      this.getCost();
      this.getCompany();
    },
    methods: {
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.buscd = '';
        this.fullName = '';
        this.$nextTick(() => this.$validator.reset())
      },
      getCost() {
        this.$axios.get('users/costcenter?per_page=20')
          .then(response => {
            this.costs = [];
            response.data.data.forEach(async (cost, key) => {
              await this.costs.push({
                key:key,
                startDate: cost.begin_date,
                endDate: cost.end_date,
                buscd: cost.business_code,
                costid: cost.costcenter_id
              })
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getCompany() {
        this.$axios.get('/objects/companytoken/CSCTR')
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      //  closeFormModal() {
      //   this.buscd = '';
      //   this.fullName = '';
      //   this.$nextTick(() => this.$validator.reset())
      // },
      //   getColumn() {
      //   this.$axios.get('/objects/alltable/Award/column')
      //     .then(response => {
      //       this.columns = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      //  getLogic() {
      //   this.$axios.get('/objects/oprationsql')
      //     .then(response => {
      //       this.logics = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getCondition() {
      //   this.$axios.get('/objects/conditionsql')
      //     .then(response => {
      //       this.conditions = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getSearchDynamic() {
      //   this.paramsearchforms = {
      //     table : "Award",//harcode sesuai form *referensi table_code*
      //     column: this.columns_model,
      //     query : this.logics_model,
      //     value : this.filters_model,
      //     andor : this.conditions_model
      //   }
      //   console.log(this.paramsearchforms)
      //    this.$axios.post('users/seachdinamis?per_page=10&page=1',this.paramsearchforms)
      //     .then(response => {

      //       this.costs = [];
      //       response.data.data.forEach(async (cost, key) => {
      //         await this.costs.push({
      //           startDate: cost.begin_date,
      //           endDate: cost.end_date,
      //           buscd: cost.business_code
      //         })
      //       });
      //       console.log(this.costs);
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
       editCost(key) {
        this.openFormModal();
        this.getCosts(key);
      },
       async getCosts(key) {
        let cost = await this.costs.find(cost => cost.key == key);
        this.startDate = cost.startDate;
        this.endDate = cost.endDate;
        this.buscd = cost.buscd;
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    }
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>