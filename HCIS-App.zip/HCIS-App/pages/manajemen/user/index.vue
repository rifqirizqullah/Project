<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-users" aria-hidden="true"></i> Manajemen Pengguna
    </h3>
    <a class="button is-pulled-right is-link is-rounded" @click="openFormModal()">Tambah Data</a>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Username</th>
          <th>Hak Akses</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(user, key) in users" :key="key">
          <td> {{key+1}} </td>
          <td> {{user.startDate}} </td>
          <td> {{user.endDate}} </td>
          <td> {{user.username}}</td>
          <td>
            <div v-for="(rol, key) in user.role" :key="key"> - {{rol.role_code}} </div>
          </td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded" @click="editAccount(user.username)"><i
                class="fa fa-pencil" aria-hidden="true"></i></a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="user.username ? deletea(key, user.username) : remove(key)"><i class="fa fa-trash"
                aria-hidden="true"></i></a>
          </td>
        </tr>
      </thead>
    </table>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Manajemen User</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="control">
                    <input id="business_name" data-display-mode="dialog" class="input" name="business_name" type="text"
                      v-model="business_name" data-vv-as="business_name"
                      v-bind:class="{ 'is-danger': errors.has('business_name')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('business_name')" class="help is-danger">{{ errors.first('business_name') }}
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Username</label>
                <div class="control">
                  <input v-if="type == 'EDIT'" name="username" class="input " type="text" v-model="username"
                    v-bind:class="{ 'is-danger': errors.has('username')}" v-validate="'required'" readonly>
                  <input v-else name="username" class="input " type="text" v-model="username"
                    v-bind:class="{ 'is-danger': errors.has('username')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('username')" class="help is-danger"> {{ errors.first('username') }}</p>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Email</label>
                <div class="control">
                  <input name="email" class="input " placeholder="email" type="" v-model="email"
                    v-bind:class="{ 'is-danger': errors.has('email')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('email')" class="help is-danger"> {{ errors.first('email') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Hak Akses</label>
                <div class="control" v-bind:class="{ 'is-danger': errors.has('role') }" data-vv-scope="role">
                  <v-select multiple label="role_name" name="role" v-model="role" :options="options"
                    v-validate="'required'" class="full-width"></v-select>
                </div>
                <p v-show="errors.has('role')" class="help is-danger"> {{
                    errors.first('role') }}</p>
              </div>
            </div>

          </div>
          <div class="columns">
            <div class="column is-12">
              <div class="field">
                <label class="label">Alamat</label>
                <div class="control">
                  <input name="address" class="input " placeholder="address" type="text" v-model="street"
                    v-bind:class="{ 'is-danger': errors.has('address')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('address')" class="help is-danger"> {{ errors.first('address') }}</p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveComponent()" class="button is-link">Simpan</button>
            <button class="button" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import Vue from 'vue'
  import vSelect from 'vue-select';
  Vue.component('v-select', vSelect)
  export default {
    components: {
      Breadcrumb,
      vSelect
    },
    data() {
      return {
        startDate: '',
        endDate: '',
        business_name: '',
        username: '',
        password: 'secret',
        street: '',
        email: '',
        type: 'ADD',
        role: [],
        options: [],
        users: [],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'User'
          }
        ],
        isActiveForm: false,
      }
    },
    created() {
      this.getUser();
      this.getRole();
    },
    methods: {
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.username = '';
        this.business_name = '';
        this.street = '';
        this.email = '';
        this.business_name = '';
        this.type = 'ADD';
        this.role = [];
        this.startDate = null;
        this.endDate = null;
        this.$nextTick(() => this.$validator.reset())
      },
      getUser() {
        this.$axios.get('users/management')
          .then(response => {
            this.users = [];
            response.data.data.forEach(async (user, key) => {
              await this.users.push({
                startDate: user.begin_date,
                endDate: user.end_date,
                username: user.username,
                business_name: user.business_name,
                role: user.role,
                email: user.email,
                street: user.street
              })
            })
          })
          .catch(e => {
            console.log(e);
          });
      },
      getRole() {
        this.options = [];
        this.$axios.get('roles/management')
          .then(response => {
            response.data.data.forEach(async (user, key) => {
              await this.options.push({
                role_code: user.role_code,
                role_name: user.role_name
              })
            })
          })
          .catch(e => {
            console.log(e);
          });
      },
      editAccount(username) {
        this.openFormModal();
        this.getAccounts(username);
      },
      async getAccounts(username) {
        let account = await this.users.find(account => account.username == username);
        this.startDate = account.startDate;
        this.endDate = account.endDate;
        this.username = account.username;
        this.business_name = account.business_name;
        this.street = account.street;
        this.email = account.email;
        this.role = account.role;
        this.type = 'EDIT';
      },
      saveComponent() {
        this.role = this.role.map(a => a.role_code)
        if (this.type == 'EDIT') {
          this.updateComponent();
        } else {
          this.storeComponent();
        }
      },
      storeComponent() {
        swal({
          title: 'Are you sure to save?',
          text: "You won't be able to revert this!",
          type: 'warning',
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.post('users/management', {
                begin_date: this.startDate,
                end_date: this.endDate,
                business_name: this.business_name,
                username: this.username,
                password: this.password,
                street: this.street,
                email: this.email,
                role: this.role
              })
              .then(response => {
                swal(
                  'Saved!',
                  'Successfully saved.',
                  'success'
                );
                this.closeFormModal();
                this.getUser();
              })
              .catch(e => {
                console.log(e);
              })
          }
        });
      },
      updateComponent() {
        swal({
          title: 'Are you sure to save?',
          text: "You won't be able to revert this!",
          type: 'warning',
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.post('users/management/' + this.username, {
                begin_date: this.startDate,
                end_date: this.endDate,
                business_name: this.business_name,
                username: this.username,
                password: this.password,
                street: this.street,
                email: this.email,
                role: this.role
              })
              .then(response => {
                swal(
                  'Saved!',
                  'Successfully saved.',
                  'success'
                );
                this.closeFormModal();
                this.getUser();
              })
              .catch(e => {
                console.log(e);
              })
          }
        });
      },
      deletea(key, username) {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.post('users/management/' + username, null)
              .then(response => {
                swal(
                  'Deleted!',
                  response.data.message,
                  'success'
                )
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.remove(key);
              })
          }

        });
      },
      remove(key) {
        this.users.splice(key, 1);
      },
    }
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
