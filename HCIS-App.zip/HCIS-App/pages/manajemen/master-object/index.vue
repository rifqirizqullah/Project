<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Master Obyek
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i
                  class="fa fa-plus" aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i
                  class="fa fa-trash" aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i
                class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <div class="columns is-multiline">
      <div v-for="(item,key) in otype.list" :key="key" class="column is-4">
        <a @click="getDetail(item.object_identifier); $router.push('/manajemen/master-object/detail?otype='
          +item.object_type.object_type)">
          <div class="box shadowed">
            <p class="has-text-centered">{{ item.object_type.object_name }}</p>
            <hr>
            <p class="has-text-centered">{{ item.object_type.object_type }}</p>
          </div>
        </a>
      </div>
    </div>
    <br>
    <pagination :state="otype" :offset="5" :storeModuleName="'otype'" />
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import {
    mapState,
    mapActions
  } from "vuex";
  import moment from "moment";
  import pagination from "@@/components/paginationBar";

  export default {
    components: {
      Breadcrumb,
      pagination
    },
    data() {
      return {
        begin_date: null,
        end_date: null,

        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],

        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'Master Objek'
          }
        ]
      }
    },
    created() {
      this.$store.dispatch("otype/getAll");
    },
    computed: {
      ...mapState(['otype'])
    },
    methods: {
      ...mapActions({
        getDetail: 'otype/getDetail',
        clearDetail: 'otype/clearDetail',
        deleteOne: 'otype/deleteOne',
        getAll: 'otype/getAll',
      }),
    }
  }

</script>

<style>
  .shadowed {
    -webkit-box-shadow: 5px 5px 20px 0px rgba(0, 0, 0, 0.75);
    -moz-box-shadow: 5px 5px 20px 0px rgba(0, 0, 0, 0.75);
    box-shadow: 5px 5px 20px 0px rgba(0, 0, 0, 0.75);
  }

</style>
