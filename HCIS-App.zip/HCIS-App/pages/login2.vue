<template>
  <section>
    <div class="columns">
      <div class="column is-7 has-text-centered is-vertical-center"
        style="background:#4C2A84;color:white;height:105vh;">
        <div>
          <div class="columns ">
            <div class="column is-half is-offset-one-quarter">
              <h1 class="title has-text-white"><b>Selamat Datang di HCIS</b></h1>
              <small>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos odio atque alias, tempora
                quaerat
                reiciendis vitae ipsa expedita libero sint ea animi nam accusamus eveniet explicabo perspiciatis et
                porro
                placeat.</small>
            </div>
          </div>
          <div class="columns">
            <div class="column is-80 is-offset-10">
              <img src="../assets/hcisloginbg.png" class="w100" />
            </div>
          </div>
        </div>
      </div>
      <div class="column is-5 has-text-centered is-vertical-center"
        style="background:#654C85;color:white;height:105vh;">
        <div class="columns" style="width:105%">
          <div class="column is-60 is-offset-20 ">
            <h1 class="title has-text-white">USER LOGIN</h1>
            <div class="field">
              <p class="control has-icons-left has-icons-right">
                <input class="input is-large" type="email" placeholder="Username">
                <span class="icon is-small is-left">
                  <i class="fa fa-user"></i>
                </span>
              </p>
            </div>
            <div class="field">
              <p class="control has-icons-left">
                <input class="input is-large" type="password" placeholder="Password">
                <span class="icon is-small is-left">
                  <i class="fa fa-lock"></i>
                </span>
              </p>
            </div>
            <button class="button is-medium is-rounded is-success">
              Login
            </button>
          </div>
        </div>
      </div>

    </div>
  </section>
</template>

<script>
  export default {
    layout: 'auth'
  }

</script>

<style>
  .is-vertical-center {
    display: flex;
    align-items: center;
  }

  .input,
  .textarea {
    background-color: #ffffff4d;
    border-color: #dbdbdb00;
    color: #ffffff;
    box-shadow: inset 0 1px 2px rgba(10, 10, 10, 0.1);
    max-width: 100%;
    width: 100%;
  }

  @media screen and (min-width: 769px) {

    .column.is-80,
    .column.is-half-tablet {
      flex: none;
      width: 80%;
    }

    .column.is-60,
    .column.is-half-tablet {
      flex: none;
      width: 60%;
    }

  }

  @media screen and (min-width: 769px) {

    .column.is-offset-10,
    .column.is-offset-one-quarter-tablet {
      margin-left: 10%;
    }

    .column.is-offset-20,
    .column.is-offset-one-quarter-tablet {
      margin-left: 20%;
    }

  }

</style>
