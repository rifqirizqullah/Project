<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> <span><i class="fa fa-plus" aria-hidden="true"></i> Tambah Data </span></a>
   <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i>Pencarian Data Penempatan Kerja
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                    {{ column.column_name }}
                  </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Grup</th>
          <th>Subgrup</th>
          <th>Area</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(Assignment, key) in Assignments" :key="key">
          <td> {{key+1}} </td>
          <td> {{Assignment.business_code.company_name}}</td>
          <td> {{Assignment.personnel_number.personnel_number}}</td>
          <td> {{Assignment.personnel_group.object_name}}</td>
          <td> {{Assignment.personnel_subgroup.object_name}}</td>
          <td> {{Assignment.personnel_area}}</td>
          <td> {{formatDate(Assignment.begin_date)}} </td>
          <td> {{formatDate(Assignment.end_date)}} </td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
                @click="editAssignment(Assignment.object_identifier)"><i class="fa fa-pencil"
                  aria-hidden="true"></i></a>
              <a class="button is-danger is-small is-outlined is-rounded"
                @click="Assignment.object_identifier ? deleteAssignment(key, Assignment.object_identifier) : removeAssignment(key)"><i
                  class="fa fa-trash" aria-hidden="true"></i></a>
              <a class="button is-warning is-small is-outlined is-rounded"
                @click="showDelimitAssignment(Assignment.object_identifier)"><i class="fa fa-clock-o"
                  aria-hidden="true"></i></a>
           </td>
        </tr>
      </thead>
    </table>

  <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getAssignments()"></pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Penempatan Kerja</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nama Perusahaan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.company') }">
                      <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                        v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                          {{ company.company_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.company')" class="help is-danger">{{ errors.first('form.company') }}</p>
                  </div>
                </div>
              </div>
          </div>

      <span v-show="company">
      <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee= null">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      :on-selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
      </div>
      <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" >
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" >
                  </div>
                </div>
              </div>
      </div>
      <hr>
      <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
      </div>
      <div class="columns">
        <div class="column">
                <div class="field">
                  <label class="label">Cost Center</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.cost_center') }">
                      <select name="cost_center" class="select" v-model="cost_center" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(cost_center, key) in cost_centers" :key="key" :value="cost_center.object_code">{{
                          cost_center.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.cost_center')" class="help is-danger">{{errors.first('form.cost_center')
                      }}</p>
                  </div>
                </div>
              </div>
        <div class="column">
                <div class="field">
                  <label class="label">Job</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.job') }">
                      <select name="job" class="select" v-model="job" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(job, key) in jobs" :key="key" :value="job.job">{{
                          job.job_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.job')" class="help is-danger">{{errors.first('form.job')
                      }}</p>
                  </div>
                </div>
              </div>            
        <div class="column">
                <div class="field">
                  <label class="label">Business Area</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.business_area') }">
                      <select name="business_area" class="select" v-model="business_area" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(business_area, key) in business_areas" :key="key" :value="business_area.object_code">{{
                          business_area.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.business_area')" class="help is-danger">{{errors.first('form.business_area')
                      }}</p>
                  </div>
                </div>
              </div>      
      </div>
      <div class="columns">
        <div class="column">
                <div class="field">
                  <label class="label">Grup</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personnel_group') }">
                      <select name="personnel_group" class="select" v-model="personnel_group" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(personnel_group, key) in personnel_groups" :key="key" :value="personnel_group.object_code">{{
                          personnel_group.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.personnel_group')" class="help is-danger">{{errors.first('form.personnel_group')
                      }}</p>
                  </div>
                </div>
              </div>            
        <div class="column">
                <div class="field">
                  <label class="label">Subgrup</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personnel_subgroup') }">
                      <select name="personnel_subgroup" class="select" v-model="personnel_subgroup" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(personnel_subgroup, key) in personnel_subgroups" :key="key" :value="personnel_subgroup.object_code">{{
                          personnel_subgroup.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.personnel_subgroup')" class="help is-danger">{{errors.first('form.personnel_subgroup')
                      }}</p>
                  </div>
                </div>
              </div>      
      </div>
      <div class="columns">
        <div class="column">
                <div class="field">
                  <label class="label">Area</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personnel_area') }">
                      <select name="personnel_area" class="select" v-model="personnel_area" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(personnel_area, key) in personnel_areas" :key="key" :value="personnel_area.object_code">{{
                          personnel_area.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.personnel_area')" class="help is-danger">{{errors.first('form.personnel_area')
                      }}</p>
                  </div>
                </div>
              </div>            
        <div class="column">
                <div class="field">
                  <label class="label">Subarea</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personnel_subarea') }">
                      <select name="personnel_subarea" class="select" v-model="personnel_subarea" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(personnel_subarea, key) in personnel_subareas" :key="key" :value="personnel_subarea.object_code">{{
                          personnel_subarea.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.personnel_subarea')" class="help is-danger">{{errors.first('form.personnel_subarea')
                      }}</p>
                  </div>
                </div>
              </div>      
      </div>
      <div class="columns">
        <div class="column">
                <div class="field">
                  <label class="label">Payroll Area</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.payroll_area') }">
                      <select name="payroll_area" class="select" v-model="payroll_area" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(payroll_area, key) in payroll_areas" :key="key" :value="payroll_area.payroll_area">{{
                          payroll_area.payroll_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.payroll_area')" class="help is-danger">{{errors.first('form.payroll_area')
                      }}</p>
                  </div>
                </div>
              </div>                 
      </div>
      </span>
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="saveAssignment()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
  </div>

  <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
            <div class="modal-background"></div>
            <div class="modal-card">
              <header class="modal-card-head">
                <p class="modal-card-title">Delimit Data Penempatan Kerja</p>
                <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
              </header>
              <section class="modal-card-body">
                <div class="columns">
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Awal Berlaku</label>
                      <div class="control">
                        <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                          v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                          data-vv-scope="delimit" disabled>
                      </div>
                      <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                  </div>
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Akhir Berlaku</label>
                      <div class="control">
                        <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                          v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                          data-vv-scope="delimit">
                      </div>
                      <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                      </p>
                    </div>
                  </div>
                </div>
              </section>
              <footer class="modal-card-foot">
                <div class="control">
                  <button @click="delimitAssignment()" class="button is-success">Simpan</button>
                  <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
                </div>
              </footer>
            </div>
  </div> 
  
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        
        Assignments: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        buscds: [],
        buscd: null, 
        cost_centers : [],  
        cost_center: null, 
        business_areas : [],
        business_area : null,
        positions : [],
        position : null,
        jobs: [],
        job: null,
        units : [],
        unit : null,
        personnel_groups: [],
        personnel_group: null,
        personnel_subgroups: [],
        personnel_subgroup: null,
        personnel_areas: [],
        personnel_area: null,
        personnel_subareas: [],
        personnel_subarea: null,
        payroll_areas: [],
        payroll_area: null,

        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: "",
        empolyeePosition: '',
        empolyeeUnit: '',
        
        perPage:5,
        search:'',
        pagination: {
            'current_page': 1
          },
         options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,
        columns:[],
        logics:[],
        conditions:[],
        filters:[],
        paramsearchforms:'',
        columns_model:[],
        filters_model:[],
        conditions_model:[],
        logics_model:[],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Penempatan Kerja'
          },
        ],
        isActiveForm:false,
        isActiveFormDelimit: false
      }
    },
    created() {
        this.getAssignments();
        //this.getColumn();
        //this.getLogic();
        //this.getCondition();
        this.getCompany();
    },
    methods: {
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(
                employee.personnel_number
                );
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.employeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal("", "Pilih nama perusahaan terlebih dahulu !", "error");
          } else {
            this.selfData(option.item);
          }
        }
      },
      selfData(nik){
          this.$axios
                .get(
                  "hcis/api/organizationalassignment?begin_date_lte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&end_date_gte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&personnel_number=" +
                  nik + "&business_code=" +this.company
                )
                .then(async response => {
                  this.empolyeeName = response.data.data[0].personnel_number.complete_name;
                  this.empolyeePosition = response.data.data[0].position.organization_name;
                  this.empolyeeUnit = response.data.data[0].unit.organization_name;
                  
                })
                .catch(e => {
                  console.log(e);
                });
        },
      
     clearEmployee() {
        if (this.employee != null) {
          this.$refs.reference= '';
        }
        this.filterEmployee = []
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeeUnit = '';
        this.empolyeePosition = '';

        this.$nextTick(() => this.$validator.reset());
      }, 
      getParam(){
      this.getBusar();  
      this.getpsGroup();
      this.getpsSGroup();
      this.getpsArea();
      this.getpsSArea();
      this.getpayroll();
    
      },
      getCostcenter() {
        this.$axios
          .get(
              'ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type='
            )
          .then(response => {
            this.cost_centers = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getJob() {
        this.$axios
          .get(
              'ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type='
            )
          .then(response => {
            this.jobs = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBusar() {
        this.$axios
          .get(
              'ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=BUSAR'
            )
          .then(response => {
            this.business_areas = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getpayroll() {
        this.$axios
          .get(
              'hcis/api/payrollarea?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type='
            )
          .then(response => {
            this.payroll_areas = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getpsGroup() {
        this.$axios
          .get(
              'ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=PRGRP'
            )
          .then(response => {
            this.personnel_groups = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getpsSGroup() {
        this.$axios
          .get(
              'ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=PRSGR'
            )
          .then(response => {
            this.personnel_subgroups = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getpsArea() {
        this.$axios
          .get(
              'ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=PRSAR'
            )
          .then(response => {
            this.personnel_areas = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getpsSArea() {
        this.$axios
          .get(
              'ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=CITY'
            )
          .then(response => {
            this.personnel_subareas = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.buscd = null;
        this.business_area = null;
        this.personnel_group = null;
        this.personnel_subgroup = null;
        this.personnel_area = null;
        this.personnel_subarea = null;
        this.payroll_area = null;
        this.job = null;
        
        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = '';
        this.empolyeeUnit = '';

        this.$nextTick(() => this.$validator.reset())
      }, 
      storeAssignment() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/organizationalassignment", {
              begin_date: this.startDate,
              end_date: this.endDate,
              
              
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getAssignments();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data penempatan kerja.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deleteAssignment(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/organizationalassignment?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", 
                response.data.message, 
                "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeAssignment(key);
              });
          }
        });
      },
      removeAssignment(key) {
        this.Assignments.splice(key, 1);
      },
      getAssignments(){
            this.$axios
            .get("hcis/api/organizationalassignment?include=business_code&include=personnel_group&include=personnel_subgroup&include=personnel_number" + '&page=' + this.pagination.current_page+'&per_page='+this.perPage)
                .then(response => {
                    this.Assignments = response.data.data;
                    this.pagination = response.data.meta.pagination;
                })
                .catch(e => {
                    console.log(e);
                });
        },
        async getAssignment(objectIdentifier){
          let Assignment = await this.Assignments.find(
          Assignment => Assignment.object_identifier == objectIdentifier
        );
        this.objectIdentifier = Assignment.object_identifier;
        this.startDate = Assignment.begin_date;
        this.endDate = Assignment.end_date;
        this.buscd = Assignment.business_code.business_code;
        this.cost_center = Assignment.cost_center_name;
        this.business_area = Assignment.business_area;
        this.personnel_group = Assignment.personnel_group;
        this.personnel_subgroup = Assignment.personnel_subgroup;
        this.personnel_area = Assignment.personnel_area;
        this.personnel_subarea = Assignment.personnel_subarea;
        this.payroll_area = Assignment.payroll_area.payroll_area;
       
        
        
        this.company = Assignment.business_code.business_code;
        this.employee = Assignment.personnel_number.personnel_number;
        this.empolyeeName = Assignment.personnel_number.complete_name;
        
        this.selfData(this.employee)   
        this.getParam();  
      
        },
      getColumn() {
        this.$axios.get('/object/alltable/Assignment/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getLogic() {
        this.$axios.get('/object/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/object/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = {
          table : "Assignment",//harcode sesuai form *referensi table_code*
          column : this.columns_model,
          query : this.logics_model,
          value : this.filters_model,
          andor : this.conditions_model
        }
        //console.log(this.paramsearchforms)
         this.$axios.post('users/seachdinamis?per_page=10&page=1',this.paramsearchforms)
          .then(response => {

            this.Assignments = [];
            response.data.data.forEach(async (employee, key) => {
              await this.Assignments.push({
                begin_date: employee.begin_date,
                end_date: employee.end_date,
                personal_number: employee.personal_number,
                buscd: employee.business_code
              })
            });
            //console.log(this.employees);
          })
          .catch(e => {
            console.log(e);
          });
      },
      editAssignment(objectIdentifier) {
        this.openFormModal();
        this.getAssignment(objectIdentifier);
      },
      updateAssignment() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/organizationalassignment", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getAssignments();
              this.closeFormModal();
              swal(
                "Updated!",
                "Successfully updated data penempatan kerja.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveAssignment() {
        this.objectIdentifier ? this.updateAssignment() : this.storeAssignment();
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;

        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitAssignment(objectIdentifier) {
        this.openFormModalDelimit();
        let Assignment = await this.Assignments.find(
          Assignment => Assignment.object_identifier == objectIdentifier
        );
        this.objectIdentifier = Assignment.object_identifier;
        this.startDate = Assignment.begin_date;
        this.endDate = Assignment.end_date;
      },
      delimitAssignment() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/organizationalassignment", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getAssignments();
              this.closeFormModalDelimit();
              swal(
                "Delimited!", 
                response.data.message, 
                "success"
                );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      },
      formatDate(date) {
        return moment(date).format('DD/MM/YYYY')
      },
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
