<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="organizational-assignment/organizational-assignment-search" class="button is-success is-rounded is-pulled-right"><span>  <i class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-users" aria-hidden="true"></i> Penempatan Kerja
    </h3>
    <div class="box has-text-white has-background-danger">
      Data Karyawan BUMN
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                  <option selected="selected" disabled="disabled" >choose option</option>
                  <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
                </select>
            </div>            
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                  <option selected="selected" disabled="disabled" >choose option</option>
                  <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
                </select>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">NIK</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10" :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="nik_query" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
        
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      
    </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Form Lokasi Penempatan
    </div>
    <div class="box">
      <div class="columns">       
        <div class="column is-4">
          <div class="field">
            <label class="label">Employee Group</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.employee_group') }">
                <select name="employee_group" class="select" v-model="employeeGroup" v-validate="'required'" 
                data-vv-scope="form" @change="getSubGroup()">
                  <option disabled selected>Choose</option>
                  <option v-for="(employeeGroup, key) in employeeGroups" :key="key" :value="employeeGroup.object_id">{{
                    employeeGroup.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.employee_group')" class="help is-danger">{{ errors.first('form.employee_group') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Sub Group</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.subGroup') }">
                <select name="form.subGroup" class="select" v-model="employeeSubGroup" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(subGroup, key) in employeeSubGroups" :key="key" :value="subGroup.object_id">{{
                    subGroup.name
                    }}</option>
                </select>
              </div> 
              <p v-show="errors.has('form.subGroup')" class="help is-danger">{{ errors.first('form.subGroup') }}</p>
            </div>
          </div>
        </div>
         <div class="column is-4">
          <div class="field">
            <label class="label">Bisnis Area</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.busArea') }">
                <select name="busArea" class="select" v-model="busArea" v-validate="'required'" 
                data-vv-scope="form" @change="getBusAreaChild()">
                  <option disabled selected>Choose</option>
                  <option v-for="(employeeGroup, key) in busAreas" :key="key" :value="employeeGroup.object_code">{{
                    employeeGroup.business_area
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.busArea')" class="help is-danger">{{ errors.first('form.busArea') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Personal Area</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.personalArea') }">
                <select name="personalArea" class="select" v-model="personalArea" v-validate="'required'" 
                data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(employeeGroup, key) in personalAreas" :key="key" :value="employeeGroup.object_id">{{
                    employeeGroup.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.personalArea')" class="help is-danger">{{ errors.first('form.personalArea') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kota Penempatan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.city') }">
                <select name="city" class="select" v-model="personalSubArea" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(city, key) in personalSubAreas" :key="key" :value="city.id">{{
                    city.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.city')" class="help is-danger">{{ errors.first('form.city') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Payroll Area</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.payArea') }">
                <select name="payArea" class="select" v-model="payArea" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(city, key) in payAreas" :key="key" :value="city.payrollarea">{{
                    city.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.payArea')" class="help is-danger">{{ errors.first('form.payArea') }}</p>
            </div>
          </div>
        </div>                               
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi</label>
            <div class="control">
              <treeselect v-model="position" :multiple="false" :options="data" @input="tes()"/>
              <!-- <input class="input" type="text" placeholder="Manager"> -->
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="organization" disabled>
            </div>
          </div>
        </div>
         <div class="column is-4">
          <div class="field">
            <label class="label">Job</label>
            <div class="control">
              <input class="input" type="text" placeholder="Programmer" v-model="job" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Cost Center</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.costCenter') }">
                <select name="costCenter" class="select" v-model="costCenter" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(city, key) in costCenters" :key="key" :value="city.costcenter_id">{{
                    city.porsi
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.costCenter')" class="help is-danger">{{ errors.first('form.costCenter') }}</p>
            </div>
          </div>
        </div>
         <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berlaku</label>
            <div class="control">
              <input class="input" id="begin_date" type="date" placeholder="10-10-2017" name="begin_date" v-model="startDate"
                data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">s.d</label>
            <div class="control">
              <input id="end_date" class="input" name="end_date" type="date" placeholder="10-10-2017" v-model="endDate"
                data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>     
    </div>
    <div class="box has-text-white has-background-danger">
      List Lokasi Penempatan
    </div>
    <div class="box" v-for="(component, key) in components" :key="key">
      <div class="columns">        
        <div class="column is-4">
          <div class="field">
            <label class="label">Employee Group</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('employee_group') }">
                <select name="employee_group" class="select" v-model="employeeGroup_input[key]" v-validate="'required'" 
                 @change="getSubGroup_tampung(key,employeeGroup_input[key])">
                  <option disabled selected>Choose</option>
                  <option v-for="(employeeGroup, key) in employeeGroups" :key="key" :value="employeeGroup.object_id">{{
                    employeeGroup.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('employee_group')" class="help is-danger">{{ errors.first('employee_group') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Sub Group</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('subGroup') }">
                <select name="subGroup" class="select" v-model="employeeSubGroup_input[key]" v-validate="'required'" >
                  <option disabled selected>Choose</option>
                  <option v-for="(subGroup, key) in employeeSubGroups_key[key]" :key="key" :value="subGroup.object_id">{{
                    subGroup.name
                    }}</option>
                </select>
              </div> 
              <p v-show="errors.has('subGroup')" class="help is-danger">{{ errors.first('subGroup') }}</p>
            </div>
          </div>
        </div>
         <div class="column is-4">
          <div class="field">
            <label class="label">Bisnis Area</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('busArea') }">
                <select name="busArea" class="select" v-model="busArea_input[key]" v-validate="'required'" 
                 @change="getBusAreaChild_tampung(key,busArea_input[key])">
                  <option disabled selected>Choose</option>
                  <option v-for="(employeeGroup, key) in busAreas" :key="key" :value="employeeGroup.object_code">{{
                    employeeGroup.business_area
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('busArea')" class="help is-danger">{{ errors.first('busArea') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Personal Area</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('personalArea') }">
                <select name="personalArea" class="select" v-model="personalArea_input[key]" v-validate="'required'" 
                >
                  <option disabled selected>Choose</option>
                  <option v-for="(employeeGroup, key) in personalAreas" :key="key" :value="employeeGroup.object_id">{{
                    employeeGroup.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('personalArea')" class="help is-danger">{{ errors.first('personalArea') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kota Penempatan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('city') }">
                <select name="city" class="select" v-model="personalSubArea_input[key]" v-validate="'required'" >
                  <option disabled selected>Choose</option>
                  <option v-for="(city, key) in personalSubAreas" :key="key" :value="city.id">{{
                    city.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('city')" class="help is-danger">{{ errors.first('city') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Payroll Area</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('payArea') }">
                <select name="payArea" class="select" v-model="payArea_input[key]" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(city, key) in payAreas" :key="key" :value="city.payrollarea">{{
                    city.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('payArea')" class="help is-danger">{{ errors.first('payArea') }}</p>
            </div>
          </div>
        </div>                               
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi</label>
            <div class="control">
              <treeselect v-model="position_input[key]" :multiple="false" :options="data" @input="tes_tampung(key,position_input[key])"/>
              <!-- <input class="input" type="text" placeholder="Manager"> -->
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="organization_input[key]" disabled>
            </div>
          </div>
        </div>
         <div class="column is-4">
          <div class="field">
            <label class="label">Job</label>
            <div class="control">
              <input class="input" type="text" placeholder="Programmer" v-model="job_input[key]" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Cost Center</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('costCenter') }">
                <select name="costCenter" class="select" v-model="costCenter_input[key]" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(city, key) in costCenters" :key="key" :value="city.costcenter_id">{{
                    city.porsi
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('costCenter')" class="help is-danger">{{ errors.first('costCenter') }}</p>
            </div>
          </div>
        </div>
         <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berlaku</label>
            <div class="control">
              <input class="input" id="begin_date" type="date" placeholder="10-10-2017" name="begin_date" v-model="startDate_input[key]"
                data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">s.d</label>
            <div class="control">
              <input id="end_date" class="input" name="end_date" type="date" placeholder="10-10-2017" v-model="endDate_input[key]"
                data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a>
        </div>
      </div>     
    </div>
    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Reset</a>
    <a class="button is-link is-rounded">Back</a> -->

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import Treeselect from '@riophae/vue-treeselect'
  // import the styles
  import '@riophae/vue-treeselect/dist/vue-treeselect.css'
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue'  
  Vue.use(VueAutosuggest);
  export default {
    components: {
      Breadcrumb,
      Treeselect
    },
    data() {
      return {
        options: [{
          data: []
        }],        
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: "Type 'e'"
        },
        limit: 10,    
        name:'',        
        nik:null,
        buscd:'',
        cUnit:'',
        cPosition:'',   
        components:[],                     
        nik_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        buscds:[],               
        data:[],
        startDate: '',
        endDate: '',
        costCenter: '',
        organization: '',
        job: '',        
        position:null,        
        employeeGroup: '',
        employeeSubGroup: '',
        busArea: '',
        personalArea: '',
        personalSubArea: '',
        payArea: '',        
        startDate_input: [],
        endDate_input: [],
        costCenter_input: [],
        organization_input: [],
        job_input: [],        
        position_input: [],        
        employeeGroup_input: [],
        employeeSubGroup_input: [],
        busArea_input: [],
        personalArea_input: [],
        personalSubArea_input: [],
        payArea_input: [],
        employeeGroups: [],
        employeeSubGroups: [],
        employeeSubGroups_key: [],
        busAreas: [],
        personalAreas: [],
        personalSubAreas: [],
        payAreas: [],
        
        costCenters:[],
        type_organizational :'',
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Penempatan Kerja'
          },
        ]
      }
    },
    created() {
      this.getBusArea();
      this.getPersonalArea();
      this.getPayArea();       
      this.getPersonalSubArea();      
      this.getTree();
      this.getCostCenter();    
      this.getBUSCD();      
      this.getEmployeeGroup();      
      if(this.nik_query != null){
        this.getData();         
        
      }  
    },
    methods: { 
      tes(){
        if (this.buscd == '') {          
          alert('isi nama perusahaan terlebih dahulu !');
        } else {
        this.$axios.get('/users/'+this.buscd+'/treeOrganization?stext='+this.position+'&relationalparentchild=parent-child')
          .then(response => {
            this.type_organizational = response.data.data.organizational_type;            
            if (this.type_organizational == '04') {
              this.$axios.get('/users/'+this.buscd+'/getUnitandJob?stext='+this.position)
              .then(response => {
                this.job = response.data.data.job.organizational_id;
                this.organization = response.data.data.unit.organizational_id; 
                this.$axios.get('/users/'+this.buscd+'/costcenter/unit/'+this.organization+'/posisi/'+this.position)
                .then(response => {
                  this.costCenter = response.data.data[0].costcenter_id;                
                })
                .catch(e => {
                  console.log(e)
                });               
              })
              .catch(e => {
                console.log(e)
              });
              
              
              
            } else {
              alert('bukan posisi !');
              
            }
          })
          .catch(e => {
            console.log(e)
          });  
        }
      },
       tes_tampung(key,position){
        if (this.buscd == '') {          
          alert('isi nama perusahaan terlebih dahulu !');
        } else {
        this.$axios.get('/users/'+this.buscd+'/treeOrganization?stext='+position+'&relationalparentchild=parent-child')
          .then(response => {
            this.type_organizational = response.data.data.organizational_type;            
            if (this.type_organizational == '04') {
              this.$axios.get('/users/'+this.buscd+'/getUnitandJob?stext='+position)
              .then(response => {
                this.job_input[key] = response.data.data.job.organizational_id;
                this.organization_input[key] = response.data.data.unit.organizational_id; 
                this.$axios.get('/users/'+this.buscd+'/costcenter/unit/'+this.organization_input[key]+'/posisi/'+position)
                .then(response => {
                  this.costCenter_input[key] = response.data.data[0].costcenter_id;                
                })
                .catch(e => {
                  console.log(e)
                });               
              })
              .catch(e => {
                console.log(e)
              });
              
              
              
            } else {
              alert('bukan posisi !');
              
            }
          })
          .catch(e => {
            console.log(e)
          });  
        }
      },
      getBusAreaChild(){
        if (this.buscd == '') {          
          alert('isi nama perusahaan terlebih dahulu !');
        } else {
          this.$axios.get('/users/'+this.buscd+'/accountAssignment/'+this.busArea)
          .then(response => {
            this.personalArea = response.data.data[0].personnel_area[0].object_id;
            this.personalSubArea = response.data.data[0].personnel_sub_area[0].id;
            this.payArea = response.data.data[0].payrollarea[0].payrollarea;
          })
          .catch(e => {
            console.log(e)
          });  
        }        
      },
      getBusAreaChild_tampung(key,busArea){
        if (this.buscd == '') {          
          alert('isi nama perusahaan terlebih dahulu !');
        } else {
          this.$axios.get('/users/'+this.buscd+'/accountAssignment/'+busArea)
          .then(response => {
            this.personalArea_input[key] = response.data.data[0].personnel_area[0].object_id;
            this.personalSubArea_input[key] = response.data.data[0].personnel_sub_area[0].id;
            this.payArea_input[key] = response.data.data[0].payrollarea[0].payrollarea;
          })
          .catch(e => {
            console.log(e)
          });  
        }        
      },
      getCostCenter() {
        this.$axios.get('users/costcenter')
          .then(response => {
            this.costCenters = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },    
      getBusArea() {
        this.$axios.get('/users/accountAssignment')
          .then(response => {
            this.busAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPersonalArea() {
        this.$axios.get('/objects/personelArea')
          .then(response => {
            this.personalAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPayArea() {
        this.$axios.get('/users/payrollArea')
          .then(response => {
            this.payAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPersonalSubArea() {
        this.$axios.get('/city/getall')
          .then(response => {
            this.personalSubAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
     
      getEmployeeGroup() {
        this.$axios.get('/objects/employeegroup')
          .then(response => {
            this.employeeGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSubGroup() {
        this.$axios.get('/objects/employeesubgroup/' + this.employeeGroup)
          .then(response => {
            this.employeeSubGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSubGroup_tampung(key,employeeGroup) {
        this.$axios.get('/objects/employeesubgroup/' + employeeGroup)
          .then(response => {
            this.employeeSubGroups_key[key] = response.data.data;
            this.$forceUpdate();
          })
          .catch(e => {
            console.log(e)
          });
      },
       getBUSCD(){
        this.$axios.get('/objects/companytoken/BNKEP')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },                      
      getData(){
         this.buscd = this.buscd_query;
         //console.log(this.buscd);
         this.nik = this.nik_query;
         //this.getCostCenter();   
         this.$axios.get('/users/'+ this.buscd +'/searchprofile/'+ this.nik)
            .then(async response => {
              this.name = response.data.data.name;            
              this.cUnit = response.data.data.unit;            
              this.cPosition = response.data.data.position;            
            })
            .catch(e => {
              console.log(e);
            });
            
            this.$axios.get('/users/'+ this.buscd +'/organizationalassignment/'+ this.nik)
            .then(response => {
              this.components = [];
              response.data.data.forEach((user, key) => {
                this.components.push({
                  begin_date : user.begin_date,
                  end_date : user.end_date,
                  business_code : user.business_code,
                  personal_number : user.personal_number,                   
                  cost_center: user.cost_center[0].costcenter_id,
                  organization: user.organization[0].organizational_id,
                  job: user.job[0].organizational_id,
                  business_area: user.business_area[0].object_code,
                  position_id: user.position_id[0].organizational_id,
                  employee_group: user.employee_group[0].object_id,
                  employee_sub_group: user.employee_sub_group[0].object_id,
                  personal_area: user.personal_area[0].object_id,
                  personal_sub_area: user.personal_sub_area[0].id,
                  payroll_area: user.payroll_area[0].payrollarea                 
                });
                this.key = key; 
                this.$axios.get('/objects/employeesubgroup/' + user.employee_group[0].object_id,)
                .then(response => {
                  this.employeeSubGroups_key[key] = response.data.data;
                  this.$forceUpdate();
                })                                                                          
                this.startDate_input[this.key]= user.begin_date;
                this.endDate_input[this.key]= user.end_date;
                this.costCenter_input[this.key]= user.cost_center[0].costcenter_id,
                this.organization_input[this.key]= user.organization[0].organizational_id,
                this.job_input[this.key]= user.job[0].organizational_id,
                this.position_input[this.key]= user.position_id[0].organizational_id,
                this.employeeGroup_input[this.key]= user.employee_group[0].object_id,
                this.employeeSubGroup_input[this.key]= user.employee_sub_group[0].object_id,
                this.busArea_input[this.key]= user.business_area[0].object_code,
                this.personalArea_input[this.key]= user.personal_area[0].object_id,
                this.personalSubArea_input[this.key]= user.personal_sub_area[0].id,
                this.payArea_input[this.key]= user.payroll_area[0].payrollarea
              });
            })          
            .catch(e => {
              console.log(e);
            });
       },      
      onSelected(option) {        
         if(option == null){
          this.nik = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
         }else{
          this.nik = option.item;
          if(this.buscd == ''){
            alert('isi nama perusahaan terlebih dahulu !')

          }else{  
            
            this.$axios.get('/users/'+ this.buscd +'/searchprofile/'+ this.nik)
            .then(async response => {
              this.name = response.data.data.name;            
              this.cUnit = response.data.data.unit;            
              this.cPosition = response.data.data.position;            
            })
            .catch(e => {
              console.log(e);
            });
            
            this.$axios.get('/users/'+ this.buscd +'/organizationalassignment/'+ this.nik)
            .then(response => {
              this.components = [];
              response.data.data.forEach((user, key) => {
                this.components.push({
                  begin_date : user.begin_date,
                  end_date : user.end_date,
                  business_code : user.business_code,
                  personal_number : user.personal_number,                   
                  cost_center: user.cost_center[0].costcenter_id,
                  organization: user.organization[0].organizational_id,
                  job: user.job[0].organizational_id,
                  business_area: user.business_area[0].object_code,
                  position_id: user.position_id[0].organizational_id,
                  employee_group: user.employee_group[0].object_id,
                  employee_sub_group: user.employee_sub_group[0].object_id,
                  personal_area: user.personal_area[0].object_id,
                  personal_sub_area: user.personal_sub_area[0].id,
                  payroll_area: user.payroll_area[0].payrollarea                 
                });
                this.key = key; 
                this.$axios.get('/objects/employeesubgroup/' + user.employee_group[0].object_id,)
                .then(response => {
                  this.employeeSubGroups_key[key] = response.data.data;
                  this.$forceUpdate();
                })                                                                          
                this.startDate_input[this.key]= user.begin_date;
                this.endDate_input[this.key]= user.end_date;
                this.costCenter_input[this.key]= user.cost_center[0].costcenter_id,
                this.organization_input[this.key]= user.organization[0].organizational_id,
                this.job_input[this.key]= user.job[0].organizational_id,
                this.position_input[this.key]= user.position_id[0].organizational_id,
                this.employeeGroup_input[this.key]= user.employee_group[0].object_id,
                this.employeeSubGroup_input[this.key]= user.employee_sub_group[0].object_id,
                this.busArea_input[this.key]= user.business_area[0].object_code,
                this.personalArea_input[this.key]= user.personal_area[0].object_id,
                this.personalSubArea_input[this.key]= user.personal_sub_area[0].id,
                this.payArea_input[this.key]= user.payroll_area[0].payrollarea
              });
            })          
            .catch(e => {
              console.log(e);
            });
            
          }
          }         
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.nik = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/'+text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,                
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);
            
            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })
          
          .catch(e => {
            console.log(e);
          }); 
        /* Full control over filtering. Maybe fetch from API?! Up to you!!! */
        
      },  
      tambahComponent() {        
                
        this.$validator.validateAll('form').then(async result => {
          if (!result) return;
        
        if(this.buscd == ''){
            alert('isi nama perusahaan terlebih dahulu !')
        }else{                           
            this.components.push({ 
              begin_date: this.startDate, 
              end_date: this.endDate,
              business_code : this.buscd,
              personal_number : this.nik,            
              cost_center: this.costCenter,
              organization: this.organization,
              job: this.job,
              business_area: this.busArea,
              position_id: this.position,
              employee_group: this.employeeGroup,
              employee_sub_group: this.employeeSubGroup,
              personal_area: this.personalArea,
              personal_sub_area: this.personalSubArea,
              payroll_area: this.payArea                  
            });            
            this.components.forEach((user, key) => {
              this.key = key; 
                this.$axios.get('/objects/employeesubgroup/' + user.employee_group,)
                .then(response => {
                  this.employeeSubGroups_key[key] = response.data.data;
                  this.$forceUpdate();
                })                      
                this.startDate_input[this.key]= user.begin_date;
                this.endDate_input[this.key]= user.end_date;
                this.costCenter_input[this.key]= user.cost_center,
                this.organization_input[this.key]= user.organization,
                this.job_input[this.key]= user.job,
                this.position_input[this.key]= user.position_id,
                this.employeeGroup_input[this.key]= user.employee_group,
                this.employeeSubGroup_input[this.key]= user.employee_sub_group,
                this.busArea_input[this.key]= user.business_area,
                this.personalArea_input[this.key]= user.personal_area,
                this.personalSubArea_input[this.key]= user.personal_sub_area,
                this.payArea_input[this.key]= user.payroll_area
            })            
        }
        });        
      },
      storeComponent() {      

        if(this.buscd != ''){
          
          if(this.nik_query == null){            
            if(this.name ==  ''){
              alert('data nik tidak ada');            
            }else{             
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  begin_date: this.startDate_input[index1], 
                  end_date: this.endDate_input[index1],                  
                  cost_center: ''+ this.costCenter_input[index1],
                  organization: this.organization_input[index1],
                  job: this.job_input[index1],
                  business_area: this.busArea_input[index1],
                  position_id: this.position_input[index1],
                  employee_group: this.employeeGroup_input[index1],
                  employee_sub_group: this.employeeSubGroup_input[index1],
                  personal_area: this.personalArea_input[index1],
                  personal_sub_area: this.personalSubArea_input[index1],
                  payroll_area: this.payArea_input[index1]                  
                });
              });              
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/'+ this.buscd +'/organizationalassignment/'+this.nik, this.components)
                    .then(response => {                 
                        
                        this.clearNik()                                              
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });            
            }
          }else{            
             
              this.components.forEach((childrens, index1) => {                
                Object.assign(this.components[index1], {
                  begin_date: this.startDate_input[index1], 
                  end_date: this.endDate_input[index1],                  
                  cost_center: ''+this.costCenter_input[index1],
                  organization: this.organization_input[index1],
                  job: this.job_input[index1],
                  business_area: this.busArea_input[index1],
                  position_id: this.position_input[index1],
                  employee_group: this.employeeGroup_input[index1],
                  employee_sub_group: this.employeeSubGroup_input[index1],
                  personal_area: this.personalArea_input[index1],
                  personal_sub_area: this.personalSubArea_input[index1],
                  payroll_area: this.payArea_input[index1]                  
                });
              });              
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/'+ this.buscd +'/organizationalassignment/'+this.nik, this.components)
                    .then(response => {                 
                        //this.clearNik()                                              
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });            
            }
          
          
        }else{
          alert('isi nama perusahaan terlebih dahulu !')
          
          //this.clearNik()
        }
      },
      deleteComponents(key) {
        
            this.components.splice(key, 1);                                    
            this.components.forEach((user, key) => {              
               this.key = key; 
                this.$axios.get('/objects/employeesubgroup/' + user.employee_group,)
                .then(response => {
                  this.employeeSubGroups_key[key] = response.data.data;
                  this.$forceUpdate();
                })                      
                this.startDate_input[this.key]= user.begin_date;
                this.endDate_input[this.key]= user.end_date;
                this.costCenter_input[this.key]= user.cost_center,
                this.organization_input[this.key]= user.organization,
                this.job_input[this.key]= user.job,
                this.position_input[this.key]= user.position_id,
                this.employeeGroup_input[this.key]= user.employee_group,
                this.employeeSubGroup_input[this.key]= user.employee_sub_group,
                this.busArea_input[this.key]= user.business_area,
                this.personalArea_input[this.key]= user.personal_area,
                this.personalSubArea_input[this.key]= user.personal_sub_area,
                this.payArea_input[this.key]= user.payroll_area                                            
            })
      },
      clearNik(){
        
        this.components = [];   
        if(this.nik != null){
          this.$refs.myRefName.searchInput = '';
        }     
        this.nik = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        
        
        this.$nextTick(() => this.$validator.reset());        
      }, 
      async getTree(){
        
      this.data = [];
      await this.$axios.get('/company')
        .then(response => {
          response.data.data.forEach(async (parent, indexparent) => {
            await this.data.push({
              indexparent:indexparent,
              id: parent.business_code,              
              label: parent.company_name, 
                   
              children:[]
            });                                                    
        await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?relationalparentchild=parent-child')
        .then(response => {
          response.data.data.child.forEach(async (child, index) => {
            await this.data[indexparent].children.push({
              index:index,
              id: child.organizational_id_child,                 
              label: child.organizational_name,              
              children:[]                                            
            });                                          
              await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child.organizational_id_child+'&relationalparentchild=parent-child')
                .then(response => {
                  response.data.data.child.forEach(async (child1, index1) => {
                    await  this.data[indexparent].children[index].children.push({
                      index1:index1,
                      id: child1.organizational_id_child,                      
                      label: child1.organizational_name,                      
                      children:[]
                    });
                    await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child1.organizational_id_child+'&relationalparentchild=parent-child')
                      .then(response => {
                        response.data.data.child.forEach(async (child2, index2) => {
                          await  this.data[indexparent].children[index].children[index1].children.push({
                            index2:index2,
                            id: child2.organizational_id_child,                            
                            label: child2.organizational_name,                            
                            children:[]
                          });
                          await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child2.organizational_id_child+'&relationalparentchild=parent-child')
                            .then(response => {
                              response.data.data.child.forEach(async (child3, index3) => {
                                await  this.data[indexparent].children[index].children[index1].children[index2].children.push({
                                  index3:index3,
                                  id: child3.organizational_id_child,                                                               
                                  label: child3.organizational_name,          
                                  children:[]
                                });
                                await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child3.organizational_id_child+'&relationalparentchild=parent-child')
                                .then(response => {
                                  response.data.data.child.forEach(async (child4, index4) => {
                                    await  this.data[indexparent].children[index].children[index1].children[index2].children[index3].children.push({
                                      index4:index4,
                                      id: child4.organizational_id_child,                                      
                                      label: child4.organizational_name,                                      
                                      children:[]
                                    });
                                    await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child4.organizational_id_child+'&relationalparentchild=parent-child')
                                    .then(response => {
                                      response.data.data.child.forEach(async (child5, index5) => {
                                        await  this.data[indexparent].children[index].children[index1].children[index2].children[index3].children[index4].children.push({
                                          index5:index5,
                                          id: child5.organizational_id_child,                                          
                                          label: child5.organizational_name,                                          
                                          children:[]
                                        });
                                      });                                                                                                                                                    
                                    }).catch(e => {
                                      console.log(e);
                                    });
                                  });                                                                                                                                                    
                                }).catch(e => {
                                  console.log(e);
                                });
                              });                                                                                                                                                    
                            }).catch(e => {
                              console.log(e);
                            });
                        });                                                                                                                                                    
                      }).catch(e => {
                        console.log(e);
                      });
                  });                                                                                                                                                    
                }).catch(e => {
                  console.log(e);
                });
          });
          }).catch(e => {
                  console.log(e);
                });
          });                               
        }).catch(e => {
          console.log(e);
        });                                  
      }      
    }
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }
</style>
