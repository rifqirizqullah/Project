<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/employee-data/diffable/diffable-search" class="button is-success is-rounded is-pulled-right"><span>
        <i class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-plus-circle" aria-hidden="true"></i> Disabilitas
    </h3>
    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Induk Karyawan</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="nik_query" disabled>
            </div>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="box shadowed" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Disabilitas</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="start_input[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="end_input[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Disabilitas</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('disability_type') }">
                <select name="disability_type" class="select" v-model="disability_type_input[key]"
                  v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(disabilityType, key) in disabilityTypes" :key="key" :value="disabilityType.id">{{
                    disabilityType.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('disability_type')" class="help is-danger">{{errors.first('disability_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="columns">
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Deskripsi</label>
                <div class="control">
                  <textarea class="textarea" placeholder="Deskripsi Disabilitas" rows="4"
                    v-model="description_input[key]"></textarea>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
    </div>

        <div class="box">
      <h4 class="subtitle is-4">Formulir Disabilitas</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="columns">
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tipe Disabilitas</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.disability_type') }">
                    <select name="disability_type" class="select" v-model="disabilityType" v-validate="'required'"
                      data-vv-scope="form">
                      <option disabled selected>Pilih</option>
                      <option v-for="(disabilityType, key) in disabilityTypes" :key="key"
                        :value="disabilityType.id">{{
                        disabilityType.value
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.disability_type')" class="help is-danger">{{errors.first('form.disability_type')
                    }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Deskripsi</label>
            <div class="control">
              <textarea class="textarea" placeholder="Deskripsi Disabilitas" rows="4" v-model="description"></textarea>
            </div>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>
    <div class="columns">
      <div class="column">
          <a class="button is-pulled-right is-success is-rounded" @click="storeComponent()">Simpan</a>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue'
  Vue.use(VueAutosuggest);

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        myDate : new Date().toISOString().slice(0,10),
        startDate: '',
        endDate: '',
        disabilityType: '',
        description: '',
        disabilityTypes: [],
        descriptions: [],
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,
        name: '',
        nik: null,
        cUnit: '',
        cPosition: '',
        components: [],
        buscds: [],
        buscd: '',
        nik_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        disability_type_input: [],
        description_input: [],
        start_input: [],
        end_input: [],
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Disabilitas'
          },
        ]
      }
    },
    created() {
      this.getDisabilityTypes();
      this.getBUSCD();
      this.getHakAkses();
      if (this.nik_query != null) {
        this.getData();
      }
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/DSBLT')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'W') {
              return this.$router.push('/employee-data/diffable/diffable-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        this.buscd = this.buscd_query;
        this.nik = this.nik_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.nik)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('/users/' + this.buscd + '/disability/' + this.nik)
          .then(response => {
            this.components = [];
            response.data.data.forEach((user, key) => {
              this.components.push({
                begin_date: user.begin_date,
                end_date: user.end_date,
                business_code: this.buscd,
                personal_number: user.personal_number,
                disability_type: user.disability_type[0].object_id,
                description: user.description
              });
              this.key = key;
              this.disability_type_input[this.key] = user.disability_type[0].object_id;
              this.description_input[this.key] = user.description;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.nik = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.nik = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('/users/' + this.buscd + '/disability/' + this.nik)
              .then(response => {
                this.components = [];
                response.data.data.forEach((user, key) => {
                  this.components.push({
                    begin_date: user.begin_date,
                    end_date: user.end_date,
                    business_code: this.buscd,
                    personal_number: user.personal_number,
                    disability_type: user.disability_type[0].object_id,
                    description: user.description
                  });
                  this.key = key;
                  this.disability_type_input[this.key] = user.disability_type[0].object_id;
                  this.description_input[this.key] = user.description;
                  this.start_input[this.key] = user.begin_date;
                  this.end_input[this.key] = user.end_date;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.nik = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      tambahComponent() {
        this.$validator.validateAll('form').then(async result => {
          if (!result) return;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.nik,
              disability_type: this.disabilityType,
              description: this.description
            });
            this.components.forEach((user, key) => {
              this.key = key;
              this.disability_type_input[this.key] = user.disability_type;
              this.description_input[this.key] = user.description;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
            })
          }
          this.clearForm();
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.nik_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  begin_date: this.start_input[index1],
                  end_date: this.end_input[index1],
                  disability_type: this.disability_type_input[index1],
                  description: this.description_input[index1]
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                text: 'Anda tidak dapat membatalkan',
                type: 'peringatan',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/disability/' + this.nik, this.components)
                    .then(response => {
                      this.clearNik()
                      swal(
                        'Data Tersimpan!',
                        'Data disablilitas berhasil tersimpan',
                        'Sukses'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              Object.assign(this.components[index1], {
                begin_date: this.start_input[index1],
                end_date: this.end_input[index1],
                disability_type: this.disability_type_input[index1],
                description: this.description_input[index1]
              });
            });
            swal({
              title: 'Apakah anda yakin ingin menyimpan data ini?',
              text: 'Anda tidak dapat membatalkan',
              type: 'peringatan',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/disability/' + this.nik, this.components)
                  .then(response => {
                    swal(
                      'Data Tersimpan!',
                      'Data disablilitas berhasil tersimpan',
                      'Sukses'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        this.components.forEach((user, key) => {
          this.key = key;
          this.disability_type_input[this.key] = user.disability_type;
          this.description_input[this.key] = user.description;
          this.start_input[this.key] = user.begin_date;
          this.end_input[this.key] = user.end_date;
        })
      },
      clearNik() {
        this.components = [];
        if (this.nik != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.nik = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.disabilityType = '';
        this.description = '';
        this.$nextTick(() => this.$validator.reset());
      },
      clearForm() {
        this.startDate = '';
        this.endDate = '';
        this.disabilityType = '';
        this.description = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getDisabilityTypes() {
        // this.$axios.get('/objects/disabilitytype')
         this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=DFTYP')
          .then(response => {
            this.disabilityTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/DSBLT')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      }
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
