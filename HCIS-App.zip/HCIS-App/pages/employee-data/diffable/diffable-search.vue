<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <!--<div class="box has-text-white has-background-danger">
      Filter Search
    </div>-->
    <!-- <nuxt-link to="/employee-data/diffable"><a class="button is-link is-rounded is-pulled-right"><span><i
            class="fa fa-plus"></i> Tambah Data </span></a>
    </nuxt-link> -->
    <a class="button is-link is-rounded is-pulled-right" @click="openFormModal()">
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data
      </span>
    </a>
    <h3 class="subtitle is-3"><i class="fa fa-plus-circle"></i> Data Disabilitas </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i
                  class="fa fa-plus" aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i
                  class="fa fa-trash" aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i
                class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Tipe Disabilitas</th>
          <th>Tanggal Awal Berakhir</th>
          <th>Tanggal Akhir Berakhir</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(diffable, key) in diffables" :key="key">
          <td>{{ key + 1 }}</td>
          <td>{{ diffable.business_code.company_name }}</td>
          <td>{{ diffable.personnel_number.personnel_number }}</td>
          <td>{{ diffable.disability_type.object_name }}</td>
          <td>{{ formatDate(diffable.begin_date) }}</td>
          <td>{{ formatDate(diffable.end_date) }}</td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="editDiffable(diffable.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="diffable.object_identifier ? deleteDiffable(key, diffable.object_identifier) : removeDiffable(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitDiffable(diffable.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>

    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getDiffables()">
    </pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Disabilitas</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                    <select name="company" class="select" v-model="company" @change="getParam()"
                      v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                        {{ company.company_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                </div>
              </div>
            </div>
          </div>

          <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                      class="is-link">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tipe Disabilitas</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('disability_type') }">
                      <select name="diffableType" class="select" v-model="diffableType" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(diffableType, key) in diffableTypes" :key="key" :value="diffableType.object_code">
                          {{ diffableType.object_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('disability_type')" class="help is-danger">
                      {{ errors.first('disability_type') }}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Deskripsi</label>
                  <div class="control">
                    <textarea name="description" class="textarea" placeholder="Deskripsi" rows="5" v-model="description"
                      v-bind:class="{ 'is-danger': errors.has('description')}" v-validate="'required'"></textarea>
                  </div>
                  <p v-show="errors.has('description')" class="help is-danger"> {{ errors.first('description')}}</p>
                </div>
              </div>
            </div>
          </span>

        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveDiffable()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Delimit Data Disabilitas</p>
          <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                    data-vv-scope="delimit" disabled>
                </div>
                <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                  {{ errors.first('delimit.begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                    data-vv-scope="delimit">
                </div>
                <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                  {{ errors.first('delimit.end_date') }}
                </p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="delimitDiffable()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from "~/components/Breadcrumb";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  import VueAutosuggest from "vue-autosuggest";
  Vue.use(VueAutosuggest);
  import moment from "moment";

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        // myDate: new Date().toISOString().slice(0, 10),
        diffables: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        diffableType: null,
        diffableTypes: [],
        description: '',

        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: "",
        empolyeePosition: "",
        empolyeeUnit: "",

        perPage: 5,
        search: '',
        pagination: {
          'current_page': 1
        },

        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,

        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        hakAkses: '',

        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Disabilitas'
          },
        ],
        isActiveForm: false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getDiffables();
      this.getCompany();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
      // this.getHakAkses();
    },
    methods: {
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getEmployeeData(nik) {
        await this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      getDiffableType() {
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=DFTYP" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.diffableTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getDiffables() {
        this.$axios
          .get("hcis/api/disability?include=business_code&include=personnel_number&include=disability_type&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&orderoid=asc" +
            '&page=' + this.pagination.current_page +
            '&per_page=' + this.perPage
          )
          // .get("hcis/api/disability")
          .then(response => {
            this.diffables = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getDiffable(objectIdentifier) {
        let diffable = await this.diffables.find(
          diffable => diffable.object_identifier == objectIdentifier
        );
        this.objectIdentifier = diffable.object_identifier;
        this.startDate = diffable.begin_date;
        this.endDate = diffable.end_date;
        this.diffableType = diffable.disability_type;
        this.description = diffable.description;

        this.company = diffable.business_code.business_code;
        this.employee = diffable.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.getDiffableType();
      },

      openFormModal() {
        this.isActiveForm = true;
        this.getDiffableType();
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.diffableType = null;
        this.description = "";

        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = "";
        this.empolyeeUnit = "";

        this.$nextTick(() => this.$validator.reset());
      },
      storeDiffable() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/disability", {
              begin_date: this.startDate,
              end_date: this.endDate,
              begin_date: this.startDate,
              end_date: this.endDate,
              disability_type: this.diffableType,
              description: this.description,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getDiffables();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data disabilitas.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      async editDiffable(objectIdentifier) {
        await this.getDiffable(objectIdentifier);
        this.openFormModal();
      },
      updateDiffable() {
        this.$validator.validateAll("disability").then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/disability", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              disability_type: this.diffableType,
              description: this.description,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getDiffables();
              this.closeFormModal();
              swal(
                "Updated!",
                "Successfully updated data disabilitas.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveDiffable() {
        this.objectIdentifier ? this.updateDiffable() : this.storeDiffable();
      },

      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitDiffable(objectIdentifier) {
        this.openFormModalDelimit();
        let diffable = await this.diffables.find(
          diffable => diffable.object_identifier == objectIdentifier
        );
        this.objectIdentifier = diffable.object_identifier;
        this.startDate = diffable.begin_date;
        this.endDate = diffable.end_date;
      },
      delimitDiffable() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/disability", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getDiffables();
              this.closeFormModalDelimit();
              swal("Delimited!", response.data.message, "success");
            })
            .catch(e => {
              console.log(e);
            });
        });
      },

      deleteDiffable(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/disability?object_identifier=" + objectIdentifier
              )
              .then(response => {
                swal("Deleted!", response.data.message, "success");
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeDiffable(key);
              });
          }
        });
      },
      removeDiffable(key) {
        this.diffables.splice(key, 1);
      },
      formatDate(date) {
        return moment(date).format("DD/MM/YYYY");
      }
      // getHakAkses() {
      //   this.$axios.get('/users/hakakses/DSBLT')
      //     .then(response => {
      //       this.hakAkses = response.data.data.access;
      //       if (this.hakAkses != '*' && this.hakAkses != 'R') {
      //         return this.$router.push('/employee-data/diffable')
      //       }
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getDiffable() {
      //   // this.$axios.get('users/disability')
      //   this.$axios.get('hcis/api/disability?begin_date_lte=' + this.myDate + '&end_date_gte=' + this.myDate +
      //       '&per_page=20')
      //     .then(response => {
      //       this.diffables = [];
      //       response.data.data.forEach(async (diffable, key) => {
      //         await this.diffables.push({
      //           startDate: diffable.begin_date,
      //           endDate: diffable.end_date,
      //           personalNumber: diffable.personnel_number.personnel_number,
      //           buscd: diffable.business_code
      //         })
      //       });
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // getColumn() {
      //   this.$axios.get('/users/disability/column')
      //     .then(response => {
      //       this.columns = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getLogic() {
      //   this.$axios.get('/objects/oprationsql')
      //     .then(response => {
      //       this.logics = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getCondition() {
      //   this.$axios.get('/objects/conditionsql')
      //     .then(response => {
      //       this.conditions = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getSearchDynamic() {
      //   this.paramsearchforms = {
      //     table: "Disabilitas", //harcode sesuai form *referensi table_code*
      //     column: this.columns_model,
      //     query: this.logics_model,
      //     value: this.filters_model,
      //     andor: this.conditions_model
      //   }
      //   console.log(this.paramsearchforms)
      //   this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
      //     .then(response => {

      //       this.diffables = [];
      //       response.data.data.forEach(async (diffable, key) => {
      //         await this.diffables.push({
      //           startDate: diffable.begin_date,
      //           endDate: diffable.end_date,
      //           personalNumber: diffable.personal_number,
      //           buscd: diffable.business_code
      //         })
      //       });
      //       console.log(this.diffables)
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // addNewFormSearch() {
      //   this.searchforms.push({
      //     column: '',
      //     logic: '',
      //     filter: '',
      //     condition: ''
      //   })
      // },
      // deleteFormSearch(key) {
      //   this.searchforms.splice(key, 1)
      // }
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
