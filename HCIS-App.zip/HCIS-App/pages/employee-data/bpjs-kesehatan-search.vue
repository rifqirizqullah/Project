<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Bpjs Kesehatan
    </h3>
    <div class="box has-text-white has-background-danger">
      Filter Search
    </div>
    <div class="box">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Column</label>
              <div class="control">
                <div class="select">
                  <select v-model="form.column">
                    <option>Personal Number</option>
                    <option>Full Name</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logic</label>
              <div class="control">
                <div class="select">
                  <select v-model="form.logic">
                    <option>Is Equal To</option>
                    <option>Is Not Equal To</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="form.filter">
              </div>
            </div>
          </div>
          <div class="column">
            <div class="field is-2">
              <label class="label">Condition</label>
              <div class="control">
                <div class="select">
                  <select v-model="form.condition">
                    <option>And</option>
                    <option>Or</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded">Cari</a>
    <br><br>
    <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Personal Number</th>
          <th>Full Name</th>
          <th>Birth Place</th>
          <th>Action</th>
        </tr>
        <tr>
          <th>1</th>
          <th>S007</th>
          <th>Mutakil</th>
          <th>Palembang</th>
          <th>
            <a class="button is-success is-outlined is-rounded"><i class="fa fa-pencil" aria-hidden="true"></i></a>
            <a class="button is-danger is-outlined is-rounded"><i class="fa fa-trash" aria-hidden="true"></i></a>
          </th>
        </tr>
      </thead>
    </table>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import Vue from 'vue';
  import VeeValidate from 'vee-validate';
  Vue.use(VeeValidate);
  import swal from 'sweetalert';

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        nikAuth: this.$auth.user.nik,
        i: null,
        startDate: '',
        endDate: '',
        businessCode: '1000',
        insuranceNumber: '',
        insuranceCompany: '',
        percentEmployer: '',
        amountEmployer: '',
        personalNumber: '',
        percentEmployee: '',
        amountEmployee: '',
        insurances: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'BPJS Kesehatan'
          },
        ]
      }
    },
    created() {

    },
    methods: {
      resetForm() {
        this.i = null;
        this.startDate = '';
        this.endDate = '';
        this.polisNumber = '';
        this.personalNumber = '';
        this.insuranceCompany = '',
          this.companyPaymentPortion = '',
          this.percentageCpp = '',
          this.employeePaymentPortion = '',
          this.percentageEpp = '',
          this.$nextTick(() => this.$validator.reset())
      },
      saveInsurance() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;

          if (this.i != null) {
            this.insurances[this.key] = {
              i: this.i,
              startDate: this.startDate,
              endDate: this.endDate,
              businessCode: this.businessCode,
              personalNumber: this.personalNumber,
              insuranceNumber: this.insuranceNumber,
              insuranceCompany: this.insuranceCompany,
              percentEmployer: this.percentEmployer,
              amountEmployer: this.amountEmployer,
              percentEmployee: this.percentEmployee,
              amountEmployee: this.amountEmployee,
              nikAuth: this.nikAuth
            }
          } else {
            await this.insurances.push({
              i: this.i,
              startDate: this.startDate,
              endDate: this.endDate,
              businessCode: this.businessCode,
              personalNumber: this.personalNumber,
              insuranceNumber: this.insuranceNumber,
              insuranceCompany: this.insuranceCompany,
              percentEmployer: this.percentEmployer,
              amountEmployer: this.amountEmployer,
              percentEmployee: this.percentEmployee,
              amountEmployee: this.amountEmployee,
              nikAuth: this.nikAuth
            })
          }
          this.storeInsurance();
          console.log(this.insurances)
          // this.resetForm();
          swal(
            'Saved!',
            'Successfully saved Insurance.',
            'success'
          )
        });
      },
      async storeInsurance() {
        let insurances = await this.insurances.map(insurance => {
          return {
            begin_date: insurance.startDate,
            end_date: insurance.endDate,
            business_code: insurance.businessCode,
            personal_number: insurance.personalNumber,
            insurance_number: insurance.insuranceNumber,
            insurance_company: insurance.insuranceCompany,
            percent_employer: insurance.percentEmployer,
            amount_employer: insurance.amountEmployer,
            percent_employee: insurance.percentEmployee,
            amount_employee: insurance.amountEmployee,
            change_user: insurance.nikAuth,
          };
        });
        this.$axios.post('/users/' + this.nikAuth + '/bpjskesehatan/' + this.personalNumber, insurances)
          .then(response => {
            this.insurances = [];
            response.data.data.forEach((insurance, key) => {
              this.insurances.push({
                key: key,
                startDate: insurance.begin_date,
                endDate: insurance.end_date,
                businessCode: insurance.business_code,
                personalNumber: insurance.personal_number,
                insuranceNumber: insurance.insurance_number,
                insuranceCompany: insurance.insurance_company,
                percentEmployer: insurance.percent_employer,
                amountEmployer: insurance.amount_employer,
                amountEmployee: insurance.amount_employee,
                percentEmployee: insurance.percent_employee,
                nikAuth: insurance.change_user
              });
            });
          })
          .catch(e => {
            console.log(e);
          })
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    }
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
