<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcrumb"></Breadcrumb>
    <hr>
    <!-- <nuxt-link to="/employee-data/spesific-date"><a class="button is-link is-rounded is-pulled-right"><span><i class="fa fa-plus"></i> Tambah Data </span></a>
    </nuxt-link> -->
    <a class="button is-link is-rounded is-pulled-right" @click="openFormModal()">
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data
      </span>
    </a>
    <h3 class="subtitle is-3"><i class="fa fa-calendar"></i> Data Tanggal Penting </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{column.column_name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{logic.name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{condition.name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column">
            <div v-if="key==0">
              <br>
              <a class="button is-success is-rounded is-outlined is-pulled-right" @click="addSearchForm()"><i
                  class="fa fa-plus"></i></a>
            </div>
            <div v-else>
              <br>
              <a class="button is-danger is-rounded is-outlined is-pulled-right" @click="deleteSearchForm(key)"><i
                  class="fa fa-trash"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-rounded is-success is-pulled-right" @click="getSearchDynamic()"><span><i
                class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tipe Tanggal</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(specificDate, key) in specificDates" :key="key">
          <td>{{ key + 1 }}</td>
          <td>{{ specificDate.business_code.company_name }}</td>
          <td>{{ specificDate.personnel_number.personnel_number }}</td>
          <td>{{ formatDate(specificDate.begin_date) }}</td>
          <td>{{ specificDate.date_type.object_name }}</td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="editSpecificDate(specificDate.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="specificDate.object_identifier ? deleteSpecificDate(key, specificDate.object_identifier) : removeSpecificDate(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>

    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getSpecificDates()">
    </pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Tanggal Penting</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                    <select name="company" class="select" v-model="company" @change="getParam()"
                      v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                        {{ company.company_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                </div>
              </div>
            </div>
          </div>

          <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                      class="is-link">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tipe Tanggal</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('date_type') }">
                      <select name="dateType" class="select" v-model="dateType" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(dateType, key) in dateTypes" :key="key" :value="dateType.object_code">
                          {{ dateType.object_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('date_type')" class="help is-danger">{{ errors.first('date_type') }}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </span>

        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveSpecificDate()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from "~/components/Breadcrumb";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  import VueAutosuggest from "vue-autosuggest";
  Vue.use(VueAutosuggest);
  import moment from "moment";

  export default {
    components: {
      Breadcrumb
    },
    data() {
      return {
        // myDate: new Date().toISOString().slice(0, 10),
        // paramsearchforms: '',
        specificDates: [],
        objectIdentifier: null,
        startDate: null,
        dateType: null,
        dateTypes: [],

        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: "",
        empolyeePosition: "",
        empolyeeUnit: "",

        perPage: 5,
        search: '',
        pagination: {
          'current_page': 1
        },

        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,

        columns_model: [],
        logics_model: [],
        filters_model: [],
        conditions_model: [],
        columns: [],
        logics: [],
        conditions: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],

        breadcrumb: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Tanggal Penting'
          }
        ],
        isActiveForm: false,
      }
    },
    created() {
      this.getSpecificDates();
      this.getCompany();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
    },
    methods: {
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getEmployeeData(nik) {
        await this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      getdateType() {
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=DTETY" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.dateTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getSpecificDates() {
        this.$axios
          .get("hcis/api/specificdate?include=business_code&include=personnel_number&include=date_type&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&orderoid=asc" +
            '&page=' + this.pagination.current_page +
            '&per_page=' + this.perPage
          )
          // .get("hcis/api/specificdate")
          .then(response => {
            this.specificDates = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getSpecificDate(objectIdentifier) {
        let specificDate = await this.specificDates.find(
          specificDate => specificDate.object_identifier == objectIdentifier
        );
        this.objectIdentifier = specificDate.object_identifier;
        this.startDate = specificDate.begin_date;
        this.dateType = specificDate.date_type.object_code;

        this.company = specificDate.business_code.business_code;
        this.employee = specificDate.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.getdateType();
      },

      openFormModal() {
        this.isActiveForm = true;
        this.getdateType();
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.dateType = null;

        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = "";
        this.empolyeeUnit = "";

        this.$nextTick(() => this.$validator.reset());
      },
      storeSpecificDate() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/specificdate", {
              begin_date: this.startDate,
              date_type: this.dateType,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getSpecificDates();
              this.closeFormModal();
              swal("Saved!", "Successfully saved data tanggal penting.", "success");
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      async editSpecificDate(objectIdentifier) {
        await this.getSpecificDate(objectIdentifier);
        this.openFormModal();
      },
      updateSpecificDate() {
        this.$validator.validateAll("specificdate").then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/specificdate", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              date_type: this.dateType,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getSpecificDates();
              this.closeFormModal();
              swal("Updated!", "Successfully updated data tanggal penting.", "success");
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveSpecificDate() {
        this.objectIdentifier ? this.updateSpecificDate() : this.storeSpecificDate();
      },

      deleteSpecificDate(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete("hcis/api/specificdate?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", response.data.message, "success");
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeSpecificDate(key);
              });
          }
        });
      },
      removeSpecificDate(key) {
        this.SpecificDates.splice(key, 1);
      },
      formatDate(date) {
        return moment(date).format("DD/MM/YYYY");
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      },

      // getColumn() {
      //   this.$axios.get('/objects/alltable/SpecificDate/column')
      //     .then(response => {
      //       this.columns = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // getLogic() {
      //   this.$axios.get('/objects/oprationsql')
      //     .then(response => {
      //       this.logics = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // getCondition() {
      //   this.$axios.get('/objects/conditionsql')
      //     .then(response => {
      //       this.conditions = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // addSearchForm() {
      //   this.searchforms.push({
      //     column: '',
      //     logic: '',
      //     filter: '',
      //     condition: ''
      //   });
      // },
      // deleteSearchForm(key) {
      //   this.searchforms.splice(key, 1);
      // },
      // getSearchDynamic() {
      //   this.paramsearchforms = {
      //     table: 'SpecificDate', //harcode sesuai form *referensi table_code*
      //     column: this.columns_model,
      //     query: this.logics_model,
      //     value: this.filters_model,
      //     andor: this.conditions_model
      //   };
      //   this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
      //     .then(response => {
      //       console.log(response);
      //       this.specificdates = [];
      //       response.data.data.forEach(async (specificdate, key) => {
      //         await this.specificdates.push({
      //           begin_date: specificdate.begin_date,
      //           end_date: specificdate.end_date,
      //           personal_number: specificdate.personnel_number
      //         })
      //       });
      //     });
      // }
    },
    middleware: ["auth"]
  }

</script>
<style>
  .has-background-danger {
    background-color: #6d6d6d !important;
  }

  .button.is-danger {
    background-color: #ce1000;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
