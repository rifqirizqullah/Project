<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/employee-data/insurance-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>

    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Asuransi
    </h3>

    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>

      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Induk Karyawan</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="" v-model="nik_query" disabled>
            </div>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="box shadowed" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Asuransi</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input class="input" id="begin_date" type="date" placeholder="10-10-2017" name="begin_date"
                v-model="start_input[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" class="input" name="end_date" type="date" placeholder="10-10-2017"
                v-model="end_input[key]" data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Asuransi</label>
            <div class="control">
              <div class="select is-fullwidth">
                <select name="insurance_type" v-model="insuranceType_input[key]" v-validate="'required'">
                  <option disabled="disabled" selected>Pilih</option>
                  <option v-for="(insuranceType, i) in insuranceTypes" :key="i" :value="insuranceType.object_id">
                    {{insuranceType.name}}
                  </option>

                </select>
              </div>
            </div>
          </div>
        </div>
        <!-- <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Urut Asuransi</label>
            <div class="control">
              <input class="input" type="text" placeholder="021255" name="insurance_serial_number" v-model="insuranceSerialNumber" v-bind:class="{ 'is-danger': errors.has('polis_number')}" v-validate="'required'">
            </div>
             <p v-show="errors.has('insurance_serial_number')" class="help is-danger"> {{ errors.first('insurance_serial_number')
                  }}</p>
          </div>
        </div> -->
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Polis</label>
            <div class="control">
              <input name="polis_number" class="input" type="text" placeholder="" v-model="insuranceNumber_input[key]"
                v-bind:class="{ 'is-danger': errors.has('polis_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('polis_number')" class="help is-danger"> {{ errors.first('polis_number')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Perusahaan Asuransi</label>
            <div class="control">
              <input name="insurance_company" class="input" type="text" placeholder=""
                v-model="insuranceCompany_input[key]" v-bind:class="{ 'is-danger': errors.has('insurance_company')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('insurance_company')" class="help is-danger"> {{ errors.first('insurance_company')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Porsi Pembayaran Perusahaan (Rp)</label>
            <div class="control">
              <input name="company_payment_portion" class="input" type="text" placeholder=""
                v-model="amountEmployer_input[key]" v-bind:class="{ 'is-danger': errors.has('company_payment_portion')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('company_payment_portion')" class="help is-danger"> {{
              errors.first('company_payment_portion')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Persentase (%) </label>
            <div class="control">
              <input name="percentage_cpp" class="input" type="text" placeholder="" v-model="percentEmployer_input[key]"
                v-bind:class="{ 'is-danger': errors.has('percentage_cpp')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('percentage_cpp')" class="help is-danger"> {{ errors.first('percentage_cpp')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Porsi Pembayaran Karyawan (Rp)</label>
            <div class="control">
              <input class="input" type="text" placeholder="" name="employee_payment_portion"
                v-model="amountEmployee_input[key]" v-bind:class="{ 'is-danger': errors.has('company_payment_portion')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('employee_payment_portion')" class="help is-danger">
              {{errors.first('employee_payment_portion')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Persentase (%) </label>
            <div class="control">
              <input class="input" type="text" placeholder="" name="percentage_epp" v-model="percentEmployee_input[key]"
                v-bind:class="{ 'is-danger': errors.has('company_payment_portion')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('percentage_epp')" class="help is-danger"> {{errors.first('percentage_epp')
              }}</p>
          </div>

        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>

    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Asuransi</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input class="input" id="begin_date" type="date" placeholder="10-10-2017" name="begin_date"
                v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('form.begin_date')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" class="input" name="end_date" type="date" placeholder="10-10-2017" v-model="endDate"
                data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Asuransi</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.insurance_type') }">
                <select name="insurance_type" v-model="insuranceType" v-validate="'required'"
                  data-vv-as="education level" data-vv-scope="form">
                  <option disabled="disabled" selected>Pilih</option>
                  <option v-for="(insuranceType, i) in insuranceTypes" :key="i" :value="insuranceType.id">
                    {{insuranceType.value}}
                  </option>

                </select>
              </div>
              <p v-show="errors.has('form.insurance_type')" class="help is-danger">{{errors.first('form.insurance_type')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Polis</label>
            <div class="control">
              <input name="polis_number" class="input" type="text" placeholder="" v-model="insuranceNumber"
                v-bind:class="{ 'is-danger': errors.has('form.polis_number')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.polis_number')" class="help is-danger"> {{ errors.first('form.polis_number')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Perusahaan Asuransi</label>
            <div class="control">
              <input name="insurance_company" class="input" type="text" placeholder="" v-model="insuranceCompany"
                v-bind:class="{ 'is-danger': errors.has('insurance_company')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.insurance_company')" class="help is-danger"> {{ errors.first('form.insurance_company')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Porsi Pembayaran Perusahaan (Rp)</label>
            <div class="control">
              <input name="company_payment_portion" class="input" type="text" placeholder="" v-model="amountEmployer"
                v-bind:class="{ 'is-danger': errors.has('form.company_payment_portion')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.company_payment_portion')" class="help is-danger"> {{
              errors.first('form.company_payment_portion')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Persentase (%) </label>
            <div class="control">
              <input name="percentage_cpp" class="input" type="text" placeholder="" v-model="percentEmployer"
                v-bind:class="{ 'is-danger': errors.has('form.percentage_cpp')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.percentage_cpp')" class="help is-danger"> {{ errors.first('form.percentage_cpp')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Porsi Pembayaran Karyawan (Rp)</label>
            <div class="control">
              <input class="input" type="text" placeholder="" name="employee_payment_portion" v-model="amountEmployee"
                v-bind:class="{ 'is-danger': errors.has('form.company_payment_portion')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.employee_payment_portion')" class="help is-danger">
              {{errors.first('form.employee_payment_portion')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Persentase (%) </label>
            <div class="control">
              <input class="input" type="text" placeholder="" name="percentage_epp" v-model="percentEmployee"
                v-bind:class="{ 'is-danger': errors.has('form.percentage_epp')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.percentage_epp')" class="help is-danger"> {{errors.first('form.percentage_epp')
              }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>

    </div>
    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Batal</a>
    <a class="button is-link is-rounded">Kembali</a> -->
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue'
  Vue.use(VueAutosuggest);
  import VeeValidate from 'vee-validate';
  Vue.use(VeeValidate);
  import swal from 'sweetalert';

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        myDate : new Date().toISOString().slice(0,10),
        startDate: '',
        endDate: '',
        insuranceType: '',
        insuranceNumber: '',
        insuranceCompany: '',
        percentEmployer: '',
        amountEmployer: '',
        percentEmployee: '',
        amountEmployee: '',
        start_input: [],
        end_input: [],
        insuranceType_input: [],
        insuranceNumber_input: [],
        insuranceCompany_input: [],
        percentEmployer_input: [],
        amountEmployer_input: [],
        percentEmployee_input: [],
        amountEmployee_input: [],
        name: '',
        nik: null,
        cUnit: '',
        cPosition: '',
        components: [],
        buscd: '',
        buscds: [],
        nik_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        insuranceTypes: [],
        hakAkses: '',
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Asuransi'
          },
        ]
      }
    },
    created() {
      this.$store.dispatch("asuransi/getAll");    
      this.$store.dispatch("company/getAll");
      // this.getInsuranceTypes();
      // this.getBUSCD();
      // this.getHakAkses();
      // if (this.nik_query != null) {
      //   this.getData();
      // }
    },
    methods: {
      // getHakAkses() {
      //   this.$axios.get('/users/hakakses/INSRC')
      //     .then(response => {
      //       this.hakAkses = response.data.data.access;
      //       if (this.hakAkses != '*' && this.hakAkses != 'W') {
      //         return this.$router.push('/employee-data/insurance-search')
      //       }
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      getData() {
        this.buscd = this.buscd_query;
        //console.log(this.buscd);
        this.nik = this.nik_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.nik)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('/users/' + this.buscd + '/insurance/' + this.nik)
          .then(response => {
            this.components = [];
            response.data.data.forEach((user, key) => {
              this.components.push({
                begin_date: user.begin_date,
                end_date: user.end_date,
                business_code: this.buscd,
                personal_number: this.nik,
                insurance_type: user.insurance_type[0].object_id,
                insurance_number: user.insurance_number,
                insurance_company: user.insurance_company,
                percent_employer: user.percent_employer,
                amount_employer: user.amount_employer,
                percent_employee: user.percent_employee,
                amount_employee: user.amount_employee
              });
              this.key = key;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
              this.insuranceType_input[this.key] = user.insurance_type[0].object_id;
              this.insuranceNumber_input[this.key] = user.insurance_number;
              this.insuranceCompany_input[this.key] = user.insurance_company;
              this.percentEmployer_input[this.key] = user.percent_employer;
              this.amountEmployer_input[this.key] = user.amount_employer;
              this.percentEmployee_input[this.key] = user.percent_employee;
              this.amountEmployee_input[this.key] = user.amount_employee;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.nik = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.nik = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('/users/' + this.buscd + '/insurance/' + this.nik)
              .then(response => {
                this.components = [];
                response.data.data.forEach((user, key) => {
                  this.components.push({
                    begin_date: user.begin_date,
                    end_date: user.end_date,
                    business_code: this.buscd,
                    personal_number: this.nik,
                    insurance_type: user.insurance_type[0].object_id,
                    insurance_number: user.insurance_number,
                    insurance_company: user.insurance_company,
                    percent_employer: user.percent_employer,
                    amount_employer: user.amount_employer,
                    percent_employee: user.percent_employee,
                    amount_employee: user.amount_employee
                  });
                  this.key = key;
                  this.start_input[this.key] = user.begin_date;
                  this.end_input[this.key] = user.end_date;
                  this.insuranceType_input[this.key] = user.insurance_type[0].object_id;
                  this.insuranceNumber_input[this.key] = user.insurance_number;
                  this.insuranceCompany_input[this.key] = user.insurance_company;
                  this.percentEmployer_input[this.key] = user.percent_employer;
                  this.amountEmployer_input[this.key] = user.amount_employer;
                  this.percentEmployee_input[this.key] = user.percent_employee;
                  this.amountEmployee_input[this.key] = user.amount_employee;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.nik = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
        /* Full control over filtering. Maybe fetch from API?! Up to you!!! */
      },
      tambahComponent() {

        this.$validator.validateAll('form').then(async result => {
          if (!result) return;

          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.nik,
              insurance_type: this.insuranceType,
              insurance_number: this.insuranceNumber,
              insurance_company: this.insuranceCompany,
              percent_employer: this.percentEmployer,
              amount_employer: this.amountEmployer,
              percent_employee: this.percentEmployee,
              amount_employee: this.amountEmployee
            });
            this.components.forEach((user, key) => {
              this.key = key;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
              this.insuranceType_input[this.key] = user.insurance_type;
              this.insuranceNumber_input[this.key] = user.insurance_number;
              this.insuranceCompany_input[this.key] = user.insurance_company;
              this.percentEmployer_input[this.key] = user.percent_employer;
              this.amountEmployer_input[this.key] = user.amount_employer;
              this.percentEmployee_input[this.key] = user.percent_employee;
              this.amountEmployee_input[this.key] = user.amount_employee;
            })
          }
        });
      },
      storeComponent() {

        if (this.buscd != '') {
          if (this.nik_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  begin_date: this.start_input[index1],
                  end_date: this.end_input[index1],
                  insurance_type: this.insuranceType_input[index1],
                  insurance_number: this.insuranceNumber_input[index1],
                  insurance_company: this.insuranceCompany_input[index1],
                  percent_employer: this.percentEmployer_input[index1],
                  amount_employer: this.amountEmployer_input[index1],
                  percent_employee: this.percentEmployee_input[index1],
                  amount_employee: this.amountEmployee_input[index1]
                });
              });
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/insurance/' + this.nik, this.components)
                    .then(response => {
                      this.clearNik()
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {

              Object.assign(this.components[index1], {
                begin_date: this.start_input[index1],
                end_date: this.end_input[index1],
                insurance_type: this.insuranceType_input[index1],
                insurance_number: this.insuranceNumber_input[index1],
                insurance_company: this.insuranceCompany_input[index1],
                percent_employer: this.percentEmployer_input[index1],
                amount_employer: this.amountEmployer_input[index1],
                percent_employee: this.percentEmployee_input[index1],
                amount_employee: this.amountEmployee_input[index1]
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/insurance/' + this.nik, this.components)
                  .then(response => {
                    //this.clearNik()                                              
                    swal(
                      'Saved!',
                      'Successfully saved.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }


        } else {
          alert('isi nama perusahaan terlebih dahulu !')

        }
      },
      deleteComponents(key) {

        this.components.splice(key, 1);
        this.components.forEach((user, key) => {
          this.key = key;
          this.start_input[this.key] = user.begin_date;
          this.end_input[this.key] = user.end_date;
          this.insuranceType_input[this.key] = user.insurance_type;
          this.insuranceNumber_input[this.key] = user.insurance_number;
          this.insuranceCompany_input[this.key] = user.insurance_company;
          this.percentEmployer_input[this.key] = user.percent_employer;
          this.amountEmployer_input[this.key] = user.amount_employer;
          this.percentEmployee_input[this.key] = user.percent_employee;
          this.amountEmployee_input[this.key] = user.amount_employee;
        })
      },
      clearNik() {

        this.components = [];
        if (this.nik != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.nik = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.insuranceType = '';
        this.insuranceNumber = '';
        this.insuranceCompany = '';
        this.percentEmployee = '';
        this.amountEmployee = '';
        this.percentEmployer = '';
        this.amountEmployer = '';

        this.$nextTick(() => this.$validator.reset());
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/INSRC')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getInsuranceTypes() {
        // this.$axios.get('/objects/insurancetype')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte=9999-12-31&object_type=INSTY')
          .then(response => {
            this.insuranceTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      }

    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
