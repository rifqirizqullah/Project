 <template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs"/>
    <hr>
    <nuxt-link to="/employee-data/specific-date-search" class="button is-success is-rounded is-pulled-right"><span>  <i class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    
    <h3 class="subtitle is-3">
      <i class="fa fa-bar-chart" aria-hidden="true"></i> Tanggal Penting
    </h3>
  
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                  <option selected="selected" disabled="disabled" >choose option</option>
                  <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
                </select>
            </div>            
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                  <option selected="selected" disabled="disabled" >choose option</option>
                  <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
                </select>
            </div>
          </div>
        </div>
        
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10" :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="nik_query" disabled>
            </div>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Form Tanggal Penting
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berlaku</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017" v-model="startDate" name="startDate"
                v-bind:class="{ 'is-danger': errors.has('component.startDate')}" v-validate="'required'" data-vv-as="start date" data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.startDate')" class="help is-danger"> {{ errors.first('component.startDate') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berakhir</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017" v-model="endDate" name="endDate"
                v-bind:class="{ 'is-danger': errors.has('component.endDate')}" v-validate="'required'" data-vv-as="end date" data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.endDate')" class="help is-danger"> {{ errors.first('component.endDate') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Tanggal</label>
            <div class="control">
              <div class="select is-fullwidth"  v-bind:class="{ 'is-danger': errors.has('component.dateType') }">
                
                <select v-model="dateType" name="dateType" v-validate="'required'" class="select" v-bind:class="{ 'is-danger': errors.has('component.nameComponent') }"
                data-vv-as="tipe tanggal" data-vv-scope="component">
                  <option selected="selected" disabled="disabled">choose option</option>
                  <option v-for="(wageType, index) in dateTypes" :key="index" :value="wageType.object_code">{{wageType.object_name}}</option>
                </select>
                
              </div>
              <p v-show="errors.has('component.dateType')" class="help is-danger">{{ errors.first('component.dateType') }}</p>
            </div>
          </div>
        </div>
        <!-- <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal</label>
            <div class="control">
              <input class="input" type="date" placeholder="8" v-model="specificDate" name="tanggal"
                v-bind:class="{ 'is-danger': errors.has('component.tanggal')}" v-validate="'required'" data-vv-as="value" data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.tanggal')" class="help is-danger"> {{ errors.first('component.tanggal') }}</p>
          </div>
        </div> -->
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth"> 
            <thead>
              <tr>
                <th>Tipe Tanggal</th>
                <!-- <th>Tanggal</th> -->
                <th>Tanggal Awal</th>
                <th>Tanggal Akhir</th>                
                <th>Aksi</th>
              </tr>
              <tr v-for="(component, key) in components" :key="key">
                <th>
                  <select v-model="dateType_input[key]" class="select is-fullwidth">                    
                    <option v-for="(wageType, index) in dateTypes" :key="index" :value="wageType.object_code">{{wageType.object_name}}</option>
                  </select>
                </th>
                <th>
                  <input class="input" type="date" placeholder="8" v-model="specificDate_input[key]">
                </th>
                <th>
                  <input class="input" type="date" v-model="start_input[key]">
                </th>
                <th>
                  <input class="input" type="date" v-model="end_input[key]">
                </th>                
                <th><a class="button is-danger is-small is-rounded is-outlined tombolhapus" @click="deleteComponents(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a></th>
              </tr>              
            </thead>
          </table>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Reset</a> -->
    

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue'
  Vue.use(VueAutosuggest);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Basic Pay'
          },
        ],
        name:'',        
        nik:null,
        cUnit:'',
        cPosition:'',
        startDate:null,
        endDate:null,
        dateType:null,
        specificDate:null,
        components:[],
        dateTypes:[],
        buscds:[],        
        buscd: '',
        nik_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        dateType_input:[],
        specificDate_input:[],
        start_input:[],
        end_input:[],
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10
      }
    },
    created() {      
      this.getBUSCD();      
      this.getDateType();      
      if(this.nik_query != null){
        this.getData();                
      }      
    },
    methods:{
       getData(){
         this.buscd = this.buscd_query;
         //console.log(this.buscd);
         this.nik = this.nik_query;
         this.$axios.get('/users/'+ this.buscd +'/searchprofile/'+ this.nik)
            .then(async response => {
              this.name = response.data.data.name;            
              this.cUnit = response.data.data.unit;            
              this.cPosition = response.data.data.position;            
            })
            .catch(e => {
              console.log(e);
            });
            
            this.$axios.get('/users/'+ this.buscd +'/specificdate/'+ this.nik)
            .then(response => {
              this.components = [];
              response.data.data.forEach((user, key) => {
                this.components.push({
                  begin_date: user.begin_date, 
                  end_date: user.end_date,
                  business_code: this.buscd,
                  personal_number: user.personal_number,
                  date_type:user.date_type[0].object_id,                  
                  specific_date: user.specific_date                  
                });
                this.key = key;                                
                this.dateType_input[this.key]= user.date_type[0].object_id,                  
                this.specificDate_input[this.key]= user.specific_date;
                this.start_input[this.key]= user.begin_date;
                this.end_input[this.key]= user.end_date;                
              });
              
              //this.payflag=[];
            })          
            .catch(e => {
              console.log(e);
            });
       },
       onSelected(option) {
         if(option == null){
          this.nik = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
         }else{         
         this.nik = option.item;
          if(this.buscd == ''){
            alert('isi nama perusahaan terlebih dahulu !')

          }else{
            this.$axios.get('/users/'+ this.buscd +'/searchprofile/'+ option.item)
            .then(async response => {
              this.name = response.data.data.name;            
              this.cUnit = response.data.data.unit;            
              this.cPosition = response.data.data.position;            
            })
            .catch(e => {
              console.log(e);
            });
            
            this.$axios.get('/users/'+ this.buscd +'/specificdate/'+ option.item)
            .then(response => {
              this.components = [];
              response.data.data.forEach((user, key) => {
                this.components.push({
                  begin_date: user.begin_date, 
                  end_date: user.end_date,
                  business_code: this.buscd,
                  personal_number: user.personal_number,
                  date_type:user.date_type[0].object_id,                  
                  specific_date: user.specific_date                  
                });
                this.key = key;                                
                this.dateType_input[this.key]= user.date_type[0].object_id,                  
                this.specificDate_input[this.key]= user.specific_date;
                this.start_input[this.key]= user.begin_date;
                this.end_input[this.key]= user.end_date;
              });
              
            })          
            .catch(e => {
              console.log(e);
            });
            

          }
         }
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.nik = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/'+text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,                
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);
            
            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })
          
          .catch(e => {
            console.log(e);
          });
        /* Full control over filtering. Maybe fetch from API?! Up to you!!! */
        
      },
      tambahComponent() {        
        
        //console.log(this.components)
        this.$validator.validateAll('component').then(async result => {
          if (!result) return;
        
        if(this.buscd == ''){
            alert('isi nama perusahaan terlebih dahulu !')
        }else{         
            this.components.push({ 
              begin_date: this.startDate, 
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.nik,
              date_type:this.dateType,              
              specific_date: this.specificDate
            });
            //console.log(this.components);
            this.components.forEach((user, key) => {
                this.key = key;                                
                this.dateType_input[this.key]= user.date_type;
                this.specificDate_input[this.key]= user.specific_date;
                this.start_input[this.key]= user.begin_date;
                this.end_input[this.key]= user.end_date;
            })                      
        }
        });        
      },
      storeComponent() {              
        if(this.buscd != ''){
          if(this.nik_query == null){
            if(this.name ==  ''){
              alert('data nik tidak ada');            
            }else{             
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {                  
                  date_type: this.dateType_input[index1],
                  specific_date: this.specificDate_input[index1],
                  begin_date:this.start_input[index1],
                  end_date:this.end_input[index1]
                });
              });              
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/'+ this.buscd +'/specificdate/'+this.nik, this.components)
                    .then(response => {                 
                        this.clearNik()                                              
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });            
            }
          }else{            
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  date_type: this.dateType_input[index1],
                  specific_date: this.specificDate_input[index1],
                  begin_date:this.start_input[index1],
                  end_date:this.end_input[index1]
                });
              });              
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/'+ this.buscd +'/specificdate/'+this.nik, this.components)
                    .then(response => {                 
                        //this.clearNik()                                              
                      swal(
                        'Saved!',
                        'Successfully saved',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });            
            }
          
          
        }else{
          alert('isi nama perusahaan terlebih dahulu !')
          
          //this.clearNik()
        }
      },
      deleteComponents(key) {
        
            this.components.splice(key, 1);            
            //console.log(this.components)
            this.components.forEach((user, key) => {
                this.key = key;                                
                this.dateType_input[this.key]= user.date_type;
                this.specificDate_input[this.key]= user.specific_date;
                this.start_input[this.key]= user.begin_date;
                this.end_input[this.key]= user.end_date;
            })                        
          
      },
      getDateType(){
        this.$axios.get('/users/otype/DTETY/object')
          .then(response => {
             this.dateTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },     
      getBUSCD(){
        this.$axios.get('/objects/companytoken/BSCPY')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      clearNik(){
        
        this.components = [];
        if(this.nik != null){
          this.$refs.myRefName.searchInput = '';
        }
        this.nik = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.dateType =null;
        this.specificDate =null;        
        this.$nextTick(() => this.$validator.reset());        
      }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
}
.button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
}
#autosuggest__input {
      outline: none;
      position: relative;
      display: block;
      font-family: monospace;
      font-size: 20px;
      border: 1px solid #616161;
      padding: 4px;
      width: 100%;
      box-sizing: border-box;
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
    }
    
    #autosuggest__input.autosuggest__input-open {
      border-bottom-left-radius: 0;
      border-bottom-right-radius: 0;
    }
    
    .autosuggest__results-container {
      position: relative;
      width: 100%;
    }
    
    .autosuggest__results {
      font-weight: 300;
      margin: 0;
      position: absolute;
      z-index: 10000001;
      width: 100%;
      border: 1px solid #e0e0e0;
      border-bottom-left-radius: 4px;
      border-bottom-right-radius: 4px;
      background: white;
      padding: 0px;
      overflow: scroll;
      max-height: 200px;
    }
    
    .autosuggest__results ul {
      list-style: none;
      padding-left: 0;
      margin: 0;
    }
    
    .autosuggest__results .autosuggest__results_item {
      cursor: pointer;
      padding: 15px;
    }
    
    #autosuggest ul:nth-child(1) > .autosuggest__results_title {
      border-top: none;
    }
    
    .autosuggest__results .autosuggest__results_title {
      color: gray;
      font-size: 11px;
      margin-left: 0;
      padding: 15px 13px 5px;
      border-top: 1px solid lightgray;
    }
    
    .autosuggest__results .autosuggest__results_item:active,
    .autosuggest__results .autosuggest__results_item:hover,
    .autosuggest__results .autosuggest__results_item:focus,
    .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
      background-color: #ddd;
    }
</style>
