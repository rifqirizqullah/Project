<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/employee-data/address/address-search" class="button is-success is-rounded is-pulled-right"><span>  <i class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Identitas Karyawan BUMN
    </h3>
    <div class="box has-text-white has-background-danger">
      Filter Search
    </div>
    <div class="box">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Column</label>
              <div class="control">
                <div class="select">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logic</label>
              <div class="control">
                <div class="select">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column">
            <div class="field is-2">
              <label class="label">Condition</label>
              <div class="control">
                <div class="select">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded" @click="getSearchDynamic()">Cari</a>
    <nuxt-link to="/employee-data/address/address"><a class="button is-link is-rounded">Tambah Data</a>
    </nuxt-link>
    <br><br>
    <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Personal Number</th>
          <th>Begin Date</th>
          <th>End Date</th>
          <th>Action</th>
        </tr>
        <tr v-for="(address, key) in empAddress" :key="key">
          <th> {{key+1}} </th>
          <th> {{address.personalNumber}}</th>
          <th> {{address.startDate}} </th>
          <th> {{address.endDate}} </th>
          <th>
            <!-- <a class="button is-success is-outlined is-rounded" @click="editEmployee(employee.personalNumber)"><i class="fa fa-pencil"
                aria-hidden="true"></i></a> -->
            <!-- <a class="button is-danger is-outlined is-rounded" @click="employee.personalNumber ? deleteEmployee(key, employee.personalNumber) : removeGroupSociometri(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a> -->
            <nuxt-link :to="'address/address?nik='+address.personalNumber+'&buscd='+address.buscd">
              <a class="button is-success is-outlined is-rounded"><i class="fa fa-pencil" aria-hidden="true"></i></a>
            </nuxt-link>
          </th>
        </tr>
      </thead>
    </table>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        empAddress: [],
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Employee Data'
          },
          {
            name: 'Address Search'
          },
        ]
      }
    },
    created() {
      this.getAddress();
      this.getColumn();
      this.getLogic();
      this.getCondition();
    },
    methods: {
      getAddress() {
        this.$axios.get('users/empaddress')
          .then(response => {
            this.empAddress = [];
            response.data.data.forEach(async (address, key) => {
              await this.empAddress.push({
                startDate: address.begin_date,
                endDate: address.end_date,
                personalNumber: address.personal_number,
                buscd: address.business_code
              })
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getColumn() {
        this.$axios.get('/users/employeeaddress/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getLogic() {
        this.$axios.get('/objects/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/objects/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = {
          table: "EmployeeAddress", //harcode sesuai form *referensi table_code*
          column: this.columns_model,
          query: this.logics_model,
          value: this.filters_model,
          andor: this.conditions_model
        }
        console.log(this.paramsearchforms)
        this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
          .then(response => {

            this.empAddress = [];
            response.data.data.forEach(async (address, key) => {
              await this.empAddress.push({
                startDate: address.begin_date,
                endDate: address.end_date,
                personalNumber: address.personal_number,
                buscd: address.business_code
              })
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
