<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <!--<div class="box has-text-white has-background-danger">
      Filter Search
    </div>-->
    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> 
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data 
        </span>
    </a>
    <h3 class="subtitle is-3"><i class="fa fa-address-card-o"></i> Pencarian Data Alamat </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Kota</th>
          <th>Alamat</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(adress, key) in addresss" :key="key">
          <td> {{key+1}} </td>
          <td> {{adress.business_code.company_name}}</td>
          <td> {{adress.personnel_number.personnel_number}} </td>
          <td> {{adress.city.object_name}}</td>
          <td> {{adress.street}}</td>
          <td> {{formatDate(adress.begin_date)}} </td>
          <td> {{formatDate(adress.end_date)}} </td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="editAddress(adress.object_identifier)"><i class="fa fa-pencil"
                aria-hidden="true"></i></a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="adress.object_identifier ? deleteAddress(key, adress.object_identifier) : removeAddress(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitAddress(adress.object_identifier)"><i class="fa fa-clock-o"
                aria-hidden="true"></i></a>
          </td>
        </tr>
      </thead>
    </table>
     <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getAddresss()"></pagination>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Formulir Alamat</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
                <div class="column">
                  <div class="field">
                    <label class="label">Nama Perusahaan</label>
                    <div class= "control">
                      <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                        <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                          v-validate="'required'">
                          <option disabled selected>Choose</option>
                          <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                            {{ company.company_name }}</option>
                        </select>
                      </div>
                      <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                    </div>
                  </div>
                </div>
          </div>
        <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee= null">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      :on-selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <hr>
			
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Alamat</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.address_type') }">
                <select name="address_type" class="select" v-model="addressType" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(addressType, key) in addressTypes" :key="key" :value="addressType.object_code">{{
                    addressType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.address_type')" class="help is-danger">{{ errors.first('form.address_type') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Urut Alamat</label>
            <div class="control">
              <input name="address_number" class="input " placeholder="" type="text"
                v-model="addressNumber" v-bind:class="{ 'is-danger': errors.has('form.address_number')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.address_number')" class="help is-danger"> {{
              errors.first('form.address_number')
              }}</p>
          </div>
        </div>
      </div>
	  	<div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Alamat</label>
            <div class="control">
              <textarea name="street" class="textarea" placeholder="" rows="5" v-model="street"
                v-bind:class="{ 'is-danger': errors.has('from.street')}" v-validate="'required'"></textarea>
            </div>
            <p v-show="errors.has('form.street')" class="help is-danger"> {{ errors.first('form.street')}}</p>
          </div>
        </div>
        <div class="column">
          <div class="columns">
            <div class="column is-6">
                <div class="field">
                  <label class="label">Negara</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.country') }">
                      <select name="country" class="select" v-model="country" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(country, key) in countries" :key="key" :value="country.object_code">{{
                          country.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.country')" class="help is-danger">{{errors.first('form.country') }}</p>
                  </div>
                </div>
              </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Provinsi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.province') }">
                    <select name="province" class="select" v-model="province" v-validate="'required'"
                      @change="getCity()">
                      <option disabled selected>Choose</option>
                      <option v-for="(province, key) in provinces" :key="key" :value="province.object_code">{{
                        province.object_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.province')" class="help is-danger">{{ errors.first('form.province') }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Kecamatan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.district') }">
                    <select name="district" class="select" v-model="district" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(district, key) in districts" :key="key" :value="district.child.object_code">{{
                        district.child.object_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.district')" class="help is-danger">{{ errors.first('form.district') }}</p>
                </div>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Kota</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.city') }">
                    <select name="city" class="select" v-model="city" v-validate="'required'" @change="getDistrict()">
                      <option disabled selected>Choose</option>
                      <option v-for="(city, key) in cities" :key="key" :value="city.child.object_code">{{
                        city.child.object_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('form.city')" class="help is-danger">{{ errors.first('form.city') }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Kode Pos</label>
            <div class="control">
              <input class="input" name="postal_code" v-model="postalCode" type="number" placeholder=""
                v-bind:class="{ 'is-danger': errors.has('form.postal_code') }" data-vv-as="postal_code"
                v-validate="'required|numeric'">
            </div>
            <p v-show="errors.has('form.postal_code')" class="help is-danger">{{ errors.first('form.postal_code') }}</p>
          </div>
        </div>
      </div>		
        </span>  
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="saveAddress()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Delimit Data Alamat</p>
          <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                    data-vv-scope="delimit" disabled>
                </div>
                <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                  {{ errors.first('delimit.begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                    data-vv-scope="delimit">
                </div>
                <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                  {{ errors.first('delimit.end_date') }}
                </p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="delimitAddress()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  Vue.use(VueAutosuggest);
  import moment from "moment";

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        isActiveForm:false,
        nikAuth: this.$auth.user.nik,
        myDate : new Date().toISOString().slice(0,10),
        key: null,
        startDate: '',
        endDate: '',
        personalNumber: '',
        addressNumber: null,
        addressTypes: [],
        addressType: null,
        street: null,
        country: null,
        countries: [],
        province: null,
        provinces: [],
        district: null,
        districts: [],
        city: null,
        cities: [],
        postalCode: null,
        
        objectIdentifier: null,
        addresss: [],
        adress: [],
        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: "",
        empolyeePosition: '',
        empolyeeUnit: '',
        perPage:5,
        search:'',
        filterEmployee: [],
        pagination: {
            'current_page': 1
          },
         options: [{
          data: []
        }],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        bankByCodes: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Alamat'
          },
        ],
        isActiveForm:false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getAddresss();
      this.getCompany();
      //this.getColumn();
      //this.getLogic();
      //this.getCondition();
      //this.getHakAkses();
    },
    methods: {
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.addressNumber = null;
        this.street = null; 
        this.country = null; 
        this.province = null; 
        this.district = null; 
        this.city = null;
        this.postalCode = null;
        this.startDate = null;
        this.endDate = null;

        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = '';
        this.empolyeeUnit = '';

        this.$nextTick(() => this.$validator.reset()); 
      },

      //getHakAkses() {
      //  this.$axios.get('/users/hakakses/ADDEP')
      //    .then(response => {
      //      this.hakAkses = response.data.data.access;
      //      if (this.hakAkses != '*' && this.hakAkses != 'R') {
      //        return this.$router.push('/employee-data/address/address')
      //      }
      //    })
      //    .catch(e => {
      //      console.log(e)
      //    });
      //},

      getCompany() {
          this.$axios
            .get(
              "hcis/api/company?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD")
            )
            .then(response => {
              this.companies = response.data.data;
            })
            .catch(e => {
              console.log(e);
            });
        },

      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(
                employee.personnel_number
                );
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },

      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.employeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal("", "Pilih nama perusahaan terlebih dahulu !", "error");
          } else {
            this.selfData(option.item);
          }
        }
      },

      selfData(nik){
          this.$axios
                .get(
                  "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&end_date_gte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&personnel_number=" +
                  nik + "&business_code=" +this.company
                )
                .then(async response => {
                  this.empolyeeName = response.data.data[0].personnel_number.complete_name;
                  this.empolyeePosition = response.data.data[0].position_name;
                  this.empolyeeUnit = response.data.data[0].unit_name;
                })
                .catch(e => {
                  console.log(e);
                });
      },

      clearEmployee() {
        if (this.employee != null) {
          this.$refs.reference= '';
        }
        this.filterEmployee = []
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeeUnit = '';
        this.empolyeePosition = '';

        this.$nextTick(() => this.$validator.reset());
      },

      getParam(){
        this.getaddressType();
        this.getProvince();
        this.getCity();
        this.getDistrict();
        this.getCountry();

      },

      getaddressType() {
        this.$axios
          .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=ADDTY" +"&business_code=*&business_code="+
              this.company
            )
          .then(response => {
            this.addressTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },

      getProvince() {
        this.$axios
          .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=PRVNC" +"&business_code=*&business_code="+ 
              this.company
            )
          .then(response => {
            this.provinces = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },

      getDistrict() {
        this.$axios
          .get(
              "ldap/api/relation?parent_type=CITY&parent="+ this.city +"&relation_type=A&relation_code=001&child_type=DSTRC&begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +"&business_code=*&business_code="+
              this.company
            )
          .then(response => {
            this.district = []
            this.districts = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },

      getCity() {
        this.$axios
          .get(
              "ldap/api/relation?parent_type=PRVNC&parent="+ this.province +"&relation_type=A&relation_code=001&child_type=CITY&begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +"&business_code=*&business_code="+
              this.company
            )
          .then(response => {
            this.cities = []
            this.cities = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },

      getCountry() {
        this.$axios
          .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=CONTR" +"&business_code=*&business_code="+
              this.company
            )
          .then(response => {
            this.countries = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },

      getAddresss() {
        this.$axios
          .get("hcis/api/employeeaddress?include=personnel_number&include=business_code&include=city&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") + '&page=' + this.pagination.current_page+'&per_page='+this.perPage)
          .then(response => {
            this.addresss = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },

      async getAddress(objectIdentifier) {
        let adress = await this.addresss.find(
          adress => adress.object_identifier == objectIdentifier
        );
        this.objectIdentifier = adress.object_identifier;
        this.startDate = adress.begin_date;
        this.endDate = adress.end_date;

        this.company = adress.business_code.business_code;
        this.employee = adress.personnel_number.personnel_number;
        this.empolyeeName = adress.personnel_number.complete_name;
        this.addressType = adress.address_type;
        this.addressNumber = adress.address_number; 
        this.street = adress.street; 
        this.country = adress.country; 
        this.province = adress.province; 
        this.district = adress.district; 
        this.city = adress.city; 
        this.postalCode = adress.postal_code;
        this.selfData(this.employee)        
        this.getProvince();
        this.getCity();
        this.getDistrict();
        this.getCountry();
        this.getaddressType();
       },
      formatDate(date) {
        return moment(date).format("DD/MM/YYYY");
      },
      onlyNumber($event) {
          let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
          if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
            $event.preventDefault();
          }
      },

      editAddress(objectIdentifier) {
        this.openFormModal();
        this.getAddress(objectIdentifier);
      },

      saveAddress() {
        this.objectIdentifier ? this.updateAddress() : this.storeAddress();
      },

      updateAddress() {
        this.$validator.validateAll('address').then(async result => {
          if (!result) return;
          this.$axios.put('hcis/api/employeeaddress', {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              address_type: this.addressType,
              address_number: this.addressNumber,
              street: this.street,
              country: this.country,
              province: this.province,
              district: this.district,
              city: this.city,
              postal_code: this.postalCode,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getAddresss();
              this.closeFormModal();
              swal(
                'Update!',
                'Successfully Update address.',
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            });
        });
      },

      storeAddress() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/employeeaddress", {
              begin_date: this.startDate,
              end_date: this.endDate,
              address_type: this.addressType,
              address_number: this.addressNumber,
              street: this.street,
              country: this.country,
              province: this.province,
              district: this.district,
              city: this.city,
              postal_code: this.postalCode,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getAddresss();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data address.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },

      deleteAddress(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/employeeaddress?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", 
                response.data.message, 
                "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeAddress(key);
              });
          }
        });
      },

      removeAddress(key) {
        this.addresss.splice(key, 1);
      },
      
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },

      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;

        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitAddress(objectIdentifier) {
        this.openFormModalDelimit();
        let adress = await this.addresss.find(
          adress => adress.object_identifier == objectIdentifier
        );
        this.objectIdentifier = adress.object_identifier;
        this.startDate = adress.begin_date;
        this.endDate = adress.end_date;
      },

      delimitAddress() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/employeeaddress", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getAddresss();
              this.closeFormModalDelimit();
              swal("Delimited!", response.data.message, "success");
            })
            .catch(e => {
              console.log(e);
            });
        });
      },

    //  getColumn() {
    //    this.$axios.get('/users/employeeaddress/column')
    //      .then(response => {
    //        this.columns = response.data.data;
    //      })
    //      .catch(e => {
    //        console.log(e)
    //      });
    //  },
    //  getLogic() {
    //    this.$axios.get('/objects/oprationsql')
    //      .then(response => {
    //        this.logics = response.data.data;
    //      })
    //      .catch(e => {
    //        console.log(e)
    //      });
    //  },
    //  getCondition() {
    //    this.$axios.get('/objects/conditionsql')
    //      .then(response => {
    //        this.conditions = response.data.data;
    //      })
    //      .catch(e => {
    //        console.log(e)
    //      });
    //  },
      getSearchDynamic() {
        this.paramsearchforms = {
          table: "EmployeeAddress", //harcode sesuai form *referensi table_code*
          column: this.columns_model,
          query: this.logics_model,
          value: this.filters_model,
          andor: this.conditions_model
    }
        //console.log(this.paramsearchforms)
        this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
        .then(response => {
            this.addresss = [];
            response.data.data.forEach(async (adress, key) => {
              await this.addresss.push({
                startDate: adress.begin_date,
                endDate: adress.end_date,
                personalNumber: adress.personnel_number,
                company: adress.business_code
              })
           });
           //console.log(this.awards);
          })
          .catch(e => {
            console.log(e);
          });
      },
    //  editBank(personalNumber) {
    //    this.openFormModal();
    //    this.getBankaccount(personalNumber);
    //  },
    // getBankByGroup() {
    //   this.$axios.get('/bank/getbyGroup/' + this.bankGroup)
    //      .then(response => {
    //        this.bankCodes = response.data.data;
    //      })
    //      .catch(e => {
    //        console.log(e)
    //     });
    //  },
    // addNewFormSearch() {
    //    this.searchforms.push({
    //      column: '',
    //      logic: '',
    //      filter: '',
    //      condition: ''
    //    })
    //  },
    //  deleteFormSearch(key) {
    //    this.searchforms.splice(key, 1)
    //  }
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
