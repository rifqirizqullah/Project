<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="address-search" class="button is-success is-rounded is-pulled-right"><span><i class="fa fa-search"
          aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Alamat
    </h3>
    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearpersonalNumber">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" v-model="personalNumber_query" disabled>
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="box" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Alamat</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="start_date_table[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="end_date_table[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Alamat</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('address_type') }">
                <select name="address_type" class="select" v-model="address_type_table[key]" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(addressType, key) in addressTypes" :key="key" :value="addressType.id">{{
                    addressType.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('language')" class="help is-danger">{{ errors.first('language') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Urut Alamat</label>
            <div class="control">
              <input name="address_number" class="input " placeholder="" type="number"
                v-model="address_number_table[key]" v-bind:class="{ 'is-danger': errors.has('address_number')}"
                v-validate="'required'" disabled>
            </div>
            <p v-show="errors.has('address_number')" class="help is-danger"> {{ errors.first('address_number')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Alamat</label>
            <div class="control">
              <textarea name="street" class="textarea" placeholder="" rows="5"
                v-model="street_table[key]" v-bind:class="{ 'is-danger': errors.has('street')}"
                v-validate="'required'"></textarea>
            </div>
            <p v-show="errors.has('street')" class="help is-danger"> {{ errors.first('street')}}</p>
          </div>
        </div>
        <div class="column">
          <div class="columns">

            <div class="column is-6">
              <div class="field">
                <label class="label">Negara</label>
                <div class="control">
                  <input name="country" class="input" placeholder="" type="text"
                    v-model="country_table[key]" v-bind:class="{ 'is-danger': errors.has('country')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('country')" class="help is-danger"> {{ errors.first('country') }}</p>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Provinsi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('province') }">
                    <select name="province" class="select" v-model="province_table[key]" v-validate="'required'"
                      @change="getCities1(key,province_table[key])">
                      <option disabled selected>Choose</option>
                      <option v-for="(province, key) in provinces" :key="key" :value="province.id">{{
                        province.name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('province')" class="help is-danger">{{ errors.first('province') }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Kecamatan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('district') }"
                    v-if="component.districts_if == 1">
                    <select name="district" class="select" v-model="district_table[key]" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(district, key) in districts1[key]" :key="key" :value="district.id">{{
                    district.name
                    }}</option>
                    </select>
                  </div>
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('district') }" v-else>
                    <select name="district" class="select" v-model="district_table[key]" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(district, key) in districts1_all" :key="key" :value="district.id">{{
                    district.name
                    }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('district')" class="help is-danger">{{ errors.first('district') }}</p>
                </div>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Kota</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('city') }"
                    v-if="component.cities_if == 1">
                    <select name="city" class="select" v-model="city_table[key]" v-validate="'required'"
                      @change="getDistricts1(key,city_table[key])">
                      <option disabled selected>Choose</option>
                      <option v-for="(city, key) in cities1[key]" :key="key" :value="city.id">{{
                        city.name
                        }}</option>
                    </select>
                  </div>
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('city') }" v-else>
                    <select name="city" class="select" v-model="city_table[key]" v-validate="'required'"
                      @change="getDistricts1(key,city_table[key])">
                      <option disabled selected>Choose</option>
                      <option v-for="(city, key) in cities1_all" :key="key" :value="city.id">{{
                        city.name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('city')" class="help is-danger">{{ errors.first('city') }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">

        <div class="column is-4">
          <div class="field">
            <label class="label">Kode Pos</label>
            <div class="control">
              <input class="input" name="postal_code" v-model="postal_code_table[key]" type="number"
                placeholder="e.g. 60118" v-bind:class="{ 'is-danger': errors.has('postal_code') }"
                data-vv-as="postal code" v-validate="'required|numeric'">
            </div>
            <p v-show="errors.has('postal_code')" class="help is-danger">{{ errors.first('postal_code') }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Alamat</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Alamat</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('address_type') }">
                <select name="address_type" class="select" v-model="addressType" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(addressType, key) in addressTypes" :key="key" :value="addressType.objectId">{{
                    addressType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('address_type')" class="help is-danger">{{ errors.first('address_type') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Alamat</label>
            <div class="control">
              <textarea name="street" class="textarea" placeholder="" rows="5" v-model="street"
                v-bind:class="{ 'is-danger': errors.has('street')}" v-validate="'required'"></textarea>
            </div>
            <p v-show="errors.has('street')" class="help is-danger"> {{ errors.first('street')}}</p>
          </div>
        </div>
        <div class="column">
          <div class="columns">
            <div class="column is-6">
              <div class="field">
                <label class="label">Negara</label>
                <div class="control">
                  <input name="country" class="input" placeholder="" type="text" v-model="country"
                    v-bind:class="{ 'is-danger': errors.has('country')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('country')" class="help is-danger"> {{ errors.first('country') }}</p>
              </div>
            </div>

            <div class="column is-6">
              <div class="field">
                <label class="label">Provinsi</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('province') }">
                    <select name="province" class="select" v-model="province" v-validate="'required'"
                      @change="getCities()">
                      <option disabled selected>Choose</option>
                      <option v-for="(province, key) in provinces" :key="key" :value="province.id">{{
                        province.name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('province')" class="help is-danger">{{ errors.first('province') }}</p>
                </div>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Kecamatan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('district') }">
                    <select name="district" class="select" v-model="district" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(district, key) in districts" :key="key" :value="district.id">{{
                    district.name
                    }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('district')" class="help is-danger">{{ errors.first('district') }}</p>
                </div>
              </div>
            </div>
            <div class="column is-6">
              <div class="field">
                <label class="label">Kota</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('city') }">
                    <select name="city" class="select" v-model="city" v-validate="'required'" @change="getDistricts()">
                      <option disabled selected>Choose</option>
                      <option v-for="(city, key) in cities" :key="key" :value="city.id">{{
                        city.name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('city')" class="help is-danger">{{ errors.first('city') }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Kode Pos</label>
            <div class="control">
              <input class="input" name="postal_code" v-model="postalCode" type="number" placeholder=""
                v-bind:class="{ 'is-danger': errors.has('postal_code') }" data-vv-as="postal code"
                v-validate="'required|numeric'">
            </div>
            <p v-show="errors.has('postal_code')" class="help is-danger">{{ errors.first('postal_code') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>
    <div class="columns">
      <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="storeComponent()">Simpan</a>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        myDate : new Date().toISOString().slice(0,10),
        key: null,
        buscd: '',
        name: '',
        personalNumber: null,
        cUnit: '',
        cPosition: '',

        startDate: '',
        endDate: '',
        addressType: '',
        addressNumber: '',
        street: '',
        postalCode: '',
        province: '',
        city: '',
        district: '',
        country: '',

        start_date_table: [],
        end_date_table: [],
        address_type_table: [],
        address_number_table: [],
        street_table: [],
        postal_code_table: [],
        city_table: [],
        province_table: [],
        country_table: [],
        district_table: [],

        buscds: [],
        components: [],
        provinces: [],
        //provinces1: [],
        cities: [],
        districts: [],
        cities1: [],
        cities1_all: [],
        districts1: [],
        districts1_all: [],
        addressTypes: [],
        employeesAddress: [],

        personalNumber_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        hakAkses: '',
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,

        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Alamat'
          },
        ]
      }
    },
    created() {
      this.getAddressTypes();
      this.getProvinces();
      //this.getProvinces1();
      this.getBUSCD();
      this.getHakAkses();
      this.getAllCities();
      this.getAllDistrict();
      //this.getAllCities1();
      //this.getAllDistrict1();
      if (this.personalNumber_query != null) {
        this.getData();
      }
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/ADDEP')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'R') {
              return this.$router.push('/employee-data/address/address-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('users/' + this.buscd + '/empaddress/' + this.personalNumber)
          .then(response => {
            this.components = [];
            response.data.data.forEach(async (address, key) => {
              this.components.push({
                begin_date: address.begin_date,
                end_date: address.end_date,
                personal_number: address.personal_number,
                address_type: address.address_type[0].object_id,
                address_number: address.address_number,
                street: address.street,
                postal_code: address.postal_code,
                city: address.city[0].id,
                province: address.province[0].id,
                country: address.country,
                district: address.district[0].id,
                business_code: address.business_code,
                cities_if: null,
                districts_if: null
              });

              this.key = key;
              this.start_date_table[this.key] = address.begin_date;
              this.end_date_table[this.key] = address.end_date;
              this.address_type_table[this.key] = address.address_type[0].object_id;
              this.address_number_table[this.key] = address.address_number;
              this.street_table[this.key] = address.street;
              this.postal_code_table[this.key] = address.postal_code;
              this.city_table[this.key] = address.city[0].id;
              this.province_table[this.key] = address.province[0].id;
              this.country_table[this.key] = address.country;
              this.district_table[this.key] = address.district[0].id;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('users/' + this.buscd + '/empaddress/' + option.item)
              .then(response => {
                this.components = [];
                response.data.data.forEach((address, key) => {
                  this.components.push({
                    begin_date: address.begin_date,
                    end_date: address.end_date,
                    personal_number: address.personal_number,
                    address_type: address.address_type[0].object_id,
                    address_number: address.address_number,
                    street: address.street,
                    postal_code: address.postal_code,
                    city: address.city[0].id,
                    province: address.province[0].id,
                    country: address.country,
                    district: address.district[0].id,
                    business_code: address.business_code,
                    cities_if: null,
                    districts_if: null

                  });
                  this.key = key;
                  this.start_date_table[this.key] = address.begin_date;
                  this.end_date_table[this.key] = address.end_date;
                  this.address_type_table[this.key] = address.address_type[0].object_id;
                  this.address_number_table[this.key] = address.address_number;
                  this.street_table[this.key] = address.street;
                  this.postal_code_table[this.key] = address.postal_code;
                  this.province_table[this.key] = address.province[0].id;
                  this.city_table[this.key] = address.city[0].id;
                  this.country_table[this.key] = address.country;
                  this.district_table[this.key] = address.district[0].id;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }

        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;


          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            if (this.components.length > 0) {
              var address_num = parseInt(this.address_number_table[this.components.length - 1]) + 1;
            } else {
              var address_num = 1;
            }
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.personalNumber,
              address_type: this.addressType,
              address_number: address_num,
              street: this.street,
              postal_code: this.postalCode,
              city: this.city,
              province: this.province,
              country: this.country,
              district: this.district,
              district_if: null,
              cities_if: null
            });
            this.components.forEach((address, key) => {
              this.key = key;
              this.start_date_table[this.key] = address.begin_date;
              this.end_date_table[this.key] = address.end_date;
              this.address_type_table[this.key] = address.address_type;
              this.address_number_table[this.key] = address.address_number;
              this.street_table[this.key] = address.street;
              this.postal_code_table[this.key] = address.postal_code;
              this.city_table[this.key] = address.city;
              this.province_table[this.key] = address.province;
              this.country_table[this.key] = address.country;
              this.district_table[this.key] = address.district;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.personalNumber_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components_input = [];
              this.components.forEach((childrens, index1) => {
                this.components_input.push({
                  business_code: this.buscd,
                  personal_number: this.personalNumber,
                  begin_date: this.start_date_table[index1],
                  end_date: this.end_date_table[index1],
                  address_type: this.address_type_table[index1],
                  address_number: this.address_number_table[index1],
                  street: this.street_table[index1],
                  postal_code: this.postal_code_table[index1],
                  city: this.city_table[index1],
                  province: this.province_table[index1],
                  country: this.country_table[index1],
                  district: this.district_table[index1],
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/empaddress/' + this.personalNumber, this
                      .components_input)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data alamat.',
                        'sukses'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components_input = [];
            this.components.forEach((childrens, index1) => {
              this.components_input.push({
                business_code: this.buscd,
                personal_number: this.personalNumber,
                begin_date: this.start_date_table[index1],
                end_date: this.end_date_table[index1],
                address_type: this.address_type_table[index1],
                address_number: this.address_number_table[index1],
                street: this.street_table[index1],
                postal_code: this.postal_code_table[index1],
                city: this.city_table[index1],
                province: this.province_table[index1],
                country: this.country_table[index1],
                district: this.district_table[index1],
              });
            });
            swal({
              title: 'Apakah anda yakin ingin menyimpan data ini?',
              text: 'Anda tidak dapat membatalkan',
              type: 'peringatan',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/empaddress/' + this.personalNumber, this
                    .components_input)
                  .then(response => {
                    swal(
                      'Data tersimpan!',
                      'Sukses menyimpan data alamat.',
                      'sukses'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearpersonalNumber()
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        var x = 1
        this.components.forEach((address, key) => {
          this.key = key;
          this.start_date_table[this.key] = address.begin_date;
          this.end_date_table[this.key] = address.end_date;
          this.address_type_table[this.key] = address.address_type;
          this.address_number_table[this.key] = x;
          address.address_number = x;
          this.street_table[this.key] = address.street;
          this.postal_code_table[this.key] = address.postal_code;
          this.city_table[this.key] = address.city;
          this.province_table[this.key] = address.province;
          this.country_table[this.key] = address.country;
          this.district_table[this.key] = address.district;
          x++;
        })
      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.startDate = '';
        this.endDate = '';
        this.company = '';
        this.personalNumber = null;
        this.addressType = '';
        this.addressNumber = '';
        this.street = '';
        this.postalCode = '';
        this.city = '';
        this.province = '';
        this.country = '';
        this.district = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/ADDFM')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getAddressTypes() {
        // this.$axios.get('/objects/addresstype')
         this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+  this.myDate +'&object_type=ADDTY')
          .then(response => {
            this.addressTypes = [];
            response.data.data.forEach(async (addressType, key) => {
              await this.addressTypes.push({
                objectId: addressType.id,
                name: addressType.value
              });
            });
          })
          .catch(e => {
            console.log(e)
          });
      },
      getProvinces() {
        this.provinces = [];
        this.$axios.get('/province/getall')
          .then(response => {
            this.provinces = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getAllCities() {
        this.cities = [];
        this.cities1_all = [];
        this.$axios.get('/city/getall')
          .then(response => {
            this.cities = response.data.data;
            this.cities1_all = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getCities() {
        this.cities = [];
        this.$axios.get('/city/byProvince/' + this.province)
          .then(response => {
            this.cities = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
        //this.districts = [];
      },
      getAllDistrict() {
        this.districts = [];
        this.districts1_all = [];
        this.$axios.get('/district/getall')
          .then(response => {
            this.districts = response.data.data;
            this.districts1_all = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getDistricts() {
        this.districts = [];
        this.$axios.get('/district/byCity/' + this.city)
          .then(response => {
            this.districts = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });;
      },
      getDistricts1(key, city) {
        this.districts1[key] = null;
        this.$axios.get('/district/byCity/' + city)
          .then(response => {
            this.components[key].districts_if = 1;
            this.districts1[key] = response.data.data;
            this.$forceUpdate()
          })
          .catch(e => {
            console.log(e);
          });;
      },
      getCities1(key, province) {
        this.cities1[key] = null;
        this.$axios.get('/city/byProvince/' + province)
          .then(response => {
            this.components[key].cities_if = 1;
            this.cities1[key] = response.data.data;
            this.$forceUpdate()
          })
          .catch(e => {
            console.log(e);
          });
        //this.districts = [];
      },

    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
