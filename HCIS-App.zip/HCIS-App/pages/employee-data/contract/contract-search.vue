<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcrumb"></Breadcrumb>
    <hr>
    <!-- <nuxt-link to="/employee-data/spesific-date"><a class="button is-link is-rounded is-pulled-right"><span><i class="fa fa-plus"></i> Tambah Data </span></a>
    </nuxt-link> -->
    <a class="button is-link is-rounded is-pulled-right" @click="openFormModal()">
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data
      </span>
    </a>
    <h3 class="subtitle is-3"><i class="fa fa-calendar"></i> Data Kontrak </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{column.column_name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{logic.name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{condition.name}}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column">
            <div v-if="key==0">
              <br>
              <a class="button is-success is-rounded is-outlined is-pulled-right" @click="addSearchForm()"><i
                  class="fa fa-plus"></i></a>
            </div>
            <div v-else>
              <br>
              <a class="button is-danger is-rounded is-outlined is-pulled-right" @click="deleteSearchForm(key)"><i
                  class="fa fa-trash"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-rounded is-success is-pulled-right" @click="getSearchDynamic()"><span><i
                class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Nomor Kontrak</th>
          <th>Referensi Kontrak</th>
          <th>Tipe Kontrak</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(Contract, key) in Contracts" :key="key">
          <td>{{ key + 1 }}</td>
          <td>{{ Contract.business_code.company_name }}</td>
          <td>{{ Contract.personnel_number.personnel_number }}</td>
          <td>{{ Contract.contract_number}}</td>
          <td>{{ Contract.reference_contract}}</td>
          <td>{{ Contract.contract_type.object_name}}</td>
          <td>{{ formatDate(Contract.begin_date) }}</td>
          <td>{{ formatDate(Contract.end_date) }}</td>
          <td>
           <a class="button is-success is-small is-outlined is-rounded"
              @click="editContract(Contract.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="Contract.object_identifier ? deleteContract(key, Contract.object_identifier) : removeContract(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitContract(Contract.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>

    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getContracts()">
    </pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Kontrak</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                    <select name="company" class="select" v-model="company" @change="getParam()"
                      v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                        {{ company.company_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                </div>
              </div>
            </div>
          </div>

          <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                      class="is-link">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>

            <hr>

            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="end date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column ">
                    <div class="field">
                    <label class="label">Tipe Dokumen</label>
                    <div class="control">
                        <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.document_type') }">
                        <select name="document_type" class="select" v-model="docType" v-validate="'required'"
                            data-vv-scope="form">
                            <option disabled selected>Choose</option>
                            <option v-for="(docType, key) in docTypes" :key="key" :value="docType.object_code">{{
                            docType.object_name
                            }}</option>
                        </select>
                        </div>
                        <p v-show="errors.has('form.document_type')" class="help is-danger">{{ errors.first('form.document_type') }}</p>
                    </div>
                    </div>
              </div> 
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Dokumen</label>
                  <div class="control">
                    <input id="document_issue" data-display-mode="dialog" class="input" name="document_issue" type="date"
                      placeholder="e.g 10-11-2018" v-model="docIssue" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('document_issue')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('document_issue')" class="help is-danger">{{ errors.first('document_issue') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                  <div class="field">
                    <label class="label">Nomor Kontrak</label>
                    <div class="control">
                      <input name="contract_number" class="input " placeholder="Nomor Kontrak" type="text"
                        v-model="conNumber" @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('contract_number')}"
                        v-validate="'required'">
                    </div>
                    <p v-show="errors.has('contract_number')" class="help is-danger">
                      {{ errors.first('contract_number') }}
                    </p>
                  </div>
              </div>
              <div class="column">
                    <div class="field">
                    <label class="label">Tipe Kontrak</label>
                    <div class="control">
                        <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.contract_type') }">
                        <select name="contract_type" class="select" v-model="conType" v-validate="'required'"
                            data-vv-scope="form">
                            <option disabled selected>Choose</option>
                            <option v-for="(conType, key) in conTypes" :key="key" :value="conType.object_code">{{
                            conType.object_name
                            }}</option>
                        </select>
                        </div>
                        <p v-show="errors.has('form.contract_type')" class="help is-danger">{{ errors.first('form.contract_type') }}</p>
                    </div>
                    </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                  <div class="field">
                    <label class="label">Deskripsi Kontrak</label>
                    <div class="control">
                      <input name="contract_desc" class="input " placeholder="Deskripsi Kontrak" type="text"
                        rows="5" v-model="conDesc" v-bind:class="{ 'is-danger': errors.has('contract_desc')}"
                        v-validate="'required'">
                    </div>
                    <p v-show="errors.has('contract_desc')" class="help is-danger">
                      {{ errors.first('contract_desc') }}
                    </p>
                  </div>
              </div> 
            </div>
            <div class="columns">
              <div class="column">
                  <div class="field">
                    <label class="label">Nomor referensi</label>
                    <div class="control">
                      <input name="reference_number" class="input " placeholder="Nomor Referensi" type="text"
                        rows="5" v-model="refNumber" v-bind:class="{ 'is-danger': errors.has('reference_number')}"
                        v-validate="'required'">
                    </div>
                    <p v-show="errors.has('reference_number')" class="help is-danger">
                      {{ errors.first('reference_number') }}
                    </p>
                  </div>
              </div> 
            </div>
            <div class="columns">
              
              <div class="column">
                <div class="field">
                  <label class="label">Posisi</label>
                  <div class="control">
                    <input name="posisi" class="input" placeholder="Posisi" type="text"
                      v-model="posisi" v-validate="'required'" >
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit</label>
                  <div class="control">
                    <input name="unit" class="input" placeholder="Unit" type="text" v-model="unit"
                      v-validate="'required'" >
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
            <div class="column">
                  <div class="field">
                    <label class="label">Referensi Kontrak<a v-if="refContract != null"
                        @click="refContract= null" class="is-link">Ubah</a></label>
                    <div class="control" v-if="refContract == null">
                      <vue-autosuggest name="reference_contract" ref="reference_contract" :suggestions="filterReference"
                        @selected="selectReference" :limit="10" :input-props="inputReference"
                        v-bind:class="{ 'is-danger': errors.has('reference_contract')}">
                      </vue-autosuggest>
                    </div>
                    <div class="control" v-else>
                      <input name="reference_contract" class="input" placeholder="Nomor Referensi" type="text"
                        v-model="refContract" v-bind:class="{ 'is-danger': errors.has('reference_contract')}"
                        disabled>
                    </div>
                    <p v-show="errors.has('reference_contract')" class="help is-danger">
                      {{ errors.first('reference_contract') }}
                    </p>
                  </div>
            </div>
            </div>
          </span>

        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveContract()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
            <div class="modal-background"></div>
            <div class="modal-card">
              <header class="modal-card-head">
                <p class="modal-card-title">Delimit Data Identitas</p>
                <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
              </header>
              <section class="modal-card-body">
                <div class="columns">
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Awal Berlaku</label>
                      <div class="control">
                        <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                          v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                          data-vv-scope="delimit" disabled>
                      </div>
                      <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                  </div>
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Akhir Berlaku</label>
                      <div class="control">
                        <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                          v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                          data-vv-scope="delimit">
                      </div>
                      <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                      </p>
                    </div>
                  </div>
                </div>
              </section>
              <footer class="modal-card-foot">
                <div class="control">
                  <button @click="delimitContract()" class="button is-success">Simpan</button>
                  <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
                </div>
              </footer>
            </div>
  </div>
  </section>
</template>

<script>
  import Breadcrumb from "~/components/Breadcrumb";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  import VueAutosuggest from "vue-autosuggest";
  Vue.use(VueAutosuggest);
  import moment from "moment";

  export default {
    components: {
      Breadcrumb
    },
    data() {
      return {
        // myDate: new Date().toISOString().slice(0, 10),
        // paramsearchforms: '',
        Contracts: [],

        docType: null,
        docTypes: [],
        docIssue: null,
        conNumber: null,
        conType: null,
        conTypes: [],
        conDesc: null,
        refNumber: null,
        refContract: null,
        unit: "",
        posisi: "",
        nama: "",


        objectIdentifier: null,
        startDate: null,
        endDate: null,

        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: "",
        empolyeePosition: "",
        empolyeeUnit: "",

        perPage: 5,
        search: '',
        pagination: {
          'current_page': 1
        },

        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        references: [{
            data: []
          }],
          filterReference: [],
          inputReference: {
            id: "autosuggest__input",
            name: "reference_contract",
            class: "input",
            onInputChange: this.getReference,
            placeholder: "Referensi Kontrak"
          },
        limit: 10,

        columns_model: [],
        logics_model: [],
        filters_model: [],
        conditions_model: [],
        columns: [],
        logics: [],
        conditions: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],

        breadcrumb: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Kontrak'
          }
        ],
        isActiveForm: false,
        isActiveFormDelimit: false,
      }
    },
    created() {
      this.getContracts();
      this.getCompany();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
    },
    methods: {
      getdocType() {
        this.$axios
          .get(
              "ldap/api/object?object_type=DOCTY"
            )
          .then(response => {
            this.docTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },  
      getconType() {
        this.$axios
          .get(
              "ldap/api/object?object_type=CTRTY"
            )
          .then(response => {
            this.conTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },  
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getReference(text) {
          if (text === '' || text === undefined) {
            return;
          }
          this.$axios
            .get(
              "hcis/api/contract?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&business_code=" + this.company
            )
            .then(response => {
              this.references[0].data = [];
              response.data.data.forEach(async (item, key) => {
                await this.references[0].data.push(
                  item.contract_number,
                );
              });

              const filteredData = this.references[0].data.filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

              this.filterReference = [{
                data: filteredData
              }];
            })
            .catch(e => {
              console.log(e);
            });
        },
      selectReference(option) {
          if (option == null) {
            this.refContract = null;
          } else {
            this.refContract = option.item;
          }
        },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getEmployeeData(nik) {
        await this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
            if(!this.objectIdentifier){
            this.nama = response.data.data[0].personnel_number.complete_name;
            this.posisi = response.data.data[0].position_name;
            this.unit = response.data.data[0].unit_name;
            }
            
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
          this.nama = '';
          this.unit = '';
          this.posisi = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      
      getContracts() {
        this.$axios
          .get("hcis/api/contract?include=business_code&include=personnel_number&include=reference_contract&include=contract_type&orderoid=asc" +
            '&page=' + this.pagination.current_page +
            '&per_page=' + this.perPage
          )
          // .get("hcis/api/Contract")
          .then(response => {
            this.Contracts = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getContract(objectIdentifier) {
        let Contract = await this.Contracts.find(
          Contract => Contract.object_identifier == objectIdentifier
        );
        this.objectIdentifier = Contract.object_identifier;
        this.startDate = Contract.begin_date;
        this.endDate = Contract.end_date;
        this.docType = Contract.document_type;
        this.conType = Contract.contract_type.object_code;
        this.conNumber = Contract.contract_number;
        this.conDesc = Contract.contract_desc;
        this.docIssue = Contract.document_issue;
        this.refNumber = Contract.reference_number;
        this.refContract = Contract.reference_contract;
        this.posisi = Contract.organizational_name;
        this.unit = Contract.position_name;
        this.nama= Contract.personal_name;

        this.company = Contract.business_code.business_code;
        this.employee = Contract.personnel_number.personnel_number;

        this.getEmployeeData(this.employee);
        this.getdocType();
        this.getconType();
      },
      getParam() {
      this.getdocType();
      this.getconType();
      },
      openFormModal() {
        this.isActiveForm = true;
        this.getdocType();
        this.getconType();
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.docType = null;
        this.conType = null;
        this.conNumber = null;
        this.conDesc = null;
        this.docIssue = null;
        this.refNumber = null;
        this.refContract = null;
        this.unit = null;
        this.posisi = null;
        this.nama= null;

        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = "";
        this.empolyeeUnit = "";

        this.$nextTick(() => this.$validator.reset());
      },
      storeContract() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/contract", {
              begin_date: this.startDate,
              end_date: this.endDate,
              document_type: this.docType,
              contract_number: this.conNumber,
              contract_type: this.conType,
              contract_desc: this.conDesc,
              document_issue: this.docIssue,
              reference_number: this.refNumber,
              reference_contract: this.refContract || '0',
              organizational_name: this.unit,
              position_name: this.posisi,
              personal_name: this.nama,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getContracts();
              this.closeFormModal();
              swal("Saved!", "Successfully saved data Kontrak.", "success");
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      async editContract(objectIdentifier) {
        await this.getContract(objectIdentifier);
        this.openFormModal();
      },
      updateContract() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/contract", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              document_type: this.docType,
              contract_number: this.conNumber,
              contract_type: this.conType,
              contract_desc: this.conDesc,
              document_issue: this.docIssue,
              reference_number: this.refNumber,
              reference_contract: this.refContract,
              organizational_name: this.unit,
              position_name: this.posisi,
              personal_name: this.nama,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getContracts();
              this.closeFormModal();
              swal("Updated!", "Successfully updated data Kontrak.", "success");
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveContract() {
        this.objectIdentifier ? this.updateContract() : this.storeContract();
      },

      deleteContract(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete("hcis/api/contract?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", response.data.message, "success");
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeContract(key);
              });
          }
        });
      },
      removeContract(key) {
        this.Contracts.splice(key, 1);
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;

        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitContract(objectIdentifier) {
        this.openFormModalDelimit();
        let Contract = await this.Contracts.find(
          Contract => Contract.object_identifier == objectIdentifier
        );
        this.objectIdentifier = Contract.object_identifier;
        this.startDate = Contract.begin_date;
        this.endDate = Contract.end_date;
      },
      delimitContract() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/contract", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getContracts();
              this.closeFormModalDelimit();
              swal(
                "Delimited!", 
                response.data.message, 
                "success"
                );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      formatDate(date) {
        return moment(date).format("DD/MM/YYYY");
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      },
    
      // getColumn() {
      //   this.$axios.get('/objects/alltable/Contract/column')
      //     .then(response => {
      //       this.columns = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // getLogic() {
      //   this.$axios.get('/objects/oprationsql')
      //     .then(response => {
      //       this.logics = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // getCondition() {
      //   this.$axios.get('/objects/conditionsql')
      //     .then(response => {
      //       this.conditions = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // addSearchForm() {
      //   this.searchforms.push({
      //     column: '',
      //     logic: '',
      //     filter: '',
      //     condition: ''
      //   });
      // },
      // deleteSearchForm(key) {
      //   this.searchforms.splice(key, 1);
      // },
      // getSearchDynamic() {
      //   this.paramsearchforms = {
      //     table: 'Contract', //harcode sesuai form *referensi table_code*
      //     column: this.columns_model,
      //     query: this.logics_model,
      //     value: this.filters_model,
      //     andor: this.conditions_model
      //   };
      //   this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
      //     .then(response => {
      //       console.log(response);
      //       this.Contracts = [];
      //       response.data.data.forEach(async (Contract, key) => {
      //         await this.Contracts.push({
      //           begin_date: Contract.begin_date,
      //           end_date: Contract.end_date,
      //           personal_number: Contract.personnel_number
      //         })
      //       });
      //     });
      // }
    },
    middleware: ["auth"]
  }

</script>
<style>
  .has-background-danger {
    background-color: #6d6d6d !important;
  }

  .button.is-danger {
    background-color: #ce1000;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
