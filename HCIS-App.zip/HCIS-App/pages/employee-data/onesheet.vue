<template>
  <section>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <section class="profile section">
      <div class="container">
        <div class="columns columntop">
          <div class="column is-two-fifths">
            <h1 class="title is-size-4">
              Fransisca Gabriellaa
            </h1>
            <p class="has-text-weight-light">
              <span class="icon has-text-infos">
                <i class="fa fa-id-badge"></i>
              </span>
              12345678
            </p>
            <p class="has-text-weight-light">
              <span class="icon has-text-infos">
                <i class="fa fa-user"></i>
              </span>
              Siska
            </p>
            <p class="has-text-weight-light">
              <span class="icon has-text-infos">
                <i class="fa fa-venus"></i>
              </span>
              Female
            </p>
          </div>
          <div class="column is-2">
            <figure class="image image is-128x128">
              <img class="is-rounded" style="height: 100%;object-fit: cover;"
                src="https://mobirise.com/bootstrap-template/profile-template/assets/images/timothy-paul-smith-256424-1200x800.jpg">
            </figure>
          </div>
          <div class="column has-text-grey-light has-text-right has-text-centered-mobile">
            <p class="has-text-weight-light">
              <span class="icon has-text-infos">
                <i class="fa fa-birthday-cake"></i>
              </span>
              20 Februari 1996
            </p>
            <p class="has-text-weight-light">
              <span class="icon has-text-infos">
                <i class="fa fa-circle"></i>
              </span>
              Islam
            </p>
            <p class="has-text-weight-light">
              <span class="icon has-text-infos">
                <i class="fa fa-flag"></i>
              </span>
              IDN, Indonesia
            </p>
            <p class="has-text-weight-light">
              <span class="icon has-text-infos">
                <i class="fa fa-bookmark"></i>
              </span>
              Married , 13th March 2019
            </p>
          </div>
        </div>
      </div>
    </section>

    <div class="hr"></div>

    <section class="section">
      <div class="container">
        <div class="columns">
          <div class="column is-three-fifths">
            <div class="summary">

              <div class="title is-size-5 has-text-info has-text-weight-bold">SUMMARY</div>
              <hr>
              <div class="wrapper">
                i was graduated from Harvard University, London. i'm passionated with coding and design.
                i have some experiences in mobile and website application programming.
              </div>
            </div>

            <div class="interest">
              <div class="title is-size-5 has-text-info has-text-weight-bold">INTEREST</div>
              <hr>
              <div class="wrapper">
                I'm passionate with coding so much more thanmy life
              </div>
            </div>

            <div class="experience">
              <div class="title is-size-5 has-text-info has-text-weight-bold">WORK PLACEMENT</div>
              <hr>
              <div class="item">
                <div class="is-size-5"><b>Telkomsigma,</b> <span class="has-text-weight-semi-bold">Serpong — <i>Junior
                      Programmer</i></span></div>
                <div class="is-size-7">June 2008 - 2012</div>
                <div>as Junor web and mobile application</div>
              </div>
              <div class="item">
                <div class="is-size-5"><b>Telkomsel,</b> <span class="has-text-weight-semi-bold">Jakarta — <i>Web
                      Designer</i></span></div>
                <div class="is-size-7">June 2012 - 2016</div>
                <div>as UI UX Designrt</div>
              </div>
              <div class="item">
                <div class="is-size-5"><b>Telkom,</b> <span class="has-text-weight-semi-bold">Jakarta — <i>UI/UX
                      Designer</i></span></div>
                <div class="is-size-7">June 2008 - 2012</div>
                <div>as Junor web and mobile application</div>
              </div>

            </div>

            <div class="education">
              <div class="title is-size-5 has-text-info has-text-weight-bold">EDUCATION</div>
              <hr>
              <div class="item">
                <div class="is-size-5"><b>SHS 1 Jakarta</b>, <span class="has-text-weight-semi-bold">Jakarta — <i>Sangat
                      Memuaskan</i></span></div>
                <div class="is-size-7">January 2011 - March 2013</div>

              </div>
              <div class="item">
                <div class="is-size-5"><b>Harvard University</b>, <span class="has-text-weight-semi-bold">London —
                    <i>Sangat
                      Memuaskan</i></span></div>
                <div class="is-size-7">January 2013 - December 2017</div>
                <div>Bachelor of Computer Science</div>
              </div>
              <div class="item">
                <div class="is-size-5"><b>Standford University</b>, <span class="has-text-weight-semi-bold">London —
                    <i>Sangat
                      Memuaskan</i></span></div>
                <div class="is-size-7">January 2017 - PRESENT</div>
                <div>Magister of Computer Science</div>
              </div>
            </div>


          </div>
          <div class="column">
            <div class="skills">
              <div class="title is-size-5 has-text-info has-text-weight-bold">SKILLS</div>
              <hr>
              <div class="wrapper">
                <div class="item">
                  <div>UI/UX Designer for mobile and web</div>
                  <progress class="progress is-danger is-small" value="90" max="100">90%</progress>
                </div>

                <div class="item">
                  <div>Front end developer</div>
                  <progress class="progress is-danger is-small" value="85" max="100">85%</progress>
                </div>

                <div class="item">
                  <div>Database administrator</div>
                  <progress class="progress is-danger is-small" value="70" max="100">70%</progress>
                </div>

                <div class="item">
                  <div>Network Solution</div>
                  <progress class="progress is-danger is-small" value="50" max="100">50%</progress>
                </div>

              </div>
            </div>
            <div class="training">
              <div class="title is-size-5 has-text-info has-text-weight-bold">TRAINING</div>
              <hr>
              <div class="item">
                <div>
                  <div class="box">
                    <article class="media">
                      <div class="media-left">
                        <span class="icon has-text-infos">
                          <i class="fa fa-star" aria-hidden="true"></i>
                        </span>
                      </div>
                      <div class="media-content">
                        <div class="content">
                          <p> <small>20 Maret 2018</small> </p>
                          <p>
                            <strong>UI/UX mobile expert trainee</strong>
                            <br>
                          </p>
                          <p><i class="fa fa-map-marker" aria-hidden="true"></i><strong>Bandung</strong>
                          </p>
                        </div>
                      </div>
                    </article>
                  </div>
                </div>
              </div>
              <br>
              <div class="item">
                <div>
                  <div class="box">
                    <article class="media">
                      <div class="media-left">
                        <span class="icon has-text-infos">
                          <i class="fa fa-star" aria-hidden="true"></i>
                        </span>
                      </div>
                      <div class="media-content">
                        <div class="content">
                          <p> <small>20 Maret 2018</small> </p>
                          <p>
                            <strong>UI/UX mobile expert trainee</strong>
                            <br>
                          </p>
                          <p><i class="fa fa-map-marker" aria-hidden="true"></i><strong>Bandung</strong>
                          </p>
                        </div>
                      </div>
                    </article>
                  </div>
                </div>
              </div>
              <br>
              <div class="item">
                <div>
                  <div class="box">
                    <article class="media">
                      <div class="media-left">
                        <span class="icon has-text-infos">
                          <i class="fa fa-star" aria-hidden="true"></i>
                        </span>
                      </div>
                      <div class="media-content">
                        <div class="content">
                          <p> <small>20 Maret 2018</small> </p>
                          <p>
                            <strong>UI/UX mobile expert trainee</strong>
                            <br>
                          </p>
                          <p><i class="fa fa-map-marker" aria-hidden="true"></i><strong>Bandung</strong>
                          </p>
                        </div>
                      </div>
                    </article>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>


  </section>
</template>
<script>
export default {
  layout: 'auth',
  data() {
    return {
      testData: ''
    }
  },
  created() {
    this.getOneSheet();
  },
  methods: {
    getOneSheet() {
      this.$axios.get('http://43.229.207.242:8500/api/users/1000/OneSheet/10101010')
      .then(response => {
        console.log(response);
      });
    }
  }
}

</script>



<style>
  body {
    font-family: 'Raleway', sans-serif;
  }

  .has-text-info {
    color: #940000 !important;
  }

  .has-text-grey-light {
    color: #7b7979 !important;
  }

  .line {
    height: 5px;
  }

  .hr {
    border-bottom: 10px solid #940000;
    margin: 1.5rem;
    border-radius: 5px;
  }

  .summary,
  .experience,
  .education,
  .projects,
  .skills,
  .awards,
  .languages,
  .interest {
    margin-bottom: 1.5rem;

  }

  .experience,
  .education,
  .projects,
  .skills,
  .awards,
  .interest,
  .training {

    padding: .5em 0;

  }

  .image.is-128x128 {
    height: 128px;
    width: 128px;
    margin-left: auto;
    margin-right: auto;
  }

  .profile {
    margin: 0 auto;
    fill: #fff;

  }

  .profile {
    text-align: center;
    background-color: #820914;
  }

  .title {
    color: #fffafa;
    font-size: 2rem;
    font-weight: 600;
    line-height: 1.125;
  }

  .subtitle {
    color: #fffdfd;
    font-size: 1.25rem;
    font-weight: 400;
    line-height: 1.25;
  }

  .has-text-grey-light {
    color: #ffffff !important;
  }

  /* Query for mobile only*/
  @media screen and (max-width: 768px) {
    .profile {
      text-align: center;
      color: #ffffff
    }
  }

  /* Query for desktop only*/
  @media screen and (min-width: 1023px) {
    .has-text-right-in-desktop {
      text-align: right;
    }
  }

  svg {
    height: 40px;
  }

  .column {
    display: block;
    flex-basis: 0;
    flex-grow: 1;
    flex-shrink: 1;
    padding: 2rem 1.5rem;
  }

  .column.is-two-fifths {
    padding: 0rem 1.5rem;
    padding-top: 35px;
    padding-bottom: 0px;
  }

  .title.is-size-4 {
    margin-bottom: 1rem;
  }

  .has-text-info {
    color: #820914 !important;
  }

  .content p:not(:last-child),
  .content dl:not(:last-child),
  .content ol:not(:last-child),
  .content ul:not(:last-child),
  .content blockquote:not(:last-child),
  .content pre:not(:last-child),
  .content table:not(:last-child) {
    margin-bottom: 0em;
  }

</style>
