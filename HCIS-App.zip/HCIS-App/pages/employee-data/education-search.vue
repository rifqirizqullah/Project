<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
     <a class="button is-link is-rounded is-pulled-right"  @click="clearDetail();openFormModal()"> <span><i class="fa fa-plus" aria-hidden="true"></i> Tambah Data </span></a>
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Pendidikan Karyawan BUMN
    </h3>
    <!--<div class="box has-text-white has-background-danger">
      Filter Search
    </div>-->
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                    {{ column.column_name }}
                  </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Level Pendidikan</th>
          <th>Instansi</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(item, key) in education.list" :key="key">
          <td> {{key+1}} </td>
          <td> {{item.business_code.company_name}}</td>
          <td> {{item.personnel_number.personnel_number}}</td>  
          <td> {{item.level.value}}</td>
          <td> {{item.institution.value}}</td>        
          <td> {{ formatDate(item.begin_date)}} </td>
          <td> {{ formatDate(item.end_date)}} </td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded" @click="showUpdateForm(item.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="deleteData(item.object_identifier, key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitForm(item.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>
    <pagination :state="education" :offset="5" :storeModuleName="'education'"/>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }"> 
      <educationForm :isActiveForm="isActiveForm" v-if="isActiveForm == true"/>          
    </div>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
        <div class="modal-background"></div>
        <div class="modal-card">
          <header class="modal-card-head">
            <p class="modal-card-title">Delimit Data</p>
            <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
          </header>
          <section class="modal-card-body">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="begin_date" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                      data-vv-scope="delimit" disabled>
                  </div>
                  <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                    {{ errors.first('delimit.begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="end_date" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                      data-vv-scope="delimit">
                  </div>
                  <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                    {{ errors.first('delimit.end_date') }}
                  </p>
                </div>
              </div>
            </div>
          </section>
          <footer class="modal-card-foot">
            <div class="control">
              <button @click="delimitData()" class="button is-success">Simpan</button>
              <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
            </div>
          </footer>
        </div>
      </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import { mapState, mapActions } from "vuex";
  import moment from "moment";
  import educationForm from "@@/components/forms/educationForm";
  import pagination from "@@/components/paginationBar";
  export default {  
    components: {
      educationForm,
      Breadcrumb,
      pagination
    },
    created() {
      this.$store.dispatch("education/getAll");    
      this.$store.dispatch("companies/getAll");
    },
    data() {
      return {      
        begin_date:null,
        end_date: null,
        isActiveForm:false,
        isActiveFormDelimit: false,
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Pendidikan'
          },
        ],
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
      };
    },
    computed: {
      ...mapState(["education", "companies"])
    },
    methods: {       
      ...mapActions({
        getDetail: "education/getDetail",
        clearDetail: "education/clearDetail",
        deleteOne: "education/deleteOne",
        getAll: "education/getAll"
      }),
    
      showUpdateForm(object_identifier) {
        this.getDetail(object_identifier);
        this.openFormModal();
      },

      async showDelimitForm(object_identifier) {
        await this.getDetail(object_identifier);
        this.begin_date = this.education.detail.begin_date;
        this.end_date = this.education.detail.end_date;
        this.openFormModalDelimit();
      },
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false        
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
      },
      deleteData(id, index) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          buttons: true,
          dangerMode: true,
          showCancelButton: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete("hcis/api/educations?object_identifier=" + id)
              .then(response => {
                swal(
                  "Deleted!",
                  response.data.message,
                  "success"
                );
                this.deleteOne(index);
              })            
              .catch(e => {
                console.log(e.response);
              });
          }
        });
      },

      delimitData() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/educations",
              {},
              {
                params: {
                  object_identifier: this.education.detail.object_identifier,
                  end_date: this.end_date
                }
              }
            )
            .then(response => {
              this.$store.dispatch("education/getAll");
              this.closeFormModalDelimit();
              swal("Saved!", "Successfully saved data.", "success");
            })
            .catch(e => {
              console.log(e.response);
            });
        });
      },
      formatDate(date) {
          return moment(date).format('DD-MM-YYYY')
      },
      // getColumn() {
      //   this.$axios.get('/users/education/column')
      //     .then(response => {
      //       this.columns = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getLogic() {
      //   this.$axios.get('/objects/oprationsql')
      //     .then(response => {
      //       this.logics = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getCondition() {
      //   this.$axios.get('/objects/conditionsql')
      //     .then(response => {
      //       this.conditions = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getSearchDynamic() {
      //   this.paramsearchforms = {
      //     table : "Education",//harcode sesuai form *referensi table_code*
      //     column : this.columns_model,
      //     query : this.logics_model,
      //     value : this.filters_model,
      //     andor : this.conditions_model
      //   }
      //   console.log(this.paramsearchforms)
      //   this.$axios.post('users/seachdinamis?per_page=10&page=1',this.paramsearchforms)
      //     .then(response => {

      //       this.educations = [];
      //       response.data.data.forEach(async (education, key) => {
      //         await this.educations.push({
      //           startDate: education.begin_date,
      //           endDate: education.end_date,
      //           personalNumber: education.personal_number
      //         })
      //       });
      //       console.log(this.educations);
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },    
      // addNewFormSearch() {
      //   this.searchforms.push({
      //     column: '',
      //     logic: '',
      //     filter: '',
      //     condition: ''
      //   })
      // },
      // deleteFormSearch(key) {
      //   this.searchforms.splice(key, 1)
      // }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
