<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/employee-data/communication-social-media-search"
      class="button is-success is-rounded is-pulled-right"><span>
        <i class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-phone" aria-hidden="true"></i> Alat Komunikasi / Social Media
    </h3>
    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearpersonalNumber">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" v-model="personalNumber_query" disabled>
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cUnit" disabled>
            </div>
          </div>
        </div>

      </div>
    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Alat Komunikasi</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Alat Komunikasi</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('communication_type') }">
                <select name="communication_type" class="select" v-model="communicationType" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(communicationType, key) in communicationTypes" :key="key"
                    :value="communicationType.objectId">{{
                    communicationType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('communication_type')" class="help is-danger">{{
                errors.first('communication_type')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Alat Komunikasi/ Email /Username</label>
            <div class="control">
              <input name="communication_number" class="input " placeholder="" type="text" v-model="communicationNumber"
                v-bind:class="{ 'is-danger': errors.has('communication_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('communication_number')" class="help is-danger"> {{
              errors.first('communication_number') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>

        <div class="columns">
      <div class="column">
        <table v-if="components.length>0" class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
          <thead>
            <tr>
              <th>Nomor Alat Komunikasi</th>
              <th>Tipe Alat Komunikasi</th>
              <th>Nomor Alat Komunikasi/ Email /Username</th>
              <th>Tanggal Awal Berlaku</th>
              <th>Tanggal Akhir Berlaku</th>
              <th>Aksi</th>
            </tr>
            <tr  v-for="(component, key) in components" :key="key">
              <th>
                <input class="input" type="text" placeholder="1" v-model="serial_number_table[key]" disabled>
              </th>
              <th>
                <select class="select is-fullwidth" v-model="communication_type_table[key]">
                  <option v-for="(communicationType, key) in communicationTypes" :key="key"
                    :value="communicationType.objectId">{{
                    communicationType.name
                    }}</option>
                </select>
              </th>
              <th>
                <input class="input" type="text" v-model="communication_number_table[key]">
              </th>
              <th>
                <input class="input" type="date" v-model="start_table[key]">
              </th>
              <th>
                <input class="input" type="date" v-model="end_table[key]">
              </th>
              <th><a class="button is-danger is-small is-rounded is-outlined tombolhapus"
                  @click="deleteComponents(key)"><i class="fa fa-trash" aria-hidden="true"></i></a></th>
            </tr>
          </thead>
        </table>
      </div>
    </div>

    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VeeValidate from 'vee-validate';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  import swal from 'sweetalert';

  Vue.use(VeeValidate);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        key: null,

        //untuk data diri
        buscd: '',
        name: '',
        personalNumber: null,
        cUnit: '',
        cPosition: '',
        //

        //v-model form input
        startDate: '',
        endDate: '',
        communicationType: '',
        serialNumber: '',
        communicationNumber: '',
        //

        components: [], //nampung data ditabel/form edit
        communicationTypes: [], //nampung data select
        buscds: [], //nampung data nama perusahaan

        //untuk saat edit diluar
        personalNumber_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        //

        //variabel untuk tampung data ditabel (edit dalam)
        communication_type_table: [],
        communication_number_table: [],
        serial_number_table: [],
        start_table: [],
        end_table: [],
        //

        //bawaan vue suggest
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,
        //
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Alat Komunikasi / Social Media'
          },
        ]
      }
    },
    created() {
      this.getBUSCD();
      this.getHakAkses();
      this.getCommunicationTypes();
      if (this.personalNumber_query != null) { //cek jika edit luar
        this.getData();
      }
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/COMEP')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'W') {
              return this.$router.push('/employee-data/communication-social-media-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('users/' + this.buscd + '/communication/' + this.personalNumber)
          .then(response => {
            this.components = [];
            response.data.data.forEach(async (communication, key) => {
              this.components.push({
                begin_date: communication.begin_date,
                end_date: communication.end_date,
                business_code: communication.business_code,
                personal_number: communication.personal_number,
                communication_type: communication.communication_type[0].object_id,
                serial_number: communication.serial_number,
                communication_number: communication.communication_number,
              });

              this.key = key,
                this.serial_number_table[this.key] = communication.serial_number;
              this.communication_type_table[this.key] = communication.communication_type[0].object_id;
              this.communication_number_table[this.key] = communication.communication_number;
              this.start_table[this.key] = communication.begin_date;
              this.end_table[this.key] = communication.end_date;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('users/' + this.buscd + '/communication/' + option.item)
              .then(response => {
                this.components = [];
                response.data.data.forEach((communication, key) => {
                  this.components.push({
                    begin_date: communication.begin_date,
                    end_date: communication.end_date,
                    personal_number: communication.personal_number,
                    communication_type: communication.communication_type[0].object_id,
                    serial_number: communication.serial_number,
                    communication_number: communication.communication_number,
                    business_code: communication.business_code
                  });
                  this.key = key,
                    this.serial_number_table[this.key] = communication.serial_number;
                  this.communication_type_table[this.key] = communication.communication_type[0].object_id;
                  this.communication_number_table[this.key] = communication.communication_number;
                  this.start_table[this.key] = communication.begin_date;
                  this.end_table[this.key] = communication.end_date;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }

        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;

          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            if (this.components.length > 0) {
              var address_num = parseInt(this.serial_number_table[this.components.length - 1]) + 1;
            } else {
              var address_num = 1;
            }
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.personalNumber,
              communication_type: this.communicationType,
              serial_number: address_num,
              communication_number: this.communicationNumber,
            });
            this.components.forEach((user, key) => {
              this.key = key;
              this.serial_number_table[this.key] = user.serial_number;
              this.communication_type_table[this.key] = user.communication_type;
              this.communication_number_table[this.key] = user.communication_number;
              this.start_table[this.key] = user.begin_date;
              this.end_table[this.key] = user.end_date;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.personalNumber_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  serial_number: this.serial_number_table[index1],
                  communication_type: this.communication_type_table[index1],
                  communication_number: this.communication_number_table[index1],
                  begin_date: this.start_table[index1],
                  end_date: this.end_table[index1]
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/communication/' + this.personalNumber, this.components)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data Komunikasi.',
                        'sukses'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              Object.assign(this.components[index1], {
                serial_number: this.serial_number_table[index1],
                communication_type: this.communication_type_table[index1],
                communication_number: this.communication_number_table[index1],
                begin_date: this.start_table[index1],
                end_date: this.end_table[index1]
              });
            });
            swal({
              title: 'Apakah anda yakin ingin menyimpan data ini?',
              text: 'Anda tidak dapat membatalkan',
              type: 'peringatan',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/basicpay/' + this.personalNumber, this.components)
                  .then(response => {
                    swal(
                      'Data tersimpan!',
                      'Sukses menyimpan data Komunikasi.',
                      'sukses'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearpersonalNumber()
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        var x = 1
        this.components.forEach((user, key) => {
          this.key = key;
          this.serial_number_table[this.key] = x;
          this.communication_type_table[this.key] = user.communication_type;
          this.communication_number_table[this.key] = user.communication_number;
          user.serial_number = x;
          this.start_table[this.key] = user.begin_date;
          this.end_table[this.key] = user.end_date;
          x++;
        })
      },
      getCommunicationTypes() {
        // this.$axios.get('/objects/communicationtype')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte=9999-12-31&object_type=COMTY')
          .then(response => {
            this.communicationTypes = [];
            response.data.data.forEach((communicationType, key) => {
              this.communicationTypes.push({
                objectId: communicationType.id,
                name: communicationType.value,
              });
            });
          })
          .catch(e => {
            console.log(e)
          });
      },
      getpersonalNumber() {
        this.$axios.get('/users/personal')
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/COMFM')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.personalNumber = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.communicationType = '';
        this.serialNumber = null;
        this.communicationNumber = null;
        this.$nextTick(() => this.$validator.reset());
      },
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
