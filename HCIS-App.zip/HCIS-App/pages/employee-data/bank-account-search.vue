<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> <span><i class="fa fa-plus" aria-hidden="true"></i> Tambah Data </span></a> 
    <h3 class="subtitle is-3">
      <i class="fa fa-credit-card-alt"></i> Pencarian Data Rekening Bank
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                    {{ column.column_name }}
                  </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Nomer Induk Karyawan</th>
          <th>Tipe Bank</th>
          <th>No Rekening</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(bankAccount, key) in bankAccounts" :key="key">
          <td> {{key+1}} </td>
          <td> {{bankAccount.personnel_number.personnel_number}}</td>
          <td> {{bankAccount.bank_type}}</td>
          <td> {{bankAccount.account_number}}</td>
          <td> {{formatDate(bankAccount.begin_date)}} </td>
          <td> {{formatDate(bankAccount.end_date)}} </td>
          <td>
           <a class="button is-success is-small is-outlined is-rounded"
              @click="editbankAccount(bankAccount.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="bankAccount.object_identifier ? deletebankAccount(key, bankAccount.object_identifier) : removebankAccount(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitbankAccount(bankAccount.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>
     <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getbankAccounts()"></pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Rekening Bank</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nama Perusahaan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                      <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                        v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                          {{ company.company_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                  </div>
                </div>
              </div>
          </div>

      <span v-show="company">
      <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee= null">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      :on-selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
      </div>
      <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
      </div>

      <hr>
      <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
      </div>
      <div class="columns">
        <div class="column is-5">
          <div class="field">
            <label class="label">Tipe Rekening</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.account_type') }">
                <select name="account_type" class="select" v-model="accountType" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(accountType, key) in accountTypes" :key="key" :value="accountType.object_code">{{
                    accountType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.account_type')" class="help is-danger">{{errors.first('form.account_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-5">
          <div class="field">
            <label class="label">Nama di Rekening</label>
            <div class="control">
              <input name="full_name" class="input " placeholder="e.g. Didik Setiawan" type="text"
                data-vv-as="full name" v-model="fullName"
                v-bind:class="{ 'is-danger': errors.has('form.full_name')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.full_name')" class="help is-danger"> {{ errors.first('form.full_name')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-5">
          <div class="field">
            <label class="label">Grup Bank</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.bank_group') }">
                <select name="bank group" class="select" v-model="bankGroup" v-validate="'required'"
                  @change="getBankByGroup()" data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(bankGroup, key) in bankGroups" :key="key" :value="bankGroup.object_code">{{
                    bankGroup.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.bank_group')" class="help is-danger">{{errors.first('form.bank_group')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-5">
          <div class="field">
            <label class="label">Nama Bank</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.bank_name') }">
                <select name="bank_name" class="select" v-model="bankCode" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(bankCode, key) in bankCodes" :key="key" :value="bankCode.bank_code">{{
                    bankCode.bank_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.bank_name')" class="help is-danger">{{errors.first('form.bank_name')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-5">
          <div class="field">
            <label class="label">Nomor Rekening</label>
            <div class="control">
              <input name="account_number" class="input " placeholder="e.g. 00215" type="text" v-model="accountNumber"
                v-bind:class="{ 'is-danger': errors.has('form.account_number')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.account_number')" class="help is-danger"> {{
              errors.first('form.account_number')
              }}</p>
          </div>
        </div>
        <div class="column is-5">
          <div class="field">
            <label class="label">Metode Pembayaran</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.payment') }">
                <select name="payment" class="select" v-model="payment" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option value="0">Tunai</option>
                  <option value="1">Transfer</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('form.payment')" class="help is-danger">{{ errors.first('form.payment') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-5">
          <div class="field">
            <label class="label">Jumlah</label>
            <div class="control">
              <input name="total" class="input " placeholder="e.g. 1.000.0000" type="number" v-model="nilai"
                v-bind:class="{ 'is-danger': errors.has('form.total')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.total')" class="help is-danger"> {{ errors.first('form.total')
              }}</p>
          </div>
        </div>
        <div class="column is-5">
          <div class="field">
            <label class="label">Persentase</label>
            <div class="control">
              <input name="percentage" class="input " placeholder="e.g. 50" type="percentage" v-model="percent  "
                v-bind:class="{ 'is-danger': errors.has('form.percentage')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.percentage')" class="help is-danger"> {{ errors.first('form.percentage')
              }}</p>
          </div>
        </div>
      </div>
      </span>
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="savebankAccount()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
  </div>

  <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
            <div class="modal-background"></div>
            <div class="modal-card">
              <header class="modal-card-head">
                <p class="modal-card-title">Delimit Data Identitas</p>
                <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
              </header>
              <section class="modal-card-body">
                <div class="columns">
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Awal Berlaku</label>
                      <div class="control">
                        <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                          v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                          data-vv-scope="delimit" disabled>
                      </div>
                      <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                  </div>
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Akhir Berlaku</label>
                      <div class="control">
                        <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                          v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                          data-vv-scope="delimit">
                      </div>
                      <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                      </p>
                    </div>
                  </div>
                </div>
              </section>
              <footer class="modal-card-foot">
                <div class="control">
                  <button @click="delimitbankAccount()" class="button is-success">Simpan</button>
                  <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
                </div>
              </footer>
            </div>
  </div>
  
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        bankAccounts: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        accountTypes: [],
        accountType: null,
        fullName: null,
        bankGroups: [],
        bankGroup:null,
        bankCodes: [],
        bankCode: null,
        accountNumber: null,
        payment: null,
        nilai: null,
        percent: null,
        
        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: "",
        empolyeePosition: '',
        empolyeeUnit: '',
        perPage:5,
        search:'',
        pagination: {
            'current_page': 1
          },
         options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },

        bankByCodes: [],

        limit: 10,
        columns:[],
        logics:[],
        conditions:[],
        filters:[],
        paramsearchforms:'',
        columns_model:[],
        filters_model:[],
        conditions_model:[],
        logics_model:[],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Employee Data'
          },
          {
            name: 'Bank Account Search'
          },
        ],
        isActiveForm:false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getbankAccounts();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
      // this.getHakAkses();
      this.getCompany();
    },
    methods: {
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(
                employee.personnel_number
                );
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.employeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal("", "Pilih nama perusahaan terlebih dahulu !", "error");
          } else {
            this.selfData(option.item);
          }
        }
      },
      selfData(nik){
          this.$axios
                .get(
                  "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&end_date_gte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&personnel_number=" +
                  nik + "&business_code=" +this.company
                )
                .then(async response => {
                  this.empolyeeName = response.data.data[0].personnel_number.complete_name;
                  this.empolyeePosition = response.data.data[0].position_name;
                  this.empolyeeUnit = response.data.data[0].unit_name;
                })
                .catch(e => {
                  console.log(e);
                });
        },
      clearEmployee() {
        if (this.employee != null) {
          this.$refs.reference= '';
        }
        this.filterEmployee = []
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeeUnit = '';
        this.empolyeePosition = '';

        this.$nextTick(() => this.$validator.reset());
      },
      getParam(){
      this.getaccountType();
      this.getbankGroup();  
      this.getbankCode();
      },
      getaccountType() {
        this.$axios
          .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=BANTY"
            )
          .then(response => {
            this.accountTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getbankGroup() {
        this.$axios
          .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=BANGR"
            )
          .then(response => {
            this.bankGroups = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getbankCode() {
        this.$axios
          .get(
              "hcis/api/bank?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +"&business_code="+
              this.company
            )
          .then(response => {
            this.bankCodes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.accountType = null;
        this.fullName = null;
        this.bankGroup = null;
        this.bankCode = null;
        this.accountNumber= null,
        this.payment= null,
        this.nilai= null,
        this.percent= null,

        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = '';
        this.empolyeeUnit = '';

        this.$nextTick(() => this.$validator.reset())
      },  
      storebankAccount() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/bankemployee", {
              begin_date: this.startDate,
              end_date: this.endDate,
              bank_type: this.accountType,
              full_name: this.fullName,
              bank_group: this.bankGroup,
              bank_code: this.bankCode,
              account_number: this.accountNumber,
              payment: this.payment,
              nilai: this.nilai,
              percent: this.percent,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getbankAccounts();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data rekening bank.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deletebankAccount(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/bankemployee?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", 
                response.data.message, 
                "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removebankAccount(key);
              });
          }
        });
      },
      removebankAccount(key) {
        this.bankAccounts.splice(key, 1);
      },
      editbankAccount(objectIdentifier) {
        this.openFormModal();
        this.getbankAccount(objectIdentifier);
      },
      updatebankAccount() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/bankemployee", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              bank_type: this.accountType,
              full_name: this.fullName,
              bank_group: this.bankGroup,
              bank_code: this.bankCode,
              account_number: this.accountNumber,
              payment: this.payment,
              nilai: this.nilai,
              percent: this.percent,

              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getbankAccounts();
              this.closeFormModal();
              swal(
                "Updated!",
                "Successfully updated data rekening bank.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      savebankAccount() {
        this.objectIdentifier ? this.updatebankAccount() : this.storebankAccount();
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;

        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitbankAccount(objectIdentifier) {
        this.openFormModalDelimit();
        let bankAccount = await this.bankAccounts.find(
          bankAccount => bankAccount.object_identifier == objectIdentifier
        );
        this.objectIdentifier = bankAccount.object_identifier;
        this.startDate = bankAccount.begin_date;
        this.endDate = bankAccount.end_date;
      },
      delimitbankAccount() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/bankemployee", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getbankAccounts();
              this.closeFormModalDelimit();
              swal(
                "Delimited!", 
                response.data.message, 
                "success"
                );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      getbankAccounts() {
        this.$axios
          .get("hcis/api/bankemployee?inlcude=personnel_number&include=business_code" + '&page=' + this.pagination.current_page+'&per_page='+this.perPage)
          .then(response => {
            this.bankAccounts = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getbankAccount(objectIdentifier) {
        let bankAccount = await this.bankAccounts.find(
          bankAccount => bankAccount.object_identifier == objectIdentifier
        );
        this.objectIdentifier = bankAccount.object_identifier;
        this.startDate = bankAccount.begin_date;
        this.endDate = bankAccount.end_date;
        this.accountType = bankAccount.bank_type;
        this.fullName = bankAccount.full_name;
        this.bankGroup = bankAccount.bank_type;
        this.bankCode = bankAccount.bank_code;
        this.accountNumber= bankAccount.account_number;
        this.payment= bankAccount.payment;
        this.nilai= bankAccount.nilai;
        this.percent= bankAccount.percent;

        this.company = bankAccount.business_code.business_code;
        this.employee = bankAccount.personnel_number.personnel_number;
        this.empolyeeName = bankAccount.personnel_number.complete_name;
        
        this.selfData(this.employee)        
        this.getaccountType();
        this.getbankGroup();  
        this.getbankCode();
       },
      formatDate(date) {
        return moment(date).format("DD/MM/YYYY");
      },
      onlyNumber($event) {
          let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
          if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
            $event.preventDefault();
          }
      },  
      getHakAkses() {
        this.$axios.get('/users/hakakses/BNKEP')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if(this.hakAkses != '*' && this.hakAkses != 'R'){
              return this.$router.push('/employee-data/bank-account')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
        getColumn() {
        this.$axios.get('/users/bank/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
       getLogic() {
        this.$axios.get('/object/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/object/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = { 
          table : "BankEmployee",//harcode sesuai form *referensi table_code*
          column : this.columns_model,
          query : this.logics_model,
          value : this.filters_model,
          andor : this.conditions_model
        }
        console.log(this.paramsearchforms)
         this.$axios.post('users/seachdinamis?per_page=10&page=1',this.paramsearchforms)
          .then(response => {

            this.bankAccounts = [];
            response.data.data.forEach(async (bankAccount, key) => {
              await this.bankAccounts.push({
                startDate: bankAccount.begin_date,
                endDate: bankAccount.end_date,
                personalNumber: bankAccount.personal_number,
                bscd: bankAccount.business_code
              })
            });
            console.log(this.bankAccounts);
          })
          .catch(e => {
            console.log(e);
          });
      },
      
      getBankByGroup() {
        this.$axios.get('hcis/api/bank?bank_group=' + this.bankGroup)
          .then(response => {
            this.bankCodes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
