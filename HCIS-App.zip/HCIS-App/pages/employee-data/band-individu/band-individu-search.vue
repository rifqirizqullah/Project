<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <!--<div class="box has-text-white has-background-danger">
      Filter Search
    </div>-->
    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> <span><i class="fa fa-plus" aria-hidden="true"></i> Tambah Data </span></a>
    <h3 class="subtitle is-3"><i class="fa fa-bar-chart"></i> Pencarian Data Band Individu </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomor Induk Karyawan</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Jabatan</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(basicLevel, key) in basicLevels" :key="key">
          <td> {{ key+1}} </td>
          <td> {{ basicLevel.business_code.company_name }}</td>
          <td> {{ basicLevel.personnel_number.personnel_number}}</td>
          <td> {{ formatDate(basicLevel.begin_date) }} </td>
          <td> {{ formatDate(basicLevel.end_date) }} </td> 
          <td> {{ basicLevel.band_individu_group}}</td> 
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="editBasicLevel(basicLevel.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i></a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="basicLevel.object_identifier ? deleteBasicLevel(key, basicLevel.object_identifier) : removeBasicLevel(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitBasicLevel(basicLevel.object_identifier)"><i class="fa fa-clock-o"
                aria-hidden="true"></i></a>
          </td>
        </tr>
      </thead>
    </table>
    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getbasicLevels()"></pagination>
    
  <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Formulir Band Individu</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nama Perusahaan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                      <select name="company" class="select" v-model="company" @change="clearEmployee();getParam()"
                        v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                          {{ company.company_name }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                  </div>
                </div>
              </div>
            </div>
            <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee= null">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      :on-selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            
            <hr>
			
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
        <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.band_individu_type') }">
                <select name="band_individu_type" class="select" v-model="individuType" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndTypee, key) in bndTypes" :key="key" :value="bndTypee.object_code">{{
                    bndTypee.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.band_individu_type')" class="help is-danger">{{errors.first('form.band_individu_type')
                }}</p>
            </div>
          </div>
        </div>
      <div class="column is-4">
                <div class="field">
                  <label class="label">Area</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.band_individu_area') }">
                      <select name="band_individu_area" class="select" v-model="individuArea" v-validate="'required'" data-vv-scope="form">
                        <option disabled selected>Choose</option>
                        <option v-for="(bndAreaa, key) in bndAreas" :key="key" :value="bndAreaa.object_code">{{
                          bndAreaa.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.band_individu_area')" class="help is-danger">{{errors.first('form.band_individu_area')
                      }}</p>
                  </div>
                </div>
              </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Grup</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.band_individu_group') }">
                <select name="band_individu_group" class="select" v-model="individuGrup" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndGroupp, key) in bndGroups" :key="key" :value="bndGroupp.object_code">{{
                    bndGroupp.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.band_individu_group')" class="help is-danger">{{errors.first('form.band_individu_group')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Level</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.band_individu_level') }">
                <select name="band_individu_level" class="select" v-model="individuLevel" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndLevell, key) in bndLevels" :key="key" :value="bndLevell.object_code">{{
                    bndLevell.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.band_individu_level')" class="help is-danger">{{errors.first('form.band_individu_level')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      </span> 
          </section>
          <footer class="modal-card-foot">
            <div class="control  ">
              <button @click="saveBasicLevel()" class="button is-success">Simpan</button>
              <button class="button is-danger" @click="closeFormModal()">Batal</button>
            </div>
          </footer>
        </div>
      </div>
      <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
        <div class="modal-background"></div>
        <div class="modal-card">
          <header class="modal-card-head">
            <p class="modal-card-title">Delimit Data Karyawan</p>
            <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
          </header>
          <section class="modal-card-body">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}" v-validate="'required'" data-vv-scope="delimit" disabled>
                  </div>
                  <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                    {{ errors.first('delimit.begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}" v-validate="'required'" data-vv-scope="delimit">
                  </div>
                  <p v-show="errors.has('delimit.end_date')" class="help is-danger">
                    {{ errors.first('delimit.end_date') }}</p>
                </div>
              </div>
            </div>          
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="delimitBasicLevel()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        basicLevels: [],  
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        individuArea: null,
        individuType: null,
        individuGrup: null,
        individuLevel: null,
        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: '',
        empolyeePosition: '',
        empolyeeUnit: '',
        perPage:5,
        search:'', 
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        bndLevels:[],
        bndGroups:[],
        bndAreas:[],
        bndTypes:[],
        pagination: {
            'current_page': 1
          },
        options: [{
          data: []
        }],
        filterEmployee: [],
          inputEmployee: {
            id: "autosuggest__input",
            name: "personnel_number",
            class: "input",
            onInputChange: this.getEmployee,
            placeholder: "Nomor Induk Karyawan"
          },  
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Band Individu'
          },
        ],
        isActiveForm:false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getbasicLevels();
      this.getCompany();
    },
    methods: {
      getCompany() {
          this.$axios
            .get(
              "hcis/api/company?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD")
            )
            .then(response => {
              this.companies = response.data.data;
            })
            .catch(e => {
              console.log(e);
            });
        },
      getEmployee(text) {
          if (text === '' || text === undefined) {
            return;
          }
          this.$axios
            .get(
              "hcis/api/personal?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&business_code=" + this.company
            )
            .then(response => {
              this.options[0].data = [];
              response.data.data.forEach(async (employee, key) => {
                await this.options[0].data.push(
                  employee.personnel_number,
                );
              });

              const filteredData = this.options[0].data.filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

              this.filterEmployee = [{
                data: filteredData
              }];
            })
            .catch(e => {
              console.log(e);
            });
        },
        selectEmployee(option) {
          if (option == null) {
            this.employee = null;
            this.empolyeeName = '';
            this.empolyeeUnit = '';
            this.empolyeePosition = '';
          } else {
            this.employee = option.item;
            if (this.company == null) {
              swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
            } else {
              this.selfData(option.item);              
            }
          }
        },
         selfData(nik){
          this.$axios
                .get(
                  "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&end_date_gte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&personnel_number=" +
                  nik + "&business_code=" +this.company
                )
                .then(async response => {
                  this.empolyeeName = response.data.data[0].personnel_number.complete_name;
                  this.empolyeePosition = response.data.data[0].position_name;
                  this.empolyeeUnit = response.data.data[0].unit_name;
                })
                .catch(e => {
                  console.log(e);
                });
        },
        clearEmployee() {
          if (this.employee != null) {
            this.$refs.reference = '';
          }          
          this.filterEmployee = []
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';

          this.$nextTick(() => this.$validator.reset());
        },
        getParam(){
          this.getbndTypee();
          this.getbndAreaa();
          this.getbndGroupp();
          this.getbndLevell();
        },
        getbndTypee() {
          this.$axios
            .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=PSTYP" +"&business_code="+
              this.company
            )
            .then(response => {
              this.bndTypes = response.data.data;
            })
            .catch(e => {
              console.log(e);
            });
        },
         getbndAreaa() {
          this.$axios
            .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=PSARE" +"&business_code="+
              this.company
            )
            .then(response => {
              this.bndAreas = response.data.data;
            })
            .catch(e => {
              console.log(e);
            });
        },
         getbndGroupp() {
          this.$axios
            .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=PSGRP" +"&business_code="+
              this.company
            )
            .then(response => {
              this.bndGroups = response.data.data;
            })
            .catch(e => {
              console.log(e);
            });
        },
         getbndLevell() {
          this.$axios
            .get(
              "ldap/api/object?begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&object_type=PSLVL" +"&business_code="+
              this.company
            )
            .then(response => {
              this.bndLevels  = response.data.data;
            })
            .catch(e => {
              console.log(e);
            });
        },
      getbasicLevels() {
        // this.$axios.get('users/bandindividu')
         this.$axios
            .get("hcis/api/bandindividu?include=personnel_number&include=business_code&begin_date_lte=" +
              moment(new Date()).format("YYYY-MM-DD") +
              "&end_date_gte=" +
              moment(new Date()).format("YYYY-MM-DD") + '&page=' + this.pagination.current_page+'&per_page='+this.perPage)
            // .get("hcis/api/award")
            .then(response => {
              this.basicLevels = response.data.data;
              this.pagination = response.data.meta.pagination;
            })
            .catch(e => {
              console.log(e);
            });
        },
        openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.individuType = null;
        this.individuArea = null;
        this.individuGrup = null;
        this.individuLevel = null;
        this.company = null;
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeePosition = '';
        this.empolyeeUnit = '';

        this.$nextTick(() => this.$validator.reset());
      },
        async getbasicLevel(objectIdentifier) {
          let basicLevel = await this.basicLevels.find(
            basicLevel => basicLevel.object_identifier == objectIdentifier
          );
          this.objectIdentifier = basicLevel.object_identifier;
          this.startDate = basicLevel.begin_date;
          this.endDate = basicLevel.end_date;
          this.individuType= basicLevel.band_individu_type;
          this.individuArea= basicLevel.band_individu_area;
          this.individuGrup= basicLevel.band_individu_group;
          this.individuLevel= basicLevel.band_individu_level; 
         
          this.company = basicLevel.business_code.business_code;
          this.employee = basicLevel.personnel_number.personnel_number;
          
          this.selfData(this.employee)        
          this.getbndTypee();
          this.getbndAreaa();
          this.getbndGroupp();
          this.getbndLevell();
        },
      editBasicLevel(objectIdentifier) {
        this.openFormModal();
        this.getbasicLevel(objectIdentifier);
      },
      saveBasicLevel() {
        this.objectIdentifier ? this.updateBasicLevel() : this.storeBasicLevel();
      },
      updateBasicLevel() {
        this.$validator.validateAll('basiclevel').then(async result => {
          if (!result) return;
          //alert(chuser)
          this.$axios.put("hcis/api/bandindividu", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate, 
              band_individu_type: this.individuType,
              band_individu_group: this.individuGrup,
              band_individu_area: this.individuArea,
              band_individu_level: this.individuLevel,
			        personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getbasicLevels();
              this.closeFormModal();
              swal(
                'Update!',
                'Successfully updated daya Band.',
                'success'
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      storeBasicLevel() {
        // if (this.hakAkses != '*' && this.hakAkses != 'W') {
        //   alert('anda tidak mempunyai hak akses !');
        // } else {
          this.$validator.validateAll().then(async result => {
            if (!result) return;

            // var res = this.maritalStatus.substring(1, 2);
            this.$axios.post("hcis/api/bandindividu", {
              begin_date: this.startDate,
              end_date: this.endDate,
              band_individu_type: this.individuType,
              band_individu_area: this.individuArea,
              band_individu_group: this.individuGrup,
              band_individu_level: this.individuLevel,

              personnel_number: this.employee,
              business_code: this.company
              })
              .then(response => {
                this.getbasicLevels();
                this.closeFormModal();
                  swal(
                    "Saved!",
                    "Successfully saved data band.",
                    "success"
                  );
              })
              .catch(e => {
                console.log(e);
              });
          });
        //}
      },
      deleteBasicLevel(key, objectIdentifier) {
        //if(this.hakAkses == '*' && this.hakAkses != 'W'){
        //  alert('anda tidak mempunyai hak akses !');
        //}else{
          swal({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            type: 'warning',
            showCancelButton: true,
            buttons: true,
            dangerMode: true,
          }).then((result) => {
            if (result) {
              this.$axios.delete("hcis/api/bandindividu?object_identifier=" + objectIdentifier)
              .then(response => {
                swal(
                  'Deleted!',
                  response.data.message,
                  'success'
                )
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeBasicLevel(key);
              })
            }

          });
        //}
      },
      removeBasicLevel(key) {
        this.basicLevels.splice(key, 1);
      },
      formatDate(date) {
          return moment(date).format('DD/MM/YYYY')
        },
      
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },

      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitBasicLevel(objectIdentifier) {
        this.openFormModalDelimit();
        let basicLevel = await this.basicLevels.find(
          basicLevel => basicLevel.object_identifier == objectIdentifier
        );
        this.objectIdentifier = basicLevel.object_identifier;
        this.startDate = basicLevel.begin_date;
        this.endDate = basicLevel.end_date;
        // this.endDate = moment(new Date()).format("YYYY-MM-DD");
      },
      delimitBasicLevel() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/bandindividu", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getbasicLevels();
              this.closeFormModalDelimit();
              swal("Delimited!", response.data.message, "success");
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      onlyNumber($event) {
          let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
          if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
            $event.preventDefault();
          }
        },
    },
    middleware: ['auth']
  }

</script>

<style>
    .has-background-danger {
      background-color: #6D6D6D !important;
    }

    .button.is-danger {
      background-color: #CE1000;
      border-color: transparent;
      color: #fff;
    }

    .autosuggest__results-container {
      position: relative;
      width: 100%;
    }

    .autosuggest__results {
      font-weight: 300;
      margin: 0;
      position: absolute;
      z-index: 10000001;
      width: 100%;
      border: 1px solid #e0e0e0;
      border-bottom-left-radius: 4px;
      border-bottom-right-radius: 4px;
      background: white;
      padding: 0px;
      overflow: scroll;
      max-height: 200px;
    }

    .autosuggest__results ul {
      list-style: none;
      padding-left: 0;
      margin: 0;
    }

    .autosuggest__results .autosuggest__results_item {
      cursor: pointer;
      padding: 15px;
    }

    #autosuggest ul:nth-child(1)>.autosuggest__results_title {
      border-top: none;
    }

    .autosuggest__results .autosuggest__results_title {
      color: gray;
      font-size: 11px;
      margin-left: 0;
      padding: 15px 13px 5px;
      border-top: 1px solid lightgray;
    }

    .autosuggest__results .autosuggest__results_item:active,
    .autosuggest__results .autosuggest__results_item:hover,
    .autosuggest__results .autosuggest__results_item:focus,
    .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
      background-color: #ddd;
    }


</style>
