<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="band-individu/band-individu-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-bar-chart" aria-hidden="true"></i> Band Individu
    </h3>
    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>

      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Induk Karyawan</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="nik_query" disabled>
            </div>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Form Edit -->

    <div class="box shadowed" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Band Individu</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="start_input[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="end_input[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe </label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('individu_type') }">
                <select name="individu_type" class="select" v-model="individu_type_input[key]" v-validate="'required'">
                  <option selected>Choose</option>
                  <option v-for="(bndTypee, key) in bndTypes" :key="key" :value="bndTypee.object_code">{{
                    bndTypee.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('individu_type')" class="help is-danger">{{errors.first('individu_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Area </label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('individu_area') }">
                <select name="individu_area" class="select" v-model="individu_area_input[key]" v-validate="'required'">
                  <option selected>Choose</option>
                  <option v-for="(bndAreaa, key) in bndAreas" :key="key" :value="bndAreaa.id">{{
                    bndAreaa.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('individu_area')" class="help is-danger">{{errors.first('individu_area')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Grup</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('individu_group') }">
                <select name="individu_group" class="select" v-model="individu_grup_input[key]" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndGroup, key) in bndGroups" :key="key" :value="bndGroup.id">{{
                    bndGroup.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('individu_group')" class="help is-danger">{{errors.first('individu_group')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Level</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('individu_level') }">
                <select name="individu_level" class="select" v-model="individu_level_input[key]" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndLevel, key) in bndLevels" :key="key" :value="bndLevel.id">{{
                    bndLevel.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('individu_level')" class="help is-danger">{{errors.first('individu_level')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
    </div>
    <div class="box">
      <h3 class="title is-4">Formulir Band Individu</h3>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku </label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe </label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.individu_type') }">
                <select name="individu_type" class="select" v-model="individuType" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndTypee, key) in bndTypes" :key="key" :value="bndTypee.id">{{
                    bndTypee.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.individu_type')" class="help is-danger">{{errors.first('form.individu_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Area</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.individu_area') }">
                <select name="individu_area" class="select" v-model="individuArea" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndAreaa, key) in bndAreas" :key="key" :value="bndAreaa.id">{{
                    bndAreaa.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.individu_area')" class="help is-danger">{{errors.first('form.individu_area')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Grup</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.individu_group') }">
                <select name="individu_group" class="select" v-model="individuGrup" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndGroupp, key) in bndGroups" :key="key" :value="bndGroupp.id">{{
                    bndGroupp.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.individu_group')" class="help is-danger">{{errors.first('form.individu_group')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Level</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.individu_level') }">
                <select name="individu_level" class="select" v-model="individuLevel" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndLevell, key) in bndLevels" :key="key" :value="bndLevell.id">{{
                    bndLevell.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.individu_level')" class="help is-danger">{{errors.first('form.individu_level')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue'
  Vue.use(VueAutosuggest);

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        startDate: '',
        endDate: '',
        individuArea: '',
        individuType: '',
        individuGrup: '',
        individuLevel:'',
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,
        name: '',
        nik: null,
        cUnit: '',
        cPosition: '',
        components: [],
        buscds: [],
        buscd: '',
        nik_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        start_input: [],
        end_input: [],
        individu_type_input: [],
        individu_area_input: [],
        individu_grup_input: [],
        individu_level_input: [],
        bndLevels:[],
        bndGroups:[],
        bndAreas:[],
        bndTypes:[],
        // bnd_type_input: [],
        // bnd_area_input: [],
        // bnd_group_input: [],
        // bnd_level_input: [],
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Band Individu'
          },
        ]
      }
    },
    created() {
      this.getBndType();
      this.getBndArea();
      this.getBndGroup();
      this.getBndLevel();
      this.getBUSCD();
      this.getHakAkses();
      if (this.nik_query != null) {
        this.getData();
      }
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/BNDIV')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'W') {
              return this.$router.push('/employee-data/band-individu/band-individu-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        this.buscd = this.buscd_query;
        this.nik = this.nik_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.nik)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('/users/' + this.buscd + '/bandindividu/' + this.nik)
          .then(response => {
            this.components = [];
            response.data.data.forEach((user, key) => {
              this.components.push({
                begin_date: user.begin_date,
                end_date: user.end_date,
                business_code: this.buscd,
                personal_number: user.personal_number,
                individu_type: user.individu_type[0].object_id,
                individu_area: user.individu_area[0].object_id,
                individu_group: user.individu_group[0].object_id,
                individu_level: user.individu_level[0].object_id,

              });
              this.key = key;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
              this.individu_type_input[this.key] = user.individu_type[0].object_id;
              this.individu_area_input[this.key] = user.individu_area[0].object_id;
              this.individu_grup_input[this.key] = user.individu_group[0].object_id;
              this.individu_level_input[this.key] = user.individu_level[0].object_id;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.nik = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.nik = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('/users/' + this.buscd + '/bandindividu/' + this.nik)
              .then(response => {
                this.components = [];
                response.data.data.forEach((user, key) => {
                  this.components.push({
                    begin_date: user.begin_date,
                    end_date: user.end_date,
                    business_code: this.buscd,
                    personal_number: user.personal_number,
                    individu_type: user.individu_type[0].object_id,
                    individu_area: user.individu_area[0].object_id,
                    individu_group: user.individu_group[0].object_id,
                    individu_level: user.individu_level[0].object_id,
                  });
                  this.key = key;
                  this.start_input[this.key] = user.begin_date;
                  this.end_input[this.key] = user.end_date;
                  this.individu_type_input[this.key] = user.individu_type[0].object_id;
                  this.individu_area_input[this.key] = user.individu_area[0].object_id;
                  this.individu_grup_input[this.key] = user.individu_group[0].object_id;
                  this.individu_level_input[this.key] = user.individu_level[0].object_id;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.nik = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      tambahComponent() {
        this.$validator.validateAll('form').then(async result => {
          if (!result) return;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.nik,
              individu_type: this.individuType,
              individu_area: this.individuArea,
              individu_group: this.individuGrup,
              individu_level: this.individuLevel
            });
            this.components.forEach((user, key) => {
              this.key = key;
              this.business_code= this.buscd,
              this.personal_number= this.nik,
              this.individu_type_input[this.key] = user.individu_type;
              this.individu_area_input[this.key] = user.individu_area;
              this.individu_grup_input[this.key] = user.individu_group;
              this.individu_level_input[this.key] = user.individu_level;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
            })
          }
          this.clearForm();
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.nik_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  begin_date: this.start_input[index1],
                  end_date: this.end_input[index1],
                  individu_type: this.individu_type_input[index1],
                  individu_area: this.individu_area_input[index1],
                  individu_group: this.individu_grup_input[index1],
                  individu_level: this.individu_level_input[index1]
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                text: 'Anda tidak dapat membatalkan',
                type: 'peringatan',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/bandindividu/' + this.nik, this.components)
                    .then(response => {
                      this.clearNik()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data alamat.',
                        'sukses'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              Object.assign(this.components[index1], {
                begin_date: this.start_input[index1],
                  end_date: this.end_input[index1],
                  individu_type: this.individu_type_input[index1],
                  individu_area: this.individu_area_input[index1],
                  individu_group: this.individu_grup_input[index1],
                  individu_level: this.individu_level_input[index1]
              });
            });
            swal({
              title: 'Apakah anda yakin ingin menyimpan data ini?',
              text: 'Anda tidak dapat membatalkan',
              type: 'peringatan',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/bandindividu/' + this.nik, this.components)
                  .then(response => {
                    swal(
                      'Data tersimpan!',
                      'Sukses menyimpan data alamat.',
                      'sukses'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        this.components.forEach((user, key) => {
          this.key = key;
          this.individu_type_input[this.key] = user.individu_type;
          this.individu_area_input[this.key] = user.individu_area;
          this.individu_grup_input[this.key] = user.individu_group;
          this.individu_level_input[this.key] = user.individu_level;
          this.start_input[this.key] = user.begin_date;
          this.end_input[this.key] = user.end_date;
        })
      },
      clearNik() {
        this.components = [];
        if (this.nik != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.nik = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.individuType = '';
        this.individuGrup = '';
        this.individuArea = '';
        this.individuLevel = '';
        this.$nextTick(() => this.$validator.reset());
      },
      clearForm() {
        this.startDate = '';
        this.endDate = '';
        this.individuType = '';
        this.individuGrup = '';
        this.individuArea = '';
        this.individuLevel = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getBndType() {
        // this.$axios.get('/users/otype/PSTYP/object ')
         this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=PSTYP')
          .then(response => {
            this.bndTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBndArea() {
        // this.$axios.get('/users/otype/PSARE/object ')
         this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=PSARE')
          .then(response => {
            this.bndAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBndGroup() {
        // this.$axios.get('/users/otype/PSGRP/object ')
          this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=PSGRP')
          .then(response => {
            this.bndGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBndLevel() {
        // this.$axios.get('/users/otype/PSLVL/object ')
         this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=PSLVL')
          .then(response => {
            this.bndLevels = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/BNDIV')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      }
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
