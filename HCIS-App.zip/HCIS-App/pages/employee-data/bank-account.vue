<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/employee-data/bank-account-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-credit-card-alt" aria-hidden="true"></i> Rekening Bank
    </h3>
    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>

      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Induk Karyawan</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="" v-model="nik_query" disabled>
            </div>
          </div>
        </div>

        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Posisi Saat Ini</label>
              <div class="control">
                <input class="input" type="text" placeholder="" v-model="cPosition" disabled>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Unit Saat Ini</label>
              <div class="control">
                <input class="input" type="text" placeholder="" v-model="cUnit" disabled>
              </div>
            </div>
          </div>
      </div>
    </div>

    <div class="box shadowed" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Rekening Bank</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="start_date[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="end_date[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Rekening</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('account_type') }">
                <select name="account_type" class="select" v-model="bank_type[key]" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(accountType, key) in accountTypes" :key="key" :value="accountType.object_id">{{
                    accountType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('account_type')" class="help is-danger">{{errors.first('account_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama di Rekening</label>
            <div class="control">
              <input name="account_name" class="input " placeholder="e.g. Didik Setiawan" type="text"
                data-vv-as="account name" v-model="full_name[key]"
                v-bind:class="{ 'is-danger': errors.has('account_name')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('account_name')" class="help is-danger"> {{ errors.first('account_name')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Grup Bank</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('group_bank') }">
                <select name="group_bank" class="select" v-model="bank_group[key]" v-validate="'required'"
                  @change="getBankByGroupTampung(key,bank_group[key])">
                  <option disabled selected>Pilih</option>
                  <option v-for="(bankGroup, key) in bankGroups" :key="key" :value="bankGroup.object_id">{{
                    bankGroup.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('group_bank')" class="help is-danger">{{errors.first('group_bank')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Bank</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('bank_name') }">
                <select name="bank_name" class="select" v-model="bank_code[key]" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(bankCode, key) in bank_codes[key]" :key="key" :value="bankCode.bank_code">{{
                    bankCode.branch
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bank_name')" class="help is-danger">{{errors.first('bank_name')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Rekening</label>
            <div class="control">
              <input name="account_number" class="input " placeholder="e.g. 00215" type="text"
                v-model="account_number[key]" v-bind:class="{ 'is-danger': errors.has('account_number')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('account_number')" class="help is-danger"> {{ errors.first('account_number')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Metode Pembayaran</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('payment') }">
                <select name="payment" class="select" v-model="payment_input[key]" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option value="0">Tunai</option>
                  <option value="1">Transfer</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('payment')" class="help is-danger">{{ errors.first('payment') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Jumlah</label>
            <div class="control">
              <input name="total" class="input " placeholder="e.g. 1.000.0000" type="number" v-model="nilai_input[key]"
                v-bind:class="{ 'is-danger': errors.has('total')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('total')" class="help is-danger"> {{ errors.first('total')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Persentase</label>
            <div class="control">
              <input name="percentage" class="input " placeholder="e.g. 50" type="percentage"
                v-model="percent_input[key]" v-bind:class="{ 'is-danger': errors.has('percentage')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('percentage')" class="help is-danger"> {{ errors.first('percentage')
              }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Rekening Bank</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Rekening</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.account_type') }">
                <select name="account_type" class="select" v-model="bankType" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(accountType, key) in accountTypes" :key="key" :value="accountType.object_id">{{
                    accountType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.account_type')" class="help is-danger">{{errors.first('form.account_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama di Rekening</label>
            <div class="control">
              <input name="account_name" class="input " placeholder="e.g. Didik Setiawan" type="text"
                data-vv-as="account name" v-model="fullname"
                v-bind:class="{ 'is-danger': errors.has('form.account_name')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.account_name')" class="help is-danger"> {{ errors.first('form.account_name')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Grup Bank</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.group_bank') }">
                <select name="group_bank" class="select" v-model="bankGroup" v-validate="'required'"
                  @change="getBankByGroup()" data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(bankGroup, key) in bankGroups" :key="key" :value="bankGroup.object_id">{{
                    bankGroup.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.group_bank')" class="help is-danger">{{errors.first('form.group_bank')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Bank</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.bank_name') }">
                <select name="bank_name" class="select" v-model="bankCode" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(bankCode, key) in bankCodes" :key="key" :value="bankCode.bank_code">{{
                    bankCode.branch
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.bank_name')" class="help is-danger">{{errors.first('form.bank_name')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">

      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Rekening</label>
            <div class="control">
              <input name="account_number" class="input " placeholder="e.g. 00215" type="text" v-model="accountNumber"
                v-bind:class="{ 'is-danger': errors.has('form.account_number')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.account_number')" class="help is-danger"> {{
              errors.first('form.account_number')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Metode Pembayaran</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.payment') }">
                <select name="payment" class="select" v-model="payment" v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option value="0">Tunai</option>
                  <option value="1">Transfer</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('form.payment')" class="help is-danger">{{ errors.first('form.payment') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Jumlah</label>
            <div class="control">
              <input name="total" class="input " placeholder="e.g. 1.000.0000" type="number" v-model="nilai"
                v-bind:class="{ 'is-danger': errors.has('form.total')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.total')" class="help is-danger"> {{ errors.first('form.total')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Persentase</label>
            <div class="control">
              <input name="percentage" class="input " placeholder="e.g. 50" type="percentage" v-model="percent  "
                v-bind:class="{ 'is-danger': errors.has('form.percentage')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.percentage')" class="help is-danger"> {{ errors.first('form.percentage')
              }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>
    <div class="columns">
      <div class="column">
         <a class="button is-pulled-right is-success is-rounded" @click="storeComponent()">Simpan</a>
      </div>
    </div>
   

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue'
  import {
    async
  } from 'q';
  Vue.use(VueAutosuggest);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,
        hakAkses: '',
        name: '',
        nik: null,
        buscd: null,
        cUnit: '',
        cPosition: '',
        nik_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        startDate: null,
        endDate: null,
        bankType: null,
        fullname: '',
        bankGroup: null,
        bankCode: null,
        accountNumber: '',
        payment: '',
        nilai: '',
        percent: '',
        accountTypes: [],
        bankCodes: [],
        bank_codes: [],
        bankGroups: [],
        components: [],
        components_input: [],
        buscds: [],
        start_date: [],
        end_date: [],
        bank_type: [],
        full_name: [],
        bank_group: [],
        bank_code: [],
        account_number: [],
        payment_input: [],
        nilai_input: [],
        percent_input: [],
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Rekening Bank'
          },
        ],

      }
    },
    created() {
      this.getBankType();
      this.getBankGroup();
      this.getBUSCD();
      this.getHakAkses();
      if (this.nik_query != null) {
        this.getData();

      }
    },
    methods: {
      getBUSCD() {
        this.$axios.get('/objects/companytoken/BNKEP')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },

      getBankType() {
        this.$axios.get('/objects/banktype')
          .then(response => {
            this.accountTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBankGroup() {
        this.$axios.get('/objects/bankgroup')
          .then(response => {
            this.bankGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBankByGroup() {
        this.$axios.get('/bank/getbyGroup/' + this.bankGroup)
          .then(response => {
            this.bankCodes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBankByGroupTampung(key, bankGroup) {
        this.$axios.get('/bank/getbyGroup/' + bankGroup)
          .then(response => {
            this.bank_codes[key] = response.data.data;
            this.$forceUpdate();
          })
          .catch(e => {
            console.log(e)
          });
      },
      getHakAkses() {
        this.$axios.get('/users/hakakses/BNKEP')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'W') {
              return this.$router.push('/employee-data/bank-account-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        this.buscd = this.buscd_query;
        //console.log(this.buscd);
        this.nik = this.nik_query;
        //this.getAllFamNum();   
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.nik)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('/users/' + this.buscd + '/bank/' + this.nik)
          .then(response => {
            this.components = [];
            response.data.data.forEach((user, key) => {
              this.components.push({
                begin_date: user.begin_date,
                end_date: user.end_date,
                business_code: user.business_code,
                personal_number: user.personal_number,
                bank_type: user.bank_type[0].object_id,
                full_name: user.full_name,
                bank_group: user.bank_code[0].bank_group,
                bank_code: user.bank_code[0].bank_code,
                account_number: user.account_number,
                payment: user.payment,
                nilai: user.nilai,
                percent: user.percent
              });
              this.key = key;
              this.$axios.get('/bank/getbyGroup/' + user.bank_code[0].bank_group)
                .then(response => {
                  this.bank_codes[key] = response.data.data;
                  this.$forceUpdate();
                })
              this.start_date[this.key] = user.begin_date;
              this.end_date[this.key] = user.end_date;
              this.bank_type[this.key] = user.bank_type[0].object_id;
              this.full_name[this.key] = user.full_name;
              this.bank_group[this.key] = user.bank_code[0].bank_group;
              this.bank_code[this.key] = user.bank_code[0].bank_code;
              this.account_number[this.key] = user.account_number;
              this.payment_input[this.key] = user.payment;
              this.nilai_input[this.key] = user.nilai;
              this.percent_input[this.key] = user.percent;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.nik = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.nik = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {

            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.nik)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('/users/' + this.buscd + '/bank/' + this.nik)
              .then(response => {
                this.components = [];
                response.data.data.forEach((user, key) => {
                  this.components.push({
                    begin_date: user.begin_date,
                    end_date: user.end_date,
                    business_code: user.business_code,
                    personal_number: user.personal_number,
                    bank_type: user.bank_type[0].object_id,
                    full_name: user.full_name,
                    bank_group: user.bank_code[0].bank_group,
                    bank_code: user.bank_code[0].bank_code,
                    account_number: user.account_number,
                    payment: user.payment,
                    nilai: user.nilai,
                    percent: user.percent
                  });

                  this.key = key;

                  this.$axios.get('/bank/getbyGroup/' + user.bank_code[0].bank_group)
                    .then(response => {
                      //this.bank_codes[key] = [{bank_code:'',branch:''}];                      
                      this.bank_codes[key] = response.data.data;
                      this.$forceUpdate();
                    })
                  this.start_date[this.key] = user.begin_date;
                  this.end_date[this.key] = user.end_date;
                  this.bank_type[this.key] = user.bank_type[0].object_id;
                  this.full_name[this.key] = user.full_name;
                  this.bank_group[this.key] = user.bank_code[0].bank_group;
                  this.bank_code[this.key] = user.bank_code[0].bank_code;
                  this.account_number[this.key] = user.account_number;
                  this.payment_input[this.key] = user.payment;
                  this.nilai_input[this.key] = user.nilai;
                  this.percent_input[this.key] = user.percent;


                });
              })
              .catch(e => {
                console.log(e);
              });
            //console.log(this.cities_tampung)

          }
        }
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.nik = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
        /* Full control over filtering. Maybe fetch from API?! Up to you!!! */

      },
      tambahComponent() {

        this.$validator.validateAll('form').then(async result => {
          if (!result) return;

          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.nik,
              bank_type: this.bankType,
              full_name: this.fullname,
              bank_group: this.bankGroup,
              bank_code: this.bankCode,
              account_number: this.accountNumber,
              payment: this.payment,
              nilai: this.nilai,
              percent: this.percent
            });
            this.components.forEach((user, key) => {
              this.key = key;
              this.$axios.get('/bank/getbyGroup/' + user.bank_group)
                .then(response => {
                  this.bank_codes[key] = response.data.data;
                  //console.log(this.bank_codes[this.key])
                  this.$forceUpdate();
                })

              this.start_date[this.key] = user.begin_date;
              this.end_date[this.key] = user.end_date;
              this.bank_type[this.key] = user.bank_type;
              this.full_name[this.key] = user.full_name;
              this.bank_group[this.key] = user.bank_group;
              this.bank_code[this.key] = user.bank_code;
              this.account_number[this.key] = user.account_number;
              this.payment_input[this.key] = user.payment;
              this.nilai_input[this.key] = user.nilai;
              this.percent_input[this.key] = user.percent;
            })
          }
        });
      },
      storeComponent() {

        if (this.buscd != '') {

          if (this.nik_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components_input = [];
              this.components.forEach((childrens, index1) => {
                var percent = parseInt(this.percent_input[index1]);
                this.components_input.push({
                  begin_date: this.start_date[index1],
                  end_date: this.end_date[index1],
                  business_code: this.buscd,
                  personal_number: this.nik,
                  bank_type: this.bank_type[index1],
                  full_name: this.full_name[index1],
                  bank_code: this.bank_code[index1],
                  account_number: this.account_number[index1],
                  payment: this.payment_input[index1],
                  nilai: this.nilai_input[index1],
                  percent: percent
                });
                // Object.assign(this.components[index1], {                  

                // });
              });
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/bank/' + this.nik, this.components_input)
                    .then(response => {

                      this.clearNik()
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components_input = [];
            this.components.forEach((childrens, index1) => {
              var percent = parseInt(this.percent_input[index1]);
              this.components_input.push({
                begin_date: this.start_date[index1],
                end_date: this.end_date[index1],
                business_code: this.buscd,
                personal_number: this.nik,
                bank_type: this.bank_type[index1],
                full_name: this.full_name[index1],
                bank_code: this.bank_code[index1],
                account_number: this.account_number[index1],
                payment: this.payment_input[index1],
                nilai: this.nilai_input[index1],
                percent: percent
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/bank/' + this.nik, this.components_input)
                  .then(response => {
                    //this.clearNik()                                              
                    swal(
                      'Saved!',
                      'Successfully saved.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }


        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearNik()
        }
      },
      deleteComponents(key) {

        this.components.splice(key, 1);
        this.components.forEach((user, key) => {
          this.key = key;
          this.$axios.get('/bank/getbyGroup/' + user.bank_group)
            .then(response => {
              this.bank_codes[key] = response.data.data;
              //console.log(this.bank_codes[this.key])
              this.$forceUpdate();
            })
          this.start_date[this.key] = user.begin_date;
          this.end_date[this.key] = user.end_date;
          this.bank_type[this.key] = user.bank_type;
          this.full_name[this.key] = user.full_name;
          this.bank_group[this.key] = user.bank_group;
          this.bank_code[this.key] = user.bank_code;
          this.account_number[this.key] = user.account_number;
          this.payment_input[this.key] = user.payment;
          this.nilai_input[this.key] = user.nilai;
          this.percent_input[this.key] = user.percent;
        })
      },
      clearNik() {

        this.components = [];
        if (this.nik != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.nik = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = null,
          this.endDate = null,
          //this.buscd =null,        
          this.bankType = null,
          this.fullname = '',
          this.bankGroup = null,
          this.bankCode = null,
          this.accountNumber = '',
          this.payment = '',
          this.nilai = '',
          this.percent = ''

        this.$nextTick(() => this.$validator.reset());
      },
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
