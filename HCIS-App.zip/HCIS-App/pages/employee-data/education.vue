<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />

    <hr>
    <nuxt-link to="/employee-data/education-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-graduation-cap" aria-hidden="true"></i> Pendidikan
    </h3>

    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>

      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="nik_query" disabled>
            </div>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- show data -->
    <div class="box shadowed" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Pendidikan</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="start_input[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('component.begin_date')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.begin_date')" class="help is-danger">
              {{ errors.first('component.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="end_input[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('component.end_date')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.end_date')" class="help is-danger">{{ errors.first('component.end_date') }}
            </p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Mulai Pendidikan</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date_edu" type="date"
                placeholder="e.g 10-11-2018" v-model="startEdu_input[key]" data-vv-as="start date education"
                v-bind:class="{ 'is-danger': errors.has('component.begin_date_edu')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.begin_date_edu')" class="help is-danger">
              {{ errors.first('component.begin_date_edu') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Selesai Pendidikan</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date_edu" type="date"
                placeholder="e.g 10-11-2018" v-model="endEdu_input[key]" data-vv-as="End date education"
                v-bind:class="{ 'is-danger': errors.has('component.end_date_edu')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.end_date_edu')" class="help is-danger">
              {{ errors.first('component.end_date_edu') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Level Pendidikan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('education_level') }">
                <select name="education_level" class="select" v-model="educationLevels_input[key]"
                  data-vv-as="education level" v-validate="'required'" data-vv-scope="component">
                  <option disabled selected>Choose</option>
                  <option v-for="(educationLevel, key) in educationLevels" :key="key" :value="educationLevel.id">{{
                    educationLevel.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('component.education_level')" class="help is-danger">{{errors.first('component.education_level')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Fakultas</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.faculty') }">
                <select name="faculty" class="select" v-model="faculties_input[key]" data-vv-as="faculty"
                  v-validate="'required'" data-vv-scope="component">
                  <option disabled selected>Choose</option>
                  <option v-for="(faculty, key) in faculties" :key="key" :value="faculty.id">{{
                    faculty.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('component.faculty')" class="help is-danger">{{errors.first('component.faculty')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Jurusan</label>
            <div class="control">
              <div class="select  is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.major') }">
                <select name="major" class="select" v-model="majors_input[key]" data-vv-as="major"
                  v-validate="'required'" data-vv-scope="component">
                  <option disabled selected>Choose</option>
                  <option v-for="(major, key) in majors" :key="key" :value="major.id">{{
                    major.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('component.major')" class="help is-danger">{{errors.first('component.major')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kelompok Keahlian</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.sub_major') }">
                <select name="sub_major" class="select" v-model="subMajors_input[key]" data-vv-as="sub major"
                  v-validate="'required'" data-vv-scope="component">
                  <option disabled selected>Choose</option>
                  <option v-for="(subMajor, key) in subMajors" :key="key" :value="subMajor.id">{{
                    subMajor.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('component.sub_major')" class="help is-danger">{{errors.first('component.sub_major')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Institusi</label>
            <div class="control">
              <div class="select  is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.institution') }">
                <select name="institution" class="select" v-model="institutions_input[key]" v-validate="'required'"
                  data-vv-scope="component">
                  <option disabled selected>Choose</option>
                  <option v-for="(institution, key) in institutions" :key="key" :value="institution.id">{{
                    institution.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('component.institution')" class="help is-danger">{{errors.first('component.institution')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Pendanaan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.pendanaan') }">
                <select name="pendanaan" class="select" v-model="funding_input[key]" data-vv-as="pendanaan"
                  v-validate="'required'" data-vv-scope="component">
                  <option value="1">Personal</option>
                  <option value="2">Agency</option>
                </select>
              </div>
              <p v-show="errors.has('component.pendanaan')" class="help is-danger">{{errors.first('component.pendanaan')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="certificate" v-model="certificate_input[key]">
            Sertifikat
          </label>
        </div>
        <!-- <div class="column is-4">
          <div class="field">
            <label class="label">Pendanaan</label>
            <div class="control">
              <label class="radio">
                <input name="funding" type="radio" v-model="funding_input[key]" value="1">
                Personal
              </label>
              <label class="radio">
                <input name="funding" type="radio" v-model="funding_input[key]" value="2">
                Agency
              </label>
            </div>
            
          </div>
        </div> -->

        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="recognition" v-model="recognition_input[key]">
            Pengakuan
          </label>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Pengakuan</label>
            <div class="control">
              <input id="recognition_date" data-display-mode="dialog" class="input" name="recognition_date" type="date"
                placeholder="e.g 10-11-2018" v-model="recognitionDate_input[key]" data-vv-as="recognition date"
                v-bind:class="{ 'is-danger': errors.has('component.recognition_date')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.recognition_date')" class="help is-danger">
              {{ errors.first('component.recognition_date') }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
    </div>

    <div class="box">
       <h4 class="subtitle is-4">Formulir Pendidikan</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Mulai Pendidikan</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date_edu" type="date"
                placeholder="e.g 10-11-2018" v-model="startEdu" data-vv-as="start date education"
                v-bind:class="{ 'is-danger': errors.has('form.begin_date_edu')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date_edu')" class="help is-danger">
              {{ errors.first('form.begin_date_edu') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Selesai Pendidikan</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date_edu" type="date"
                placeholder="e.g 10-11-2018" v-model="endEdu" data-vv-as="End date education"
                v-bind:class="{ 'is-danger': errors.has('form.end_date_edu')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date_edu')" class="help is-danger">{{ errors.first('form.end_date_edu') }}
            </p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Level Pendidikan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.education_level') }">
                <select name="education_level" class="select" v-model="educationLevel" data-vv-as="education level"
                  v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(educationLevel, key) in educationLevels" :key="key" :value="educationLevel.id">{{
                    educationLevel.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.education_level')" class="help is-danger">{{errors.first('form.education_level')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Fakultas</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.faculty') }">
                <select name="faculty" class="select" v-model="faculty" data-vv-as="faculty" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(faculty, key) in faculties" :key="key" :value="faculty.id">{{
                    faculty.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.faculty')" class="help is-danger">{{errors.first('form.faculty')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Jurusan</label>
            <div class="control">
              <div class="select  is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.major') }">
                <select name="major" class="select" v-model="major" data-vv-as="major" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(major, key) in majors" :key="key" :value="major.id">{{
                    major.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.major')" class="help is-danger">{{errors.first('form.major')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Keahlian</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.sub_major') }">
                <select name="sub_major" class="select" v-model="subMajor" data-vv-as="sub major"
                  v-validate="'required'" data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(subMajor, key) in subMajors" :key="key" :value="subMajor.id">{{
                    subMajor.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.sub_major')" class="help is-danger">{{errors.first('form.sub_major')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Institusi</label>
            <div class="control">
              <div class="select  is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.institution') }">
                <select name="institution" class="select" v-model="institution" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(institution, key) in institutions" :key="key" :value="institution.id">{{
                    institution.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.institution')" class="help is-danger">{{errors.first('form.institution')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Pendanaan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.pendanaan') }">
                <select name="pendanaan" class="select" v-model="funding" data-vv-as="pendanaan" v-validate="'required'"
                  data-vv-scope="form">
                  <option value="1">Personal</option>
                  <option value="2">Agency</option>
                </select>
              </div>
              <p v-show="errors.has('form.pendanaan')" class="help is-danger">{{errors.first('form.pendanaan')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="certificate" v-model="certificate">
            Sertifikat
          </label>
        </div>
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="recognition" v-model="recognition">
            Pengakuan
          </label>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Pengakuan</label>
            <div class="control">
              <input id="recognition_date" data-display-mode="dialog" class="input" name="recognition_date" type="date"
                placeholder="e.g 10-11-2018" v-model="recognitionDate" data-vv-as="recognition date"
                v-bind:class="{ 'is-danger': errors.has('form.recognition_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.recognition_date')" class="help is-danger">
              {{ errors.first('form.recognition_date') }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Reset</a>
    <a class="button is-link is-rounded">Back</a> -->
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue'
  Vue.use(VueAutosuggest);

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        name: '',
        myDate : new Date().toISOString().slice(0,10),
        nik: null,
        cUnit: '',
        cPosition: '',
        components: [],
        buscds: [],
        buscd: '',
        nik_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        educationLevels_input: [],
        faculties_input: [],
        start_input: [],
        end_input: [],
        startEdu_input: [],
        endEdu_input: [],
        majors_input: [],
        subMajors_input: [],
        institutions_input: [],
        certificate_input: [],
        recognition_input: [],
        funding_input: [],
        recognitionDate_input: [],
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,
        startDate: null,
        endDate: null,
        startEdu: null,
        endEdu: null,
        educationLevel: '',
        major: '',
        subMajor: '',
        institution: '',
        certificate: '',
        funding: '',
        recognition: '',
        recognitionDate: '',
        faculty: '',
        educationLevels: [],
        faculties: [],
        majors: [],
        subMajors: [],
        educations: [],
        institutions: [],
        hakAkses: '',
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Pendidikan'
          },
        ]
      }
    },
    created() {
      this.getEducationLevels();
      this.getFaculty();
      this.getMajor();
      this.getSubMajor();
      this.getInstution();
      this.getBUSCD();
      this.getHakAkses();
      if (this.nik_query != null) {
        this.getData();

      }
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/EDUCT')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'W') {
              return this.$router.push('/employee-data/education-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        this.buscd = this.buscd_query;
        // console.log(this.buscd);
        this.nik = this.nik_query;

        // this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.nik)
        this.$axios.get('hcis/api/educations?business_code[]='+this.buscd +'&personnel_number[]='+ this.nik +'&begin_date_lte='+this.myDate+'&end_date_gte='+this.myDate)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        // this.$axios.get('/users/' + this.buscd + '/education/' + this.nik)
          this.$axios.get('hcis/api/educations?business_code[]='+this.buscd +'&personnel_number[]='+ this.nik +'&begin_date_lte='+this.myDate+'&end_date_gte='+this.myDate)
          .then(response => {
            this.components = [];
            response.data.data.forEach((user, key) => {
              this.components.push({
                begin_date: user.begin_date,
                end_date: user.end_date,
                business_code: this.buscd,
                personal_number: user.personnel_number,
                education_level: user.level.id,
                major: user.major[0].object_id,
                sub_major: user.sub_major[0].object_id,
                faculty: user.faculty[0].object_id,
                institution: user.institution[0].object_id,
                certificate: user.certificate,
                funding: user.funding,
                recognition: user.recognition,
                recognition_date: user.recognition_date,
                start_education: user.start_education,
                finish_education: user.finish_education
              });
              this.key = key;
              this.recognition_input[this.key] = null
              this.certificate_input[this.key] = null
              this.educationLevels_input[this.key] = user.level.id;
              this.faculties_input[this.key] = user.faculty[0].object_id;
              this.majors_input[this.key] = user.major[0].object_id;
              this.subMajors_input[this.key] = user.sub_major[0].object_id;
              this.institutions_input[this.key] = user.institution[0].object_id;
              (user.certificate == '1') ? this.certificate_input[this.key] = user.certificate: '';
              (user.recognition == '1') ? this.recognition_input[this.key] = user.recognition: '';
              this.recognitionDate_input[this.key] = user.recognition_date;
              this.funding_input[this.key] = user.funding;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
              this.startEdu_input[this.key] = user.start_education;
              this.endEdu_input[this.key] = user.finish_education;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.nik = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.nik = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('/users/' + this.buscd + '/education/' + option.item)
              .then(response => {
                this.components = [];
                response.data.data.forEach((user, key) => {
                  this.components.push({
                    begin_date: user.begin_date,
                    end_date: user.end_date,
                    business_code: this.buscd,
                    personal_number: user.personal_number,
                    education_level: user.education_level[0].object_id,
                    major: user.major[0].object_id,
                    sub_major: user.sub_major[0].object_id,
                    faculty: user.faculty[0].object_id,
                    institution: user.institution[0].object_id,
                    certificate: user.certificate,
                    funding: user.funding,
                    recognition: user.recognition,
                    recognition_date: user.recognition_date,
                    start_education: user.start_education,
                    finish_education: user.finish_education
                  });
                  this.key = key;
                  this.recognition_input[this.key] = null
                  this.certificate_input[this.key] = null
                  this.educationLevels_input[this.key] = user.education_level[0].object_id;
                  this.faculties_input[this.key] = user.faculty[0].object_id;
                  this.majors_input[this.key] = user.major[0].object_id;
                  this.subMajors_input[this.key] = user.sub_major[0].object_id;
                  this.institutions_input[this.key] = user.institution[0].object_id;
                  (user.certificate == '1') ? this.certificate_input[this.key] = user.certificate: '';
                  (user.recognition == '1') ? this.recognition_input[this.key] = user.recognition: '';
                  // this.certificate_input[this.key]= user.certificate;
                  // this.recognition_input[this.key]= user.recognition;
                  this.recognitionDate_input[this.key] = user.recognition_date;
                  this.funding_input[this.key] = user.funding;
                  this.start_input[this.key] = user.begin_date;
                  this.end_input[this.key] = user.end_date;
                  this.startEdu_input[this.key] = user.start_education;
                  this.endEdu_input[this.key] = user.finish_education;
                });
              })
              .catch(e => {
                console.log(e);
              });


          }
        }
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.nik = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
        /* Full control over filtering. Maybe fetch from API?! Up to you!!! */

      },
      tambahComponent() {

        //console.log(this.components)
        this.$validator.validateAll('form').then(async result => {
          if (!result) return;
          //  var found = this.components.some(function(el) {
          //             return el.education_level === educationLevel;
          // });
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            // if(!found){
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.nik,
              education_level: this.educationLevel,
              major: this.major,
              sub_major: this.subMajor,
              faculty: this.faculty,
              institution: this.institution,
              certificate: this.certificate,
              funding: this.funding,
              recognition: this.recognition,
              recognition_date: this.recognitionDate,
              start_education: this.startEdu,
              finish_education: this.endEdu
            });
            this.components.forEach((user, key) => {
              this.key = key;
              this.recognition_input[this.key] = null
              this.certificate_input[this.key] = null
              this.educationLevels_input[this.key] = user.education_level;
              this.faculties_input[this.key] = user.faculty;
              this.majors_input[this.key] = user.major;
              this.subMajors_input[this.key] = user.sub_major;
              this.institutions_input[this.key] = user.institution;
              (user.certificate == '1') ? this.certificate_input[this.key] = user.certificate: '';
              (user.recognition == '1') ? this.recognition_input[this.key] = user.recognition: '';
              // this.certificate_input[this.key]= user.certificate;
              // this.recognition_input[this.key]= user.recognition;
              this.recognitionDate_input[this.key] = user.recognition_date;
              this.funding_input[this.key] = user.funding;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
              this.startEdu_input[this.key] = user.start_education;
              this.endEdu_input[this.key] = user.finish_education;
            })

            // }else{
            //   alert('data sudah ada');
            // } 
          }
        });
      },
      storeComponent() {

        if (this.buscd != '') {
          if (this.nik_query == null) {
            // const searchNik = this.options[0].data.filter(item => {
            //   return item.toLowerCase().indexOf(this.nik.toLowerCase()) > -1;
            // }).slice(0, this.limit);
            // if(searchNik.length ==  0){
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((childrens, index1) => {
                if (this.certificate_input[index1] == true) {
                  this.certificate_input[index1] = '1';
                } else {
                  this.certificate_input[index1] = '0';
                }

                if (this.recognition_input[index1] == true) {
                  this.recognition_input[index1] = '1';
                } else {
                  this.recognition_input[index1] = '0';
                }
                Object.assign(this.components[index1], {
                  education_level: this.educationLevels_input[index1],
                  faculty: this.faculties_input[index1],
                  major: this.majors_input[index1],
                  sub_major: this.subMajors_input[index1],
                  institution: this.institutions_input[index1],
                  certificate: this.certificate_input[index1],
                  recognition: this.recognition_input[index1],
                  funding: this.funding_input[index1],
                  begin_date: this.start_input[index1],
                  end_date: this.end_input[index1],
                  recognition_date: this.recognitionDate_input[index1],
                  start_education: this.startEdu_input[index1],
                  finish_education: this.endEdu_input[index1]
                });
              });
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/education/' + this.nik, this.components)
                    .then(response => {
                      this.clearNik()
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              if (this.certificate_input[index1] == true) {
                this.certificate_input[index1] = '1';
              } else {
                this.certificate_input[index1] = '0';
              }

              if (this.recognition_input[index1] == true) {
                this.recognition_input[index1] = '1';
              } else {
                this.recognition_input[index1] = '0';
              }
              Object.assign(this.components[index1], {
                education_level: this.educationLevels_input[index1],
                faculty: this.faculties_input[index1],
                major: this.majors_input[index1],
                sub_major: this.subMajors_input[index1],
                institution: this.institutions_input[index1],
                certificate: this.certificate_input[index1],
                recognition: this.recognition_input[index1],
                funding: this.funding_input[index1],
                begin_date: this.start_input[index1],
                end_date: this.end_input[index1],
                recognition_date: this.recognitionDate_input[index1],
                start_education: this.startEdu_input[index1],
                finish_education: this.endEdu_input[index1]
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/education/' + this.nik, this.components)
                  .then(response => {
                    //this.clearNik()                                              
                    swal(
                      'Saved!',
                      'Successfully saved.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }


        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearNik()
        }
      },
      deleteComponents(key) {

        this.components.splice(key, 1);
        this.components.forEach((user, key) => {
          this.key = key;
          this.recognition_input[this.key] = null
          this.certificate_input[this.key] = null
          this.educationLevels_input[this.key] = user.education_level;
          this.faculties_input[this.key] = user.faculty;
          this.majors_input[this.key] = user.major;
          this.subMajors_input[this.key] = user.sub_major;
          this.institutions_input[this.key] = user.institution;
          (user.certificate == '1') ? this.certificate_input[this.key] = user.certificate: '';
          (user.recognition == '1') ? this.recognition_input[this.key] = user.recognition: '';
          // this.certificate_input[this.key]= user.certificate;
          // this.recognition_input[this.key]= user.recognition;
          this.recognitionDate_input[this.key] = user.recognition_date;
          this.funding_input[this.key] = user.funding;
          this.start_input[this.key] = user.begin_date;
          this.end_input[this.key] = user.end_date;
          this.startEdu_input[this.key] = user.start_education;
          this.endEdu_input[this.key] = user.finish_education;
        })
        //console.log(this.components)



      },
      clearNik() {

        this.components = [];
        if (this.nik != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.nik = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.educationLevel = '';
        this.major = '';
        this.subMajor = '';
        this.institution = '';
        this.certificate = '';
        this.funding = '';
        this.recognition = '';
        this.recognitionDate = '';
        this.faculty = '';
        this.startEdu = null;
        this.endEdu = null;

        this.$nextTick(() => this.$validator.reset());
        //console.log(this.$refs.myRefName.searchInput)
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/EDUCT')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getNik() {
        this.$axios.get('/users/personal')
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
      },
      getEducationLevels() {
        // this.$axios.get('/objects/educationallevel')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=EDULV')
          .then(response => {
            this.educationLevels = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getFaculty() {
        // this.$axios.get('/objects/educationfaculty')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=EDUFC')
          .then(response => {
            this.faculties = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getMajor() {
        // this.$axios.get('/objects/educationmajor')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=EDUBR')
          .then(response => {
            this.majors = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSubMajor() {
        // this.$axios.get('/objects/educationsubmajor')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=EDUMR')
          .then(response => {
            this.subMajors = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getInstution() {
        // this.$axios.get('/objects/educationinstitution')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=EDUIN')
          .then(response => {
            this.institutions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      }

    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
