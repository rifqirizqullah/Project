<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="employee/employee-search" class="button is-success is-rounded is-pulled-right"><span> <i class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3 ">
      <i class="fa fa-users" aria-hidden="true"></i> Data Karyawan
    </h3>
    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                <select name="nama_perusahaan" class="select" v-model="company" v-validate="'required'" @change="resetFormSearch()">
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in companies" :key="key" :value="company.business_code">{{
                    company.company_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control">
              <input name="personal_number" class="input " placeholder="" type="text" 
                v-model="personalNumber" v-bind:class="{ 'is-danger': errors.has('personal_number')}" v-validate="'required'" @keyup="getEmployees1(personalNumber)">
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number') }}</p>
          </div>
        </div>

        <div class="column is-8">
          <div class="field">
            <label class="label">Nama Lengkap</label>
            <div class="control">
              <input name="full_name" class="input " placeholder="" type="text" v-model="fullName"
                v-bind:class="{ 'is-danger': errors.has('full_name')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('full_name')" class="help is-danger"> {{ errors.first('full_name') }}</p>
          </div>
        </div>
      </div>
    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Data Karyawan</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date" placeholder=""
                v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('begin_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date" placeholder=""
                v-model="endDate" data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Panggilan</label>
            <div class="control">
              <input name="nickname" class="input " placeholder="" type="text" v-model="nickName" v-bind:class="{ 'is-danger': errors.has('nickname')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tempat Lahir</label>
            <div class="control">
              <input name="birth_place" class="input " placeholder="" type="text" v-model="birthPlace"
                v-bind:class="{ 'is-danger': errors.has('birth_place')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('birth_place')" class="help is-danger"> {{ errors.first('birth_place') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Lahir</label>
            <div class="control">
              <input name="born_date" class="input " placeholder="
              " type="date" v-model="birthDate"
                v-bind:class="{ 'is-danger': errors.has('born_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('born_date')" class="help is-danger"> {{ errors.first('born_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Jenis Kelamin</label>
            <div class="control">
              <label class="radio">
                <input name="gender" type="radio" v-model="gender" value="L" v-validate="'required|included:L,P'">
                Laki - Laki
              </label>
              <label class="radio">
                <input name="gender" type="radio" v-model="gender" value="P">
                Perempuan
              </label>
            </div>
            <p v-show="errors.has('gender')" class="help is-danger">{{ errors.first('gender') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Agama</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('religion') }">
                <select name="religion" class="select" v-model="religion" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(religion, key) in religions" :key="key" :value="religion.object_type">{{
                    religion.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('religion')" class="help is-danger">{{ errors.first('religion') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Bahasa</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('language') }">
                <select name="language" class="select" v-model="language" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(language, key) in languages" :key="key" :value="language.object_type">{{
                    language.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('language')" class="help is-danger">{{ errors.first('language') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kewarganegaraan</label>
            <div class="control">
              <div class="select is-fullwidth">
                <select v-model="national" name="national" v-validate="'required'">
                  <option disabled="disabled" selected="selected">Choose</option>
                  <option value="WNI">WNI</option>
                  <option value="WNA">WNA</option>
                </select>
              </div>
              <p v-show="errors.has('national')" class="help is-danger">{{ errors.first('national') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Suku</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('tribe') }">
                <select name="tribe" class="select" v-model="tribe" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(tribe, key) in tribes" :key="key" :value="tribe.object_id">{{
                    tribe.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('tribe')" class="help is-danger">{{ errors.first('tribe') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Golongan Darah</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('bloodType') }">
                <select name="bloodType" class="select" v-model="bloodType" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bloodType, key) in bloodTypes" :key="key" :value="bloodType.object_type">{{
                    bloodType.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bloodType')" class="help is-danger">{{ errors.first('bloodType') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Resus</label>
            <div class="control">
              <div class="select is-fullwidth">
                <select v-model="rhesus" name="rhesus" v-validate="'required'">
                  <option disabled="disabled" selected="selected">Choose</option>
                  <option value="">Kosong</option>
                  <option value="+">+</option>
                  <option value="-">-</option>
                </select>
              </div>
              <p v-show="errors.has('rhesus')" class="help is-danger">{{ errors.first('rhesus') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Status Pernikahan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('marital_status') }">
                <select name="marital_status" class="select" v-model="maritalStatus" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(maritalStatus, key) in maritalsStatus" :key="key" :value="maritalStatus.object_id">{{
                    maritalStatus.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bloodType')" class="help is-danger">{{ errors.first('bloodType') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Pernikahan</label>
            <div class="control">
              <input name="marital_date" class="input " placeholder="e.g. 10-10-2018" type="date" v-model="maritalDate"
                v-bind:class="{ 'is-danger': errors.has('marital_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('marital_date')" class="help is-danger"> {{ errors.first('marital_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">NIK Referensi</label>
            <div class="control">
              <input name="personal_number_reference" class="input " placeholder="e.g. 00000" type="text" v-model="personalNumberReference"
                v-bind:class="{ 'is-danger': errors.has('personal_number_reference')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('personal_number_reference')" class="help is-danger"> {{
              errors.first('personal_number_reference') }}</p>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded is-pulled-right" @click="saveEmployee()"> <span> <i class="fa fa-floppy-o" aria-hidden="true"></i> Simpan</span></a>
    <br>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import SearchFilter from '~/components/SearchFilter';
  import Vue from 'vue';
  import VeeValidate from 'vee-validate';
  Vue.use(VeeValidate);
  import swal from 'sweetalert';

  export default {
    components: {
      Breadcrumb,
      SearchFilter,
    },
    created() {
      this.getReligions();
      this.getLanguages();
      this.getTribes();
      this.getBloodType();
      this.getMaritalStatus();
      this.getCompany();
      this.getHakAkses();

    },
    data() {
      return {
        myDate : new Date().toISOString().slice(0,10),
        startDate: '',
        endDate: '',
        personalNumber: '',
        fullName: '',
        nickName: '',
        birthPlace: '',
        birthDate: '',
        gender: '',
        religion: '',
        language: '',
        national: '',
        tribe: '',
        hakAkses:'',
        bloodType: '',
        maritalStatus: '',
        rhesus: '',
        maritalStatus: '',
        maritalDate: '',
        personalNumberReference: '-',
        company: '',
        religions: [],
        languages: [],
        bloodTypes: [],
        tribes: [],
        maritalsStatus: [],
        employees: [],
        companies: [],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },

        ]
      }
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/PRSNL')
          .then(response => {
            this.hakAkses = response.data.data.access;            
            if(this.hakAkses != '*' && this.hakAkses != 'W'){
              return this.$router.push('/employee-data/employee/employee-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      resetFormCompany() {
        this.company = '';
      },
      resetForm() {
        this.startDate = '';
        this.endDate = '';
        this.personalNumber = null;
        this.fullName = '';
        this.company = '';
        this.nickName = '';
        this.birthPlace = '';
        this.birthDate = '';
        this.gender = '';
        this.religion = '';
        this.language = '';
        this.national = '';
        this.tribe = '';
        this.bloodType = '';
        this.maritalStatus = '';
        this.rhesus = '';
        this.maritalStatus = '';
        this.maritalDate = '';
        this.personalNumberReference = '';
        this.$nextTick(() => this.$validator.reset())
      },
      resetFormSearch() {
        this.startDate = '';
        this.endDate = '';
        this.fullName = '';
        this.nickName = '';
        this.birthPlace = '';
        this.birthDate = '';
        this.gender = '';
        this.religion = '';
        this.language = '';
        this.national = '';
        this.tribe = '';
        this.bloodType = '';
        this.maritalStatus = '';
        this.rhesus = '';
        this.maritalStatus = '';
        this.maritalDate = '';
        this.personalNumberReference = '';
        this.$nextTick(() => this.$validator.reset())
      },
      getLanguages() {
        // this.$axios.get('/objects/language')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte=9999-12-31&object_type=LANGU')
          .then(response => {
            this.languages = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getReligions() {
        // this.$axios.get('/objects/religion')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte=9999-12-31&object_type=RELIG')
          .then(response => {
            this.religions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getTribes() {
        this.$axios.get('/objects/tribe')
          .then(response => {
            this.tribes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBloodType() {
        // this.$axios.get('/objects/bloodtype')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte=9999-12-31&object_type=BLDTY')
          .then(response => {
            this.bloodTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getMaritalStatus() {
        this.$axios.get('/objects/marital_status')
          .then(response => {
            this.maritalsStatus = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCompany() {
        this.$axios.get('/objects/companytoken/PRSNL')
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getEmployees1(personalNumber) {
        this.$axios.get('users/' + this.company + '/personal/' + this.personalNumber)
          .then(response => {
            if (response.data.data.length > 0) {
              this.employees = [];
              response.data.data.forEach(async (employee, key) => {
                await this.employees.push({
                  startDate: employee.begin_date,
                  endDate: employee.end_date,
                  personalNumber: employee.personal_number,
                  fullName: employee.full_name,
                  nickName: employee.nickname,
                  birthPlace: employee.born_city,
                  birthDate: employee.born_date,
                  gender: employee.gender[0].object_id,
                  religion: employee.religion[0].object_id,
                  language: employee.language[0].object_id,
                  national: employee.national,
                  tribe: employee.tribe[0].object_id,
                  bloodType: employee.blood_type[0].object_id,
                  rhesus: employee.rhesus,
                  maritalStatus: employee.marital_status[0].object_id,
                  maritalDate: employee.marital_date,
                  personalNumberReference: employee.personal_number_reference,
                  company: employee.business_code,
                })
              })
              this.getEmployee(personalNumber);
            } else {
              this.resetFormSearch();
            }

          })
          .catch(e => {
            console.log(e);
          });
      },
      async getEmployee(personalNumber) {
        let employee = await this.employees.find(employee => employee.personalNumber == personalNumber);
        this.startDate = employee.startDate;
        this.endDate = employee.endDate;
        this.personalNumber = employee.personalNumber;
        this.fullName = employee.fullName;
        this.nickName = employee.nickName;
        this.birthPlace = employee.birthPlace;
        this.birthDate = employee.birthDate;
        this.gender = employee.gender;
        this.religion = employee.religion;
        this.language = employee.language;
        this.national = employee.national;
        this.tribe = employee.tribe;
        this.bloodType = employee.bloodType;
        this.rhesus = employee.rhesus;
        this.maritalStatus = employee.maritalStatus;
        this.maritalDate = employee.maritalDate;
        this.personalNumberReference = employee.personalNumberReference;
        //this.nikAuth = employee.nikAuth;
        this.company = employee.company
      },

      saveEmployee() {
        // alert(this.company)
        this.personalNumber ? this.updateEmployee(this.personalNumber) : this.storeEmployee();
      },
      updateEmployee() {
        this.$validator.validateAll('employee').then(async result => {
          if (!result) return;
          var res = this.maritalStatus.substring(1, 2);
          this.$axios.post('users/' + this.company + '/personal/' + this.personalNumber, {
              begin_date: this.startDate,
              end_date: this.endDate,
              personal_number: this.personalNumber,
              full_name: this.fullName,
              nickname: this.nickName,
              born_city: this.birthPlace,
              born_date: this.birthDate,
              gender: this.gender,
              religion: this.religion,
              language: this.language,
              national: this.national,
              tribe: this.tribe,
              blood_type: this.bloodType,
              rhesus: this.rhesus,
              marital_status: res,
              marital_date: this.maritalDate,
              personal_number_reference: this.personalNumberReference,
              business_code: this.company,
            })
            .then(response => {
              this.resetForm();
              swal(
                'Saved!',
                'Successfully saved employee.',
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      storeEmployee() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          var res = this.maritalStatus.substring(1, 2);

          this.$axios.post('users/' + this.company + '/personal/' + this.personalNumber, {
              begin_date: this.startDate,
              end_date: this.endDate,
              personal_number: this.personalNumber,
              full_name: this.fullName,
              nickname: this.nickName,
              born_city: this.birthPlace,
              born_date: this.birthDate,
              gender: this.gender,
              religion: this.religion,
              language: this.language,
              national: this.national,
              tribe: this.tribe,
              blood_type: this.bloodType,
              rhesus: this.rhesus,
              marital_status: res,
              marital_date: this.maritalDate,
              personal_number_reference: this.personalNumberReference,
              //change_user: this.nikAuth,
              business_code: this.company,
            })
            .then(response => {
              console.log(this.employees)
              //this.getEmployee();
              this.resetForm();
              swal(
                'Saved!',
                'Successfully saved Employee Data.',
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deleteEmployee(key, personalNumber) {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
          this.$axios.post('users/' + this.nikAuth + '/personal/' + personalNumber, {})
            .then(response => {
              $swal(
                'Deleted!',
                response.data.message,
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            })
            .then(() => {
              this.removeEmployee(key);
            })
        });
      },
      removeEmployee(key) {
        this.employees.splice(key, 1);
      },
    },
    middleware: ['auth']
  }

</script>

<style scoped>
  .tabs.is-boxed a:hover {
    background-color: rgba(255, 255, 255, 0.27843);
    border-bottom-color: #dbdbdb;
  }

  .tabs.is-boxed li.is-active a {
    background-color: #ffffff47;
    border-color: #dbdbdb;
    border-bottom-color: none;
  }

  .has-background-danger {
    background-color: #6D6D6D !important;
  }

</style>
