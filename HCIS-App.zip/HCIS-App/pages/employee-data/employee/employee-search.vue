<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <!-- <nuxt-link to="/employee-data/employee"><a class="button is-link is-rounded is-pulled-right"> <span><i class="fa fa-plus" aria-hidden="true"></i> Tambah Data </span></a>
    </nuxt-link> -->
    <a class="button is-link is-rounded is-pulled-right" @click="openFormModal()"> <span><i class="fa fa-plus"
          aria-hidden="true"></i> Tambah Data </span></a>
    <h3 class="subtitle is-3">
      <i class="fa fa-users" aria-hidden="true"></i> Pencarian Data Karyawan
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-1">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i
                  class="fa fa-plus" aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i
                  class="fa fa-trash" aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"> <span> <i
                class="fa fa-search" aria-hidden="true"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Nomer Induk Karyawan</th>
          <th>Nama Lengkap</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(employee, key) in employees" :key="key">
          <td> {{key+1}} </td>
          <td> {{employee.personnel_number}}</td>
          <td> {{employee.complete_name}}</td>
          <td> {{employee.begin_date}} </td>
          <td> {{employee.end_date}} </td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="editEmployee(employee.object_identifier)"><i class="fa fa-pencil" aria-hidden="true"></i></a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="employee.object_identifier ? deleteEmployee(key, employee.object_identifier) : removeEmployee(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitEmployee(employee.object_identifier)"><i class="fa fa-clock-o"
                aria-hidden="true"></i></a>
          </td>
        </tr>
      </thead>
    </table>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Karyawan</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomer Induk Karyawan</label>
                  <div class="control">
                    <input name="personnel_number" class="input " placeholder="e.g. S00215" type="text"
                      v-model="personalNumber" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'">
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger"> {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama Lengkap</label>
                  <div class="control">
                    <input name="full_name" class="input " placeholder="e.g. Adi Purnama" type="text" v-model="fullName"
                      v-bind:class="{ 'is-danger': errors.has('full_name')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('full_name')" class="help is-danger"> {{ errors.first('full_name') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Nama Panggilan</label>
                  <div class="control">
                    <input name="nickname" class="input " placeholder="e.g. Adi" type="text" v-model="nickName"
                      v-bind:class="{ 'is-danger': errors.has('nickname')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname') }}</p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Tempat Lahir</label>
                  <div class="control">
                    <input name="birth_place" class="input " placeholder="e.g. Depok" type="text" v-model="birthPlace"
                      v-bind:class="{ 'is-danger': errors.has('birth_place')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('birth_place')" class="help is-danger"> {{ errors.first('birth_place') }}</p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Tanggal Lahir</label>
                  <div class="control">
                    <input name="born_date" class="input " placeholder="e.g. 10-10-2018" type="date" v-model="birthDate"
                      v-bind:class="{ 'is-danger': errors.has('born_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('born_date')" class="help is-danger"> {{ errors.first('born_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Jenis Kelamin</label>
                  <div class="control">
                    <label class="radio">
                      <input name="gender" type="radio" v-model="gender" value="L" v-validate="'required|included:L,P'">
                      Pria
                    </label>
                    <label class="radio">
                      <input name="gender" type="radio" v-model="gender" value="P">
                      Wanita
                    </label>
                  </div>
                  <p v-show="errors.has('gender')" class="help is-danger">{{ errors.first('gender') }}</p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Agama</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.religion') }">
                      <select name="religion" class="select" v-model="religion"
                        v-validate="'required|included:01,02,03,04,05,06'">
                        <option disabled selected>Choose</option>
                        <option v-for="(religion, key) in religions" :key="key" :value="religion.object_code">{{
                          religion.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.religion')" class="help is-danger">{{ errors.first('form.religion') }}</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Bahasa</label>
                  <div class="control">
                    <div class="select " v-bind:class="{ 'is-danger': errors.has('form.language') }">
                      <select name="language" class="select" v-model="language" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(language, key) in languages" :key="key" :value="language.object_code">{{
                          language.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.language')" class="help is-danger">{{ errors.first('form.language') }}</p>
                  </div>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Nasionalisme</label>
                  <div class="control">
                    <div class="select " v-bind:class="{ 'is-danger': errors.has('form.nationality') }">
                    <select name="nationality" class="select" v-model="national" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(nationality, key) in nationalities" :key="key" :value="nationality.object_code">{{
                          nationality.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.nationality')" class="help is-danger">{{ errors.first('form.nationality') }}</p>
                  </div>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Suku</label>
                  <div class="control">
                    <div class="select " v-bind:class="{ 'is-danger': errors.has('form.tribe') }">
                      <select name="tribe" class="select" v-model="tribe" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(tribe, key) in tribes" :key="key" :value="tribe.object_code">{{
                          tribe.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.tribe')" class="help is-danger">{{ errors.first('form.tribe') }}</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Golongan Darah</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.blood') }">
                      <select name="blood" class="select" v-model="bloodType" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(bloodType, key) in bloodTypes" :key="key" :value="bloodType.object_code">{{
                          bloodType.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.blood')" class="help is-danger">{{ errors.first('form.blood') }}</p>
                  </div>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Rhesus</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.rhesus') }">
                      <select name="rhesus" class="select" v-model="rhesus" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(rhesus, key) in rhesuses" :key="key" :value="rhesus.object_code">{{
                          rhesus.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.rhesus')" class="help is-danger">{{ errors.first('form.rhesus') }}</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Status Pernikahan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.marital_status') }">
                      <select name="marital_status" class="select" v-model="maritalStatus" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(maritalStatus, key) in maritalsStatus" :key="key"
                          :value="maritalStatus.object_code">{{
                          maritalStatus.object_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('form.marital_status')" class="help is-danger">{{ errors.first('form.marital_status') }}</p>
                  </div>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Tanggal Pernikahan</label>
                  <div class="control">
                    <input name="marital_date" class="input " placeholder="e.g. 10-10-2018" type="date"
                      v-model="maritalDate" v-bind:class="{ 'is-danger': errors.has('marital_date')}"
                      >
                  </div>
                  <p v-show="errors.has('marital_date')" class="help is-danger"> {{ errors.first('marital_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Nomer Induk Pemberi Referensi</label>
                  <div class="control">
                    <input name="personnel_number_reference" class="input " placeholder="e.g. 00000" type="text"
                      v-model="personalNumberReference"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number_reference')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('personnel_number_reference')" class="help is-danger"> {{
                    errors.first('personnel_number_reference') }}</p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Kode Perusahaan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                      <select name="company" class="select" v-model="company" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(company, key) in companies" :key="key"
                          :value="company.business_code">{{
                          company.company_name
                          }}</option>
                      </select>
                    </div>
                    <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                  </div>
                  <p v-show="errors.has('business_code')" class="help is-danger"> {{
                    errors.first('business_code') }}</p>
                </div>
              </div>
            </div>
          </section>
          <footer class="modal-card-foot">
            <div class="control  ">
              <button @click="saveEmployee()" class="button is-success">Simpan</button>
              <button class="button is-danger" @click="closeFormModal()">Batal</button>
            </div>
          </footer>
        </div>
      </div>
      <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
        <div class="modal-background"></div>
        <div class="modal-card">
          <header class="modal-card-head">
            <p class="modal-card-title">Delimit Data Karyawan</p>
            <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
          </header>
          <section class="modal-card-body">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('delimit.begin_date')}" v-validate="'required'" data-vv-scope="delimit" disabled>
                  </div>
                  <p v-show="errors.has('delimit.begin_date')" class="help is-danger">{{ errors.first('delimit.begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('delimit.end_date')}" v-validate="'required'" data-vv-scope="delimit">
                  </div>
                  <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}</p>
                </div>
              </div>
            </div>          
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="delimitEmployee()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
          </div>
        </footer>
       </div>
      </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import moment from 'moment'
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        tableCode: 'Personal',
        oid: null,
        startDate: null,
        endDate: null,
        personalNumber: null,
        fullName: '',
        nickName: '',
        birthPlace: '',
        birthDate: null,
        gender: null,
        religion: null,
        language: null,
        national: null,
        tribe: null,
        bloodType: null,
        maritalStatus: null,
        rhesus: null,
        maritalDate: null,
        personalNumberReference: null,
        company: null,
        companies: [],
        religions: [],
        languages: [],
        bloodTypes: [],
        nationalities: [],
        rhesuses: [],
        tribes: [],
        maritalsStatus: [],
        employees: [],
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Pencarian'
          },
        ],
        isActiveForm: false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getEmployees();
      this.getReligions();
      this.getLanguages();
      this.getTribes();
      this.getBloodType();
      this.getMaritalStatus();
      this.getRhesus();
      this.getNationality();
      this.getCompany();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
      //console.log(this.getEmployees)
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/PRSNL')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'R') {
              return this.$router.push('/employee-data/employee')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.startDate = null
        this.endDate = null
        this.personalNumber = null
        this.fullName = ''
        this.nickName = ''
        this.birthPlace = ''
        this.birthDate = null
        this.gender = null
        this.religion = null
        this.language = null
        this.national = null
        this.tribe = null
        this.bloodType = null
        this.rhesus = null
        this.maritalStatus = null
        this.maritalDate = null
        this.personalNumberReference = null
        this.company = null
        this.$nextTick(() => this.$validator.reset())
      },
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.startDate = null
        this.endDate = null
        this.personalNumber = null
        this.fullName = ''
        this.nickName = ''
        this.birthPlace = ''
        this.birthDate = null
        this.gender = null
        this.religion = null
        this.language = null
        this.national = null
        this.tribe = null
        this.bloodType = null
        this.rhesus = null
        this.maritalStatus = null
        this.maritalDate = null
        this.personalNumberReference = null
        this.company = null
        this.$nextTick(() => this.$validator.reset())
      },
      getLanguages() {
        this.$axios.get('ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=LANGU')
          .then(response => {
            this.languages = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getReligions() {
        this.$axios.get('ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=RELIG')
          .then(response => {
            this.religions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getTribes() {
        this.$axios.get('ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=TRIBE')
          .then(response => {
            this.tribes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBloodType() {
        this.$axios.get('ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=BLDTY')
          .then(response => {
            this.bloodTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getNationality() {
        this.$axios.get('ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=NATIO')
          .then(response => {
            this.nationalities = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getRhesus() {
        this.$axios.get('ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=BLDRH')
          .then(response => {
            this.rhesuses = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getMaritalStatus() {
        this.$axios.get('ldap/api/object?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD") + '&object_type=MRTST')
          .then(response => {
            this.maritalsStatus = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCompany() {
        this.$axios.get('hcis/api/company?begin_date_lte=' + moment(new Date()).format("YYYY-MM-DD") +
            '&end_date_gte=' + moment(new Date()).format("YYYY-MM-DD"))
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getColumn() {
        this.$axios.get('/users/personal/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getLogic() {
        this.$axios.get('/object/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/object/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = {
          table: "Personal", //harcode sesuai form *referensi table_code*
          column: this.columns_model,
          query: this.logics_model,
          value: this.filters_model,
          andor: this.conditions_model
        }
        console.log(this.paramsearchforms)
        this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
          .then(response => {
            this.employees = [];
            response.data.data.forEach(async (employee, key) => {
              await this.employees.push({
                startDate: employee.begin_date,
                endDate: employee.end_date,
                personalNumber: employee.personnel_number,
                businessCode: employee.business_code
              })
            });
            console.log(this.employees);
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployees() {
        this.$axios.get('hcis/api/personal')
          .then(response => {
            this.employees = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      saveEmployee() {
        this.oid ? this.updateEmployee() : this.storeEmployee();
      },
      updateEmployee() {
        this.$validator.validateAll('employee').then(async result => {
          if (!result) return;
          var res = this.maritalStatus.substring(1, 2);
          //alert(chuser)
          this.$axios.put('hcis/api/personal', {
              object_identifier: this.oid,
              begin_date: this.startDate,
              end_date: this.endDate,
              personnel_number: this.personalNumber,
              complete_name: this.fullName,
              nickname: this.nickName,
              birth_city: this.birthPlace,
              birth_date: this.birthDate,
              gender: this.gender,
              religion: this.religion,
              language: this.language,
              nationality: this.national,
              tribe: this.tribe,
              blood: this.bloodType,
              rhesus: this.rhesus,
              marital_status: this.maritalStatus,
              marital_date: this.maritalDate,
              personnel_number_reference: this.personalNumberReference,
              business_code: this.company,
            })
            .then(response => {
              this.getEmployees();
              this.closeFormModal();
              swal(
                'Saved!',
                'Successfully saved employee.',
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      storeEmployee() {
        // if (this.hakAkses != '*' && this.hakAkses != 'W') {
        //   alert('anda tidak mempunyai hak akses !');
        // } else {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          if (this.maritalDate == null) {
            this.maritalDate = '9999-12-30'
          }
          // var res = this.maritalStatus.substring(1, 2);
          this.$axios.post('hcis/api/personal', {
              begin_date: this.startDate,
              end_date: this.endDate,
              personnel_number: this.personalNumber,
              complete_name: this.fullName,
              nickname: this.nickName,
              birth_city: this.birthPlace,
              birth_date: this.birthDate,
              gender: this.gender,
              religion: this.religion,
              language: this.language,
              nationality: this.national,
              tribe: this.tribe,
              blood: this.bloodType,
              rhesus: this.rhesus,
              marital_status: this.maritalStatus,
              marital_date: this.maritalDate,
              personnel_number_reference: this.personalNumberReference,
              business_code: this.company,
            })
            .then(response => {
              this.getEmployees();
              this.closeFormModal();
              swal(
                'Saved!',
                'Successfully saved employee.',
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            });
        });
        //}
      },
      editEmployee(oid) {
        this.openFormModal();
        this.getEmployee(oid);
      },
      async showDelimitEmployee(oid) {
        this.openFormModalDelimit();
        let employee = await this.employees.find(employee => employee.object_identifier == oid);
        this.oid = employee.object_identifier
        this.startDate = employee.begin_date;
        this.endDate = moment(new Date()).format("YYYY-MM-DD")
      },
      async getEmployee(oid) {
        let employee = await this.employees.find(employee => employee.object_identifier == oid);
        this.oid = employee.object_identifier
        this.startDate = employee.begin_date;
        this.endDate = employee.end_date;
        this.personalNumber = employee.personnel_number;
        this.fullName = employee.complete_name;
        this.nickName = employee.nickname;
        this.birthPlace = employee.birth_city,
          this.birthDate = employee.birth_date,
          this.gender = employee.gender,
          this.religion = employee.religion,
          this.language = employee.language,
          this.national = employee.nationality,
          this.tribe = employee.tribe,
          this.bloodType = employee.blood,
          this.rhesus = employee.rhesus,
          this.maritalStatus = employee.marital_status,
          this.maritalDate = employee.marital_date,
          this.personalNumberReference = employee.personnel_number_reference,
          this.company = employee.business_code.business_code
      },
      deleteEmployee(key, oid) {
        // if (this.hakAkses != '*' && this.hakAkses != 'W') {
        //   alert('anda tidak mempunyai hak akses !');
        // } else {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.delete('hcis/api/personal?object_identifier=' + oid)
              .then(response => {
                swal(
                  'Deleted!',
                  response.data.message,
                  'success'
                )
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeEmployee(key);
              })
          }

        });
        //}
      },
      removeEmployee(key) {
        this.employees.splice(key, 1);
      },
      delimitEmployee() {
        this.$validator.validateAll('delimit').then(async result => {
          if (!result) return;
          this.$axios.patch('hcis/api/personal', {}, {
              params: {
                object_identifier: this.oid,
                end_date: this.endDate,
              }
            })
            .then(response => {
              this.getEmployees();
              this.closeFormModalDelimit();
              swal(
                'Delimited!',
                response.data.message,
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            })
        });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    },
    middleware: ['auth']
  }
</script>