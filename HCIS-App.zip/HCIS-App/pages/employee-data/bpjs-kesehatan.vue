<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/employee-data/bpjs-kesehatan-search" class="button is-success is-rounded is-pulled-right">Search</nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> BPJS Kesehatan
    </h3>
    <div class="box has-text-white has-background-danger">
      Data Karyawan
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">NIK</label>
            <div class="control">
              <input name="personal_number" class="input " placeholder="e.g. S00215" type="text" v-on:change="getBpjsKesehatans(personalNumber)"
                v-model="personalNumber" v-bind:class="{ 'is-danger': errors.has('personal_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. Budi Kurniawan">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth">
              <select>
                <option disabled selected>Pilih</option>
                <option>Select dropdown</option>
                <option>With options</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. Manager">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. DPCB">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Formulir BPJS Kesehatan
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal berlaku</label>
            <div class="control">
              <input class="input" id="begin_date" type="date" placeholder="10-10-2017" name="begin_date" v-model="startDate"
                data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">s.d</label>
            <div class="control">
              <input id="end_date" class="input" name="end_date" type="date" placeholder="10-10-2017" v-model="endDate"
                data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor BPJS Kesehatan</label>
            <div class="control">
              <input name="polis_number" class="input" type="text" placeholder="0001258" v-model="insuranceNumber"
                v-bind:class="{ 'is-danger': errors.has('polis_number')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('polis_number')" class="help is-danger"> {{ errors.first('polis_number')
              }}</p>
          </div>
        </div>
        <div class="column">
          <div class="field">
            <label class="label">Instansi Asuransi</label>
            <div class="control">
              <input name="insurance_company" class="input" type="text" placeholder="e.g. BPJS" v-model="insuranceCompany"
                v-bind:class="{ 'is-danger': errors.has('insurance_company')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('insurance_company')" class="help is-danger"> {{ errors.first('insurance_company')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Porsi Pembayaran Perusahaan (Rp)</label>
            <div class="control">
              <input name="company_payment_portion" class="input" type="text" placeholder="e.g. 100.000.000" v-model="amountEmployer"
                v-bind:class="{ 'is-danger': errors.has('company_payment_portion')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('company_payment_portion')" class="help is-danger"> {{
              errors.first('company_payment_portion')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Persentase (%) </label>
            <div class="control">
              <input name="percentage_cpp" class="input" type="text" placeholder="e.g. 2" v-model="percentEmployer"
                v-bind:class="{ 'is-danger': errors.has('percentage_cpp')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('percentage_cpp')" class="help is-danger"> {{ errors.first('percentage_cpp')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Porsi Pembayaran Karyawan (Rp)</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. 100.000.000" name="employee_payment_portion" v-model="amountEmployee"
                v-bind:class="{ 'is-danger': errors.has('company_payment_portion')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('employee_payment_portion')" class="help is-danger">
              {{errors.first('employee_payment_portion')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Persentase (%) </label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. 2" name="percentage_epp" v-model="percentEmployee"
                v-bind:class="{ 'is-danger': errors.has('company_payment_portion')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('percentage_epp')" class="help is-danger"> {{errors.first('percentage_epp')
              }}</p>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded" @click="saveInsurances()">Simpan</a>
    <a class="button is-danger is-rounded">Batal</a>
    <a class="button is-link is-rounded">Kembali</a>
  </section>
</template>
<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import Vue from 'vue';
  import VeeValidate from 'vee-validate';
  Vue.use(VeeValidate);
  import swal from 'sweetalert';

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        nikAuth: this.$auth.user.nik,
        i: null,
        startDate: '',
        endDate: '',
        businessCode: '1000',
        insuranceNumber: '',
        insuranceCompany: '',
        percentEmployer: '',
        amountEmployer: '',
        personalNumber: '',
        percentEmployee: '',
        amountEmployee: '',
        insurances: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'BPJS Kesehatan'
          },
        ]
      }
    },
    created() {

    },
    methods: {
      resetForm() {
        this.i = null;
        this.startDate = '';
        this.endDate = '';
        this.polisNumber = '';
        this.personalNumber = null;
        this.insuranceCompany = '',
        this.companyPaymentPortion = '',
        this.percentageCpp = '',
        this.employeePaymentPortion = '',
        this.percentageEpp = '',
        this.$nextTick(() => this.$validator.reset())
      },
      getBpjsKesehatans(personalNumber) {
        this.$axios.get('users/' + this.nikAuth + '/bpjskesehatan/' + this.personalNumber)
          .then(response => {
            if (response.data.data.length > 0) {
              this.insurances = [];
              response.data.data.forEach(async (insurance, key) => {
                await this.insurances.push({
                  startDate: insurance.begin_date,
                  endDate: insurance.end_date,
                  personalNumber: insurance.personal_number,
                  insuranceNumber: insurance.insurance_number,
                  insuranceCompany: insurance.insurance_company,
                  percentEmployer: insurance.percent_employer,
                  amountEmployer: insurance.amount_employer,
                  percentEmployee : insurance.percent_employee,
                  amountEmployee : insurance.amount_employee,
                  businessCode: insurance.business_code,
                  nikAuth: insurance.change_user
                })
              })
              this.getBpjskesehatan(personalNumber);
            } else {
              this.resetFormSearch();
            }

          })
          .catch(e => {
            console.log(e);
          });
      },
      async getBpjskesehatan(personalNumber) {
        let insurance = await this.insurances.find(insurance => insurance.personalNumber == personalNumber);
        this.startDate = insurance.startDate;
        this.endDate = insurance.endDate;
        this.personalNumber = insurance.personalNumber;
        this.insuranceNumber = insurance.insuranceNumber;
        this.insuranceCompany = insurance.insuranceCompany;
        this.percentEmployer = insurance.percentEmployer;
        this.amountEmployer = insurance.amountEmployer;
        this.percentEmployee = insurance.percentEmployee;
        this.amountEmployee = insurance.amountEmployee;
        this.businessCode = insurance.businessCode;
        this.nikAuth = insurance.nikAuth
      },
      saveInsurances() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;

          if (this.key != null) {
            this.insurances[this.key] = {
              key: this.key,
              startDate: this.startDate,
              endDate: this.endDate,
              businessCode: this.businessCode,
              personalNumber: this.personalNumber,
              insuranceNumber: this.insuranceNumber,
              insuranceCompany: this.insuranceCompany,
              percentEmployer: this.percentEmployer,
              amountEmployer: this.amountEmployer,
              percentEmployee: this.percentEmployee,
              amountEmployee: this.amountEmployee,
              nikAuth: this.nikAuth
            }
          } else {
            await this.insurances.push({
              key: this.key,
              startDate: this.startDate,
              endDate: this.endDate,
              businessCode: this.businessCode,
              personalNumber: this.personalNumber,
              insuranceNumber: this.insuranceNumber,
              insuranceCompany: this.insuranceCompany,
              percentEmployer: this.percentEmployer,
              amountEmployer: this.amountEmployer,
              percentEmployee: this.percentEmployee,
              amountEmployee: this.amountEmployee,
              nikAuth: this.nikAuth
            })
          }
          this.storeInsurance(this.personalNumber);
          this.resetForm();
          //this.resetForm();
          swal(
            'Saved!',
            'Successfully saved Tax.',
            'success'
          )
        });
      },
      // async storeBpjs(personalNm) {
      //   let bpjskesehatans = await this.bpjskesehatans.map(bpjskesehatan => {
      //     return {
      //       begin_date: bpjskesehatan.startDate,
      //       end_date: bpjskesehatan.endDate,
      //       business_code: bpjskesehatan.businessCode,
      //       personal_number: bpjskesehatan.personalNumber,
      //       insurance_number: bpjskesehatan.insuranceNumber,
      //       insurance_company: bpjskesehatan.insuranceCompany,
      //       percent_employer: bpjskesehatan.percentEmployer,
      //       amount_employer: bpjskesehatan.amountEmployer,
      //       percent_employee: bpjskesehatan.percentEmployee,
      //       amount_employee: bpjskesehatan.amountEmployee,
      //       change_user: bpjskesehatan.nikAuth
      //     };
      //   });
      //   var bpjsks = [bpjskesehatans [bpjskesehatans.length -1]]
      //   this.$axios.post('/users/' + this.nikAuth + '/bpjskesehatan/' + personalNm, bpjsks)
      //     .then(response => {
      //       this.bpjskesehatans = [];
      //       response.data.data.forEach((bpjskesehatan, key) => {
      //         this.bpjskesehatans.push({
      //           key: key,
      //           startDate: bpjskesehatan.begin_date,
      //           endDate: bpjskesehatan.end_date,
      //           businessCode: bpjskesehatan.business_code,
      //           personalNumber: bpjskesehatan.personal_number,
      //           insuranceNumber: bpjskesehatan.insurance_number,
      //           insuranceCompany: bpjskesehatan.insurance_company,
      //           percentEmployer: bpjskesehatan.percent_employer,
      //           amountEmployer: bpjskesehatan.amount_employer,
      //           percentEmployee: bpjskesehatan.percent_employee,
      //           amountEmployee: bpjskesehatan.amount_employee,
      //           nikAuth: bpjskesehatan.change_user
      //         });
      //       });
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     })
      // },
      async storeInsurance(personalNm) {
        let insurances = await this.insurances.map(insurance => {
          return {
            begin_date: insurance.startDate,
            end_date: insurance.endDate,
            business_code: insurance.businessCode,
            personal_number: insurance.personalNumber,
            insurance_number: insurance.insuranceNumber,
            insurance_company: insurance.insuranceCompany,
            percent_employer: insurance.percentEmployer,
            amount_employer: insurance.amountEmployer,
            percent_employee: insurance.percentEmployee,
            amount_employee: insurance.amountEmployee,
            change_user: insurance.nikAuth,
          };
        });
        var insurancess = [insurances [insurances.length -1]]
        this.$axios.post('/users/' + this.nikAuth + '/bpjskesehatan/' + personalNm, insurancess)
          .then(response => {
            this.insurances = [];
            response.data.data.forEach((insurance, key) => {
              this.insurances.push({
                key: key,
                startDate: insurance.begin_date,
                endDate: insurance.end_date,
                businessCode: insurance.business_code,
                personalNumber: insurance.personal_number,
                insuranceNumber: insurance.insurance_number,
                insuranceCompany: insurance.insurance_company,
                percentEmployer: insurance.percent_employer,
                amountEmployer: insurance.amount_employer,
                amountEmployee: insurance.amount_employee,
                percentEmployee: insurance.percent_employee,
                nikAuth: insurance.change_user
              });
            });
          })
          .catch(e => {
            console.log(e);
          })
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    }
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
