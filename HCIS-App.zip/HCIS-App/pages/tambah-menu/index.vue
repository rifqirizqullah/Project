<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      Tambah Menu
    </h3>
    <div class="columns">
      <div class="column is-4">
        <label for="">Nama Menu</label>
        <input class="input" type="text" placeholder="">
      </div>
    </div>
    <div class="columns is-multiline">
      <div class="column is-3">
        <div class="box">
          <label class="checkbox">
            <input type="checkbox">
            Karyawan
          </label>
        </div>
      </div>
      <div class="column is-3">
        <div class="box">
          <label class="checkbox">
            <input type="checkbox">
            Penempatan Kerja
          </label>
        </div>
      </div>
         <div class="column is-3">
        <div class="box">
          <label class="checkbox">
            <input type="checkbox">
            Karyawan
          </label>
        </div>
      </div>
      <div class="column is-3">
        <div class="box">
          <label class="checkbox">
            <input type="checkbox">
            Penempatan Kerja
          </label>
        </div>
      </div>
         <div class="column is-3">
        <div class="box">
          <label class="checkbox">
            <input type="checkbox">
            Karyawan
          </label>
        </div>
      </div>
      <div class="column is-3">
        <div class="box">
          <label class="checkbox">
            <input type="checkbox">
            Penempatan Kerja
          </label>
        </div>
      </div>
    </div>
    <div class="columns">
      <div class="column">
        <a class="button is-success is-rounded is-pulled-right">Simpan</a>
      </div>
    </div>

    <!-- <div class="steps" id="stepsDemo">
      <div class="step-item" @click="step = 'step1'" v-bind:class="{'is-active': step == 1 }">
        <div class="step-marker">1</div>
        <div class="step-details">
          <p class="step-title">Account</p>
        </div>
      </div>
      <div class="step-item " @click="step = 'step2'" v-bind:class="{'is-active':  step == 2 }">
        <div class="step-marker">2</div>
        <div class="step-details">
          <p class="step-title">Profile</p>
        </div>
      </div>
      <div class="step-item" @click="step = 'step3'" v-bind:class="{'is-active': step == 3}">
        <div class="step-marker">3</div>
        <div class="step-details">
          <p class="step-title">Social</p>
        </div>
      </div>
      <div class="step-item" @click="step = 'step4'" v-bind:class="{'is-active': step == 4}">
        <div class="step-marker">4</div>
        <div class="step-details">
          <p class="step-title">Finish</p>
        </div>
      </div>
      <div class="steps-content">
        <div class="step-content has-text-centered " v-bind:class="{'is-active': step == 1}">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Username</label>
            </div>
            <div class="field-body">
              <div class="field">
                <div class="control">
                  <input class="input" name="username" id="username" type="text" placeholder="Username" autofocus
                    data-validate="require">
                </div>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Password</label>
            </div>
            <div class="field-body">
              <div class="field">
                <div class="control has-icon has-icon-right">
                  <input class="input" type="password" name="password" id="password" placeholder="Password"
                    data-validate="require">
                </div>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Confirm password</label>
            </div>
            <div class="field-body">
              <div class="field">
                <div class="control has-icon has-icon-right">
                  <input class="input" type="password" name="password_confirm" id="password_confirm"
                    placeholder="Confirm password" data-validate="require">
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="step-content has-text-centered " v-bind:class="{'is-active': step == 2}">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Firstname</label>
            </div>
            <div class="field-body">
              <div class="field">
                <div class="control">
                  <input class="input" name="firstname" id="firstname" type="text" placeholder="Firstname" autofocus
                    data-validate="require">
                </div>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Last name</label>
            </div>
            <div class="field-body">
              <div class="field">
                <div class="control has-icon has-icon-right">
                  <input class="input" type="text" name="lastname" id="lastname" placeholder="Last name"
                    data-validate="require">
                </div>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Email</label>
            </div>
            <div class="field-body">
              <div class="field">
                <div class="control has-icon has-icon-right">
                  <input class="input" type="email" name="email" id="email" placeholder="Email" data-validate="require">
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="step-content has-text-centered" v-bind:class="{'is-active': step == 3}">
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Facebook account</label>
            </div>
            <div class="field-body">
              <div class="field">
                <div class="control">
                  <input class="input" name="facebook" id="facebook" type="text" placeholder="Facebook account url"
                    autofocus data-validate="require">
                </div>
              </div>
            </div>
          </div>
          <div class="field is-horizontal">
            <div class="field-label is-normal">
              <label class="label">Twitter account</label>
            </div>
            <div class="field-body">
              <div class="field">
                <div class="control">
                  <input class="input" name="twitter" id="twitter" type="text" placeholder="Twitter account url"
                    autofocus data-validate="require">
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="step-content has-text-centered" v-bind:class="{'is-active': step == 4}">
          <h1 class="title is-4">Your account is now created!</h1>
        </div>
      </div>
      <div class="steps-actions">
        <div class="steps-action" @click="prevStep(step)" v-if="step > 1">
          <a href="#" data-nav="previous" class="button is-light">Previous</a>
        </div>
        <div class="steps-action" @click="nextStep(step)" v-if="step < 4">
          <a href="#" data-nav="next" class="button is-light">Next</a>
        </div>
      </div>
    </div> -->

    <!-- <p>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Tempore quod accusamus corporis, tempora quia culpa
      soluta dolores perspiciatis tenetur perferendis beatae doloribus sit ipsum quam! Debitis vero assumenda aliquid
      sunt?
    </p> -->
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        step: 1,
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Aksi'
          },
          {
            name: 'Tambah Menu'
          }
        ]
      }
    },
    methods: {
      nextStep(step) {
        this.step = step + 1;
      },
      prevStep(step) {
        this.step = step - 1;
      }
    }
  }

</script>
