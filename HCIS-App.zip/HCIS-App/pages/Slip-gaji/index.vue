<template>
  <div class="container">
    <div class="box shadowed">
      <div class="columns">
        <div class="column logo-perusahaan is-6">
          <img class="logo-perusahaan"
            src="http://www.telkomsigma.co.id/wp-content/uploads/2015/10/logo_telkomsigma_trusted-IT-company_official1.png"
            alt="">
        </div>
        <div class="column is-6">
          <h4 class="title is-4 is-pulled-right">
            RAHASIA PRIBADI <br> PRIVATE & CONFIDENTIAL
          </h4>
        </div>
      </div>
      <hr>
      <div class="columns">
        <div class="column pt-0">
          <p class="is-pulled-right">REG/Maret/2019</p>
        </div>
      </div>
      <center>
        <h3 class="is-3 title is-marginless"> SLIP GAJI</h3>
        <p>Maret 2019</p>
      </center>
      <hr>
      <div class="columns">
        <div class="column is-8">
          <table>
            <tr>
              <th>NIK</th>
              <td class="ml-3"> : 12312</td>
            </tr>
            <tr>
              <th>Nama Pegawai</th>
              <td> : Budi Sudarsono</td>
            </tr>
            <tr>
              <th>Posisi</th>
              <td> : VP Delivery</td>
            </tr>
            <tr>
              <th>Lokasi Kerja</th>
              <td> : Bandung</td>
            </tr>
          </table>
        </div>
        <div class="column ">
          <div class="box">
            <table>
              <tr>
                <th>Jenis Gaji</th>
                <td class="ml-3"> : Reguler</td>
              </tr>
              <tr>
                <th>Periode </th>
                <td> : Maret/2019</td>
              </tr>
              <tr>
                <th>Susunan Keluarga</th>
                <td> : K/0</td>
              </tr>
              <tr>
                <th>Jenis Kelamin</th>
                <td> : Laki - laki</td>
              </tr>
            </table>
          </div>
        </div>
      </div>
      <hr>
      <b>No NPWP</b>
      <hr>
      <center>
        <h5 class="is-5 subtitle is-marginless"> PERINCIAN GAJI</h5>
      </center>
      <hr>
      <div class="columns">
        <div class="column has-text-centered">
          Total Penghasilan (Rp)
        </div>
        <div class="column has-text-centered">
          Total Potongan (Rp)
        </div>
        <div class="column has-text-centered">
          Gaji Bersih (Rp)
        </div>
      </div>
      <hr>
      <table class="table is-fullwidth">
        <tr>
          <th>Jenis Penghasilan</th>
          <th>Jumlah (Rp)</th>
          <th>Rapel (Rp)</th>
          <th>Jenis Potongan</th>
          <th>Jumlah (Rp)</th>
          <th>Rapel (Rp)</th>
        </tr>
        <tr>
          <td>Gaji Reguler</td>
          <td>211311123</td>
          <td>213123231</td>
          <td>A</td>
          <td>13231</td>
          <td>11321313</td>
        </tr>
      </table>
      <p class="has-text-centered">
        RINGKASAN PERHITUNGAN PAJAK
      </p>
      <hr>
      <div class="columns has-text-centered">
        <div class="column">
          Penghasilan s/d bulan lalu(Rp)
        </div>
        <div class="column">
          Iuran Dana Pensiun + Taspen Pajak Penghasilan s/d bulan lalu(Rp)
        </div>
        <div class="column">
          Pajak Penghasilan s/d bulan lalu(Rp)
        </div>
      </div>
      <hr>
      <div class="columns">
        <div class="column">
         Telah dibukukukan ke rekening Saudara Nomor di
        </div>
        <div class="column">
          Lembar Catatan
        </div>
        <hr>
      </div>
      <hr>
      <p>Sesuai Fatwa MUI No.3 Tahun 2003 dan Keputusan BAZNAS No. 73 Tahun 2017 bahwa Pendapatan/Penghasilan yang telah mencapai Nisab wajib dikeluarkan Zakatnya.</p>
    </div>
    <br>
  </div>
</template>

<script>
  export default {
    layout: 'auth'

  }

</script>

<style>
  img.logo-perusahaan {
    width: 200px;
  }

  .container {
    margin-top: 40px;
  }

  .pt-0 {
    padding-top: 0px;
    padding-bottom: 0px;
  }

  .ml-3 {
    margin-left: 3px;
  }

  .shadowed {
    box-shadow: 10px 10px 38px 0px rgba(0, 0, 0, 0.75);
}
</style>
