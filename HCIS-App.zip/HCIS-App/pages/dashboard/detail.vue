<template>
  <section class="section">
    <h3 class="subtitle is-3">
      <i class="fa fa-building" aria-hidden="true"></i> {{name}}
    </h3>
    <div class="columns is-multiline">
      <div class="column is-4" v-for="(buscd, key) in buscdDetails" :key="key">
        <!-- <nuxt-link :to="'/dashboard/detail?buscd='+buscd.id"> -->
        <div v-if="buscd.status == 'Y'">
          <div class="box shadowed">
            <p class="has-text-centered">{{buscd.name}}</p>            
            <p class="has-text-centered">{{buscd.nor}}</p>                        
          </div>
          </div>
          <div v-else>
            <div class="box has-background-danger">
              <p class="has-text-centered">{{buscd.name}}</p>            
              <p class="has-text-centered">{{buscd.nor}}</p>                        
          </div>
          </div>
        <!-- </nuxt-link> -->
      </div>      
    </div>
  </section>
</template>

<script>
  export default {
    data() {
      return {
        buscd : this.$route.query.buscd,
        name : this.$route.query.name,
        buscdDetails :[]
      }
    },
    created() {            
      this.getBUSCDDetail();
    },
    methods:{
      getBUSCDDetail(){      
        this.$axios.get('/users/dashboard/'+this.buscd)
          .then(response => {
            this.buscdDetails = [];
            response.data.data.forEach((buscd, key) => {
              this.buscdDetails.push({
                id: buscd.table_code,
                name: buscd.table_name,
                nor: buscd.number_of_rows,
                status: buscd.verification_status
              });
            });
          })
          .catch(e => {
            console.log(e);
          });      
      }
    },
    middleware: ['auth']
  }

</script>

<style>
  .shadowed {
    -webkit-box-shadow: 10px 10px 38px 0px rgba(0, 0, 0, 0.75);
    -moz-box-shadow: 10px 10px 38px 0px rgba(0, 0, 0, 0.75);
    box-shadow: 10px 10px 38px 0px rgba(0, 0, 0, 0.75);
  }

</style>
