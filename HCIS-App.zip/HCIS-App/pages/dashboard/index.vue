<template>
  <section class="section">
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Dashboard
    </h3>
    <div class="columns is-multiline">
      <div class="column is-4" v-for="(buscd, key) in buscds" :key="key">
        <nuxt-link :to="'/dashboard/detail?buscd='+buscd.id+'&name='+buscd.name">
        <div v-if="buscd.status == 'Y'">
          <div class="box shadowed">
            <p class="has-text-centered">{{buscd.name}}</p>
            <p class="has-text-centered">Data Sudah Terisi</p>
          </div>
          </div>
          <div v-else>
            <div class="box has-background-danger">
              <p class="has-text-centered">{{buscd.name}}</p>
              <p class="has-text-centered">Data Belum Terisi</p>
          </div>
          </div>
        </nuxt-link>
      </div>

    </div>
  </section>
</template>

<script>
  export default {
    data() {
      return {
        buscds:[]
      }
    },
    created() {
      this.getBUSCD();
    },
    methods:{
      getBUSCD(){
        this.$axios.get('/users/dashboard')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach((buscd, key) => {
              this.buscds.push({
                id: buscd.business_code,
                name: buscd.company_name,
                status: buscd.verification_status
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      }
    },
    middleware: ['auth']
  }

</script>

<style>
  .shadowed {
    -webkit-box-shadow: 10px 10px 38px 0px rgba(0, 0, 0, 0.75);
    -moz-box-shadow: 10px 10px 38px 0px rgba(0, 0, 0, 0.75);
    box-shadow: 10px 10px 38px 0px rgba(0, 0, 0, 0.75);
  }

</style>
