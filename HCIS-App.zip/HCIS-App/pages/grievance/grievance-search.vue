<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <!-- <nuxt-link to="/grievance"><a class="button is-link is-rounded is-pulled-right"><span><i class="fa fa-plus"></i>
          Tambah Data </span></a>
    </nuxt-link> -->
    <a class="button is-link is-rounded is-pulled-right" @click="openFormModal()">
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data
      </span>
    </a>
    <h3 class="subtitle is-3">
      <i class="fa fa-ban" aria-hidden="true"></i> Data Pembinaan
    </h3>
    <!--<div class="box has-text-white has-background-danger">
      Filter Search
    </div>-->
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i
                  class="fa fa-plus" aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i
                  class="fa fa-trash" aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i
                class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Tipe Pembinaan</th>
          <th>Tanggal Awal Berakhir</th>
          <th>Tanggal Akhir Berakhir</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(grievance, key) in grievances" :key="key">
          <td>{{ key + 1 }}</td>
          <td>{{ grievance.business_code.company_name }}</td>
          <td>{{ grievance.personnel_number.personnel_number }}</td>
          <td>{{ grievance.grievance_type.object_name }}</td>
          <td>{{ formatDate(grievance.begin_date) }}</td>
          <td>{{ formatDate(grievance.end_date) }}</td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="editGrievance(grievance.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="grievance.object_identifier ? deleteGrievance(key, grievance.object_identifier) : removeGrievance(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitGrievance(grievance.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>

    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getGrievances()">
    </pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Pembinaan</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                    <select name="company" class="select" v-model="company" @change="getParam()"
                      v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                        {{ company.company_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                </div>
              </div>
            </div>
          </div>

          <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                      class="is-link">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Asal Pembinaan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('grievance_source') }">
                      <select name="grievanceSource" class="select" v-model="grievanceSource" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option selected :value="1">Internal</option>
                        <option selected :value="2">Eksternal</option>
                      </select>
                    </div>
                    <p v-show="errors.has('grievance_source')" class="help is-danger">
                      {{ errors.first('grievance_source') }}</p>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tipe Pembinaan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('grievance_type') }">
                      <select name="grievanceType" class="select" v-model="grievanceType" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(grievanceType, key) in grievanceTypes" :key="key" :value="grievanceType.object_code">
                          {{ grievanceType.object_name }}
                        </option>
                      </select>
                    </div>
                    <p v-show="errors.has('grievance_type')" class="help is-danger">
                      {{ errors.first('grievance_type') }}</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Pembinaan</label>
                  <div class="control">
                    <input name="grievance_organization" class="input " placeholder="Pembinaan" type="text"
                      v-model="grievanceOrganization"
                      v-bind:class="{ 'is-danger': errors.has('grievance_organization')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('grievance_organization')" class="help is-danger">
                    {{ errors.first('grievance_organization') }}
                  </p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Mata Uang</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('grievance_currency') }">
                      <select name="grievanceCurrency" class="select" v-model="grievanceCurrency"
                        v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(grievanceCurrency, key) in grievanceCurrencies" :key="key"
                          :value="grievanceCurrency.object_code">
                          {{ grievanceCurrency.object_name }}
                        </option>
                      </select>
                    </div>
                    <p v-show="errors.has('grievance_currency')" class="help is-danger">
                      {{ errors.first('grievance_currency') }}</p>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Ganti Rugi</label>
                  <div class="control">
                    <input name="grievance_money" class="input " placeholder="Ganti Rugi" type="text"
                      v-model="grievanceMoney" @keypress="onlyNumber"
                      v-bind:class="{ 'is-danger': errors.has('grievance_money')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('grievance_money')" class="help is-danger">
                    {{ errors.first('grievance_money') }}
                  </p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Cara Pembayaran</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('grievance_payment') }">
                      <select name="grievancePayment" class="select" v-model="grievancePayment" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option selected :value="1">Via Payroll</option>
                        <option selected :value="2">Cash</option>
                      </select>
                    </div>
                    <p v-show="errors.has('grievance_payment')" class="help is-danger">
                      {{ errors.first('grievance_payment') }}</p>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Bayar</label>
                  <div class="control">
                    <input id="grievance_payment_date" data-display-mode="dialog" class="input"
                      name="grievance_payment_date" type="date" placeholder="e.g 10-11-2018"
                      v-model="grievancePaymentDate" data-vv-as="Award Payment date"
                      v-bind:class="{ 'is-danger': errors.has('grievance_payment_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('grievance_payment_date')" class="help is-danger">
                    {{ errors.first('grievance_payment_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Referensi <a v-if="referenceNumber != null" @click="referenceNumber= null"
                      class="is-link">Ubah</a></label>
                  <div class="control" v-if="referenceNumber == null">
                    <vue-autosuggest name="reference_number" ref="reference_number" :suggestions="filterReference"
                      @selected="selectReference" :limit="10" :input-props="inputReference"
                      v-bind:class="{ 'is-danger': errors.has('reference_number')}">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="reference_number" class="input" placeholder="Nomor Referensi" type="text"
                      v-model="referenceNumber" v-bind:class="{ 'is-danger': errors.has('reference_number')}" disabled>
                  </div>
                  <p v-show="errors.has('reference_number')" class="help is-danger">
                    {{ errors.first('reference_number') }}
                  </p>
                </div>
              </div>
            </div>
          </span>

        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveGrievance()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Delimit Data Pembinaan</p>
          <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                    data-vv-scope="delimit" disabled>
                </div>
                <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                  {{ errors.first('delimit.begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                    data-vv-scope="delimit">
                </div>
                <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                </p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="delimitGrievance()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from "~/components/Breadcrumb";
  import Vue from 'vue';
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  import VueAutosuggest from "vue-autosuggest";
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        // myDate : new Date().toISOString().slice(0,10),
        // nikAuth: this.$auth.user.nik,
        // key: null,
        grievances: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        grievanceSource: null,
        grievanceType: null,
        grievanceTypes: [],
        grievanceOrganization: '',
        grievanceCurrency: null,
        grievanceCurrencies: [],
        grievanceMoney: null,
        grievancePayment: null,
        grievancePaymentDate: null,
        referenceNumber: null,
        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: '',
        empolyeePosition: '',
        empolyeeUnit: '',
        perPage: 5,
        search: '',
        pagination: {
          'current_page': 1
        },
        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        filterReference: [],
        inputReference: {
          id: "autosuggest__input",
          name: "reference_number",
          class: "input",
          onInputChange: this.getReference,
          placeholder: "Nomor Referensi"
        },
        limit: 10,
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        bankByCodes: [],
        hakAkses: '',
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Pembinaan'
          },
        ],
        isActiveForm: false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getGrievances();
      this.getCompany();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
      // this.getHakAkses();
    },
    methods: {
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });
            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);
            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getEmployeeData(nik) {
        await this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      getGrievanceType() {
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=GRITY" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.grievanceTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getGrievanceCurrency() {
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=CURTY" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.grievanceCurrencies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getReference(text) {
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/contract?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (item, key) => {
              await this.options[0].data.push(
                item.contract_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);
            this.filterReference = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectReference(option) {
        if (option == null) {
          this.referenceNumber = null;
        } else {
          this.referenceNumber = option.item;
        }
      },
      getGrievances() {
        this.$axios
          .get("hcis/api/grievance?include=personnel_number&include=business_code&include=grievance_type&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&orderoid=asc" +
            '&page=' + this.pagination.current_page +
            '&per_page=' + this.perPage
          )
          // .get("hcis/api/grievance")
          .then(response => {
            this.grievances = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getGrievance(objectIdentifier) {
        let grievance = await this.grievances.find(
          grievance => grievance.object_identifier == objectIdentifier
        );
        this.objectIdentifier = grievance.object_identifier;
        this.startDate = grievance.begin_date;
        this.endDate = grievance.end_date;
        this.grievanceSource = grievance.grievance_source;
        this.grievanceType = grievance.grievance_type.object_code;
        this.grievanceOrganization = grievance.grievance_organization;
        this.grievanceCurrency = grievance.grievance_currency;
        this.grievanceMoney = grievance.grievance_money;
        this.grievancePayment = grievance.grievance_payment;
        this.grievancePaymentDate = grievance.grievance_payment_date;
        this.referenceNumber = grievance.reference_number.contract_number;
        this.company = grievance.business_code.business_code;
        this.employee = grievance.personnel_number.personnel_number;
        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.getGrievanceType();
        this.getGrievanceCurrency();
      },
      openFormModal() {
        this.isActiveForm = true;
        this.getGrievanceType();
        this.getGrievanceCurrency();
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.grievanceSource = null;
        this.grievanceType = null;
        this.grievanceOrganization = null;
        this.grievanceCurrency = null;
        this.grievanceMoney = null;
        this.grievancePayment = null;
        this.grievancePaymentDate = null;
        this.referenceNumber = null;
        this.company = null;
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeePosition = '';
        this.empolyeeUnit = '';
        this.$nextTick(() => this.$validator.reset());
      },
      storeGrievance() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/grievance", {
              begin_date: this.startDate,
              end_date: this.endDate,
              grievance_source: this.grievanceSource,
              grievance_type: this.grievanceType,
              grievance_organization: this.grievanceOrganization,
              grievance_currency: this.grievanceCurrency,
              grievance_money: this.grievanceMoney,
              grievance_payment: this.grievancePayment,
              grievance_payment_date: this.grievancePaymentDate,
              reference_number: this.referenceNumber,
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getGrievances();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data pembinaan.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      async editGrievance(objectIdentifier) {
        await this.getGrievance(objectIdentifier);
        this.openFormModal();
      },
      updateGrievance() {
        this.$validator.validateAll("grievance").then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/grievance", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              grievance_source: this.grievanceSource,
              grievance_type: this.grievanceType,
              grievance_organization: this.grievanceOrganization,
              grievance_currency: this.grievanceCurrency,
              grievance_money: this.grievanceMoney,
              grievance_payment: this.grievancePayment,
              grievance_payment_date: this.grievancePaymentDate,
              reference_number: this.referenceNumber,
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getGrievances();
              this.closeFormModal();
              swal(
                "Updated!",
                "Successfully updated data pembinaan.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveGrievance() {
        this.objectIdentifier ? this.updateGrievance() : this.storeGrievance();
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitGrievance(objectIdentifier) {
        this.openFormModalDelimit();
        let grievance = await this.grievances.find(
          grievance => grievance.object_identifier == objectIdentifier
        );
        this.objectIdentifier = grievance.object_identifier;
        this.startDate = grievance.begin_date;
        this.endDate = grievance.end_date;
      },
      delimitGrievance() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/grievance", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getGrievances();
              this.closeFormModalDelimit();
              swal(
                "Delimited!",
                response.data.message,
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deleteGrievance(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete("hcis/api/grievance?object_identifier=" + objectIdentifier)
              .then(response => {
                swal(
                  "Deleted!",
                  response.data.message,
                  "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeGrievance(key);
              });
          }
        });
      },
      removeGrievance(key) {
        this.grievances.splice(key, 1);
      },
      formatDate(date) {
        return moment(date).format('DD/MM/YYYY')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      },
      // getHakAkses() {
      //   this.$axios.get('/users/hakakses/GRVAC')
      //     .then(response => {
      //       this.hakAkses = response.data.data.access;
      //       if (this.hakAkses != '*' && this.hakAkses != 'R') {
      //         return this.$router.push('/grievance')
      //       }
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getGrievance() {
      //   // this.$axios.get('users/grievance?per_page=20')
      //   this.$axios.get('hcis/api/familycommunication?begin_date_lte[]=' + this.myDate + '&end_date_gte[]=' + this
      //       .myDate + '&per_page[]=20')
      //     .then(response => {
      //       this.grievances = [];
      //       response.data.data.forEach(async (grievance, key) => {
      //         await this.grievances.push({
      //           startDate: grievance.begin_date,
      //           endDate: grievance.end_date,
      //           personalNumber: grievance.personnel_number,
      //           buscd: grievance.business_code
      //         })
      //       });
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // closeFormModal() {
      //   this.personalNumber = '';
      //   this.fullName = '';
      //   this.$nextTick(() => this.$validator.reset())
      // },
      // getColumn() {
      //   this.$axios.get('/objects/alltable/Hukuman/column')
      //     .then(response => {
      //       this.columns = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getLogic() {
      //   this.$axios.get('/objects/oprationsql')
      //     .then(response => {
      //       this.logics = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getCondition() {
      //   this.$axios.get('/objects/conditionsql')
      //     .then(response => {
      //       this.conditions = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getSearchDynamic() {
      //   this.paramsearchforms = {
      //     table: "Hukuman", //harcode sesuai form *referensi table_code*
      //     column: this.columns_model,
      //     query: this.logics_model,
      //     value: this.filters_model,
      //     andor: this.conditions_model
      //   }
      //   console.log(this.paramsearchforms)
      //   this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
      //     .then(response => {
      //       this.grievances = [];
      //       response.data.data.forEach(async (grievance, key) => {
      //         await this.grievances.push({
      //           startDate: grievance.begin_date,
      //           endDate: grievance.end_date,
      //           personalNumber: grievance.personal_number
      //         })
      //       });
      //       console.log(this.grievances);
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // editBank(personalNumber) {
      //   this.openFormModal();
      //   this.getBankaccount(personalNumber);
      // },
      // getBankByGroup() {
      //   this.$axios.get('/bank/getbyGroup/' + this.bankGroup)
      //     .then(response => {
      //       this.bankCodes = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // addNewFormSearch() {
      //   this.searchforms.push({
      //     column: '',
      //     logic: '',
      //     filter: '',
      //     condition: ''
      //   })
      // },
      // deleteFormSearch(key) {
      //   this.searchforms.splice(key, 1)
      // }
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  .is-link {
    float: right;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
