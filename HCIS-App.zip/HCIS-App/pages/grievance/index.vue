<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="grievance/grievance-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-ban" aria-hidden="true"></i> Pembinaan
    </h3>

    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearpersonalNumber">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" v-model="personalNumber_query" disabled>
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="box shadowed" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Pembinaan</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate_form[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('component.begin_date')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.begin_date')" class="help is-danger">
              {{ errors.first('component.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate_form[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('component.end_date')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.end_date')" class="help is-danger">{{ errors.first('component.end_date') }}
            </p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Asal Pembinaan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.asal_hukuman') }">
                <select name="asal_hukuman" class="select" v-model="grievanceSource_form[key]" v-validate="'required'"
                  data-vv-scope="component">
                  <option disabled selected>Pilih</option>
                  <option value="1">Internal</option>
                  <option value="2">Eksternal</option>
                </select>
              </div>
              <p v-show="errors.has('component.asal_hukuman')" class="help is-danger">
                {{ errors.first('component.asal_hukuman') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Pembinaan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.tipe_hukuman') }">
                <select name="tipe_hukuman" class="select" v-model="grievanceType_form[key]" v-validate="'required'"
                  data-vv-scope="component">
                  <option disabled selected>Pilih</option>
                  <option v-for="(grievanceType, key) in grievanceTypes" :key="key" :value="grievanceType.object_id">{{
                    grievanceType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('component.tipe_hukuman')" class="help is-danger">
                {{ errors.first('component.tipe_hukuman') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Pemberi Binaan</label>
            <div class="control">
              <input id="pemberi_hukuman" data-display-mode="dialog" class="input" name="pemberi_hukuman" type="text"
                v-model="grievanceOrganization_form[key]" data-vv-as="pemberi hukuman"
                v-bind:class="{ 'is-danger': errors.has('component.pemberi_hukuman')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.pemberi_hukuman')" class="help is-danger">{{ errors.first('component.pemberi_hukuman')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Ganti Rugi</label>
            <div class="control">
              <input name="denda_hukuman" class="input " type="number" v-model="grievanceMoney_form[key]"
                v-bind:class="{ 'is-danger': errors.has('component.denda_hukuman')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.denda_hukuman')" class="help is-danger"> {{ errors.first('component.denda_hukuman')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Mata Uang</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.mata_uang') }">
                <select name="mata_uang" class="select" v-model="grievanceCurrency_form[key]" v-validate="'required'"
                  data-vv-scope="component">
                  <option disabled selected>Pilih</option>
                  <option v-for="(grievanceCurrency, key) in grievanceCurrencys" :key="key"
                    :value="grievanceCurrency.object_id">{{
                    grievanceCurrency.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('component.mata_uang')" class="help is-danger">
                {{ errors.first('component.mata_uang') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Cara Pembayaran</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.cara_bayar') }">
                <select name="cara_bayar" class="select" v-model="grievancePayment_form[key]" v-validate="'required'"
                  data-vv-scope="component">
                  <option disabled selected>Pilih</option>
                  <option value="1">Via Payroll</option>
                  <option value="2">Cash</option>
                </select>
              </div>
              <p v-show="errors.has('component.cara_bayar')" class="help is-danger">
                {{ errors.first('component.cara_bayar') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Bayar</label>
            <div class="control">
              <input id="tanggal_bayar" data-display-mode="dialog" class="input" name="tanggal_bayar" type="date"
                placeholder="e.g 10-11-2018" v-model="grievancePaymentDate_form[key]" data-vv-as="tanggal bayar"
                v-bind:class="{ 'is-danger': errors.has('component.tanggal_bayar')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.tanggal_bayar')" class="help is-danger">
              {{ errors.first('component.tanggal_bayar') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Referensi</label>
            <div class="control">
              <input name="nomor_referensi" class="input " type="text" v-model="referenceNumber_form[key]"
                v-bind:class="{ 'is-danger': errors.has('component.nomor_referensi')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.nomor_referensi')" class="help is-danger">
              {{errors.first('component.nomor_referensi') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
      <!-- <a class="button is-danger is-rounded" @click="deleteComponents(key)">Hapus</a>  -->
    </div>


    <div class="box">
      <h4 class="subtitle is-4">Formulir Rekening Bank</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Asal Pembinaan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('asal_hukuman') }">
                <select name="asal_hukuman" class="select" v-model="grievanceSource" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option value="1">Internal</option>
                  <option value="2">Eksternal</option>
                </select>
              </div>
              <p v-show="errors.has('asal_hukuman')" class="help is-danger">{{ errors.first('asal_hukuman') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Pembinaan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('tipe_hukuman') }">
                <select name="tipe_hukuman" class="select" v-model="grievanceType" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(grievanceType, key) in grievanceTypes" :key="key" :value="grievanceType.object_id">{{
                    grievanceType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('tipe_hukuman')" class="help is-danger">{{ errors.first('tipe_hukuman') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Pembinaan</label>
            <div class="control">
              <input id="pemberi_hukuman" data-display-mode="dialog" class="input" name="pemberi_hukuman" type="text"
                v-model="grievanceOrganization" data-vv-as="pemberi hukuman"
                v-bind:class="{ 'is-danger': errors.has('pemberi_hukuman')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('pemberi_hukuman')" class="help is-danger">{{ errors.first('pemberi_hukuman')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Ganti Rugi</label>
            <div class="control">
              <input name="denda_hukuman" class="input " type="number" v-model="grievanceMoney"
                v-bind:class="{ 'is-danger': errors.has('denda_hukuman')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('denda_hukuman')" class="help is-danger"> {{ errors.first('denda_hukuman')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Mata Uang</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('mata_uang') }">
                <select name="mata_uang" class="select" v-model="grievanceCurrency" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(grievanceCurrency, key) in grievanceCurrencys" :key="key"
                    :value="grievanceCurrency.object_id">{{
                    grievanceCurrency.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('mata_uang')" class="help is-danger">{{ errors.first('mata_uang') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Cara Pembayaran</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('cara_bayar') }">
                <select name="cara_bayar" class="select" v-model="grievancePayment" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option value="1">Via Payroll</option>
                  <option value="2">Cash</option>
                </select>
              </div>
              <p v-show="errors.has('cara_bayar')" class="help is-danger">{{ errors.first('cara_bayar') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Bayar</label>
            <div class="control">
              <input id="tanggal_bayar" data-display-mode="dialog" class="input" name="tanggal_bayar" type="date"
                placeholder="e.g 10-11-2018" v-model="grievancePaymentDate" data-vv-as="tanggal bayar"
                v-bind:class="{ 'is-danger': errors.has('tanggal_bayar')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('tanggal_bayar')" class="help is-danger">{{ errors.first('tanggal_bayar') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Referensi</label>
            <div class="control">
              <input name="nomor_referensi" class="input " type="text" v-model="referenceNumber"
                v-bind:class="{ 'is-danger': errors.has('nomor_referensi')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('nomor_referensi')" class="help is-danger"> {{
              errors.first('nomor_referensi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>
    <div class="columns">
      <div class="column">
         <a class="button is-pulled-right is-success is-rounded" @click="storeComponent()">Simpan</a>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        key: null,
        buscd: '',
        name: '',
        personalNumber: null,
        cUnit: '',
        cPosition: '',

        startDate: '',
        endDate: '',
        grievanceSource: '',
        grievanceType: '',
        grievanceOrganization: '',
        grievanceMoney: '',
        grievanceCurrency: '',
        grievancePayment: '',
        grievancePaymentDate: '',
        referenceNumber: '',

        startDate_form: [],
        endDate_form: [],
        grievanceSource_form: [],
        grievanceType_form: [],
        grievanceOrganization_form: [],
        grievanceMoney_form: [],
        grievanceCurrency_form: [],
        grievancePayment_form: [],
        grievancePaymentDate_form: [],
        referenceNumber_form: [],

        buscds: [],
        components: [],
        grievanceTypes: [],
        grievanceCurrencys: [],

        personalNumber_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,

        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,
        hakAkses: '',
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Karyawan'
          },
          {
            name: 'Pembinaan'
          },
        ]
      }
    },
    created() {
      this.getGrievanceType();
      this.gerCurrencyType();
      this.getBUSCD();
      this.getHakAkses();
      if (this.personalNumber_query != null) {
        this.getData();
      } else {
        this.getpersonalNumber();
      }
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/GRVAC')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'W') {
              return this.$router.push('/grievance/grievance-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('users/' + this.buscd + '/grievance/' + this.personalNumber)
          .then(response => {
            this.components = [];
            response.data.data.forEach(async (grievance, key) => {
              this.components.push({
                begin_date: grievance.begin_date,
                end_date: grievance.end_date,
                personal_number: grievance.personal_number,
                business_code: grievance.business_code,
                grievancetype: grievance.grievance_type[0].object_id,
                grievancesource: grievance.grievance_source,
                grievanceorganization: grievance.grievance_organization,
                grievancemoney: grievance.grievance_money,
                grievancecurrency: grievance.grievance_currency[0].object_id,
                grievancepayment: grievance.grievance_payment,
                grievancepayment_date: grievance.grievance_payment_date,
                reference_number: grievance.reference_number,
              });
              this.key = key;
              this.startDate_form[this.key] = grievance.begin_date;
              this.endDate_form[this.key] = grievance.end_date;
              this.grievanceType_form[this.key] = grievance.grievance_type[0].object_id;
              this.grievanceSource_form[this.key] = grievance.grievance_source;
              this.grievanceOrganization_form[this.key] = grievance.grievance_organization;
              this.grievanceMoney_form[this.key] = grievance.grievance_money;
              this.grievanceCurrency_form[this.key] = grievance.grievance_currency[0].object_id;
              this.grievancePayment_form[this.key] = grievance.grievance_payment;
              this.grievancePaymentDate_form[this.key] = grievance.grievance_payment_date;
              this.referenceNumber_form[this.key] = grievance.reference_number;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('users/' + this.buscd + '/grievance/' + option.item)
              .then(response => {
                this.components = [];
                response.data.data.forEach((grievance, key) => {
                  this.components.push({
                    begin_date: grievance.begin_date,
                    end_date: grievance.end_date,
                    personal_number: grievance.personal_number,
                    business_code: grievance.business_code,
                    grievance_type: grievance.grievance_type[0].object_id,
                    grievance_source: grievance.grievance_source,
                    grievance_organization: grievance.grievance_organization,
                    grievance_money: grievance.grievance_money,
                    grievance_currency: grievance.grievance_currency[0].object_id,
                    grievance_payment: grievance.grievance_payment,
                    grievance_payment_date: grievance.grievance_payment_date,
                    reference_number: grievance.reference_number,
                  });
                  this.key = key;
                  this.startDate_form[this.key] = grievance.begin_date;
                  this.endDate_form[this.key] = grievance.end_date;
                  this.grievanceType_form[this.key] = grievance.grievance_type[0].object_id;
                  this.grievanceSource_form[this.key] = grievance.grievance_source;
                  this.grievanceOrganization_form[this.key] = grievance.grievance_organization;
                  this.grievanceMoney_form[this.key] = grievance.grievance_money;
                  this.grievanceCurrency_form[this.key] = grievance.grievance_currency[0].object_id;
                  this.grievancePayment_form[this.key] = grievance.grievance_payment;
                  this.grievancePaymentDate_form[this.key] = grievance.grievance_payment_date;
                  this.referenceNumber_form[this.key] = grievance.reference_number;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }

        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;

          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              personal_number: this.personalNumber,
              business_code: this.buscd,
              grievance_type: this.grievanceType,
              grievance_source: this.grievanceSource,
              grievance_organization: this.grievanceOrganization,
              grievance_money: this.grievanceMoney,
              grievance_currency: this.grievanceCurrency,
              grievance_payment: this.grievancePayment,
              grievance_payment_date: this.grievancePaymentDate,
              reference_number: this.referenceNumber,
            });
            this.components.forEach((grievance, key) => {
              this.key = key;
              this.startDate_form[this.key] = grievance.begin_date;
              this.endDate_form[this.key] = grievance.end_date;
              this.grievanceType_form[this.key] = grievance.grievance_type;
              this.grievanceSource_form[this.key] = grievance.grievance_source;
              this.grievanceOrganization_form[this.key] = grievance.grievance_organization;
              this.grievanceMoney_form[this.key] = grievance.grievance_money;
              this.grievanceCurrency_form[this.key] = grievance.grievance_currency;
              this.grievancePayment_form[this.key] = grievance.grievance_payment;
              this.grievancePaymentDate_form[this.key] = grievance.grievance_payment_date;
              this.referenceNumber_form[this.key] = grievance.reference_number;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.personalNumber_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((grievances, index1) => {
                Object.assign(this.components[index1], {
                  begin_date: this.startDate_form[index1],
                  end_date: this.endDate_form[index1],
                  grievance_type: this.grievanceType_form[index1],
                  grievance_source: this.grievanceSource_form[index1],
                  grievance_organization: this.grievanceOrganization_form[index1],
                  grievance_money: this.grievanceMoney_form[index1],
                  grievance_currency: this.grievanceCurrency_form[index1],
                  grievance_payment: this.grievancePayment_form[index1],
                  grievance_payment_date: this.grievancePaymentDate_form[index1],
                  reference_number: this.referenceNumber_form[index1],
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/grievance/' + this.personalNumber, this.components)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data hukuman.',
                        'sukses'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((grievances, index1) => {
              Object.assign(this.components[index1], {
                begin_date: this.startDate_form[index1],
                end_date: this.endDate_form[index1],
                grievance_type: this.grievanceType_form[index1],
                grievance_source: this.grievanceSource_form[index1],
                grievance_organization: this.grievanceOrganization_form[index1],
                grievance_money: this.grievanceMoney_form[index1],
                grievance_currency: this.grievanceCurrency_form[index1],
                grievance_payment: this.grievancePayment_form[index1],
                grievance_payment_date: this.grievancePaymentDate_form[index1],
                reference_number: this.referenceNumber_form[index1],
              });
            });
            swal({
              title: 'Apakah anda yakin ingin menyimpan data ini?',
              text: 'Anda tidak dapat membatalkan',
              type: 'peringatan',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/grievance/' + this.personalNumber, this.components)
                  .then(response => {
                    swal(
                      'Data tersimpan!',
                      'Sukses menyimpan data hukuman.',
                      'sukses'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          this.clearpersonalNumber()
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        this.components.forEach((grievance, key) => {
          this.key = key;
          this.startDate_form[this.key] = grievance.begin_date;
          this.endDate_form[this.key] = grievance.end_date;
          this.grievanceType_form[this.key] = grievance.grievance_type;
          this.grievanceSource_form[this.key] = grievance.grievance_source;
          this.grievanceOrganization_form[this.key] = grievance.grievance_organization;
          this.grievanceMoney_form[this.key] = grievance.grievance_money;
          this.grievanceCurrency_form[this.key] = grievance.grievance_currency;
          this.grievancePayment_form[this.key] = grievance.grievance_payment;
          this.grievancePaymentDate_form[this.key] = grievance.grievance_payment_date;
          this.referenceNumber_form[this.key] = grievance.reference_number;

        })
      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.startDate = '';
        this.endDate = '';
        this.startDate = '';
        this.endDate = '';
        this.grievanceType = '';
        this.grievanceSource = '';
        this.grievanceOrganization = '';
        this.grievanceMoney = '';
        this.grievanceCurrency = '';
        this.grievancePayment = '';
        this.grievancePaymentDate = '';
        this.referenceNumber = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getpersonalNumber() {
        this.$axios.get('/users/personal')
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/GRVAC')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getGrievanceType() {
        this.$axios.get('/objects/grievancetype')
          .then(response => {
            this.grievanceTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      gerCurrencyType() {
        this.$axios.get('/objects/currencytype')
          .then(response => {
            this.grievanceCurrencys = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block; 
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
