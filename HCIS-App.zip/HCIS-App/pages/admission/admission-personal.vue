<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-user" aria-hidden="true"></i> Personal
    </h3>
    <div class="box has-text-white has-background-danger">
      Personal
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berlaku</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">s.d</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">NIK</label>
            <div class="control">
              <input class="input" type="text" placeholder="Nik">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Name">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
        Detail Karyawan BUMN </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Panggilan</label>
            <div class="control">
              <input class="input" type="text" placeholder="Nick Name">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tempat Lahir</label>
            <div class="control">
              <input class="input" type="text" placeholder="Tempat Lahir">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Lahir</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
              <label class="label">Jenis Kelamin</label>
              <div class="control">
                <label class="radio">
                  <input name="gender" type="radio" v-model="gender" value="L" v-validate="'required|included:L,P'">
                  Laki-laki
                </label>
                <label class="radio">
                  <input name="gender" type="radio" v-model="gender" value="P">
                  Perempuan
                </label>
              </div>
              <p v-show="errors.has('gender')" class="help is-danger">{{ errors.first('gender') }}</p>
            </div>
        </div>
        <div class="column is-4">
          <div class="field">
              <label class="label">Agama</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select>
                    <option disabled="disabled" selected="selected">Choose</option>
                    <option>Islam</option>
                    <option>Kristen</option>
                    <option>Katolik</option>
                    <option>Hindu</option>
                    <option>Budha</option>
                    <option>Kong Hu Chu</option>
                  </select>
                </div>
              </div>
            </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
              <label class="label">Bahasa</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select>
                    <option disabled="disabled" selected="selected">Choose</option>
                    <option>Indonesian</option>
                    <option>English</option>
                  </select>
                </div>
              </div>
            </div>
        </div>
        <div class="column is-4">
          <div class="field">
              <label class="label">Kewarganegaraan</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select>
                    <option disabled="disabled" selected="selected">Choose</option>
                    <option>Warga Negara Indonesia</option>
                    <option>Warga Negara Asing</option>
                  </select>
                </div>
              </div>
            </div>
        </div>
      </div>
      <div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Suku Bangsa</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select>
                    <option disabled="disabled" selected="selected">Choose</option>
                    <option>Jawa</option>
                    <option>Sunda</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Golongan Darah</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select>
                    <option disabled="disabled" selected="selected">Choose</option>
                    <option>A</option>
                    <option>B</option>
                    <option>AB</option>
                    <option>O</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Rhesus</label>
              <div class="control">
              <input class="input" type="text" placeholder="Rhesus">
            </div>
            </div>
          </div>
        </div>
        <div class="columns">
          <div class="column is-4">
            <div class="field">
              <label class="label">Status Pernikahan</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select>
                    <option disabled="disabled" selected="selected">Choose</option>
                    <option>Lajang</option>
                    <option>Menikah</option>
                    <option>Duda</option>
                    <option>Janda</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Tanggal Pernikahan</label>
              <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
            </div>
          </div>
          <div class="column is-4">
            <div class="field">
              <label class="label">Nik Pemberi Referensi</label>
              <div class="control">
                <input class="input" type="number" placeholder="Nik Pemberi Referensi">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Data Diffable
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berlaku</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">s.d</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Jenis Diffable</label>
            <div class="control">
                <div class="select is-fullwidth">
                  <select>
                    <option disabled="disabled" selected="selected">Choose</option>
                    <option>Option 1</option>
                    <option>Option 2</option>
                    <option>Option 3</option>
                  </select>
                </div>
              </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-12">
          <div class="field">
            <label class="label">Keterangan</label>
            <div class="control">
              <input class="input" type="text" placeholder="Keterangan">
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- <a class="button is-success is-rounded">Save</a>
    <a class="button is-danger is-rounded">Reset</a> -->
    <a class="button is-link is-rounded">Continue</a>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Penerimaan'
          },
          {
            name: 'Pribadi'
          },
        ]
      }
    },
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
