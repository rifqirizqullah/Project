<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="recurring/recurring-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-user" aria-hidden="true"></i> Bulanan
    </h3>
    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="personalNumber_query" disabled>
            </div>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Alamat</h4>
      <hr>
      <div class="columns">
        <div class="column is-6">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-6">
          <div class="field">
            <label class="label">Tanggal Berakhir</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Komponen Penghasilan</label>
            <div class="control">
              <div class="select " v-bind:class="{ 'is-danger': errors.has('wage_type') }">
                <select name="wage_type" class="select" v-model="wageType" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(wage, key) in wages" :key="key" :value="wage.wage_type">{{
                        wage.wage_name
                        }}</option>
                </select>
              </div>
              <p v-show="errors.has('wage_type')" class="help is-danger">{{ errors.first('wage_type')
                    }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Jumlah</label>
            <div class="control">
              <input name="amount" class="input " placeholder="e.g. 00215" type="number" v-model="amount"
                v-bind:class="{ 'is-danger': errors.has('amount')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('amount')" class="help is-danger"> {{ errors.first('amount')}}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Alasan Perubahan</label>
            <div class="control">
              <div class="select " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                <select name="nama_perusahaan" class="select" v-model="changeReason" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(reasonn, key) in reasons" :key="key" :value="reasonn.object_code">{{
                        reasonn.object_name
                        }}</option>
                </select>
              </div>
              <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan')
                    }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded" @click="tambahComponent()">Tambah</a>
        </div>
      </div>
    </div>

    <div class="box has-text-white has-background-danger">
      List Bulanan
    </div>
    <div class="box" v-for="(component, key) in components" :key="key">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="start_input[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Berakhir</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="end_input[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Komponen Penghasilan</label>
            <div class="control">
              <div class="select " v-bind:class="{ 'is-danger': errors.has('wage_type') }">
                <select name="wage_type" class="select" v-model="wage_type_input[key]" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(wage, key) in wages" :key="key" :value="wage.wage_type">{{
                        wage.wage_name
                        }}</option>
                </select>
              </div>
              <p v-show="errors.has('wage_type')" class="help is-danger">{{ errors.first('wage_type')
                    }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Jumlah</label>
            <div class="control">
              <input name="amount" class="input " placeholder="e.g. 00215" type="number" v-model="amount_input[key]"
                v-bind:class="{ 'is-danger': errors.has('amount')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('amount')" class="help is-danger"> {{ errors.first('amount')}}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Alasan Perubahan</label>
            <div class="control">
              <div class="select " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                <select name="nama_perusahaan" class="select" v-model="change_reason_input[key]"
                  v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(reasonn, key) in reasons" :key="key" :value="reasonn.object_code">{{
                        reasonn.object_name
                        }}</option>
                </select>
              </div>
              <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan')
                    }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <a class="button is-danger is-rounded" @click="deleteComponents(key)">Hapus</a>
        </div>
      </div>
    </div>



    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Reset</a>
    <a class="button is-link is-rounded">Kembali</a> -->

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue'
  Vue.use(VueAutosuggest);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        // nikAuth: this.$auth.user.nik,
        // nik: null,
        key: null,
        personalNumber: null,
        name: '',
        cUnit: '',
        cPosition: '',
        startDate: '',
        endDate: '',
        wageType: '',
        changeReason: '',
        amount: '',
        buscd: '',
        change_reason: '',
        wage: '',
        options: [{
          data: []
        }],
        limit: 10,
        filteredOptions: [],
        reasons: [],
        wages: [],
        buscds: [],
        components: [],
        start_input: [],
        components_input: [],
        end_input: [],
        amount_input: [],
        change_reason_input: [],
        wage_type_input: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        personalNumber_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Payroll'
          },
          {
            name: 'Bulanan'
          },
        ]
      }
    },
    created() {
      this.getBUSCD();
      this.getReason();
      this.getWage();
      if (this.personalNumber_query != null) {
        this.getData();
      }
    },
    methods: {
      getData() {
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('/users/' + this.buscd + '/recurring/' + this.personalNumber)
          .then(response => {
            this.components = [];
            response.data.data.forEach((user, key) => {
              this.components.push({
                begin_date: user.begin_date,
                end_date: user.end_date,
                amount: user.amount,
                wage_type: user.wage_type,
                change_reason: user.change_reason,
                business_code: user.business_code,
              });
              this.key = key;
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
              this.amount_input[this.key] = user.amount;
              this.wage_type_input[this.key] = user.wage_type;
              this.change_reason_input[this.key] = user.change_reason;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('/users/' + this.buscd + '/recurring/' + this.personalNumber)
              .then(response => {
                this.components = [];
                response.data.data.forEach((user, key) => {
                  this.components.push({
                    begin_date: user.begin_date,
                    end_date: user.end_date,
                    wage_type: user.wage_type[0].wage_type,
                    amount: user.amount,
                    change_reason: user.change_reason[0].object_id,
                    business_code: user.business_code,
                  });
                  this.key = key;
                  this.start_input[this.key] = user.begin_date;
                  this.end_input[this.key] = user.end_date;
                  this.wage_type_input[this.key] = user.wage_type[0].wage_type;
                  this.amount_input[this.key] = user.amount;
                  this.change_reason_input[this.key] = user.change_reason[0].object_id;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/RCCRG')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      clearNik() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.personalNumber = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.wageType = '';
        this.amount = '';
        this.changeReason = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getReason() {
        this.$axios.get('/users/otype/CHGRN/object')
          .then(response => {
            this.reasons = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getWage() {
        this.$axios.get('/users/wagetype')
          .then(response => {
            this.wages = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              personal_number: this.personalNumber,
              business_code: this.buscd,
              begin_date: this.startDate,
              end_date: this.endDate,
              wage_type: this.wageType,
              amount: this.amount,
              change_reason: this.changeReason,
            });
            this.components.forEach((user, key) => {
              this.key = key;
              // this.$axios.get('users/' + this.buscd + '/selectfamily/' + this.personalNumber + '/type/' + familyIdentity.family_type)
              //   .then(response => {
              //     this.valueFT1[this.key] = response.data.data;
              //     this.$forceUpdate();
              //   })
              this.start_input[this.key] = user.begin_date;
              this.end_input[this.key] = user.end_date;
              this.wage_type_input[this.key] = user.wage_type;
              this.amount_input[this.key] = user.amount;
              this.change_reason_input[this.key] = user.change_reason;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.personalNumber_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components_input = [];
              this.components.forEach((childrens, index1) => {
                this.components_input.push({
                  personal_number: this.personalNumber,
                  begin_date: this.start_input[index1],
                  end_date: this.end_input[index1],
                  wage_type: this.wage_type_input[index1],
                  amount: this.amount_input[index1],
                  change_reason: this.change_reason_input[index1],
                  business_code: this.buscd,
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('/users/' + this.buscd + '/recurring/' + this.personalNumber, this
                      .components_input)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data identity keluarga.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components_input = [];
            this.components.forEach((childrens, index1) => {
              this.components_input.push({
                personal_number: this.personalNumber,
                business_code: this.buscd,
                begin_date: this.start_input[index1],
                end_date: this.end_input[index1],
                wage_type: this.wage_type_input[index1],
                amount: this.amount_input[index1],
                change_reason: this.change_reason_input[index1],
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('/users/' + this.buscd + '/recurring/' + this.personalNumber, this
                    .components_input)
                  .then(response => {
                    swal(
                      'Saved!',
                      'Sukses menyimpan data identity keluarga.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          // this.clearpersonalNumber()
        }
      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.buscd = '';
        this.startDate = '';
        this.endDate = '';
        this.wageType = '';
        this.amount = '';
        this.changeReason = '';
        this.$nextTick(() => this.$validator.reset());
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        this.components.forEach((user, key) => {
          this.key = key;
          this.start_input[this.key] = user.begin_date;
          this.end_input[this.key] = user.end_date;
          this.amount_input[this.key] = user.amount;
          this.wage_type_input[this.key] = user.wage_type;
          this.change_reason_input[this.key] = user.change_reason;
        })
      },
    }
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }


  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
