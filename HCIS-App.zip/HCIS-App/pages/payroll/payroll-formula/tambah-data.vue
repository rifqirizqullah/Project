<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="/payroll/payroll-formula" class="button is-success is-rounded is-pulled-right"><span> List Payroll
        Formula </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-user" aria-hidden="true"></i> Formula Payroll
    </h3>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="control">
              <div class="select is-fullwidth " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                <select v-if="id != null" name="nama_perusahaan" class="select" v-model="company"
                  v-validate="'required'" disabled>
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in companies" :key="key" :value="company.business_code">{{
                    company.company_name
                    }}</option>
                </select>
                <select v-else name="nama_perusahaan" class="select" v-model="company" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in companies" :key="key" :value="company.business_code">{{
                    company.company_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="begin_date" data-vv-as="begin_date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="end_date" data-vv-as="end_date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Jenis Kelamin</label>
            <div class="control">
              <div class="select is-fullwidth " v-bind:class="{ 'is-danger': errors.has('gender') }">
                <select name="gender" class="select" v-model="gender" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in genders" :key="key" :value="company.object_code">{{
                    company.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('gender')" class="help is-danger">{{ errors.first('gender') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Status Pernikahan</label>
            <div class="control">
              <div class="select is-fullwidth " v-bind:class="{ 'is-danger': errors.has('marital_status') }">
                <select name="marital_status" class="select" v-model="marital_status" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in marital_statuses" :key="key" :value="company.object_code">{{
                    company.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('marital_status')" class="help is-danger">{{ errors.first('marital_status') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Komponen Penghasilan </label>
            <div class="control">
              <div class="select is-fullwidth " v-bind:class="{ 'is-danger': errors.has('wage_type') }">
                <select name="wage_type" class="select" v-model="wage_type" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in wageTypes" :key="key" :value="company.object_code">{{
                    company.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('wage_type')" class="help is-danger">{{ errors.first('wage_type') }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Masa Kerja Minimal</label>
            <div class="control">
              <input data-display-mode="dialog" class="input" name="min_masakerja" type="number" v-model="min_masakerja"
                v-bind:class="{ 'is-danger': errors.has('min_masakerja')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('min_masakerja')" class="help is-danger">{{ errors.first('min_masakerja') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Masa Kerja Maksimal</label>
            <div class="control">
              <input data-display-mode="dialog" class="input" name="max_masakerja" type="number" v-model="max_masakerja"
                v-bind:class="{ 'is-danger': errors.has('max_masakerja')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('max_masakerja')" class="help is-danger">{{ errors.first('max_masakerja') }}</p>
          </div>
        </div>
      </div>
      <div class="columns is-multiline">
        <div class="column is-4">
          <div class="field">
            <label class="label">Grup Status Karyawan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.employee_group') }">
                <select name="employee_group" class="select" v-model="employee_group" v-validate="'required'"
                  data-vv-scope="form" @change="getSubGroup()">
                  <option disabled selected>Choose</option>
                  <option v-for="(employeeGroup, key) in employeeGroups" :key="key" :value="employeeGroup.object_code">{{
                    employeeGroup.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.employee_group')" class="help is-danger">{{
                errors.first('form.employee_group') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Sub Grup Status Karyawan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.subGroup') }">
                <select name="form.subGroup" class="select" v-model="employee_sub_group" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Choose</option>
                  <option v-for="(subGroup, key) in employeeSubGroups" :key="key" :value="subGroup.object_id">{{
                    subGroup.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.subGroup')" class="help is-danger">{{ errors.first('form.subGroup') }}</p>
            </div>
          </div>
        </div>
      </div>

      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanda</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('assign') }">
                <select name="assign" class="select" v-model="assign" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(subGroup, key) in assigns" :key="key" :value="subGroup.object_code">{{
                    subGroup.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('assign')" class="help is-danger">{{ errors.first('assign') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Jumlah</label>
            <div class="control">
              <input v-if="porsi > 0" data-display-mode="dialog" class="input" name="amount" type="number" v-model="amount"
                v-bind:class="{ 'is-danger': errors.has('amount')}" v-validate="'required'" readonly>
              <input v-else data-display-mode="dialog" class="input" name="amount" type="number" v-model="amount"
                v-bind:class="{ 'is-danger': errors.has('amount')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('amount')" class="help is-danger">{{ errors.first('amount') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Porsi</label>
            <div class="control">
              <input v-if="amount > 0" data-display-mode="dialog" class="input" name="porsi" type="number" v-model="porsi"
                v-bind:class="{ 'is-danger': errors.has('porsi')}" v-validate="'required'" readonly />
              <input v-else data-display-mode="dialog" class="input" name="porsi" type="number" v-model="porsi"
                v-bind:class="{ 'is-danger': errors.has('porsi')}" v-validate="'required'" />
            </div>
            <p v-show="errors.has('porsi')" class="help is-danger">{{ errors.first('porsi') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Referensi Komponen Penghasilan</label>
            <div class="control">
              <div class="select is-fullwidth " v-bind:class="{ 'is-danger': errors.has('reference_wage_type') }">
                <select name="reference_wage_type" class="select" v-model="reference_wage_type" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(company, key) in wageTypes" :key="key" :value="company.object_code">{{
                    company.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('reference_wage_type')" class="help is-danger">
                {{ errors.first('reference_wage_type') }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <h3 class=" is-3 subtitle">Organisasi</h3>
    <div class="box">
      <div class="columns is-multiline">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi</label>
            <div class="control">
              <treeselect v-model="position" :multiple="false" :options="data" @input="tes()" />
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Job</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="job" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="organization" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Pusat Biaya</label>
            <div class="control">

              <input class="input" type="hidden" placeholder="" v-model="costCenter">
              <input class="input" type="text" placeholder="" v-model="costCenter_name" disabled>

            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Area Payroll </label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('payArea') }">
                <select name="payArea" class="select" v-model="payArea" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(city, key) in payAreas" :key="key" :value="city.payrollarea">{{
                    city.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('payArea')" class="help is-danger">{{ errors.first('payArea') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Bisnis Area</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.busArea') }">
                <select name="busArea" class="select" v-model="busArea" v-validate="'required'" data-vv-scope="form">
                  <!-- <select name="busArea" class="select" v-model="busArea" v-validate="'required'" data-vv-scope="form"
                  @change="getBusAreaChild()"> -->
                  <option disabled selected>Choose</option>
                  <option v-for="(employeeGroup, key) in busAreas" :key="key" :value="employeeGroup.object_code">{{
                    employeeGroup.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.busArea')" class="help is-danger">{{ errors.first('form.busArea') }}</p>
            </div>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Kelompok Pengelola Karyawan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('personal_area') }">
                <select name="personal_area" class="select" v-model="personal_area" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(subGroup, key) in personalAreas" :key="key" :value="subGroup.object_code">{{
                    subGroup.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('personal_area')" class="help is-danger">{{ errors.first('personal_area') }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Sub Kelompok Pengelola Karyawan </label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('personal_sub_area') }">
                <select name="personal_sub_area" class="select" v-model="personal_sub_area" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(subGroup, key) in personalSubAreas" :key="key" :value="subGroup.id">{{
                    subGroup.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('personal_sub_area')" class="help is-danger">{{ errors.first('personal_sub_area') }}
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>

    <h3 class="is-3 subtitle">Band Posisi</h3>
    <div class="box">
      <div class="columns is-multiline">

        <div class="column is-4">
          <div class="field">
            <label class="label">Area Level Posisi</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('ps_area') }">
                <select name="ps_area" class="select" v-model="bndArea" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndArea, key) in bndAreas" :key="key" :value="bndArea.object_code">{{
                    bndArea.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('ps_area')" class="help is-danger">{{errors.first('ps_area')
                }}</p>
            </div>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Level Posisi</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('bnd_type') }">
                <select name="bnd_type" class="select" v-model="bndType" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndType, key) in bndTypes" :key="key" :value="bndType.object_code">{{
                    bndType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bnd_type')" class="help is-danger">{{errors.first('bnd_type')
                }}</p>
            </div>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Level Posisi</label>

            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('bnd_level') }">
                <select name="bnd_level" class="select" v-model="bndLevel" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(psLevel, key) in bndLevels" :key="key" :value="psLevel.object_code">{{
                    psLevel.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bnd_level')" class="help is-danger">{{errors.first('bnd_level')
                }}</p>
            </div>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Grup Level Posisi</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('bnd_group') }">
                <select name="bnd_group" class="select" v-model="bndGroup" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndGroup, key) in bndGroups" :key="key" :value="bndGroup.object_code">{{
                    bndGroup.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bnd_group')" class="help is-danger">{{errors.first('bnd_group')
                }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <h3 class="subtitle is-3">Band Individu</h3>
    <div class="box">
      <div class="columns is-multiline">

        <div class="column is-4">
          <div class="field">
            <label class="label">Area Level Individu</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('ps_area2') }">
                <select name="ps_area2" class="select" v-model="bndArea2" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndArea, key) in bndAreas" :key="key" :value="bndArea.object_code">{{
                    bndArea.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('ps_area2')" class="help is-danger">{{errors.first('ps_area2')
                }}</p>
            </div>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Level Individu</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('bnd_type2') }">
                <select name="bnd_type2" class="select" v-model="bndType2" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndType, key) in bndTypes" :key="key" :value="bndType.object_code">{{
                    bndType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bnd_type2')" class="help is-danger">{{errors.first('bnd_type2')
                }}</p>
            </div>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Level Individu</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('bnd_level2') }">
                <select name="bnd_level2" class="select" v-model="bndLevel2" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(psLevel, key) in bndLevels" :key="key" :value="psLevel.object_code">{{
                    psLevel.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bnd_level2')" class="help is-danger">{{errors.first('bnd_level2')
                }}</p>
            </div>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Grup Level Individu</label>

            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('bnd_group2') }">
                <select name="bnd_group2" class="select" v-model="bndGroup2" v-validate="'required'">
                  <option disabled selected>Choose</option>
                  <option v-for="(bndGroup, key) in bndGroups" :key="key" :value="bndGroup.object_code">{{
                    bndGroup.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('bnd_group2')" class="help is-danger">{{errors.first('bnd_group2')
                }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>


    <a class="button is-success is-rounded" @click="saveData()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Reset</a>
    <a class="button is-link is-rounded">Kembali</a> -->

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import Treeselect from '@riophae/vue-treeselect';
  import '@riophae/vue-treeselect/dist/vue-treeselect.css';
  export default {
    components: {
      Breadcrumb,
      Treeselect
    },
    data() {
      return {
        company: null,
        begin_date: null,
        end_date: null,
        gender: null,
        marital_status: null,
        wage_type: null,
        reference_wage_type: null,
        min_masakerja: null,
        max_masakerja: null,
        employee_group: null,
        employee_sub_group: null,
        personal_area: null,
        personal_sub_area: null,
        assign: null,
        porsi: 0,
        amount: 0,
        position: null,
        job: '',
        organization: '',
        costCenter: '',
        costCenter_name: '',
        payArea: null,
        busArea: null,
        bndType: null,
        bndArea: null,
        bndGroup: null,
        bndLevel: null,
        bndType2: null,
        bndArea2: null,
        bndGroup2: null,
        bndLevel2: null,
        bndTypes: [],
        bndAreas: [],
        bndGroups: [],
        bndLevels: [],
        companies: [],
        genders: [],
        marital_statuses: [],
        wageTypes: [],
        personalAreas: [],
        personalSubAreas: [],
        assigns: [],
        employeeGroups: [],
        employeeSubGroups: [],
        data: [],
        payAreas: [],
        busAreas: [],
        id: this.$route.query.id,
        company_query: this.$route.query.buscd,
        type_organizational: '',
        position_tree: null,
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Payroll'
          },
          {
            name: 'Formula Payroll'
          },
          {
            name: 'Tambah Data'
          },
        ]
      }
    },
    created() {
      this.getCompany();
      this.getKelamin();
      this.getKawin();
      this.getWage();
      this.getEmployeeGroup();
      this.getPersonalArea();
      this.getPersonalSubArea();
      this.getAssign();
      this.getPayArea();
      this.getBusArea();
      this.getBndType();
      this.getBndArea();
      this.getBndGroup();
      this.getBndLevel();
      this.getTree();
      if (this.id != null) {
        this.getData();
      }
    },
    methods: {
      getData() {
        this.$axios.get(this.company_query + '/payrollformula/' + this.id)
          .then(response => {
            this.company = response.data.data[0].business_code;
            this.begin_date = response.data.data[0].begin_date;
            this.end_date = response.data.data[0].end_date;
            this.gender = response.data.data[0].gender[0].object_id;
            this.marital_status = response.data.data[0].marital_status[0].object_id;
            this.wage_type = response.data.data[0].wage_type[0].wage_type;
            this.reference_wage_type = response.data.data[0].reference_wage_type[0].wage_type;
            this.min_masakerja = response.data.data[0].min_masakerja;
            this.max_masakerja = response.data.data[0].max_masakerja;
            this.position_tree = 1;
            this.employee_group = response.data.data[0].employee_group[0].object_id;
            this.$axios.get('/objects/employeesubgroup/' + this.employee_group)
              .then(response => {
                this.employeeSubGroups = response.data.data;
                this.$forceUpdate();
              })
            this.employee_sub_group = response.data.data[0].employee_sub_group[0].object_id;
            this.personal_area = response.data.data[0].personnel_area[0].object_id;
            this.personal_sub_area = response.data.data[0].personnel_sub_area[0].id;
            this.assign = response.data.data[0].assign[0].object_id;
            this.porsi = response.data.data[0].porsi;
            this.amount = response.data.data[0].amount;
            this.position = response.data.data[0].position_id[0].organizational_id;
            this.job = response.data.data[0].job[0].organizational_id;
            this.organization = response.data.data[0].organization[0].organizational_id;
            this.costCenter = response.data.data[0].cost_center[0].organizational_id;
            this.costCenter_name = response.data.data[0].cost_center[0].organizational_name;
            this.payArea = response.data.data[0].payroll_area[0].payrollarea;
            this.busArea = response.data.data[0].business_area[0].object_id;
            this.bndType = response.data.data[0].ps_type[0].object_id;
            this.bndArea = response.data.data[0].ps_area[0].object_id;
            this.bndGroup = response.data.data[0].ps_group[0].object_id;
            this.bndLevel = response.data.data[0].ps_level[0].object_id;
            this.bndType2 = response.data.data[0].individu_type[0].object_id;
            this.bndArea2 = response.data.data[0].individu_area[0].object_id;
            this.bndGroup2 = response.data.data[0].individu_group[0].object_id;
            this.bndLevel2 = response.data.data[0].individu_level[0].object_id;
          })
          .catch(e => {
            console.log(e)
          });
      },
      saveData() {
        if (this.id != null) {
          this.updateComponent();
        } else {
          this.storeComponent();
        }
      },
      storeComponent() {
        swal({
          title: 'Are you sure to save?',
          text: "You won't be able to revert this!",
          type: 'warning',
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.post('payrollformula', {
                begin_date: this.begin_date,
                end_date: this.end_date,
                business_code: this.company,
                wage_type: this.wage_type,
                cost_center: this.costCenter,
                organization: this.organization,
                job: this.job,
                business_area: this.busArea,
                position_id: this.position,
                employee_group: this.employee_group,
                employee_sub_group: this.employee_sub_group,
                payroll_area: this.payArea,
                ps_type: this.bndType,
                ps_area: this.bndArea,
                ps_group: this.bndGroup,
                ps_level: this.bndLevel,
                individu_type: this.bndType2,
                individu_area: this.bndArea2,
                individu_group: this.bndGroup2,
                individu_level: this.bndLevel2,
                min_masakerja: this.min_masakerja,
                max_masakerja: this.max_masakerja,
                assign: this.assign,
                gender: this.gender,
                marital_status: this.marital_status,
                personnel_area: this.personal_area,
                personnel_sub_area: this.personal_sub_area,
                amount: this.amount,
                porsi: this.porsi,
                reference_wage_type: this.reference_wage_type
              })
              .then(response => {
                swal(
                  'Saved!',
                  'Successfully saved.',
                  'success'
                );
                this.clearData()
              })
              .catch(e => {
                console.log(e);
              })
          }
        });
      },
      updateComponent() {
        swal({
          title: 'Are you sure to save?',
          text: "You won't be able to revert this!",
          type: 'warning',
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.post(this.company + '/payrollformula/' + this.id, {
                begin_date: this.begin_date,
                end_date: this.end_date,
                business_code: this.company,
                wage_type: this.wage_type,
                cost_center: this.costCenter,
                organization: this.organization,
                job: this.job,
                business_area: this.busArea,
                position_id: this.position,
                employee_group: this.employee_group,
                employee_sub_group: this.employee_sub_group,
                payroll_area: this.payArea,
                ps_type: this.bndType,
                ps_area: this.bndArea,
                ps_group: this.bndGroup,
                ps_level: this.bndLevel,
                individu_type: this.bndType2,
                individu_area: this.bndArea2,
                individu_group: this.bndGroup2,
                individu_level: this.bndLevel2,
                min_masakerja: this.min_masakerja,
                max_masakerja: this.max_masakerja,
                assign: this.assign,
                gender: this.gender,
                marital_status: this.marital_status,
                personnel_area: this.personal_area,
                personnel_sub_area: this.personal_sub_area,
                amount: this.amount,
                porsi: this.porsi,
                reference_wage_type: this.reference_wage_type
              })
              .then(response => {
                swal(
                  'Saved!',
                  'Successfully saved.',
                  'success'
                );
                //this.clearData()
              })
              .catch(e => {
                console.log(e);
              })
          }
        });
      },
      tes() {
        if (this.company == null) {
          alert('isi nama perusahaan terlebih dahulu !');
        } else {
          this.$axios.get('/users/' + this.company + '/treeOrganization?stext=' + this.position +
              '&relationalparentchild=parent-child')
            .then(response => {
              this.type_organizational = response.data.data.organizational_type;
              if (this.type_organizational == '04') {
                this.$axios.get('/users/' + this.company + '/getUnitandJob?stext=' + this.position)
                  .then(response => {
                    this.job = response.data.data.job.organizational_id;
                    this.organization = response.data.data.unit.organizational_id;
                  })
                  .catch(e => {
                    console.log(e)
                  });
                this.$axios.get(this.company + '/getCostCenter?stext=' + this.position)
                  .then(response => {
                    this.costCenter = response.data.data.costcenter.organizational_id;
                    this.costCenter_name = response.data.data.costcenter.organizational_name;
                  })
                  .catch(e => {
                    console.log(e)
                  });
                if (this.position_tree == null) {
                  this.$axios.get('/users/' + this.company + '/accountAssignment/' + this.type_organizational +
                      '/Data/' + this.position)
                    .then(response => {
                      this.busArea = response.data.data[0].business_area[0].object_id;
                      this.personal_area = response.data.data[0].personnel_area[0].object_id;
                      this.personal_sub_area = response.data.data[0].personnel_sub_area[0].id;
                      this.payArea = response.data.data[0].payrollarea[0].payrollarea;
                    })
                    .catch(e => {
                      console.log(e)
                    });
                }

              } else {
                if (this.position != null) {
                  alert('bukan posisi !');
                  this.organization = '';
                  this.job = '';
                  this.position = null;
                  this.costCenter = null;
                  this.costCenter_name = null;
                }
              }
            })
            .catch(e => {
              console.log(e)
            });
        }
      },
      clearData() {

        this.begin_date = null;
        this.end_date = null;
        this.gender = null;
        this.marital_status = null;
        this.wage_type = null;
        this.reference_wage_type = null;
        this.min_masakerja = null;
        this.max_masakerja = null;
        this.employee_group = null;
        this.employee_sub_group = null;
        this.personal_area = null;
        this.personal_sub_area = null;
        this.assign = null;
        this.porsi = null;
        this.amount = null;
        this.position = null;
        this.job = '';
        this.organization = '';
        this.costCenter = '';
        this.costCenter_name = '';
        this.payArea = null;
        this.busArea = null;
        this.bndType = null;
        this.bndArea = null;
        this.bndGroup = null;
        this.bndLevel = null;
        this.bndType2 = null;
        this.bndArea2 = null;
        this.bndGroup2 = null;
        this.bndLevel2 = null;
        this.$nextTick(() => this.$validator.reset());
      },
      getBndType() {
        this.$axios.get('/users/otype/PSTYP/object ')
          .then(response => {
            this.bndTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBndArea() {
        this.$axios.get('/users/otype/PSARE/object ')
          .then(response => {
            this.bndAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBndGroup() {
        this.$axios.get('/users/otype/PSGRP/object ')
          .then(response => {
            this.bndGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBndLevel() {
        this.$axios.get('/users/otype/PSLVL/object ')
          .then(response => {
            this.bndLevels = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPayArea() {
        this.$axios.get('/users/payrollArea')
          .then(response => {
            this.payAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getBusArea() {
        this.$axios.get('/users/otype/BUSAR/object')
          .then(response => {
            this.busAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getAssign() {
        this.$axios.get('/users/otype/CSIGN/object')
          .then(response => {
            this.assigns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPersonalArea() {
        this.$axios.get('/users/otype/PRSAR/object')
          .then(response => {
            this.personalAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPersonalSubArea() {
        this.$axios.get('/city/getall')
          .then(response => {
            this.personalSubAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getEmployeeGroup() {
        this.$axios.get('/users/otype/PRGRP/object')
          .then(response => {
            this.employeeGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSubGroup() {
        this.$axios.get('/objects/employeesubgroup/' + this.employee_group)
          .then(response => {
            this.employeeSubGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getWage() {
        this.$axios.get('/users/wagetype')
          .then(response => {
            this.wageTypes = [];
            response.data.data.forEach((wageType, key) => {
              this.wageTypes.push({
                object_code: wageType.wage_type,
                object_name: wageType.wage_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getKawin() {
        this.$axios.get('/users/otype/MRTST/object')
          .then(response => {
            this.marital_statuses = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getKelamin() {
        this.$axios.get('/users/otype/GENDR/object')
          .then(response => {
            this.genders = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPsType() {
        this.$axios.get('/objects/payscaletype')
          .then(response => {
            this.psTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPsArea() {
        this.$axios.get('/objects/payscalearea')
          .then(response => {
            this.psAreas = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPsGroup() {
        this.$axios.get('/objects/payscalegroup')
          .then(response => {
            this.psGroups = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getPsLevel() {
        this.$axios.get('/objects/payscalelevel')
          .then(response => {
            this.psLevels = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCompany() {
        this.$axios.get('/objects/companytoken/ACCAS')
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      async getTree() {

        this.data = [];
        await this.$axios.get('/company')
          .then(response => {
            response.data.data.forEach(async (parent, indexparent) => {
              await this.data.push({
                indexparent: indexparent,
                id: parent.business_code,
                label: parent.company_name,

                children: []
              });
              await this.$axios.get('/users/' + parent.business_code +
                  '/treeOrganization?relationalparentchild=parent-child')
                .then(response => {
                  response.data.data.child.forEach(async (child, index) => {
                    await this.data[indexparent].children.push({
                      index: index,
                      id: child.organizational_id_child,
                      label: child.organizational_name,
                      children: []
                    });
                    await this.$axios.get('/users/' + parent.business_code +
                        '/treeOrganization?stext=' + child.organizational_id_child +
                        '&relationalparentchild=parent-child')
                      .then(response => {
                        response.data.data.child.forEach(async (child1, index1) => {
                          await this.data[indexparent].children[index].children.push({
                            index1: index1,
                            id: child1.organizational_id_child,
                            label: child1.organizational_name,
                            children: []
                          });
                          await this.$axios.get('/users/' + parent.business_code +
                              '/treeOrganization?stext=' + child1.organizational_id_child +
                              '&relationalparentchild=parent-child')
                            .then(response => {
                              response.data.data.child.forEach(async (child2, index2) => {
                                await this.data[indexparent].children[index].children[
                                  index1].children.push({
                                  index2: index2,
                                  id: child2.organizational_id_child,
                                  label: child2.organizational_name,
                                  children: []
                                });
                                await this.$axios.get('/users/' + parent
                                    .business_code +
                                    '/treeOrganization?stext=' + child2
                                    .organizational_id_child +
                                    '&relationalparentchild=parent-child')
                                  .then(response => {
                                    response.data.data.child.forEach(async (child3,
                                      index3) => {
                                      await this.data[indexparent].children[
                                        index].children[index1].children[
                                        index2].children.push({
                                        index3: index3,
                                        id: child3
                                          .organizational_id_child,
                                        label: child3.organizational_name,
                                        children: []
                                      });
                                      await this.$axios.get('/users/' +
                                          parent.business_code +
                                          '/treeOrganization?stext=' + child3
                                          .organizational_id_child +
                                          '&relationalparentchild=parent-child'
                                        )
                                        .then(response => {
                                          response.data.data.child.forEach(
                                            async (child4, index4) => {
                                              await this.data[
                                                  indexparent].children[
                                                  index].children[
                                                  index1].children[
                                                  index2].children[
                                                  index3].children
                                                .push({
                                                  index4: index4,
                                                  id: child4
                                                    .organizational_id_child,
                                                  label: child4
                                                    .organizational_name,
                                                  children: []
                                                });
                                              await this.$axios.get(
                                                  '/users/' + parent
                                                  .business_code +
                                                  '/treeOrganization?stext=' +
                                                  child4
                                                  .organizational_id_child +
                                                  '&relationalparentchild=parent-child'
                                                )
                                                .then(response => {
                                                  response.data.data
                                                    .child
                                                    .forEach(async (
                                                      child5,
                                                      index5) => {
                                                      await this
                                                        .data[
                                                          indexparent
                                                        ]
                                                        .children[
                                                          index]
                                                        .children[
                                                          index1]
                                                        .children[
                                                          index2]
                                                        .children[
                                                          index3]
                                                        .children[
                                                          index4]
                                                        .children
                                                        .push({
                                                          index5: index5,
                                                          id: child5
                                                            .organizational_id_child,
                                                          label: child5
                                                            .organizational_name,
                                                          children: []
                                                        });
                                                    });
                                                }).catch(e => {
                                                  console.log(e);
                                                });
                                            });
                                        }).catch(e => {
                                          console.log(e);
                                        });
                                    });
                                  }).catch(e => {
                                    console.log(e);
                                  });
                              });
                            }).catch(e => {
                              console.log(e);
                            });
                        });
                      }).catch(e => {
                        console.log(e);
                      });
                  });
                }).catch(e => {
                  console.log(e);
                });
            });
          }).catch(e => {
            console.log(e);
          });
      }
    }
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
