<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="off-cycle/off-cycle-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-user" aria-hidden="true"></i> Off Cycle
    </h3>
    <a class="button is-pulled-left is-link is-rounded" @click="openFormModal()">Tambah Data</a>
    <br><br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Nomor Induk Karyawan</th>
          <th>Komponen Penghasilan</th>
          <th>Offcycle</th>
          <th>Nilai</th>
          <th>Alasan Berubah</th>
          <th>Action</th>
        </tr>
        <tr v-for="(list, key) in lists" :key="key">
          <th> {{key+1}} </th>
          <th> {{list.personal_number}} </th>
          <th> {{list.wage_type[0].wage_name}} </th>
          <th> {{list.offcycle[0].name}} </th>
          <th> {{list.amount}} </th>
          <th> {{list.change_reason[0].name}}</th>
          <td>
            <a class="button is-success is-outlined is-rounded" @click="editList(list.business_code,list.personal_number, list.wage_type[0].wage_type, list.begin_date)"><i class="fa fa-pencil"
                aria-hidden="true"></i></a>
            <a class="button is-danger is-outlined is-rounded" @click="deleteList(key,list.business_code,list.personal_number, list.wage_type[0].wage_type, list.begin_date)"><i
                class="fa fa-trash" aria-hidden="true"></i></a>
          </td>
        </tr>
      </thead>
    </table>
    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getList()"></pagination>
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Form Data</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
            <div class="columns">
                <div class="column">
                    <div class="field">
                    <label class="label">Nama Perusahaan</label>
                    <div class="control">
                        <div class="select " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                        <select v-if="type=='EDIT'" name="nama_perusahaan" class="select" v-model="business_code" v-validate="'required'" disabled>
                            <option disabled selected>Choose</option>
                            <option v-for="(buscd, key) in companies" :key="key" :value="buscd.business_code">{{
                            buscd.company_name
                            }}</option>
                        </select>
                        <select v-else name="nama_perusahaan" class="select" v-model="business_code" v-validate="'required'">
                            <option disabled selected>Choose</option>
                            <option v-for="(buscd, key) in companies" :key="key" :value="buscd.business_code">{{
                            buscd.company_name
                            }}</option>
                        </select>
                        </div>
                        <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan')
                        }}</p>
                    </div>
                    </div>
                </div>
            </div>
            <div class="columns">
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Nomor Induk Karyawan</label>
                        <div class="control">
                        <input v-if="type =='EDIT'" id="personal_number" data-display-mode="dialog" class="input" name="personal_number" type="number" placeholder="e.g 10-11-2018"
                            v-model="personal_number" data-vv-as="personal_number" v-bind:class="{ 'is-danger': errors.has('personal_number')}"
                            v-validate="'required'" readonly>
                        <input v-else id="personal_number" data-display-mode="dialog" class="input" name="personal_number" type="number" placeholder="e.g 10-11-2018"
                            v-model="personal_number" data-vv-as="personal_number" v-bind:class="{ 'is-danger': errors.has('personal_number')}"
                            v-validate="'required'">
                        </div>
                        <p v-show="errors.has('personal_number')" class="help is-danger">{{ errors.first('personal_number') }}</p>
                    </div>
                </div>
            </div>
            <div class="columns">
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Tanggal Pembayaran</label>
                        <div class="control">
                        <input v-if="type=='EDIT'" id="end_date" data-display-mode="dialog" class="input" name="begin_date" type="date" placeholder="e.g 10-11-2018"
                            v-model="begin_date" data-vv-as="begin_date" v-bind:class="{ 'is-danger': errors.has('begin_date')}"
                            v-validate="'required'" readonly>
                        <input v-else id="end_date" data-display-mode="dialog" class="input" name="begin_date" type="date" placeholder="e.g 10-11-2018"
                            v-model="begin_date" data-vv-as="begin_date" v-bind:class="{ 'is-danger': errors.has('begin_date')}"
                            v-validate="'required'">
                        </div>
                        <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Komponen Penghasilan</label>
                        <div class="control">
                                <div class="select " v-bind:class="{ 'is-danger': errors.has('wage_type') }">
                                <select v-if="type=='EDIT'" name="wage_type" class="select" v-model="wage_type" v-validate="'required'" disabled>
                                    <option disabled selected>Choose</option>
                                    <option v-for="(buscd, key) in wage_types" :key="key" :value="buscd.wage_type">{{
                                    buscd.wage_name
                                    }}</option>
                                </select>
                                <select v-else name="wage_type" class="select" v-model="wage_type" v-validate="'required'">
                                    <option disabled selected>Choose</option>
                                    <option v-for="(buscd, key) in wage_types" :key="key" :value="buscd.wage_type">{{
                                    buscd.wage_name
                                    }}</option>
                                </select>
                                </div>
                                <p v-show="errors.has('wage_type')" class="help is-danger">{{ errors.first('wage_type')
                                }}</p>
                        </div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Nilai</label>
                        <div class="control">
                        <input id="amount" data-display-mode="dialog" class="input" name="amount" type="number" placeholder="e.g 10-11-2018"
                            v-model="amount" data-vv-as="amount" v-bind:class="{ 'is-danger': errors.has('amount')}"
                            v-validate="'required'">
                        </div>
                        <p v-show="errors.has('amount')" class="help is-danger">{{ errors.first('amount') }}</p>
                    </div>
                </div>
            </div>
            <div class="columns">
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Alasan Berubah</label>
                            <div class="control">
                                <div class="select " v-bind:class="{ 'is-danger': errors.has('change_reason') }">
                                <select name="change_reason" class="select" v-model="change_reason" v-validate="'required'">
                                    <option disabled selected>Choose</option>
                                    <option v-for="(buscd, key) in change_reasons" :key="key" :value="buscd.object_code">{{
                                    buscd.object_name
                                    }}</option>
                                </select>
                                </div>
                                <p v-show="errors.has('change_reason')" class="help is-danger">{{ errors.first('change_reason')
                                }}</p>
                        </div>
                    </div>
                </div>
                <div class="column is-4">
                    <div class="field">
                        <label class="label">Offcycle</label>
                            <div class="control">
                                <div class="select " v-bind:class="{ 'is-danger': errors.has('offcycle') }">
                                <select name="offcycle" class="select" v-model="offcycle" v-validate="'required'">
                                    <option disabled selected>Choose</option>
                                    <option v-for="(buscd, key) in offcycles" :key="key" :value="buscd.object_code">{{
                                    buscd.object_name
                                    }}</option>
                                </select>
                                </div>
                                <p v-show="errors.has('offcycle')" class="help is-danger">{{ errors.first('offcycle')
                                }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="storeComponent()" class="button is-link">Save</button>
            <button class="button" @click="closeFormModal()">Cancel</button>
          </div>
        </footer>
      </div>
    </div>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import Vue from 'vue';
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        business_code: null,
        personal_number:null,
        begin_date:null,
        wage_type:null,
        amount:null,
        change_reason:null,
        offcycle:null,
        companies:[],
        wage_types:[],
        change_reasons:[],
        offcycles:[],
        lists:[],
        type:'ADD',
        perPage:1,
        pagination: {
          'current_page': 1
        },
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Manajemen'
          },
          {
            name: 'Insidental Payment'
          }
        ],
        isActiveForm: false,
      }
    },
    created() {
      this.getList();
      this.getWageType();
      this.getChangeReason();
      this.getCompany();
      this.getOffCycle();
    },
    methods: {
      getCompany() {
        this.$axios.get('/objects/companytoken/ADDPY')
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getWageType() {
        this.$axios.get('/users/wagetype')
          .then(response => {
            this.wage_types = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getChangeReason() {
        this.$axios.get('/users/otype/CHGRN/object')
          .then(response => {
            this.change_reasons = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getOffCycle() {
        this.$axios.get('/users/otype/OFFTY/object')
          .then(response => {
            this.offcycles = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getList() {
        await this.$axios.get('users/offcycle?page=' + this.pagination.current_page+'&per_page='+this.perPage)
          .then(response => {
            this.lists = [];
            response.data.data.forEach(async (relat, key) => {
              await this.lists.push({
                business_code: relat.business_code,
                personal_number: relat.personal_number,
                begin_date: relat.begin_date,
                wage_type: relat.wage_type,
                amount: relat.amount,
                change_reason: relat.change_reason,
                offcycle: relat.offcycle,
              });
            });
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.type = 'ADD';
        this.business_code= null;
        this.personal_number=null;
        this.begin_date=null;
        this.wage_type=null;
        this.amount=null;
        this.change_reason=null;
        this.offcycle=null;
        this.$nextTick(() => this.$validator.reset())
      },
      editList(business_code,personal_number, wage_type, begin_date) {
        this.type ='EDIT';
        this.openFormModal();
        this.getEdit(business_code,personal_number, wage_type, begin_date);
        //penjelasan keynya dapet nilai dari lemparan editAccountnya
      },
        async getEdit(business_code,personal_number, wage_type, begin_date) {
            let list = await this.lists.find(list => list.business_code == business_code && list.personal_number == personal_number &&
            list.wage_type[0].wage_type == wage_type && list.begin_date == begin_date);
            this.begin_date = list.begin_date;
            this.business_code = list.business_code;
            this.personal_number = list.personal_number;
            this.wage_type = list.wage_type[0].wage_type;
            this.amount = list.amount;
            this.change_reason = list.change_reason[0].object_id
            this.offcycle = list.offcycle[0].object_id
      },
       storeComponent() {
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.input=[];
                  this.input.push({
                    business_code: this.business_code,
                    personal_number: this.personal_number,
                    begin_date:this.begin_date,
                    wage_type:this.wage_type,
                    amount:this.amount,
                    change_reason:this.change_reason,
                    offcycle:this.offcycle
                  })
                  this.$axios.post('users/'+this.business_code+'/offcycle/'+this.personal_number+'/wagetype/'+this.wage_type+'/date/'+this.begin_date,
                  this.input)
                    .then(response => {
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                      this.closeFormModal();
                      this.getList()
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            },

      deleteList(key,business_code,personal_number, wage_type, begin_date) {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          showCancelButton: true,
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.post('users/'+business_code+'/offcycle/'+personal_number+'/wagetype/'+wage_type+'/date/'+begin_date,[])
            .then(response => {
              swal(
                'Deleted!',
                response.data.message,
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            })
            .then(() => {
              this.removeList(key);
            })
          }

        });
      },
       removeList(key) {
        this.lists.splice(key, 1);
      },

  }
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

</style>
