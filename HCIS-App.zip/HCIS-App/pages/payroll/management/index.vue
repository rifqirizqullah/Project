<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> <span><i class="fa fa-plus" aria-hidden="true"></i> Tambah Data </span></a>
   <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Data Manajemen Payroll
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                    {{ column.column_name }}
                  </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
         
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(payMan, key) in payMans" :key="key">
          <td> {{key+1}} </td>
         
          <td> {{formatDate(payMan.begin_date)}} </td>
          <td> {{formatDate(payMan.end_date)}} </td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
                @click="editpayMan(payMan.object_identifier)"><i class="fa fa-pencil"
                  aria-hidden="true"></i></a>
              <a class="button is-danger is-small is-outlined is-rounded"
                @click="payMan.object_identifier ? deletepayMan(key, payMan.object_identifier) : removepayMan(key)"><i
                  class="fa fa-trash" aria-hidden="true"></i></a>
              <a class="button is-warning is-small is-outlined is-rounded"
                @click="showDelimitpayMan(payMan.object_identifier)"><i class="fa fa-clock-o"
                  aria-hidden="true"></i></a>
           </td>
        </tr>
      </thead>
    </table>

  <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getpayMans()"></pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Pengucualian Payroll</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          

      
      <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
      </div>
      <div class="columns">
       
        
      </div>
      
      
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="savepayMan()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
  </div>

  <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
            <div class="modal-background"></div>
            <div class="modal-card">
              <header class="modal-card-head">
                <p class="modal-card-title">Delimit Data Identitas</p>
                <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
              </header>
              <section class="modal-card-body">
                <div class="columns">
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Awal Berlaku</label>
                      <div class="control">
                        <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                          v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                          data-vv-scope="delimit" disabled>
                      </div>
                      <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                        {{ errors.first('delimit.begin_date') }}</p>
                    </div>
                  </div>
                  <div class="column">
                    <div class="field">
                      <label class="label">Tanggal Akhir Berlaku</label>
                      <div class="control">
                        <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                          placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                          v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                          data-vv-scope="delimit">
                      </div>
                      <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                      </p>
                    </div>
                  </div>
                </div>
              </section>
              <footer class="modal-card-foot">
                <div class="control">
                  <button @click="delimitpayMan()" class="button is-success">Simpan</button>
                  <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
                </div>
              </footer>
            </div>
  </div> 
  
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        
        payMans: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        
        
        business_code: null,
        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: "",
        empolyeePosition: '',
        empolyeeUnit: '',
        
        perPage:5,
        search:'',
        pagination: {
            'current_page': 1
          },
         options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,
        columns:[],
        logics:[],
        conditions:[],
        filters:[],
        paramsearchforms:'',
        columns_model:[],
        filters_model:[],
        conditions_model:[],
        logics_model:[],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Data Karyawan'
          },
          {
            name: 'Manajemen Payroll'
          },
        ],
        isActiveForm:false,
        isActiveFormDelimit: false
      }
    },
    created() {
        this.getpayMans();
        //this.getColumn();
        //this.getLogic();
        //this.getCondition();
        this.getCompany();
    },
    methods: {
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code[]=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(
                employee.personnel_number
                );
            });

            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              }).slice(0, this.limit);

            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.employeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal("", "Pilih nama perusahaan terlebih dahulu !", "error");
          } else {
            this.selfData(option.item);
          }
        }
      },
      selfData(nik){
          this.$axios
                .get(
                  "hcis/api/organizationalassignment?"+"begin_date_lte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&end_date_gte=" +
                  moment(new Date()).format("YYYY-MM-DD") +
                  "&personnel_number[]=" +
                  nik + "&business_code[]=" +this.company
                )
                .then(async response => {
                  this.empolyeeName = response.data.data[0].personnel_number.complete_name;
                  this.empolyeePosition = response.data.data[0].position.organization_name;
                  this.empolyeeUnit = response.data.data[0].unit.organization_name;
                })
                .catch(e => {
                  console.log(e);
                });
        },
      
     clearEmployee() {
        if (this.employee != null) {
          this.$refs.reference= '';
        }
        this.filterEmployee = []
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeeUnit = '';
        this.empolyeePosition = '';

        this.$nextTick(() => this.$validator.reset());
      }, 
      
      getParam(){
      
      },
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
       
        
        this.company = null;
        this.employee = null;
        this.empolyeeName = "";
        this.empolyeePosition = '';
        this.empolyeeUnit = '';

        this.$nextTick(() => this.$validator.reset())
      }, 
      storepayMan() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .post("hcis/api/payrollexception", {
              begin_date: this.startDate,
              end_date: this.endDate,
              
              
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getpayMans();
              this.closeFormModal();
              swal(
                "Saved!",
                "Successfully saved data pengcualian payroll.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deletepayMan(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete(
                "hcis/api/pajakrange?object_identifier=" + objectIdentifier)
              .then(response => {
                swal("Deleted!", 
                response.data.message, 
                "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removepayMan(key);
              });
          }
        });
      },
      removepayMan(key) {
        this.payMans.splice(key, 1);
      },
      getpayMans(){
            this.$axios
            .get("hcis/api/pajakrange?include=business_code&order[oid]=asc" + '&page=' + this.pagination.current_page+'&per_page='+this.perPage)
                .then(response => {
                    this.payMans = response.data.data;
                    this.pagination = response.data.meta.pagination;
                })
                .catch(e => {
                    console.log(e);
                });
        },
        async getpayMan(objectIdentifier){
          let payMan = await this.payMans.find(
          payMan => payMan.object_identifier == objectIdentifier
        );
        this.objectIdentifier = payMan.object_identifier;
        this.startDate = payMan.begin_date;
        this.endDate = payMan.end_date;
        
        
        this.company = payMan.business_code.business_code;
        this.employee = payMan.personnel_number.personnel_number;
        this.empolyeeName = payMan.personnel_number.complete_name;
        
        this.selfData(this.employee)        
        
        
        },
      getColumn() {
        this.$axios.get('/objects/alltable/payMan/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getLogic() {
        this.$axios.get('/objects/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/objects/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = {
          table : "payMan",//harcode sesuai form *referensi table_code*
          column : this.columns_model,
          query : this.logics_model,
          value : this.filters_model,
          andor : this.conditions_model
        }
        //console.log(this.paramsearchforms)
         this.$axios.post('users/seachdinamis?per_page=10&page=1',this.paramsearchforms)
          .then(response => {

            this.payMans = [];
            response.data.data.forEach(async (employee, key) => {
              await this.payMans.push({
                begin_date: employee.begin_date,
                end_date: employee.end_date,
                personal_number: employee.personal_number,
                buscd: employee.business_code
              })
            });
            //console.log(this.employees);
          })
          .catch(e => {
            console.log(e);
          });
      },
      editpayMan(objectIdentifier) {
        this.openFormModal();
        this.getpayMan(objectIdentifier);
      },
      updatepayMan() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          this.$axios
            .put("hcis/api/pajakrange", {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              
             
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getpayMans();
              this.closeFormModal();
              swal(
                "Updated!",
                "Successfully updated data pengecualian payroll.",
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      savepayMan() {
        this.objectIdentifier ? this.updatepayMan() : this.storepayMan();
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;

        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitpayMan(objectIdentifier) {
        this.openFormModalDelimit();
        let payMan = await this.payMans.find(
          payMan => payMan.object_identifier == objectIdentifier
        );
        this.objectIdentifier = payMan.object_identifier;
        this.startDate = payMan.begin_date;
        this.endDate = payMan.end_date;
      },
      delimitpayMan() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/pajakrange", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getpayMans();
              this.closeFormModalDelimit();
              swal(
                "Delimited!", 
                response.data.message, 
                "success"
                );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      },
      formatDate(date) {
        return moment(date).format('DD/MM/YYYY')
      },
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
