<template>
  <section class="section">
    <div class="">
      <div>
        <div class="box has-text-white has-background-danger">
          Pencarian Antar Tabel
        </div>
        <div class="box">
          <div v-for="(form, key) in searchforms" :key="key">
            <div class="columns">
              <div class="column is-2">
                <div class="field">
                  <label class="label">Table</label>
                  <div class="control">
                    <div class="select">
                      <select v-model="tables_model[key]">
                        <option v-for="(column, key) in tables" :key="key" :value="column.table_code">
                        {{ column.table_name }}
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="column is-2">
                <div class="field">
                  <label class="label">Column</label>
                  <div class="control">
                    <div class="select">
                      <select v-model="columns_model[key]">
                        <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                        {{ column.column_name }}
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="column is-2">
                <div class="field">
                  <label class="label">Logic</label>
                  <div class="control">
                    <div class="select">
                      <select v-model="logics_model[key]">
                        <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                          {{ logic.name }}
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="column is-3">
                <div class="field">
                  <label class="label">Filter</label>
                  <div class="control">
                    <input class="input" type="text" v-model="filters_model[key]">
                  </div>
                </div>
              </div>
              <div class="column is-2">
                <div class="field is-2">
                  <label class="label">Condition</label>
                  <div class="control">
                    <div class="select">
                      <select v-model="conditions_model[key]">
                        <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                          {{ condition.name }}
                        </option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
              <div class="column is-">
                <br>
                <div v-if="key==0">
                  <a class="button is-success is-outlined is-rounded" @click="addNewFormSearch()"><i class="fa fa-plus"
                      aria-hidden="true"></i></a>
                </div>
                <div v-else>
                  <a class="button is-danger is-outlined is-rounded" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                      aria-hidden="true"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <a class="button is-success is-rounded" @click="getSearchDynamic()">Cari</a>
        <br><br>
        <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
          <thead>
            <tr>
              <th>No.</th>
              <th>Personal Number</th>
              <th>Begin Date</th>
              <th>End Date</th>
              <th>Action</th>
            </tr>
            <tr v-for="(list, key) in lists" :key="key">
              <th>{{ key + 1}}</th>
              <th>{{ list.personalNumber}}</th>
              <th>{{ list.startDate}}</th>
              <th>{{ list.endDate}}</th>
              <th>
                <a class="button is-success is-outlined is-rounded"><i class="fa fa-pencil" aria-hidden="true"></i></a>
                <a class="button is-danger is-outlined is-rounded"><i class="fa fa-trash" aria-hidden="true"></i></a>
              </th>
            </tr>
          </thead>
        </table>
      </div>
    </div>
  </section>
</template>

<script>
  export default {
    components: {

    },
    data() {
      return {
        key: '',
        columns:[],
        logics:[],
        conditions:[],        
        tables:[],
        lists:[],
        paramsearchforms:'',
        columns_model:[],
        filters_model:[],
        conditions_model:[],
        logics_model:[],
        tables_model:[],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
      }
    },
    created(){
      this.getTable();
      this.getColumn();
      this.getLogic();
      this.getCondition();      
    },
    methods: {
      getSearchDynamic() {
        this.paramsearchforms = {
          table : this.tables_model,//harcode sesuai form *referensi table_code*
          column : this.columns_model,
          query : this.logics_model,
          value : this.filters_model,
          andor : this.conditions_model
        }
        console.log(this.paramsearchforms)
         this.$axios.post('users/seachdinamisantartable?per_page=10&page=1',this.paramsearchforms)
          .then(response => {
            this.lists = [];
            response.data.data.forEach(async (bpjs, key) => {
              await this.lists.push({
                startDate: bpjs.begin_date,
                endDate: bpjs.end_date,
                personalNumber: bpjs.personal_number,
                buscd: bpjs.business_code
              })
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getColumn() {
        this.$axios.get('/objects/alltable/BandIndividu/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
       getLogic() {
        this.$axios.get('/objects/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/objects/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getTable() {
        this.$axios.get('/objects/alltable')
          .then(response => {
            this.tables = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    }
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>