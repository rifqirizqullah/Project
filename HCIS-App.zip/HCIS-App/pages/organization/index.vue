<template>
  <section class="section">
    <div class="modal " v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background" @click="closeFormModal()"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Tambah Organisasi</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
            <div class="field">
            <label class="label">Kode Parent</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input" name="code_parent" v-model="code_parent"
                v-bind:class="{ 'is-danger': errors.has('organization.code_parent')}" v-validate="'required'" data-vv-scope="organization" disabled>
            </div>
            <p v-show="errors.has('organization.code_parent')" class="help is-danger"> {{ errors.first('organization.code_parent') }}</p>
          </div>
          <div class="field">
            <label class="label">Nama Parent</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input" name="name_parent" v-model="name_parent"
                v-bind:class="{ 'is-danger': errors.has('organization.name_parent')}" v-validate="'required'" data-vv-scope="organization" disabled>
            </div>
            <p v-show="errors.has('organization.name_parent')" class="help is-danger"> {{ errors.first('organization.name_parent') }}</p>
          </div>
           <div class="field">
              <label class="label">Kode Relasi</label>
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('organization.relCode') }">
                <select name="relCode" data-vv-as="relCode" class="select" v-model="relCode" v-validate="'required'"
                  data-vv-scope="organization" v-bind:class="{ 'is-danger': errors.has('organization.relCode') }">
                  <option value="">Choose Type</option>
                  <option value="001">Memiliki</option>
                  <option value="002">Chief</option>
                  <option value="003">Staff</option>                                                      
                </select>
              </div>
              <p v-show="errors.has('organization.relCode')" class="help is-danger">{{ errors.first('organization.relCode') }}</p>
            </div>
          <div class="field">
              <label class="label">Tipe</label>
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('organization.type') }">
                <select name="type" data-vv-as="type" class="select" v-model="type" v-validate="'required'"
                  data-vv-scope="organization" v-bind:class="{ 'is-danger': errors.has('organization.type') }">
                  <option value="">Choose Type</option>
                  <option v-for="(orType, index) in orTypes" :key="index" :value="orType.objectId">{{orType.name}}</option>
                  
                </select>
              </div>
              <p v-show="errors.has('organization.type')" class="help is-danger">{{ errors.first('organization.type') }}</p>
            </div>
          <div class="field">
            <label class="label">Kode</label>
            <div class="control" v-if="typeModal == 'EDIT'">
              <input class="input" type="text" readonly placeholder="Text input" name="id" v-model="id"
                v-bind:class="{ 'is-danger': errors.has('organization.id')}" v-validate="'required'" data-vv-scope="organization">
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="" name="id" v-model="id"
                v-bind:class="{ 'is-danger': errors.has('organization.id')}" v-validate="'required'" data-vv-scope="organization">
            </div>
            <p v-show="errors.has('organization.id')" class="help is-danger"> {{ errors.first('organization.id') }}</p>
          </div>          
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="" name="name" v-model="name"
                v-bind:class="{ 'is-danger': errors.has('organization.name')}" v-validate="'required'" data-vv-scope="organization">
            </div>
            <p v-show="errors.has('organization.name')" class="help is-danger"> {{ errors.first('organization.name') }}</p>
          </div>
            
        </section>
        <footer class="modal-card-foot">
          <div v-if="typeModal == 'EDIT'">
          <button  class="button is-success" @click="saveOrganization()">Update</button>
          </div>
          <div v-else>
          <button  class="button is-success" @click="saveOrganization()" >Simpan</button>
          </div>
          <button class="button">Batal</button>
        </footer>
      </div>
    </div>
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <div class="box has-text-white has-background-danger">
      Manajemen Organisasi
    </div>
    <div>
      <h3>Tree Organization</h3>
      <!-- <v-jstree :data="data" show-checkbox multiple allow-batch whole-row @item-click="itemClick"> -->
      <v-jstree :data="data" allow-batch whole-row>
        <template slot-scope="_">
          <div style="display: inherit; width: 200px">                    
            <i class="fa fa-file" v-if="_.model.type == '01'">{{_.model.text}} </i>
            <i class="fa fa-users" v-else-if="_.model.type == '02'">{{_.model.text}} </i>
            <i class="fa fa-tasks" v-else-if="_.model.type == '03'">{{_.model.text}} </i>
            <i class="fa fa-user" v-else-if="_.model.type == '04'">{{_.model.text}} </i>
            <i class="fa fa-money" v-else-if="_.model.type == '05'">{{_.model.text}} </i>
              <button v-if="_.model.level < 6" @click="openFormModal(_.model)"><i class="fa fa-plus"></i></button>
              <button v-if="_.model.level > 0" @click="openFormModalEdit(_.model)"><i class="fa fa-pencil"></i></button>
              <button v-if="_.model.level > 0" @click="deleteOrganization(_.model)"><i class="fa fa-remove"></i></button>
          </div>
        </template>  
      </v-jstree>
        
    </div>
  </section>
</template>
<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        orTypes: [],
        data: [],
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Organisasi '
          },
          {
            name: 'Manajemen'
          }
        ],
        company:'',
        isActiveForm: false,
        typeModal:'ADD',
        name:'',
        name_parent:'',
        code_parent:'',
        type:'',        
        level:null,
        id:null,
        idParent:null,
        typeParent:null,
        relType:'',
        relCode:'',
        business_code:'',
        nikAuth: this.$auth.user.username
      }
    },
    created(){
      //this.getCompany();
      this.getTree();
      //console.log(this.nikAuth)
    },
    methods: {
      async getCompany() {
        await this.$axios.get('/users/1000/treeOrganization?relationalparentchild=parent-child')
          .then(response => {
            this.company = response.data.data.company.company_name;
          })
          .catch(e => {
            console.log(e);
          });
      },      
      // getId() {
      //   this.$axios.get('/users/generateOrganization')
      //     .then(response => {
      //       this.id = response.data.data.id;
      //   })
      //   .catch(e => {
      //     console.log(e);
      //   });
      // },
      getOrtype(){
        this.$axios.get('/objects/organizationtype')
          .then(response => {
            this.orTypes = [];
            response.data.data.forEach(async (orType, key) => {
              await this.orTypes.push({
                objectId: orType.object_id,
                name: orType.name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      async openFormModal(node){
        await this.getOrtype();
        //await this.getId();           
        this.name_parent = node.text;
        this.code_parent= node.id;
        this.typeParent = node.type;
        this.idParent = node.id;                
        this.business_code = node.business_code;                
        //this.relCode = node.relCode; ambil dari form               
        this.typeModal='ADD';
        this.isActiveForm = true;        
      },
      async openFormModalEdit(node){
        await this.getOrtype();
        this.type = node.type;        
        this.id = node.id;
        
        this.code_parent= node.idParent;
        this.name_parent = node.text;
        this.name = node.text;
        this.typeParent = node.typeParent;
        this.idParent = node.idParent;        
        this.business_code = node.business_code;                
        //this.relType = node.relType;
        this.relCode = node.relCode;                        
        this.typeModal='EDIT';
        this.isActiveForm = true;        
      },
       closeFormModal() {
        this.isActiveForm = false;
        this.id = null;
        this.name = '';
        this.type = '';
        this.typeModal='';
        this.idParent=null;
        this.typeParent=null;
        this.business_code = '';                
        //this.relType=null;
        this.relCode=null;        
        this.$nextTick(() => this.$validator.reset())
      },
      saveOrganization() {
        this.$validator.validateAll('organization').then(async result => {
          if (!result) return;
          if(this.typeModal == 'EDIT'){
            this.$axios.put('/users/'+this.business_code+'/treeOrganization', {
              begin_date: '' + new Date().toISOString().slice(0,10),
              end_date: '9999-12-31',
              business_code: this.business_code,
              plan_version:'01',
              organizational_type:this.type,
              organizational_id: this.id,
              organizational_name: this.name,
              relation_type: 'A',
              relation_code: this.relCode,
              organizational_id_parent: this.idParent,
              organizational_type_parent: this.typeParent,              
              change_date: '' + new Date().toISOString().slice(0,10),
              change_user: this.nikAuth              
            })
            .then(response => {
              this.getTree();
              this.closeFormModal();
              swal(
                'Saved!',
                'Successfully saved organization.',
                'success'
              )
            })
            .catch(e => {
              console.log(e);
            });
          }else{
            this.$axios.post('/users/'+this.business_code+'/treeOrganization', {
              begin_date: '' + new Date().toISOString().slice(0,10),
              end_date: '9999-12-31',
              business_code: this.business_code,
              plan_version:'01',
              organizational_type:this.type,
              organizational_id: this.id,
              organizational_name: this.name,
              relation_type: 'A',
              relation_code: this.relCode,
              organizational_id_parent: this.idParent,
              organizational_type_parent: this.typeParent,              
              change_date: '' + new Date().toISOString().slice(0,10),
              change_user: this.nikAuth              
            })
            .then(response => {
              console.log(response.data.status)
              if(response.data.status == 500){
                alert('kode sudah digunakan');
              }else{
                this.getTree();
                this.closeFormModal();
                swal(
                  'Saved!',
                  'Successfully saved organization.',
                  'success'
                )
              }
            })
            .catch(e => {
              console.log(e);
            });  
          }
          
        });
      },      
      deleteOrganization(id) {
        swal({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: 'warning',
          buttons: true,
          dangerMode: true,
        }).then((result) => {
          if (result) {
            this.$axios.delete('users/'+id.business_code+'/treeOrganization?stext=' + id.id)
              .then(response => {
                swal(
                  'Deleted!',
                  response.data.message,
                  'success', {
                   icon: "success",
                  }
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.getTree();
              })
          }
        });
      },
      async getTree(){
        
      this.data = [];
      await this.$axios.get('/company')
        .then(response => {
          response.data.data.forEach(async (parent, indexparent) => {
            await this.data.push({
              indexparent:indexparent,
              id: parent.business_code,              
              text: parent.company_name,
              business_code: parent.business_code,
              level: 0,
              opened:false,
              type: '01',
              children:[]
            });                                                    
        await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?relationalparentchild=parent-child')
        .then(response => {
          response.data.data.child.forEach(async (child, index) => {
            await this.data[indexparent].children.push({
              index:index,
              id: child.organizational_id_child,
              type: child.organizational_type_child,
              idParent: child.organizational_id_parent,
              typeParent: child.organizational_type_parent,
              text: child.organizational_name,
              business_code: parent.business_code,
              level: 1,
              opened:false,              
              //relType: child.relation_type,
              relCode: child.relation_code,
              children:[]                                            
            });                                          
              await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child.organizational_id_child+'&relationalparentchild=parent-child')
                .then(response => {
                  response.data.data.child.forEach(async (child1, index1) => {
                    await  this.data[indexparent].children[index].children.push({
                      index1:index1,
                      id: child1.organizational_id_child,
                      type: child1.organizational_type_child,
                      idParent: child1.organizational_id_parent,
                      typeParent: child1.organizational_type_parent,
                      text: child1.organizational_name,
                      business_code: parent.business_code,
                      level: 2,
                      opened:false,                      
                      //relType: child1.relation_type,
                      relCode: child1.relation_code,
                      children:[]
                    });
                    await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child1.organizational_id_child+'&relationalparentchild=parent-child')
                      .then(response => {
                        response.data.data.child.forEach(async (child2, index2) => {
                          await  this.data[indexparent].children[index].children[index1].children.push({
                            index2:index2,
                            id: child2.organizational_id_child,
                            type: child2.organizational_type_child,
                            idParent: child2.organizational_id_parent,
                            typeParent: child2.organizational_type_parent,
                            text: child2.organizational_name,
                            business_code: parent.business_code,
                            level: 3,
                            opened:false,                      
                            //relType: child1.relation_type,
                            relCode: child2.relation_code,
                            children:[]
                          });
                          await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child2.organizational_id_child+'&relationalparentchild=parent-child')
                            .then(response => {
                              response.data.data.child.forEach(async (child3, index3) => {
                                await  this.data[indexparent].children[index].children[index1].children[index2].children.push({
                                  index3:index3,
                                  id: child3.organizational_id_child,
                                  type: child3.organizational_type_child,
                                  idParent: child3.organizational_id_parent,
                                  typeParent: child3.organizational_type_parent,
                                  text: child3.organizational_name,
                                  business_code: parent.business_code,
                                  level: 4,
                                  opened:false,                      
                                  //relType: child1.relation_type,
                                  relCode: child3.relation_code,
                                  children:[]
                                });
                                await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child3.organizational_id_child+'&relationalparentchild=parent-child')
                                .then(response => {
                                  response.data.data.child.forEach(async (child4, index4) => {
                                    await  this.data[indexparent].children[index].children[index1].children[index2].children[index3].children.push({
                                      index4:index4,
                                      id: child4.organizational_id_child,
                                      type: child4.organizational_type_child,
                                      idParent: child4.organizational_id_parent,
                                      typeParent: child4.organizational_type_parent,
                                      text: child4.organizational_name,
                                      business_code: parent.business_code,
                                      level: 5,
                                      opened:false,                      
                                      //relType: child1.relation_type,
                                      relCode: child4.relation_code,
                                      children:[]
                                    });
                                    await this.$axios.get('/users/'+parent.business_code+'/treeOrganization?stext='+child4.organizational_id_child+'&relationalparentchild=parent-child')
                                    .then(response => {
                                      response.data.data.child.forEach(async (child5, index5) => {
                                        await  this.data[indexparent].children[index].children[index1].children[index2].children[index3].children[index4].children.push({
                                          index5:index5,
                                          id: child5.organizational_id_child,
                                          type: child5.organizational_type_child,
                                          idParent: child5.organizational_id_parent,
                                          typeParent: child5.organizational_type_parent,
                                          text: child5.organizational_name,
                                          business_code: parent.business_code,
                                          level: 6,
                                          opened:false,                      
                                          //relType: child1.relation_type,
                                          relCode: child5.relation_code,
                                          children:[]
                                        });
                                      });                                                                                                                                                    
                                    }).catch(e => {
                                      console.log(e);
                                    });
                                  });                                                                                                                                                    
                                }).catch(e => {
                                  console.log(e);
                                });
                              });                                                                                                                                                    
                            }).catch(e => {
                              console.log(e);
                            });
                        });                                                                                                                                                    
                      }).catch(e => {
                        console.log(e);
                      });
                  });                                                                                                                                                    
                }).catch(e => {
                  console.log(e);
                });
          });
          }).catch(e => {
                  console.log(e);
                });
          });                               
        }).catch(e => {
          console.log(e);
        });                                  
      }      
      // itemClick(node) {
      //   console.log(node.model.text + ' clicked !')
      // }
    },
  middleware: ['auth']
  }

</script>
