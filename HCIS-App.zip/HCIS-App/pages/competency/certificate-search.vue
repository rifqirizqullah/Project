<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-address-card-o" aria-hidden="true"></i> Identitas Karyawan BUMN
    </h3>
    <div class="box has-text-white has-background-danger">
      Filter Search
    </div>
    <div class="box">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Column</label>
              <div class="control">
                <div class="select">
                  <select v-model="form.column">
                    <option>Personal Number</option>
                    <option>Full Name</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logic</label>
              <div class="control">
                <div class="select">
                  <select v-model="form.logic">
                    <option>Is Equal To</option>
                    <option>Is Not Equal To</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="form.filter">
              </div>
            </div>
          </div>
          <div class="column">
            <div class="field is-2">
              <label class="label">Condition</label>
              <div class="control">
                <div class="select">
                  <select v-model="form.condition">
                    <option>And</option>
                    <option>Or</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded">Cari</a>
    <nuxt-link to="/employee-data/address/address"><a class="button is-link is-rounded">Tambah Data</a>
    </nuxt-link>
    <br><br>
    <table class="table is-bordered is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Personal Number</th>
          <th>Tanggal Awal</th>
          <th>Tanggal Akhir</th>
          <th>Action</th>
        </tr>
        <tr v-for="(certificate, key) in certificates" :key="key">
          <th>{{ key + 1}}</th>
          <th>{{certificate.personal_number}}</th>
          <th>{{certificate.begin_date}}</th>
          <th>{{certificate.end_date}}</th>
          <th>
            <nuxt-link :to="'/competency/certification?nik='+certificate.personal_number+'&buscd='+certificate.buscd">
              <a class="button is-success is-outlined is-rounded"><i class="fa fa-pencil" aria-hidden="true"></i></a>
            </nuxt-link>
            <!-- <a class="button is-danger is-outlined is-rounded"><i class="fa fa-trash" aria-hidden="true"></i></a> -->
          </th>
        </tr>
      </thead>
    </table>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        families:[],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Kompetensi'
          },
          {
            name: 'Pencarian Sertifikat'
          },
        ],
        certificates: []
      }
    },
    created() {
      this.getAllCertificate();
    },
    methods: {
      getAllCertificate() {
        this.$axios.get('/users/certificate?per_page=20')
          .then(response => {
            response.data.data.forEach((certificate, key) => {
              this.certificates.push({
                begin_date: certificate.begin_date,
                end_date: certificate.end_date,
                personal_number: certificate.personal_number,
                buscd: certificate.business_code
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
