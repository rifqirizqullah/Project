<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <h3 class="subtitle is-3">
      <i class="fa fa-fa-university" aria-hidden="true"></i> Pendidikan Karyawan
    </h3>
    <div class="box has-text-white has-background-danger">
      Data Karyawan
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">NIK</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. S021557">
            </div>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. Budi Kurniawan">
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. Manager">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. DPCB">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box has-text-white has-background-danger">
      Formulir Pendidikan
    </div>
    <div class="box">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal berlaku</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">s.d</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Level Pendidikan</label>
            <div class="control">
              <div class="select is-fullwidth">
                <select>
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option>SD</option>
                  <option>SMP</option>
                  <option>SMA</option>
                </select>
              </div>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Fakultas</label>
            <div class="control">
              <div class="select is-fullwidth">
                <select>
                  <option disabled="disabled" selected="selected">Pilih</option>
                  <option>Kedokteran</option>
                  <option>Information System</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Institusi Pendidikan</label>
            <div class="control">
              <input class="input" type="text" placeholder="e.g. Telkom University">
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <label class="checkbox">
            <input type="checkbox">
            Berijazah
          </label>
        </div>
        <div class="column is-4">
          <label class="label">Sumber Dana</label>
          <div class="control">
            <label class="radio">
              <input type="radio" name="foobar">
              Pribadi
            </label>
            <label class="radio">
              <input type="radio" name="foobar" checked>
              Dinas
            </label>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <label class="checkbox">
            <input type="checkbox">
            Pengakuan
          </label>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Pengakuan</label>
            <div class="control">
              <input class="input" type="date" placeholder="10-10-2017">
            </div>
          </div>
        </div>
      </div>
    </div>
    <a class="button is-success is-rounded">Simpan</a>
    <a class="button is-danger is-rounded">Batal</a>
    <a class="button is-link is-rounded">Kembali</a>

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        breadcumbs: [{
            name: 'Home'
          },
          {
            name: 'Kompetensi'
          },
          {
            name: 'Pendidikan'
          },
        ]
      }
    },
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
}
.button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
}
</style>