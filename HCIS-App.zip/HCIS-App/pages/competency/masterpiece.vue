<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="masterpiece-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-file-text-o" aria-hidden="true"></i> Mahakarya
    </h3>

    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearpersonalNumber">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">

        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" v-model="personalNumber_query" disabled>
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">

        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="box" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Maha Karya</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate_form[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate_form[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Dikeluarkan</label>
            <div class="control">
              <input name="tanggal_dikeluarkan" class="input " placeholder="e.g. 011124" type="date"
                v-model="dateIssue_form[key]" v-bind:class="{ 'is-danger': errors.has('tanggal_dikeluarkan')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('tanggal_dikeluarkan')" class="help is-danger"> {{
              errors.first('tanggal_dikeluarkan')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Kadaluarsa</label>
            <div class="control">
              <input name="tanggal_kadeluarsa" class="input " placeholder="e.g. Leadership" type="date"
                v-model="expireDate_form[key]" v-bind:class="{ 'is-danger': errors.has('tanggal_kadeluarsa')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('tanggal_kadeluarsa')" class="help is-danger"> {{ errors.first('tanggal_kadeluarsa')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Masterpiece</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('component.tipe_sertifikat') }">
                <select name="tipe_sertifikat" class="select" v-model="masterpiece_type_input[key]"
                  v-validate="'required'" data-vv-scope="component">
                  <option disabled selected>Pilih</option>
                  <option v-for="(certificateType, key) in masterPieceTypes" :key="key"
                    :value="certificateType.id">{{
                    certificateType.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('component.tipe_sertifikat')" class="help is-danger">{{errors.first('component.tipe_sertifikat')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit</label>
            <div class="control">
              <input name="nama_sertifikat" class="input " placeholder="e.g. Leadership" type="text"
                v-model="unit_input[key]" v-bind:class="{ 'is-danger': errors.has('component.nama_sertifikat')}"
                v-validate="'required'" data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.nama_sertifikat')" class="help is-danger"> {{ errors.first('component.nama_sertifikat')
              }}</p>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi</label>
            <div class="control">
              <input name="nomor_sertifikat" class="input " placeholder="e.g. 011124" type="text"
                v-model="position_input[key]" v-bind:class="{ 'is-danger': errors.has('component.nomor_sertifikat')}"
                v-validate="'required'" data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.nomor_sertifikat')" class="help is-danger"> {{ errors.first('component.nomor_sertifikat')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Event</label>
            <div class="control">
              <input name="badan_sertifikasi" class="input " placeholder="e.g. Telkom" type="text"
                v-model="event_name_input[key]" v-bind:class="{ 'is-danger': errors.has('component.badan_sertifikasi')}"
                v-validate="'required'" data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.badan_sertifikasi')" class="help is-danger"> {{ errors.first('component.badan_sertifikasi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Lokasi</label>
            <div class="control">
              <input name="location" class="input " placeholder="e.g. Telkom" type="text" v-model="location_input[key]"
                v-bind:class="{ 'is-danger': errors.has('component.location')}" v-validate="'required'"
                data-vv-scope="component">
            </div>
            <p v-show="errors.has('component.location')" class="help is-danger"> {{ errors.first('component.location')
              }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
      <!-- <a class="button is-danger is-rounded" @click="deleteComponents(key)">Hapus</a> -->
    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Mahakarya</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Dikeluarkan</label>
            <div class="control">
              <input name="tanggal_dikeluarkan" class="input " placeholder="e.g. 011124" type="date" v-model="dateIssue"
                v-bind:class="{ 'is-danger': errors.has('form.tanggal_dikeluarkan')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.tanggal_dikeluarkan')" class="help is-danger"> {{
              errors.first('form.tanggal_dikeluarkan')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Kadaluarsa</label>
            <div class="control">
              <input name="tanggal_kadeluarsa" class="input " placeholder="e.g. Leadership" type="date"
                v-model="expireDate" v-bind:class="{ 'is-danger': errors.has('form.tanggal_kadeluarsa')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.tanggal_kadeluarsa')" class="help is-danger"> {{ errors.first('form.tanggal_kadeluarsa')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Mahakarya</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.tipe_sertifikat') }">
                <select name="tipe_sertifikat" class="select" v-model="masterpiece_type" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(certificateType, key) in masterPieceTypes" :key="key"
                    :value="certificateType.id">{{
                    certificateType.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.tipe_sertifikat')" class="help is-danger">{{errors.first('form.tipe_sertifikat')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit</label>
            <div class="control">
              <input name="nama_sertifikat" class="input " placeholder="e.g. Leadership" type="text" v-model="unit"
                v-bind:class="{ 'is-danger': errors.has('form.nama_sertifikat')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.nama_sertifikat')" class="help is-danger"> {{ errors.first('form.nama_sertifikat')
              }}</p>
          </div>
        </div>

        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi</label>
            <div class="control">
              <input name="nomor_sertifikat" class="input " placeholder="e.g. 011124" type="text" v-model="position"
                v-bind:class="{ 'is-danger': errors.has('form.nomor_sertifikat')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.nomor_sertifikat')" class="help is-danger"> {{ errors.first('form.nomor_sertifikat')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Acara</label>
            <div class="control">
              <input name="badan_sertifikasi" class="input " placeholder="e.g. Telkom" type="text" v-model="event_name"
                v-bind:class="{ 'is-danger': errors.has('form.badan_sertifikasi')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.badan_sertifikasi')" class="help is-danger"> {{ errors.first('form.badan_sertifikasi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Lokasi</label>
            <div class="control">
              <input name="location" class="input " placeholder="e.g. Telkom" type="text" v-model="location"
                v-bind:class="{ 'is-danger': errors.has('form.location')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.location')" class="help is-danger"> {{ errors.first('form.location')
              }}</p>
          </div>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>


      <!-- <a class="button is-success is-rounded" @click="tambahComponent()">Tambah</a> -->
    </div>
    <a class="button is-success is-rounded" @click="storeComponent()">Simpan</a>
    <!-- <a class="button is-danger is-rounded">Batal</a>
    <a class="button is-link is-rounded">Kembali</a> -->

  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        key: null,
        buscd: '',
        name: '',
        personalNumber: null,
        cUnit: '',
        cPosition: '',
        startDate: '',
        endDate: '',
        dateIssue: '',
        expireDate: '',
        masterpiece_type: '',
        position: '',
        unit: '',
        event_name: '',
        location: '',
        startDate_form: [],
        endDate_form: [],
        dateIssue_form: [],
        expireDate_form: [],
        masterpiece_type_input: [],
        position_input: [],
        unit_input: [],
        event_name_input: [],
        location_input: [],
        buscds: [],
        components: [],
        masterPieceTypes: [],

        personalNumber_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,

        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: "S001257"
        },
        limit: 10,

        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Kompetensi'
          },
          {
            name: 'Mahakarya'
          },
        ]
      }
    },
    created() {
      this.getMasterPieceType();
      this.getBUSCD();
      if (this.personalNumber_query != null) {
        this.getData();
      }
    },
    methods: {
      getData() {
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('users/' + this.buscd + '/masterpiece/' + this.personalNumber)
          .then(response => {
            this.components = [];
            response.data.data.forEach(async (certificate, key) => {
              this.components.push({
                begin_date: certificate.begin_date,
                end_date: certificate.end_date,
                masterpiece_start: certificate.masterpiece_start,
                masterpiece_finish: certificate.masterpiece_finish,
                personal_number: certificate.personal_number,
                business_code: certificate.business_code,
                masterpiece_type: certificate.masterpiece_type[0].object_id,
                position: certificate.position,
                unit: certificate.unit,
                event_name: certificate.event_name,
                location: certificate.location

              });
              this.key = key;
              this.startDate_form[this.key] = certificate.begin_date;
              this.endDate_form[this.key] = certificate.end_date;
              this.dateIssue_form[this.key] = certificate.masterpiece_start;
              this.expireDate_form[this.key] = certificate.masterpiece_finish;
              this.masterpiece_type_input[this, key] = certificate.masterpiece_type[0].object_id;
              this.position_input[this.key] = certificate.position;
              this.unit_input[this.key] = certificate.unit;
              this.event_name_input[this.key] = certificate.event_name;
              this.location_input[this.key] = certificate.location;

            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('users/' + this.buscd + '/masterpiece/' + this.personalNumber)
              .then(response => {
                this.components = [];
                response.data.data.forEach(async (certificate, key) => {
                  this.components.push({
                    begin_date: certificate.begin_date,
                    end_date: certificate.end_date,
                    masterpiece_start: certificate.masterpiece_start,
                    masterpiece_finish: certificate.masterpiece_finish,
                    personal_number: certificate.personal_number,
                    business_code: certificate.business_code,
                    masterpiece_type: certificate.masterpiece_type[0].object_id,
                    position: certificate.position,
                    unit: certificate.unit,
                    event_name: certificate.event_name,
                    location: certificate.location

                  });
                  this.key = key;
                  this.startDate_form[this.key] = certificate.begin_date;
                  this.endDate_form[this.key] = certificate.end_date;
                  this.dateIssue_form[this.key] = certificate.masterpiece_start;
                  this.expireDate_form[this.key] = certificate.masterpiece_finish;
                  this.masterpiece_type_input[this, key] = certificate.masterpiece_type[0].object_id;
                  this.position_input[this.key] = certificate.position;
                  this.unit_input[this.key] = certificate.unit;
                  this.event_name_input[this.key] = certificate.event_name;
                  this.location_input[this.key] = certificate.location;

                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }

        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;


          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              personal_number: this.personalNumber,
              business_code: this.buscd,
              masterpiece_start: this.dateIssue,
              masterpiece_finish: this.expireDate,
              masterpiece_type: this.masterpiece_type,
              unit: this.unit,
              location: this.location,
              position: this.position,
              event_name: this.event_name
            });
            this.components.forEach((certificate, key) => {
              this.key = key;
              this.startDate_form[this.key] = certificate.begin_date;
              this.endDate_form[this.key] = certificate.end_date;
              this.dateIssue_form[this.key] = certificate.masterpiece_start;
              this.expireDate_form[this.key] = certificate.masterpiece_finish;
              this.masterpiece_type_input[this.key] = certificate.masterpiece_type;
              this.unit_input[this.key] = certificate.unit;
              this.position_input[this.key] = certificate.position;
              this.location_input[this.key] = certificate.location;
              this.event_name_input[this.key] = certificate.event_name;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.personalNumber_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  begin_date: this.startDate_form[index1],
                  end_date: this.endDate_form[index1],
                  masterpiece_start: this.dateIssue_form[index1],
                  masterpiece_finish: this.expireDate_form[index1],
                  masterpiece_type: this.masterpiece_type_input[index1],
                  unit: this.unit_input[index1],
                  position: this.position_input[index1],
                  location: this.location_input[index1],
                  event_name: this.event_name_input[index1]
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/masterpiece/' + this.personalNumber, this.components)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data Komunikasi.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              Object.assign(this.components[index1], {
                begin_date: this.startDate_form[index1],
                end_date: this.endDate_form[index1],
                masterpiece_start: this.dateIssue_form[index1],
                masterpiece_finish: this.expireDate_form[index1],
                masterpiece_type: this.masterpiece_type_input[index1],
                unit: this.unit_input[index1],
                position: this.position_input[index1],
                location: this.location_input[index1],
                event_name: this.event_name_input[index1]
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/masterpiece/' + this.personalNumber, this.components)
                  .then(response => {
                    swal(
                      'Saved!',
                      'Successfully saved basic pay.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearpersonalNumber()
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        this.components.forEach((certificate, key) => {
          this.key = key;
          this.startDate_form[this.key] = certificate.begin_date;
          this.endDate_form[this.key] = certificate.end_date;
          this.dateIssue_form[this.key] = certificate.masterpiece_start;
          this.expireDate_form[this.key] = certificate.masterpiece_finish;
          this.masterpiece_type_input[this.key] = certificate.masterpiece_type;
          this.unit_input[this.key] = certificate.unit;
          this.position_input[this.key] = certificate.position;
          this.location_input[this.key] = certificate.location;
          this.event_name_input[this.key] = certificate.event_name;
        })
      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.personalNumber = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.dateIssue = '';
        this.expireDate = '';
        this.masterpiece_type = '';
        this.location = '';
        this.unit = '';
        this.position = '';
        this.event_name = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/CRTFT')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getMasterPieceType() {
        // this.$axios.get('/users/otype/MSTTY/object')
        this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=MSTTY')
          .then(response => {
            this.masterPieceTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      }

    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-certificate: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
