<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <a class="button is-link is-rounded is-pulled-right"  @click="openFormModal()"> <span><i class="fa fa-plus" aria-hidden="true"></i> Tambah Data </span></a>

    <h3 class="subtitle is-3">
      <i class="fa fa-star-o" aria-hidden="true"></i> Pencarian Data Kompetensi
    </h3>
    <!--<div class="box has-text-white has-background-danger">
      Filter Search
    </div>-->
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i class="fa fa-plus"
                  aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i class="fa fa-trash"
                  aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"><span><i class="fa fa-search"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Nomer Induk Karyawan</th>
          <th>Tanggal Awal Berlaku</th>
          <th>Tanggal Akhir Berlaku</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(competency, key) in competencys" :key="key">
          <td> {{key+1}} </td>
          <td> {{competency.personalNumber}}</td>
          <td> {{competency.startDate}} </td>
          <td> {{competency.endDate}} </td>
          <td>
            <nuxt-link :to="'/competency?nik='+competency.personalNumber+'&buscd='+competency.buscd">
                <a class="button is-success is-outlined is-rounded is-small"><i class="fa fa-pencil" aria-hidden="true"></i></a>
            </nuxt-link>
            <!-- <a class="button is-success is-outlined is-rounded" @click="editCompete(competency.personalNumber)"><i
                class="fa fa-pencil" aria-hidden="true"></i></a>
            <a class="button is-danger is-outlined is-rounded" @click="competency.personalNumber ? deleteEmployee(key, competency.personalNumber) : removeGroupSociometri(key)"><i
                class="fa fa-trash" aria-hidden="true"></i></a> -->
          </td>
        </tr>
      </thead>
    </table>
    <!-- <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Edit Data</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Start Date</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('begin_date')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">End Date</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date" placeholder="e.g 10-11-2018"
                    v-model="endDate" data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('end_date')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select " v-bind:class="{ 'is-danger': errors.has('nama_perusahaan') }">
                    <select name="nama_perusahaan" class="select" v-model="company" v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">{{
                        company.company_name
                        }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('nama_perusahaan')" class="help is-danger">{{ errors.first('nama_perusahaan')
                    }}</p>
                </div>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Payroll Area</label>
                <div class="control">
                  <input name="full_name" class="input " placeholder="Payroll Area" type="text" v-model="fullName"
                    v-bind:class="{ 'is-danger': errors.has('full_name')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('full_name')" class="help is-danger"> {{ errors.first('full_name') }}</p>
              </div>
            </div>
          </div>
          <div class="columns">
            <div class="column is-4">
              <div class="field">
                <label class="label">Nama Payroll</label>
                <div class="control">
                  <input name="nickname" class="input " placeholder="Nama Payroll" type="text" v-model="nickName"
                    v-bind:class="{ 'is-danger': errors.has('nickname')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('nickname')" class="help is-danger"> {{ errors.first('nickname') }}</p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">Tanggal Berlaku</label>
                <div class="control">
                  <input name="birth_place" class="input " placeholder="Tanggal Berlaku" type="date" v-model="birthPlace"
                    v-bind:class="{ 'is-danger': errors.has('birth_place')}" v-validate="'required'">
                </div>
                <p v-show="errors.has('birth_place')" class="help is-danger"> {{ errors.first('birth_place') }}</p>
              </div>
            </div>
            <div class="column is-4">
              <div class="field">
                <label class="label">S.d</label>
                <div class="control">
                  <input name="born_date" class="input " placeholder="S.d" type="date" v-model="birthDate" v-bind:class="{ 'is-danger': errors.has('born_date')}"
                    v-validate="'required'">
                </div>
                <p v-show="errors.has('born_date')" class="help is-danger"> {{ errors.first('born_date') }}</p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveEmployee()" class="button is-link">Save</button>
            <button class="button" @click="closeFormModal()">Cancel</button>
          </div>
        </footer>
      </div>
    </div> -->
    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Formulir Kompetensi</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body"> 
    
      <div class="columns">
        <div class="column is-5">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">         
        <div class="column is-5">
          <div class="field">
            <label class="label">Nomor Induk Karyawan</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="" v-model="nik_query" disabled>
            </div>
          </div>
        </div> 
        <div class="column is-5">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="name" disabled>
            </div>
          </div>
        </div> 
      </div>
      <div class="columns">
        <div class="column is-5">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="Manager" v-model="cPosition" disabled>
            </div>
          </div>
        </div>  
        <div class="column is-5">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="DPCB" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
      <hr>
      <div class="columns">
        <div class="column is-5">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input class="input" id="begin_date" type="date" placeholder="10-10-2017" name="begin_date"
                v-model="startDate" data-vv-as="start date" v-bind:class="{ 'is-danger': errors.has('form.begin_date')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-5">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" class="input" name="end_date" type="date" placeholder="10-10-2017" v-model="endDate"
                data-vv-as="End date" v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
        </div>
          <div class="columns">
        <div class="column">
          <div class="field">
            <label class="label">Kompetensi</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('competence_type') }">
                <select name="competence_type" class="select" v-model="objectCode" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(competenceType, key) in competenceTypes" :key="key" :value="competenceType.object_id">{{
                    competenceType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('competence_type')" class="help is-danger">{{errors.first('competence_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column">
          <div class="field">
            <label class="label">Tipe Data</label>
            <div class="control">
              <div class="select  is-fullwidth" v-bind:class="{ 'is-danger': errors.has('data_type') }">
                <select name="data_type" class="select" v-model="dataType" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(dataType, key) in dataTypes" :key="key" :value="dataType.object_id">{{
                    dataType.name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('data_type')" class="help is-danger">{{errors.first('data_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column">
          <div class="field">
            <label class="label">Nilai Kompetensi</label>
            <div class="control">
              <input name="nilai_kompetensi" class="input " placeholder="" type="text" v-model="objectValue"
                v-bind:class="{ 'is-danger': errors.has('nilai_kompetensi')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('nilai_kompetensi')" class="help is-danger"> {{ errors.first('nilai_kompetensi')
              }}</p>
          </div>
        </div>
      </div>
      <a class="button is-success is-rounded" @click="tambahComponent()">+</a>
    
        </section>
        <footer class="modal-card-foot">
          <div class="control  ">
            <button @click="saveEmployee()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
  </div>
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        isActiveForm:false,
        nikAuth: this.$auth.user.nik,
        key: null,
        startDate: '',
        endDate: '',
        businessCode: '1000',
        personalNumber: '',
        fullName: '',
        competencys: [],
        companies: [],
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Kompetensi'
          },
          {
            name: 'Pencarian'
          }
        ],
        isActiveForm: false,
      }
    },
    created() {
      this.getCompetency();
      //this.getCompany();
      this.getColumn();
      this.getLogic();
      this.getCondition();
    },
    methods: {
      openFormModal() {
        this.isActiveForm = true;
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.personalNumber = '';
        this.fullName = '';
        this.$nextTick(() => this.$validator.reset())
      },
      getCompetency() {
        this.$axios.get('users/qualification/0001?per_page=20')
          .then(response => {
            this.competencys = [];
            response.data.data.forEach(async (competency, key) => {
              await this.competencys.push({
                startDate: competency.begin_date,
                endDate: competency.end_date,
                personalNumber: competency.personal_number,
                buscd: competency.business_code
              })
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      //  closeFormModal() {
      //   this.buscd = '';
      //   this.fullName = '';
      //   this.$nextTick(() => this.$validator.reset())
      // },
      getColumn() {
        this.$axios.get('/objects/alltable/Qualification/column')
          .then(response => {
            this.columns = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getLogic() {
        this.$axios.get('/objects/oprationsql')
          .then(response => {
            this.logics = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCondition() {
        this.$axios.get('/objects/conditionsql')
          .then(response => {
            this.conditions = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getSearchDynamic() {
        this.paramsearchforms = {
          table: "Qualification", //harcode sesuai form *referensi table_code*
          column: this.columns_model,
          query: this.logics_model,
          value: this.filters_model,
          andor: this.conditions_model
        }
        console.log(this.paramsearchforms)
        this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
          .then(response => {

            this.competencys = [];
            response.data.data.forEach(async (competency, key) => {
              await this.competencys.push({
                startDate: competency.begin_date,
                endDate: competency.end_date,
                personalNumber: competency.personal_number,
                buscd: competency.business_code
              })
            });
            console.log(this.competencys);
          })
          .catch(e => {
            console.log(e);
          });
      },
      editCompete(personalNumber) {
        this.openFormModal();
        this.getCompetencys(personalNumber);
      },
      async getCompetencys(personalNumber) {
        let competency = await this.competencys.find(competency => competency.personalNumber == personalNumber);
        this.startDate = competency.startDate;
        this.endDate = competency.endDate;
        this.personalNumber = competency.personalNumber;
      },
      getCompany() {
        this.$axios.get('/objects/companytoken')
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      addNewFormSearch() {
        this.searchforms.push({
          column: '',
          logic: '',
          filter: '',
          condition: ''
        })
      },
      deleteFormSearch(key) {
        this.searchforms.splice(key, 1)
      }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
</style>
