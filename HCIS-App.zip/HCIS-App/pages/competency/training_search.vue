<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <!-- <nuxt-link to="/competency/training"><a class="button is-link is-rounded is-pulled-right">Tambah Data</a>
    </nuxt-link> -->
    <a class="button is-link is-rounded is-pulled-right" @click="openFormModal()">
      <span>
        <i class="fa fa-plus" aria-hidden="true"></i> Tambah Data
      </span>
    </a>
    <h3 class="subtitle is-3">
      <i class="fa fa-star-o" aria-hidden="true"></i> Data Pelatihan
    </h3>
    <div class="box shadowed">
      <div v-for="(form, key) in searchforms" :key="key">
        <div class="columns">
          <div class="column is-3">
            <div class="field">
              <label class="label">Kolum</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="columns_model[key]">
                    <option v-for="(column, key) in columns" :key="key" :value="column.column_code">
                      {{ column.column_name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Logika</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="logics_model[key]">
                    <option v-for="(logic, key) in logics" :key="key" :value="logic.object_id">
                      {{ logic.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-3">
            <div class="field">
              <label class="label">Filter</label>
              <div class="control">
                <input class="input" type="text" v-model="filters_model[key]">
              </div>
            </div>
          </div>
          <div class="column is-2">
            <div class="field">
              <label class="label">Kondisi</label>
              <div class="control">
                <div class="select is-fullwidth">
                  <select v-model="conditions_model[key]">
                    <option v-for="(condition, key) in conditions" :key="key" :value="condition.object_id">
                      {{ condition.name }}
                    </option>
                  </select>
                </div>
              </div>
            </div>
          </div>
          <div class="column is-1">
            <br>
            <div v-if="key==0">
              <a class="button is-success is-outlined is-rounded is-pulled-right" @click="addNewFormSearch()"><i
                  class="fa fa-plus" aria-hidden="true"></i></a>
            </div>
            <div v-else>
              <a class="button is-danger is-outlined is-rounded is-pulled-right" @click="deleteFormSearch(key)"><i
                  class="fa fa-trash" aria-hidden="true"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column">
          <a class="button is-success is-rounded is-pulled-right" @click="getSearchDynamic()"> <span> <i
                class="fa fa-search" aria-hidden="true"></i> Cari </span></a>
        </div>
      </div>
    </div>
    <br>
    <table class="table is-striped is-narrow is-hoverable is-fullwidth">
      <thead>
        <tr>
          <th>No.</th>
          <th>Perusahaan</th>
          <th>Nomer Induk Karyawan</th>
          <th>Nama Pelatihan</th>
          <th>Kelas Pelatihan</th>
          <th>Tanggal Awal Berakhir</th>
          <th>Tanggal Akhir Berakhir</th>
          <th>Aksi</th>
        </tr>
        <tr v-for="(training, key) in trainings" :key="key">
          <td>{{ key + 1 }}</td>
          <td>{{ training.business_code.company_name }}</td>
          <td>{{ training.personnel_number.personnel_number }}</td>
          <td>{{ training.training_title }}</td>
          <td>{{ training.training_class }}</td>
          <td>{{ formatDate(training.begin_date) }}</td>
          <td>{{ formatDate(training.end_date) }}</td>
          <td>
            <a class="button is-success is-small is-outlined is-rounded"
              @click="editTraining(training.object_identifier)">
              <i class="fa fa-pencil" aria-hidden="true"></i>
            </a>
            <a class="button is-danger is-small is-outlined is-rounded"
              @click="training.object_identifier ? deleteTraining(key, training.object_identifier) : removeTraining(key)">
              <i class="fa fa-trash" aria-hidden="true"></i>
            </a>
            <a class="button is-warning is-small is-outlined is-rounded"
              @click="showDelimitTraining(training.object_identifier)">
              <i class="fa fa-clock-o" aria-hidden="true"></i>
            </a>
          </td>
        </tr>
      </thead>
    </table>

    <pagination v-if="pagination.total_pages > 1" :pagination="pagination" :offset="5" @paginate="getTrainings()">
    </pagination>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveForm }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Data Pelatihan</p>
          <button @click="closeFormModal()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Nama Perusahaan</label>
                <div class="control">
                  <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('company') }">
                    <select name="company" class="select" v-model="company" @change="getParam()"
                      v-validate="'required'">
                      <option disabled selected>Choose</option>
                      <option v-for="(company, key) in companies" :key="key" :value="company.business_code">
                        {{ company.company_name }}</option>
                    </select>
                  </div>
                  <p v-show="errors.has('company')" class="help is-danger">{{ errors.first('company') }}</p>
                </div>
              </div>
            </div>
          </div>

          <span v-show="company">
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Induk Karyawan <a v-if="employee != null" @click="employee = null"
                      class="is-link">Ubah</a></label>
                  <div class="control" v-if="employee == null">
                    <vue-autosuggest name="personnel_number" ref="reference" :suggestions="filterEmployee"
                      @selected="selectEmployee" :limit="10" :input-props="inputEmployee"
                      v-bind:class="{ 'is-danger': errors.has('personnel_number')}" v-validate="'required'">
                    </vue-autosuggest>
                  </div>
                  <div class="control" v-else>
                    <input name="personnel_number" class="input" placeholder="Nomor Induk Karyawan" type="text"
                      v-model="employee" v-bind:class="{ 'is-danger': errors.has('personnel_number')}"
                      v-validate="'required'" disabled>
                  </div>
                  <p v-show="errors.has('personnel_number')" class="help is-danger">
                    {{ errors.first('personnel_number') }}
                  </p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nama</label>
                  <div class="control">
                    <input name="empolyeeName" class="input" placeholder="Nama" type="text" v-model="empolyeeName"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Posisi Saat Ini</label>
                  <div class="control">
                    <input name="empolyeePosition" class="input" placeholder="Posisi" type="text"
                      v-model="empolyeePosition" v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Unit Saat Ini</label>
                  <div class="control">
                    <input name="empolyeeUnit" class="input" placeholder="Unit" type="text" v-model="empolyeeUnit"
                      v-validate="'required'" disabled>
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Awal Berlaku</label>
                  <div class="control">
                    <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                      v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Akhir Berlaku</label>
                  <div class="control">
                    <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                      placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                      v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Mulai Pelatihan</label>
                  <div class="control">
                    <input id="start_training" data-display-mode="dialog" class="input" name="start_training"
                      type="date" placeholder="e.g 10-11-2018" v-model="startTraining" data-vv-as="Masterpiece Start"
                      v-bind:class="{ 'is-danger': errors.has('start_training')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('start_training')" class="help is-danger">
                    {{ errors.first('start_training') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Tanggal Selesai Pelatihan</label>
                  <div class="control">
                    <input id="finish_training" data-display-mode="dialog" class="input" name="finish_training"
                      type="date" placeholder="e.g 10-11-2018" v-model="endTraining" data-vv-as="Masterpiece Finish"
                      v-bind:class="{ 'is-danger': errors.has('finish_training')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('finish_training')" class="help is-danger">
                    {{ errors.first('finish_training') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Judul Pelatihan</label>
                  <div class="control">
                    <input name="training_title" class="input " placeholder="Judul Pelatihan" type="text"
                      v-model="trainingTitle" v-bind:class="{ 'is-danger': errors.has('training_title')}"
                      v-validate="'required'">
                  </div>
                  <p v-show="errors.has('training_title')" class="help is-danger"> {{ errors.first('training_title') }}
                  </p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Kode Pelatihan</label>
                  <div class="control">
                    <input name="training_code" class="input " placeholder="Kelas Pelatihan" type="text" v-model="trainingCode"
                      v-bind:class="{ 'is-danger': errors.has('training_code')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('training_code')" class="help is-danger"> {{ errors.first('training_code') }}
                  </p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Kelas Pelatihan</label>
                  <div class="control">
                    <input name="training_class" class="input " placeholder="Kelas Pelatihan" type="text" v-model="classTraining"
                      v-bind:class="{ 'is-danger': errors.has('training_class')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('training_class')" class="help is-danger"> {{ errors.first('training_class') }}
                  </p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Klasifikasi</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('classification') }">
                      <select name="classification" class="select" v-model="classification" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(classification, key) in classifications" :key="key" :value="classification.object_code">
                          {{ classification.object_name }}
                        </option>
                      </select>
                    </div>
                    <p v-show="errors.has('classification')" class="help is-danger">
                      {{ errors.first('classification') }}</p>
                  </div>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Institusi</label>
                  <div class="control">
                    <input name="institution" class="input " placeholder="Institusi" type="text" v-model="institution"
                      v-bind:class="{ 'is-danger': errors.has('institution')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('institution')" class="help is-danger"> {{ errors.first('institution') }}
                  </p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Deskripsi</label>
                  <div class="control">
                    <input name="information" class="input " placeholder="Deskripsi" type="text" v-model="information"
                      v-bind:class="{ 'is-danger': errors.has('information')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('information')" class="help is-danger"> {{ errors.first('information') }}
                  </p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Mata Uang Pelatihan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('currency_type1') }">
                      <select name="currency_type1" class="select" v-model="currencyType01" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(currencyType01, key) in currencyTypes" :key="key" :value="currencyType01.object_code">
                          {{ currencyType01.object_name }}
                        </option>
                      </select>
                    </div>
                    <p v-show="errors.has('currency_type1')" class="help is-danger">{{ errors.first('currency_type1') }}
                    </p>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Biaya Pelatihan</label>
                  <div class="control">
                    <input name="training_cost" class="input" placeholder="Biaya Pelatihan" type="text"
                      v-model="trainingCost" @keypress="onlyNumber"
                      v-bind:class="{ 'is-danger': errors.has('training_cost')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('training_cost')" class="help is-danger">{{ errors.first('training_cost') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Mata Uang Perjalanan</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('currency_type2') }">
                      <select name="currency_type2" class="select" v-model="currencyType02" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(currencyType02, key) in currencyTypes" :key="key" :value="currencyType02.object_code">
                          {{ currencyType02.object_name }}
                        </option>
                      </select>
                    </div>
                    <p v-show="errors.has('currency_type2')" class="help is-danger">{{ errors.first('currency_type2') }}
                    </p>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Biaya Perjalanan</label>
                  <div class="control">
                    <input name="travel_cost" class="input" placeholder="Biaya Perjalanan" type="text"
                      v-model="travelCost" @keypress="onlyNumber"
                      v-bind:class="{ 'is-danger': errors.has('travel_cost')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('travel_cost')" class="help is-danger">{{ errors.first('travel_cost') }}</p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label class="label">Jumlah Peserta</label>
                  <div class="control">
                    <input name="number_participants" class="input " placeholder="Jumlah Peserta" type="text"
                      v-model="totalParticipant" @keypress="onlyNumber"
                      v-bind:class="{ 'is-danger': errors.has('number_participants')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('number_participants')" class="help is-danger">
                    {{ errors.first('number_participants') }}
                  </p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Durasi</label>
                  <div class="control">
                    <input name="long_time" @keypress="onlyNumber" class="input " placeholder="Durasi" type="text"
                      v-model="duration" v-bind:class="{ 'is-danger': errors.has('long_time')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('long_time')" class="help is-danger"> {{ errors.first('long_time') }}
                  </p>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label class="label">Tipe Waktu</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('time_type') }">
                      <select name="time_type" class="select" v-model="timeType" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(timeType, key) in timeTypes" :key="key" :value="timeType.object_code">
                          {{ timeType.object_name }}
                        </option>
                      </select>
                    </div>
                    <p v-show="errors.has('time_type')" class="help is-danger">
                      {{ errors.first('time_type') }}</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Negara</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('country') }">
                      <select name="country" class="select" v-model="country" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(country, key) in countries" :key="key" :value="country.object_code">
                          {{ country.object_name }}
                        </option>
                      </select>
                    </div>
                    <p v-show="errors.has('country')" class="help is-danger">{{ errors.first('country') }}
                    </p>
                  </div>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Kota</label>
                  <div class="control">
                    <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('city') }">
                      <select name="city" class="select" v-model="city" v-validate="'required'">
                        <option disabled selected>Choose</option>
                        <option v-for="(city, key) in cities" :key="key" :value="city.object_code">
                          {{ city.object_name }}
                        </option>
                      </select>
                    </div>
                    <p v-show="errors.has('city')" class="help is-danger">{{ errors.first('city') }}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column">
                <div class="field">
                  <label class="label">Ranking</label>
                  <div class="control">
                    <input name="rank" class="input" placeholder="Ranking" type="text" v-model="rank"
                      @keypress="onlyNumber" v-bind:class="{ 'is-danger': errors.has('rank')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('rank')" class="help is-danger">{{ errors.first('rank') }}</p>
                </div>
              </div>
              <div class="column">
                <div class="field">
                  <label class="label">Nomor Referensi</label>
                  <div class="control">
                    <input name="reference_number" class="input" placeholder="Nomor Referensi" type="text"
                      v-model="referenceNumber" @keypress="onlyNumber"
                      v-bind:class="{ 'is-danger': errors.has('reference_number')}" v-validate="'required'">
                  </div>
                  <p v-show="errors.has('reference_number')" class="help is-danger">
                    {{ errors.first('reference_number') }}
                  </p>
                </div>
              </div>
            </div>
            <div class="columns">
              <div class="column is-4">
                <div class="field">
                  <label for="checkbox" class="checkbox">
                    <input type="checkbox" name="before_after_company" v-model="beforeAfterCompany">
                    Setelah Masuk Perusahaan
                  </label>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label for="checkbox" class="checkbox">
                    <input type="checkbox" name="flag_done" v-model="flagDone">
                    Selesai
                  </label>
                </div>
              </div>
              <div class="column is-4">
                <div class="field">
                  <label for="checkbox" class="checkbox">
                    <input type="checkbox" name="flag_success" v-model="flagSuccess">
                    Sukses
                  </label>
                </div>
              </div>
            </div>
          </span>

        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="saveTraining()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModal()">Batal</button>
          </div>
        </footer>
      </div>
    </div>

    <div class="modal" id="modal-form" v-bind:class="{ 'is-active': isActiveFormDelimit }">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">Delimit Data Pelatihan</p>
          <button @click="closeFormModalDelimit()" class="delete" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
          <div class="columns">
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Awal Berlaku</label>
                <div class="control">
                  <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                    v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'"
                    data-vv-scope="delimit" disabled>
                </div>
                <p v-show="errors.has('delimit.begin_date')" class="help is-danger">
                  {{ errors.first('delimit.begin_date') }}</p>
              </div>
            </div>
            <div class="column">
              <div class="field">
                <label class="label">Tanggal Akhir Berlaku</label>
                <div class="control">
                  <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                    placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                    v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'"
                    data-vv-scope="delimit">
                </div>
                <p v-show="errors.has('delimit.end_date')" class="help is-danger">{{ errors.first('delimit.end_date') }}
                </p>
              </div>
            </div>
          </div>
        </section>
        <footer class="modal-card-foot">
          <div class="control">
            <button @click="delimitTraining()" class="button is-success">Simpan</button>
            <button class="button is-danger" @click="closeFormModalDelimit()">Batal</button>
          </div>
        </footer>
      </div>
    </div>
  </section>
</template>

<script>
  import Breadcrumb from "~/components/Breadcrumb";
  import Vue from "vue";
  import Pagination from '~/components/PaginationComponent.vue';
  Vue.component('pagination', Pagination);
  import VueAutosuggest from "vue-autosuggest";
  Vue.use(VueAutosuggest);
  import moment from "moment";
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        trainings: [],
        objectIdentifier: null,
        startDate: null,
        endDate: null,
        startTraining: null,
        endTraining: null,
        trainingCode: null,
        trainingTitle: '',
        classTraining: '',
        classification: null,
        classifications: [],
        institution: '',
        information: '',
        currencyType01: null,
        trainingCost: null,
        currencyType02: null,
        travelCost: null,
        currencyTypes: [],
        totalParticipant: null,
        duration: null,
        timeType: null,
        timeTypes: [],
        country: null,
        countries: [],
        city: null,
        cities: [],
        rank: null,
        referenceNumber: null,
        beforeAfterCompany: '',
        flagDone: '',
        flagSuccess: '',
        company: null,
        companies: [],
        employee: null,
        employees: [],
        empolyeeName: "",
        empolyeePosition: "",
        empolyeeUnit: "",
        perPage: 5,
        search: '',
        pagination: {
          'current_page': 1
        },
        options: [{
          data: []
        }],
        filterEmployee: [],
        inputEmployee: {
          id: "autosuggest__input",
          name: "personnel_number",
          class: "input",
          onInputChange: this.getEmployee,
          placeholder: "Nomor Induk Karyawan"
        },
        limit: 10,
        columns: [],
        logics: [],
        conditions: [],
        filters: [],
        paramsearchforms: '',
        columns_model: [],
        filters_model: [],
        conditions_model: [],
        logics_model: [],
        searchforms: [{
          column: '',
          logic: '',
          filter: '',
          condition: ''
        }],
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Kualifikasi'
          },
          {
            name: 'Pelatihan'
          }
        ],
        isActiveForm: false,
        isActiveFormDelimit: false
      }
    },
    created() {
      this.getTrainings();
      this.getCompany();
      // this.getCompetency();
      // this.getColumn();
      // this.getLogic();
      // this.getCondition();
    },
    methods: {
      getCompany() {
        this.$axios
          .get(
            "hcis/api/company?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD")
          )
          .then(response => {
            this.companies = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getEmployee(text) {
        if (text === "" || text === undefined) {
          return;
        }
        this.$axios
          .get(
            "hcis/api/personal?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (employee, key) => {
              await this.options[0].data.push(employee.personnel_number);
            });
            const filteredData = this.options[0].data
              .filter(item => {
                return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
              })
              .slice(0, this.limit);
            this.filterEmployee = [{
              data: filteredData
            }];
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getEmployeeData(nik) {
        await this.$axios
          .get(
            "hcis/api/organizationalassignment?include=personnel_number&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&personnel_number=" + nik +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(async response => {
            this.empolyeeName = response.data.data[0].personnel_number.complete_name;
            this.empolyeePosition = response.data.data[0].position_name;
            this.empolyeeUnit = response.data.data[0].unit_name;
          })
          .catch(e => {
            console.log(e);
          });
      },
      selectEmployee(option) {
        if (option == null) {
          this.employee = null;
          this.empolyeeName = '';
          this.empolyeeUnit = '';
          this.empolyeePosition = '';
        } else {
          this.employee = option.item;
          if (this.company == null) {
            swal('', 'Pilih nama perusahaan terlebih dahulu !', 'error')
          } else {
            this.getEmployeeData(option.item);
          }
        }
      },
      getClassification() {
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=CLASS" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.classifications = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getCurrencyType() {
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=CURTY"
          )
          .then(response => {
            this.currencyTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getTimeType() {
        this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=ZEINH" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.timeTypes = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getCountry() {
        await this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=CONTR" +
            "&per_page=9999" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.countries = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getCity() {
        await this.$axios
          .get(
            "ldap/api/object?begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&object_type=CITY" +
            "&per_page=9999" +
            "&business_code=*" +
            "&business_code=" + this.company
          )
          .then(response => {
            this.cities = response.data.data;
          })
          .catch(e => {
            console.log(e);
          });
      },
      getTrainings() {
        this.$axios
          .get("hcis/api/pelatihan?include=personnel_number&include=business_code&begin_date_lte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&end_date_gte=" +
            moment(new Date()).format("YYYY-MM-DD") +
            "&order[oid]=asc" +
            '&page=' + this.pagination.current_page +
            '&per_page=' + this.perPage
          )
          // .get("hcis/api/pelatihan")
          .then(response => {
            this.trainings = response.data.data;
            this.pagination = response.data.meta.pagination;
          })
          .catch(e => {
            console.log(e);
          });
      },
      async getTraining(objectIdentifier) {
        let training = await this.trainings.find(
          training => training.object_identifier == objectIdentifier
        );
        this.objectIdentifier = training.object_identifier;
        this.startDate = training.begin_date;
        this.endDate = training.end_date;
        this.timeType = training.time_type;
        (training.before_after_company == 'y') ? this.beforeAfterCompany = true: 'n';
        this.rank = training.rank;
        this.country = training.country;
        this.duration = training.long_time;
        this.city = training.city;
        this.information = training.information;
        (training.flag_done == 'y') ? this.flagDone = true: 'n';
        this.trainingCode = training.training_code;
        this.classification = training.classification;
        (training.flag_success == 'y') ? this.flagSuccess = true: 'n';
        this.totalParticipant = training.number_participants;
        this.trainingTitle = training.training_title;
        this.institution = training.institution;
        this.currencyType01 = training.currency_type1;
        this.currencyType02 = training.currency_type2;
        this.trainingCost = training.training_cost;
        this.travelCost = training.travel_cost;
        this.classTraining = training.training_class;
        this.referenceNumber = training.reference_number;
        this.startTraining = training.start_training;
        this.endTraining = training.finish_training;
        this.company = training.business_code.business_code;
        this.employee = training.personnel_number.personnel_number;
        this.getEmployeeData(this.employee);
      },
      getParam() {
        this.getClassification();
        this.getCurrencyType();
        this.getTimeType();
        this.getCountry();
        this.getCity();
      },
      openFormModal() {
        this.isActiveForm = true;
        this.getParam();
      },
      closeFormModal() {
        this.isActiveForm = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.startTraining = null;
        this.endTraining = null;
        this.trainingCode = null;
        this.trainingTitle = null;
        this.classTraining = null;
        this.classification = null;
        this.institution = null;
        this.information = null;
        this.currencyType01 = null;
        this.trainingCost = null;
        this.currencyType02 = null;
        this.travelCost = null;
        this.totalParticipant = null;
        this.duration = null;
        this.timeType = null;
        this.country = null;
        this.city = null;
        this.rank = null;
        this.referenceNumber = null;
        this.beforeAfterCompany = null;
        this.flagDone = null;
        this.flagSuccess = null;
        this.company = null;
        this.employee = null;
        this.empolyeeName = '';
        this.empolyeePosition = '';
        this.empolyeeUnit = '';
        this.$nextTick(() => this.$validator.reset());
      },
      storeTraining() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;
          if (this.beforeAfterCompany == true) {
            this.beforeAfterCompany = 'y';
          } else {
            this.beforeAfterCompany = 'n';
          }
          if (this.flagDone == true) {
            this.flagDone = 'y';
          } else {
            this.flagDone = 'n';
          }
          if (this.flagSuccess == true) {
            this.flagSuccess = 'y';
          } else {
            this.flagSuccess = 'n';
          }
          this.$axios
            .post('hcis/api/pelatihan', {
              begin_date: this.startDate,
              end_date: this.endDate,
              time_type: this.timeType,
              before_after_company: this.beforeAfterCompany,
              rank: this.rank,
              country: this.country,
              long_time: this.duration,
              city: this.city,
              information: this.information,
              number_participants: this.totalParticipant,
              flag_done: this.flagDone,
              training_code: this.trainingCode,
              classification: this.classification,
              flag_success: this.flagSuccess,
              training_title: this.trainingTitle,
              institution: this.institution,
              currency_type1: this.currencyType01,
              currency_type2: this.currencyType02,
              training_cost: this.trainingCost,
              travel_cost: this.travelCost,
              training_class: this.classTraining,
              reference_number: this.referenceNumber,
              start_training: this.startTraining,
              finish_training: this.endTraining,
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getTrainings();
              this.closeFormModal();
              swal(
                'Saved!',
                'Successfully saved data pelatihan.',
                'success'
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      async editTraining(objectIdentifier) {
        await this.getTraining(objectIdentifier);
        this.openFormModal();
      },
      updateTraining() {
        this.$validator.validateAll('pelatihan').then(async result => {
          if (!result) return;
          if (this.beforeAfterCompany == true) {
            this.beforeAfterCompany = 'y';
          } else {
            this.beforeAfterCompany = 'n';
          }
          if (this.flagDone == true) {
            this.flagDone = 'y';
          } else {
            this.flagDone = 'n';
          }
          if (this.flagSuccess == true) {
            this.flagSuccess = 'y';
          } else {
            this.flagSuccess = 'n';
          }
          this.$axios
            .put('hcis/api/pelatihan', {
              object_identifier: this.objectIdentifier,
              begin_date: this.startDate,
              end_date: this.endDate,
              time_type: this.timeType,
              before_after_company: this.beforeAfterCompany,
              rank: this.rank,
              country: this.country,
              long_time: this.duration,
              city: this.city,
              information: this.information,
              number_participants: this.totalParticipant,
              flag_done: this.flagDone,
              training_code: this.trainingCode,
              classification: this.classification,
              flag_success: this.flagSuccess,
              training_title: this.trainingTitle,
              institution: this.institution,
              currency_type1: this.currencyType01,
              currency_type2: this.currencyType02,
              training_cost: this.trainingCost,
              travel_cost: this.travelCost,
              training_class: this.classTraining,
              reference_number: this.referenceNumber,
              start_training: this.startTraining,
              finish_training: this.endTraining,
              personnel_number: this.employee,
              business_code: this.company
            })
            .then(response => {
              this.getTrainings();
              this.closeFormModal();
              swal(
                'Updated!',
                'Successfully updated data pelatihan.',
                'success'
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      saveTraining() {
        this.objectIdentifier ? this.updateTraining() : this.storeTraining();
      },
      openFormModalDelimit() {
        this.isActiveFormDelimit = true;
      },
      closeFormModalDelimit() {
        this.isActiveFormDelimit = false;
        this.objectIdentifier = null;
        this.startDate = null;
        this.endDate = null;
        this.$nextTick(() => this.$validator.reset());
      },
      async showDelimitTraining(objectIdentifier) {
        this.openFormModalDelimit();
        let training = await this.trainings.find(
          training => training.object_identifier == objectIdentifier
        );
        this.objectIdentifier = training.object_identifier;
        this.startDate = training.begin_date;
        this.endDate = training.end_date;
      },
      delimitTraining() {
        this.$validator.validateAll("delimit").then(async result => {
          if (!result) return;
          this.$axios
            .patch(
              "hcis/api/pelatihan", {}, {
                params: {
                  object_identifier: this.objectIdentifier,
                  end_date: this.endDate
                }
              }
            )
            .then(response => {
              this.getTrainings();
              this.closeFormModalDelimit();
              swal(
                "Delimited!",
                response.data.message,
                "success"
              );
            })
            .catch(e => {
              console.log(e);
            });
        });
      },
      deleteTraining(key, objectIdentifier) {
        swal({
          title: "Are you sure?",
          text: "You won't be able to revert this!",
          type: "warning",
          showCancelButton: true,
          buttons: true,
          dangerMode: true
        }).then(result => {
          if (result) {
            this.$axios
              .delete("hcis/api/pelatihan?object_identifier=" + objectIdentifier)
              .then(response => {
                swal(
                  "Deleted!",
                  response.data.message,
                  "success"
                );
              })
              .catch(e => {
                console.log(e);
              })
              .then(() => {
                this.removeTraining(key);
              });
          }
        });
      },
      removeTraining(key) {
        this.trainings.splice(key, 1);
      },
      formatDate(date) {
        return moment(date).format('DD/MM/YYYY')
      },
      onlyNumber($event) {
        let keyCode = ($event.keyCode ? $event.keyCode : $event.which);
        if ((keyCode < 48 || keyCode > 57) && keyCode !== 46) {
          $event.preventDefault();
        }
      },
      // getCompetency() {
      //   // this.$axios.get('users/training')
      //   this.$axios.get('hcis/api/pelatihan?begin_date_lte[]=' + this.myDate + '&end_date_gte[]=' + this.myDate +
      //       '&per_page[]=20')
      //     .then(response => {
      //       this.competencys = [];
      //       response.data.data.forEach(async (competency, key) => {
      //         await this.competencys.push({
      //           startDate: competency.begin_date,
      //           endDate: competency.end_date,
      //           personalNumber: competency.personnel_number.personnel_number,
      //           buscd: competency.business_code,
      //           company: competency.business_code.company_name
      //         })
      //       });
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // getColumn() {
      //   this.$axios.get('/objects/alltable/Pelatihan/column')
      //     .then(response => {
      //       this.columns = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getLogic() {
      //   this.$axios.get('/objects/oprationsql')
      //     .then(response => {
      //       this.logics = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getCondition() {
      //   this.$axios.get('/objects/conditionsql')
      //     .then(response => {
      //       this.conditions = response.data.data;
      //     })
      //     .catch(e => {
      //       console.log(e)
      //     });
      // },
      // getSearchDynamic() {
      //   this.paramsearchforms = {
      //     table: "Pelatihan", //harcode sesuai form *referensi table_code*
      //     column: this.columns_model,
      //     query: this.logics_model,
      //     value: this.filters_model,
      //     andor: this.conditions_model
      //   }
      //   console.log(this.paramsearchforms)
      //   this.$axios.post('users/seachdinamis?per_page=10&page=1', this.paramsearchforms)
      //     .then(response => {
      //       this.competencys = [];
      //       response.data.data.forEach(async (competency, key) => {
      //         await this.competencys.push({
      //           startDate: competency.begin_date,
      //           endDate: competency.end_date,
      //           personalNumber: competency.personal_number,
      //           buscd: competency.business_code
      //         })
      //       });
      //       console.log(this.competencys);
      //     })
      //     .catch(e => {
      //       console.log(e);
      //     });
      // },
      // addNewFormSearch() {
      //   this.searchforms.push({
      //     column: '',
      //     logic: '',
      //     filter: '',
      //     condition: ''
      //   })
      // },
      // deleteFormSearch(key) {
      //   this.searchforms.splice(key, 1)
      // }
    },
    middleware: ['auth']
  }
</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }
  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }
  .is-link {
    float: right;
  }
  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }
  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }
  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }
  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }
  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }
  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }
  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }
</style>