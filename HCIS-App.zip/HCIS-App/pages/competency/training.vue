<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="training_search" class="button is-success is-rounded is-pulled-right"><span> <i class="fa fa-search"
          aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-star-o" aria-hidden="true"></i> Pelatihan
    </h3>

    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearNik">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="nik_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" placeholder="Budi Kurniawan" v-model="nik_query" disabled>
            </div>
          </div>
        </div>
        <div class="column is-8">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder=" " v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="box shadowed" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Pelatihan</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate_input[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('form.begin_date')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.begin_date')" class="help is-danger">{{ errors.first('form.begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate_input[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('form.end_date')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.end_date')" class="help is-danger">{{ errors.first('form.end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Pelatihan</label>
            <div class="control">
              <div class="select" v-bind:class="{ 'is-danger': errors.has('form.training_type') }">
                <select name="training_type" class="select" v-model="trainingType_input[key]" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(trainingType, key) in trainingTypes" :key="key" :value="trainingType.object_code">{{
                    trainingType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('form.training_type')" class="help is-danger">{{errors.first('form.training_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Judul Pelatihan</label>
            <div class="control">

              <input name="judul_pelatihan" class="input " placeholder="" type="text"
                v-model="judulPelatihan_input[key]" v-bind:class="{ 'is-danger': errors.has('form.judul_pelatihan')}"
                v-validate="'required'" data-vv-scope="form">

              <p v-show="errors.has('form.judul_pelatihan')" class="help is-danger">{{errors.first('form.judul_pelatihan')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kelas Pelatihan</label>
            <div class="control">
              <input name="kelas_pelatihan" class="input " placeholder="" type="text"
                v-model="kelasPelatihan_input[key]" v-bind:class="{ 'is-danger': errors.has('form.kelas_pelatihan')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.kelas_pelatihan')" class="help is-danger"> {{ errors.first('form.kelas_pelatihan')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Klasifikasi</label>
            <div class="control">
              <div class="select" v-bind:class="{ 'is-danger': errors.has('form.classification') }">
                <select name="classification" class="select" v-model="classification_input[key]" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(classification, key) in classifications" :key="key"
                    :value="classification.object_code">{{
                    classification.object_name
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('form.classification')" class="help is-danger"> {{ errors.first('form.classification')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Institusi</label>
            <div class="control">
              <input name="institusi" class="input " placeholder="" type="text" v-model="institution_input[key]"
                v-bind:class="{ 'is-danger': errors.has('form.institusi')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.institusi')" class="help is-danger"> {{ errors.first('form.institusi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Deskripsi</label>
            <div class="control">
              <input name="description" class="input " placeholder="" type="text" v-model="description_input[key]"
                v-bind:class="{ 'is-danger': errors.has('form.description')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.description')" class="help is-danger"> {{ errors.first('form.description')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Mata Uang Pelatihan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.current_type1') }">
                <select name="current_type1" class="select" v-model="currentType1_input[key]" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(currentType, key) in currentTypes" :key="key" :value="currentType.object_code">{{
                    currentType.object_name
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('form.current_type1')" class="help is-danger"> {{ errors.first('form.current_type1')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Biaya Pelatihan</label>
            <div class="control">
              <input name="biaya_pelatihan" class="input " placeholder="" type="number"
                v-model="trainingCost_input[key]" v-bind:class="{ 'is-danger': errors.has('form.biaya_pelatihan')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.biaya_pelatihan')" class="help is-danger"> {{ errors.first('form.biaya_pelatihan')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Mata Uang Perjalanan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.current_type2') }">
                <select name="current_type2" class="select" v-model="currentType2_input[key]" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(currentType, key) in currentTypes" :key="key" :value="currentType.object_code">{{
                    currentType.object_name
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('form.current_type2')" class="help is-danger"> {{ errors.first('form.current_type2')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Biaya Perjalanan</label>
            <div class="control">
              <input name="biaya_perjalanan" class="input " placeholder="" type="number" v-model="travelCost_input[key]"
                v-bind:class="{ 'is-danger': errors.has('form.biaya_perjalanan')}" v-validate="'required'"
                data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.biaya_perjalanan')" class="help is-danger"> {{ errors.first('form.biaya_perjalanan')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Jumlah Peserta</label>
            <div class="control">
              <input name="jumlah_peserta" class="input " placeholder="" type="number"
                v-model="numberParticipant_input[key]" v-bind:class="{ 'is-danger': errors.has('form.jumlah_peserta')}"
                v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.jumlah_peserta')" class="help is-danger"> {{ errors.first('form.jumlah_peserta')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Durasi</label>
            <div class="control">
              <input name="durasi" class="input " placeholder="" type="number" v-model="longTime_input[key]"
                v-bind:class="{ 'is-danger': errors.has('form.durasi')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.durasi')" class="help is-danger"> {{ errors.first('form.durasi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Waktu</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.tipe_waktu') }">
                <select name="tipe_waktu" class="select" v-model="timeType_input[key]" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(timeType, key) in timeTypes" :key="key" :value="timeType.id">{{
                    timeType.value
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('form.tipe_waktu')" class="help is-danger"> {{ errors.first('form.tipe_waktu')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Negara</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.negara') }">
                <select name="negara" class="select" v-model="country_input[key]" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(country, key) in countries" :key="key" :value="country.id">{{
                    country.value
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('form.negara')" class="help is-danger"> {{ errors.first('form.negara')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kota</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('form.kota') }">
                <select name="kota" class="select" v-model="city_input[key]" v-validate="'required'"
                  data-vv-scope="form">
                  <option disabled selected>Pilih</option>
                  <option v-for="(city, key) in cities" :key="key" :value="city.id">{{
                    city.name
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('form.kota')" class="help is-danger"> {{ errors.first('form.kota')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Ranking</label>
            <div class="control">
              <input name="ranking" class="input " placeholder="" type="number" v-model="rank_input[key]"
                v-bind:class="{ 'is-danger': errors.has('form.ranking')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.ranking')" class="help is-danger"> {{ errors.first('form.ranking')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">No Referensi</label>
            <div class="control">
              <input name="no_ref" class="input " placeholder="" type="text" v-model="referenceNumber_input[key]"
                v-bind:class="{ 'is-danger': errors.has('form.no_ref')}" v-validate="'required'" data-vv-scope="form">
            </div>
            <p v-show="errors.has('form.no_ref')" class="help is-danger"> {{ errors.first('form.no_ref')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="before" v-model="beforeAfterCompany_input[key]">
            Setelah Masuk Perusahaan
          </label>
        </div>
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="selesai" v-model="flagDone_input[key]">
            Selesai
          </label>
        </div>
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="sukses" v-model="flagSuccess_input[key]">
            Sukses
          </label>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Pelatihan Karyawan</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Mulai Pelatihan</label>
            <div class="control">
              <input id="training_date" data-display-mode="dialog" class="input" name="training_date" type="date"
                placeholder="e.g 10-11-2018" v-model="trainingDate" data-vv-as="training date"
                v-bind:class="{ 'is-danger': errors.has('training_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('training_date')" class="help is-danger">{{ errors.first('training_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Selesai Pelatihan</label>
            <div class="control">
              <input id="training_end" data-display-mode="dialog" class="input" name="training_end" type="date"
                placeholder="e.g 10-11-2018" v-model="trainingEnd" data-vv-as="training date"
                v-bind:class="{ 'is-danger': errors.has('training_end')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('training_end')" class="help is-danger">{{ errors.first('training_end') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Pelatihan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('training_type') }">
                <select name="training_type" class="select" v-model="trainingType" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(trainingType, key) in trainingTypes" :key="key" :value="trainingType.object_code">{{
                    trainingType.object_name
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('training_type')" class="help is-danger">{{errors.first('training_type')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Judul Pelatihan</label>
            <div class="control">

              <input name="judul_pelatihan" class="input " placeholder="" type="text" v-model="judulPelatihan"
                v-bind:class="{ 'is-danger': errors.has('judul_pelatihan')}" v-validate="'required'">

              <p v-show="errors.has('judul_pelatihan')" class="help is-danger">{{errors.first('judul_pelatihan')
                }}</p>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kelas Pelatihan</label>
            <div class="control">
              <input name="kelas_pelatihan" class="input " placeholder="" type="text" v-model="kelasPelatihan"
                v-bind:class="{ 'is-danger': errors.has('kelas_pelatihan')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('kelas_pelatihan')" class="help is-danger"> {{ errors.first('kelas_pelatihan')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Klasifikasi</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('classification') }">
                <select name="classification" class="select" v-model="classification" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(classification, key) in classifications" :key="key"
                    :value="classification.object_code">{{
                    classification.object_name
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('classification')" class="help is-danger"> {{ errors.first('classification')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Institusi</label>
            <div class="control">
              <input name="institusi" class="input " placeholder="" type="text" v-model="institution"
                v-bind:class="{ 'is-danger': errors.has('institusi')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('institusi')" class="help is-danger"> {{ errors.first('institusi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Deskripsi</label>
            <div class="control">
              <input name="description" class="input " placeholder="" type="text" v-model="description"
                v-bind:class="{ 'is-danger': errors.has('description')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('description')" class="help is-danger"> {{ errors.first('description')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Mata Uang Pelatihan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('current_type1') }">
                <select name="current_type1" class="select" v-model="currentType1" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(currentType, key) in currentTypes" :key="key" :value="currentType.object_code">{{
                    currentType.object_name
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('current_type1')" class="help is-danger"> {{ errors.first('current_type1')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Biaya Pelatihan</label>
            <div class="control">
              <input name="biaya_pelatihan" class="input " placeholder="" type="number" v-model="trainingCost"
                v-bind:class="{ 'is-danger': errors.has('biaya_pelatihan')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('biaya_pelatihan')" class="help is-danger"> {{ errors.first('biaya_pelatihan')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Mata Uang Perjalanan</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('current_type2') }">
                <select name="current_type2" class="select" v-model="currentType2" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(currentType, key) in currentTypes" :key="key" :value="currentType.object_code">{{
                    currentType.object_name
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('current_type2')" class="help is-danger"> {{ errors.first('current_type2')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Biaya Perjalanan</label>
            <div class="control">
              <input name="biaya_perjalanan" class="input " placeholder="" type="number" v-model="travelCost"
                v-bind:class="{ 'is-danger': errors.has('biaya_perjalanan')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('biaya_perjalanan')" class="help is-danger"> {{ errors.first('biaya_perjalanan')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Jumlah Peserta</label>
            <div class="control">
              <input name="jumlah_peserta" class="input " placeholder="" type="number" v-model="numberParticipant"
                v-bind:class="{ 'is-danger': errors.has('jumlah_peserta')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('jumlah_peserta')" class="help is-danger"> {{ errors.first('jumlah_peserta')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Durasi</label>
            <div class="control">
              <input name="durasi" class="input " placeholder="" type="number" v-model="longTime"
                v-bind:class="{ 'is-danger': errors.has('durasi')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('durasi')" class="help is-danger"> {{ errors.first('durasi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Waktu</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('tipe_waktu') }">
                <select name="tipe_waktu" class="select" v-model="timeType" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(timeType, key) in timeTypes" :key="key" :value="timeType.id">{{
                    timeType.value
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('tipe_waktu')" class="help is-danger"> {{ errors.first('tipe_waktu')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Negara</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('negara') }">
                <select name="negara" class="select" v-model="country" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(country, key) in countries" :key="key" :value="country.id">{{
                    country.value
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('negara')" class="help is-danger"> {{ errors.first('negara')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kota</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('kota') }">
                <select name="kota" class="select" v-model="city" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(city, key) in cities" :key="key" :value="city.id">{{
                    city.name
                    }}</option>
                </select>
              </div>
            </div>
            <p v-show="errors.has('kota')" class="help is-danger"> {{ errors.first('kota')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Ranking</label>
            <div class="control">
              <input name="ranking" class="input " placeholder="" type="number" v-model="rank"
                v-bind:class="{ 'is-danger': errors.has('ranking')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('ranking')" class="help is-danger"> {{ errors.first('ranking')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">No Referensi</label>
            <div class="control">
              <input name="no_ref" class="input " placeholder="" type="text" v-model="referenceNumber"
                v-bind:class="{ 'is-danger': errors.has('no_ref')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('no_ref')" class="help is-danger"> {{ errors.first('no_ref')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="before" v-model="beforeAfterCompany">
            Setelah Masuk Perusahaan
          </label>
        </div>
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="selesai" v-model="flagDone">
            Selesai
          </label>
        </div>
        <div class="column is-2">
          <label for="checkbox" class="checkbox">
            <input type="checkbox" id="sukses" v-model="flagSuccess">
            Sukses
          </label>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>
    <div class="columns">
      <div class="column">
         <a class="button is-pulled-right is-success is-rounded" @click="storeComponent()">Simpan</a>
      </div>
    </div>
   
  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);
  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        myDate : new Date().toISOString().slice(0,10),
        name: '',
        nik: null,
        cUnit: '',
        cPosition: '',
        components: [],
        buscds: [],
        buscd: '',
        nik_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,
        startDate: null,
        endDate: null,
        referenceNumber: '',
        trainingType: null,
        judulPelatihan: '',
        kelasPelatihan: '',
        classification: null,
        institution: '',
        description: '',
        currentType1: null,
        currentType2: null,
        trainingCost: null,
        travelCost: null,
        numberParticipant: null,
        longTime: null,
        timeType: null,
        city: null,
        country: null,
        beforeAfterCompany: '',
        rank: null,
        flagDone: '',
        flagSuccess: '',
        trainingDate: null,
        trainingEnd: null,
        startDate_input: [],
        endDate_input: [],
        referenceNumber_input: [],
        trainingType_input: [],
        judulPelatihan_input: [],
        kelasPelatihan_input: [],
        classification_input: [],
        institution_input: [],
        description_input: [],
        currentType1_input: [],
        currentType2_input: [],
        trainingCost_input: [],
        travelCost_input: [],
        numberParticipant_input: [],
        longTime_input: [],
        timeType_input: [],
        city_input: [],
        country_input: [],
        beforeAfterCompany_input: [],
        rank_input: [],
        flagDone_input: [],
        flagSuccess_input: [],
        trainingDate_input: [],
        trainingEnd_input: [],
        hakAkses: '',
        timeTypes: [],
        countries: [],
        cities: [],
        classifications: [],
        trainingTypes: [],
        currentTypes: [],
        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,
        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Kompetensi'
          },
          {
            name: 'Pelatihan'
          }
        ]
      }
    },
    created() {
      this.getTimeType();
      this.getCountry();
      this.getCity();
      this.getTrainingType();
      this.getClassification();
      this.getCurrentType();
      this.getHakAkses();
      this.getBUSCD();
      if (this.nik_query != null) {
        this.getData();

      }
    },
    methods: {
      getHakAkses() {
        this.$axios.get('/users/hakakses/TRAIN')
          .then(response => {
            this.hakAkses = response.data.data.access;
            if (this.hakAkses != '*' && this.hakAkses != 'W') {
              return this.$router.push('/competency/training-search')
            }
          })
          .catch(e => {
            console.log(e)
          });
      },
      getTimeType() {
        // this.$axios.get('/users/otype/ZEINH/object')
        this.$axios.get('ldap/api/objects?begin_date_lte[]='+ this.myDate +'&end_date_gte[]='+ this.myDate +'&object_type[]=ZEINH')
          .then(response => {
            this.timeTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });

      },
      getCountry() {
        // this.$axios.get('/users/otype/CONTR/object')
        this.$axios.get('ldap/api/objects?begin_date_lte[]='+ this.myDate +'&end_date_gte[]='+ this.myDate +'&object_type[]=CONTR')
          .then(response => {
            this.countries = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCity() {
        this.$axios.get('/city/getall')
          .then(response => {
            this.cities = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getClassification() {
        this.$axios.get('/users/otype/CLASS/object')
          .then(response => {
            this.classifications = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getTrainingType() {
        this.$axios.get('/users/otype/TRNTY/object')
          .then(response => {
            this.trainingTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCurrentType() {
        this.$axios.get('/users/otype/CURTY/object')
          .then(response => {
            this.currentTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getData() {
        this.buscd = this.buscd_query;
        //console.log(this.buscd);
        this.nik = this.nik_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.nik)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('/users/' + this.buscd + '/training/' + this.nik)
          .then(response => {
            this.components = [];
            response.data.data.forEach((user, key) => {
              this.components.push({
                begin_date: user.begin_date,
                end_date: user.end_date,
                business_code: this.buscd,
                personal_number: user.personal_number,
                reference_number: user.reference_number,
                training_type: user.training_type[0].object_id,
                training_title: user.training_title,
                training_class: user.training_class,
                classification: user.classification[0].object_id,
                institution: user.institution,
                information: user.information,
                currency_type1: user.currency_type1[0].object_id,
                training_cost: user.training_cost,
                currency_type2: user.currency_type2[0].object_id,
                travel_cost: user.travel_cost,
                number_participants: user.number_participants,
                long_time: user.long_time,
                time_type: user.time_type[0].object_id,
                city: user.city[0].id,
                country: user.country[0].object_id,
                before_after_company: user.before_after_company,
                rank: user.rank,
                flag_done: user.flag_done,
                flag_success: user.flag_success,
                start_training: user.start_training,
                finish_training: user.finish_training
              });
              this.key = key;
              this.beforeAfterCompany_input[this.key] = null;
              this.flagSuccess_input[this.key] = null;
              this.flagDone_input[this.key] = null;
              this.referenceNumber_input[this.key] = user.reference_number;
              this.trainingType_input[this.key] = user.training_type[0].object_id;
              this.judulPelatihan_input[this.key] = user.training_title;
              this.kelasPelatihan_input[this.key] = user.training_class;
              this.classification_input[this.key] = user.classification[0].object_id;
              this.institution_input[this.key] = user.institution;
              this.description_input[this.key] = user.information;
              this.currentType1_input[this.key] = user.currency_type1[0].object_id;
              this.trainingCost_input[this.key] = user.training_cost;
              this.currentType2_input[this.key] = user.currency_type2[0].object_id;
              this.travelCost_input[this.key] = user.travel_cost;
              this.numberParticipant_input[this.key] = user.number_participants;
              this.longTime_input[this.key] = user.long_time;
              this.timeType_input[this.key] = user.time_type[0].object_id;
              this.city_input[this.key] = user.city[0].id;
              this.country_input[this.key] = user.country[0].object_id;
              (user.before_after_company == 'y') ? this.beforeAfterCompany_input[this.key] = true: '';
              this.rank_input[this.key] = user.rank;
              (user.flag_done == 'y') ? this.flagDone_input[this.key] = true: '';
              (user.flag_success == 'y') ? this.flagSuccess_input[this.key] = true: '';
              this.trainingDate_input[this.key] = user.start_training;
              this.trainingEnd_input[this.key] = user.finish_training;
              this.startDate_input[this.key] = user.begin_date;
              this.endDate_input[this.key] = user.end_date;
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.nik = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.nik = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('/users/' + this.buscd + '/training/' + this.nik)
              .then(response => {
                this.components = [];
                response.data.data.forEach((user, key) => {
                  this.components.push({
                    begin_date: user.begin_date,
                    end_date: user.end_date,
                    business_code: this.buscd,
                    personal_number: user.personal_number,
                    reference_number: user.reference_number,
                    training_type: user.training_type[0].object_id,
                    training_title: user.training_title,
                    training_class: user.training_class,
                    classification: user.classification[0].object_id,
                    institution: user.institution,
                    information: user.information,
                    currency_type1: user.currency_type1[0].object_id,
                    training_cost: user.training_cost,
                    currency_type2: user.currency_type2[0].object_id,
                    travel_cost: user.travel_cost,
                    number_participants: user.number_participants,
                    long_time: user.long_time,
                    time_type: user.time_type[0].object_id,
                    city: user.city[0].id,
                    country: user.country[0].object_id,
                    before_after_company: user.before_after_company,
                    rank: user.rank,
                    flag_done: user.flag_done,
                    flag_success: user.flag_success,
                    start_training: user.start_training,
                    finish_training: user.finish_training
                  });
                  this.key = key;
                  this.beforeAfterCompany_input[this.key] = null;
                  this.flagSuccess_input[this.key] = null;
                  this.flagDone_input[this.key] = null;
                  this.referenceNumber_input[this.key] = user.reference_number;
                  this.trainingType_input[this.key] = user.training_type[0].object_id;
                  this.judulPelatihan_input[this.key] = user.training_title;
                  this.kelasPelatihan_input[this.key] = user.training_class;
                  this.classification_input[this.key] = user.classification[0].object_id;
                  this.institution_input[this.key] = user.institution;
                  this.description_input[this.key] = user.information;
                  this.currentType1_input[this.key] = user.currency_type1[0].object_id;
                  this.trainingCost_input[this.key] = user.training_cost;
                  this.currentType2_input[this.key] = user.currency_type2[0].object_id;
                  this.travelCost_input[this.key] = user.travel_cost;
                  this.numberParticipant_input[this.key] = user.number_participants;
                  this.longTime_input[this.key] = user.long_time;
                  this.timeType_input[this.key] = user.time_type[0].object_id;
                  this.city_input[this.key] = user.city[0].id;
                  this.country_input[this.key] = user.country[0].object_id;
                  (user.before_after_company == 'y') ? this.beforeAfterCompany_input[this.key] = true: '';
                  this.rank_input[this.key] = user.rank;
                  (user.flag_done == 'y') ? this.flagDone_input[this.key] = true: '';
                  (user.flag_success == 'y') ? this.flagSuccess_input[this.key] = true: '';
                  this.trainingDate_input[this.key] = user.start_training;
                  this.trainingEnd_input[this.key] = user.finish_training;
                  this.startDate_input[this.key] = user.begin_date;
                  this.endDate_input[this.key] = user.end_date;
                });
              })
              .catch(e => {
                console.log(e);
              });


          }
        }
      },
      onInputChange(text) {
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.nik = text;
        if (text === '' || text === undefined) {
          return;
        }
        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
        /* Full control over filtering. Maybe fetch from API?! Up to you!!! */

      },
      tambahComponent() {

        //console.log(this.components)
        this.$validator.validateAll('form').then(async result => {
          if (!result) return;
          //  var found = this.components.some(function(el) {
          //             return el.education_level === educationLevel;
          // });
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            if (this.flagDone == true) {
              this.flagDone = 'y';
            } else {
              this.flagDone = '';
            }

            if (this.flagSuccess == true) {
              this.flagSuccess = 'y';
            } else {
              this.flagSuccess = '';
            }
            if (this.beforeAfterCompany == true) {
              this.beforeAfterCompany = 'y';
            } else {
              this.beforeAfterCompany = '';
            }
            // if(!found){
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              business_code: this.buscd,
              personal_number: this.nik,
              reference_number: this.referenceNumber,
              training_type: this.trainingType,
              training_title: this.judulPelatihan,
              training_class: this.kelasPelatihan,
              classification: this.classification,
              institution: this.institution,
              information: this.description,
              currency_type1: this.currentType1,
              training_cost: this.trainingCost,
              currency_type2: this.currentType2,
              travel_cost: this.travelCost,
              number_participants: this.numberParticipant,
              long_time: this.longTime,
              time_type: this.timeType,
              city: this.city,
              country: this.country,
              before_after_company: this.beforeAfterCompany,
              rank: this.rank,
              flag_done: this.flagDone,
              flag_success: this.flagSuccess,
              start_training: this.trainingDate,
              finish_training: this.trainingEnd
            });
            this.components.forEach((user, key) => {
              this.key = key;
              this.referenceNumber_input[this.key] = user.reference_number;
              this.trainingType_input[this.key] = user.training_type;
              this.judulPelatihan_input[this.key] = user.training_title;
              this.kelasPelatihan_input[this.key] = user.training_class;
              this.classification_input[this.key] = user.classification;
              this.institution_input[this.key] = user.institution;
              this.description_input[this.key] = user.information;
              this.currentType1_input[this.key] = user.currency_type1;
              this.trainingCost_input[this.key] = user.training_cost;
              this.currentType2_input[this.key] = user.currency_type2;
              this.travelCost_input[this.key] = user.travel_cost;
              this.numberParticipant_input[this.key] = user.number_participants;
              this.longTime_input[this.key] = user.long_time;
              this.timeType_input[this.key] = user.time_type;
              this.city_input[this.key] = user.city;
              this.country_input[this.key] = user.country;
              (user.before_after_company == 'y') ? this.beforeAfterCompany_input[this.key] = true: '';
              this.rank_input[this.key] = user.rank;
              (user.flag_done == 'y') ? this.flagDone_input[this.key] = true: '';
              (user.flag_success == 'y') ? this.flagSuccess_input[this.key] = true: '';
              this.trainingDate_input[this.key] = user.start_training;
              this.trainingEnd_input[this.key] = user.finish_training;
              this.startDate_input[this.key] = user.begin_date;
              this.endDate_input[this.key] = user.end_date;
            })

            // }else{
            //   alert('data sudah ada');
            // } 
          }
        });
      },
      storeComponent() {

        if (this.buscd != '') {
          if (this.nik_query == null) {
            // const searchNik = this.options[0].data.filter(item => {
            //   return item.toLowerCase().indexOf(this.nik.toLowerCase()) > -1;
            // }).slice(0, this.limit);
            // if(searchNik.length ==  0){
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((childrens, index1) => {
                if (this.flagDone_input[index1] == true) {
                  this.flagDone_input[index1] = 'y';
                } else {
                  this.flagDone_input[index1] = 'n';
                }

                if (this.flagSuccess_input[index1] == true) {
                  this.flagSuccess_input[index1] = 'y';
                } else {
                  this.flagSuccess_input[index1] = 'n';
                }
                if (this.beforeAfterCompany_input[index1] == true) {
                  this.beforeAfterCompany_input[index1] = 'y';
                } else {
                  this.beforeAfterCompany_input[index1] = 'n';
                }
                var rank = parseInt(this.rank_input[index1]);
                var trainingCost = parseInt(this.trainingCost_input[index1]);
                var travelCost = parseInt(this.travelCost_input[index1]);
                var numberParticipant = parseInt(this.numberParticipant_input[index1]);
                var longTime = parseInt(this.longTime_input[index1]);
                Object.assign(this.components[index1], {
                  reference_number: this.referenceNumber_input[index1],
                  training_type: this.trainingType_input[index1],
                  training_title: this.judulPelatihan_input[index1],
                  training_class: this.kelasPelatihan_input[index1],
                  classification: this.classification_input[index1],
                  institution: this.institution_input[index1],
                  information: this.description_input[index1],
                  currency_type1: this.currentType1_input[index1],
                  training_cost: trainingCost,
                  currency_type2: this.currentType2_input[index1],
                  travel_cost: travelCost,
                  number_participants: numberParticipant,
                  long_time: longTime,
                  time_type: this.timeType_input[index1],
                  city: this.city_input[index1],
                  country: this.country_input[index1],
                  rank: rank,
                  start_training: this.trainingDate_input[index1],
                  finish_training: this.trainingEnd_input[index1],
                  begin_date: this.startDate_input[index1],
                  end_date: this.endDate_input[index1],
                  flag_done: this.flagDone_input[index1],
                  flag_success: this.flagSuccess_input[index1],
                  before_after_company: this.beforeAfterCompany_input[index1]
                });
              });
              swal({
                title: 'Are you sure to save?',
                text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/training/' + this.nik, this.components)
                    .then(response => {
                      this.clearNik()
                      swal(
                        'Saved!',
                        'Successfully saved.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              if (this.flagDone_input[index1] == true) {
                this.flagDone_input[index1] = 'y';
              } else {
                this.flagDone_input[index1] = 'n';
              }
              if (this.flagSuccess_input[index1] == true) {
                this.flagSuccess_input[index1] = 'y';
              } else {
                this.flagSuccess_input[index1] = 'n';
              }
              if (this.beforeAfterCompany_input[index1] == true) {
                this.beforeAfterCompany_input[index1] = 'y';
              } else {
                this.beforeAfterCompany_input[index1] = 'n';
              }
              var rank = parseInt(this.rank_input[index1]);
              var trainingCost = parseInt(this.trainingCost_input[index1]);
              var travelCost = parseInt(this.travelCost_input[index1]);
              var numberParticipant = parseInt(this.numberParticipant_input[index1]);
              var longTime = parseInt(this.longTime_input[index1]);
              Object.assign(this.components[index1], {
                reference_number: this.referenceNumber_input[index1],
                training_type: this.trainingType_input[index1],
                training_title: this.judulPelatihan_input[index1],
                training_class: this.kelasPelatihan_input[index1],
                classification: this.classification_input[index1],
                institution: this.institution_input[index1],
                information: this.description_input[index1],
                currency_type1: this.currentType1_input[index1],
                training_cost: trainingCost,
                currency_type2: this.currentType2_input[index1],
                travel_cost: travelCost,
                number_participants: numberParticipant,
                long_time: longTime,
                time_type: this.timeType_input[index1],
                city: this.city_input[index1],
                country: this.country_input[index1],
                rank: rank,
                start_training: this.trainingDate_input[index1],
                finish_training: this.trainingEnd_input[index1],
                begin_date: this.startDate_input[index1],
                end_date: this.endDate_input[index1],
                flag_done: this.flagDone_input[index1],
                flag_success: this.flagSuccess_input[index1],
                before_after_company: this.beforeAfterCompany_input[index1]
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/training/' + this.nik, this.components)
                  .then(response => {
                    //this.clearNik()                                              
                    swal(
                      'Saved!',
                      'Successfully saved.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }


        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearNik()
        }
      },
      deleteComponents(key) {

        this.components.splice(key, 1);
        this.components.forEach((user, key) => {

          this.key = key;
          this.flagDone_input[this.key] = null,
            this.flagSuccess_input[this.key] = null,
            this.beforeAfterCompany_input[this.key] = null,
            this.referenceNumber_input[this.key] = user.reference_number;
          this.trainingType_input[this.key] = user.training_type;
          this.judulPelatihan_input[this.key] = user.training_title;
          this.kelasPelatihan_input[this.key] = user.training_class;
          this.classification_input[this.key] = user.classification;
          this.institution_input[this.key] = user.institution;
          this.description_input[this.key] = user.information;
          this.currentType1_input[this.key] = user.currency_type1;
          this.trainingCost_input[this.key] = user.training_cost;
          this.currentType2_input[this.key] = user.currency_type2;
          this.travelCost_input[this.key] = user.travel_cost;
          this.numberParticipant_input[this.key] = user.number_participants;
          this.longTime_input[this.key] = user.long_time;
          this.timeType_input[this.key] = user.time_type;
          this.city_input[this.key] = user.city;
          this.country_input[this.key] = user.country;
          (user.before_after_company == 'y') ? this.beforeAfterCompany_input[this.key] = true: '';
          this.rank_input[this.key] = user.rank;
          (user.flag_done == 'y') ? this.flagDone_input[this.key] = true: '';
          (user.flag_success == 'y') ? this.flagSuccess_input[this.key] = true: '';
          this.trainingDate_input[this.key] = user.start_training;
          this.trainingEnd_input[this.key] = user.finish_training;
          this.startDate_input[this.key] = user.begin_date;
          this.endDate_input[this.key] = user.end_date;
        })
        //console.log(this.components)                        

      },
      clearNik() {

        this.components = [];
        if (this.nik != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.nik = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.referenceNumber = '';
        this.trainingType = null;
        this.judulPelatihan = '';
        this.kelasPelatihan = '';
        this.classification = null;
        this.institution = '';
        this.description = '';
        this.currentType1 = null;
        this.trainingCost = null;
        this.currentType2 = null;
        this.travelCost = null;
        this.numberParticipant = null;
        this.longTime = null;
        this.timeType = null;
        this.city = null;
        this.country = null;
        this.beforeAfterCompany = '';
        this.rank = null;
        this.flagDone = '';
        this.flagSuccess = '';
        this.trainingDate = null;
        this.trainingEnd = null;

        this.$nextTick(() => this.$validator.reset());
        //console.log(this.$refs.myRefName.searchInput)
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/EDUCT')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      }
    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-family: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
