<template>
  <section class="section">
    <Breadcrumb :breadcumbs="breadcumbs" />
    <hr>
    <nuxt-link to="certification-search" class="button is-success is-rounded is-pulled-right"><span> <i
          class="fa fa-search" aria-hidden="true"></i> Pencarian </span></nuxt-link>
    <h3 class="subtitle is-3">
      <i class="fa fa-file-text-o" aria-hidden="true"></i> Sertifikasi
    </h3>

    <div class="box shadowed">
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Perusahaan</label>
            <div class="select is-fullwidth" v-if="buscd_query == null">
              <select v-model="buscd" name="buscd" class="select is-fullwidth" @change="clearpersonalNumber">
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
            <div class="control" v-else>
              <select v-model="buscd_query" name="buscd" class="select is-fullwidth" disabled>
                <option selected="selected" disabled="disabled">choose option</option>
                <option v-for="(buscd, index) in buscds" :key="index" :value="buscd.objectId">{{buscd.name}}</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomer Induk Karyawan</label>
            <div class="control" v-if="personalNumber_query == null">
              <vue-autosuggest ref="myRefName" :suggestions="filteredOptions" :on-selected="onSelected" :limit="10"
                :input-props="inputProps"></vue-autosuggest>
            </div>
            <div class="control" v-else>
              <input class="input" type="text" v-model="personalNumber_query" disabled>
            </div>
            <p v-show="errors.has('personal_number')" class="help is-danger"> {{ errors.first('personal_number')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama</label>
            <div class="control">
              <input class="input" type="text" placeholder=" " v-model="name" disabled>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">

        <div class="column is-4">
          <div class="field">
            <label class="label">Posisi Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cPosition" disabled>
            </div>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Unit Saat Ini</label>
            <div class="control">
              <input class="input" type="text" placeholder="" v-model="cUnit" disabled>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box shadowed" v-for="(component, key) in components" :key="key">
      <div class="box has-text-white has-background-info">
        <h4 class="title is-4 has-text-white"> Sertifikasi</h4>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate_form[key]" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate_form[key]" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Dikeluarkan</label>
            <div class="control">
              <input name="tanggal_dikeluarkan" class="input " placeholder="e.g. 011124" type="date"
                v-model="dateIssue_form[key]" v-bind:class="{ 'is-danger': errors.has('tanggal_dikeluarkan')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('tanggal_dikeluarkan')" class="help is-danger"> {{
              errors.first('tanggal_dikeluarkan')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Kadaluarsa</label>
            <div class="control">
              <input name="tanggal_kadeluarsa" class="input " placeholder="e.g. Leadership" type="date"
                v-model="expireDate_form[key]" v-bind:class="{ 'is-danger': errors.has('tanggal_kadeluarsa')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('tanggal_kadeluarsa')" class="help is-danger"> {{ errors.first('tanggal_kadeluarsa')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Sertifikat</label>
            <div class="control">
              <input name="nomor_sertifikat" class="input " placeholder="e.g. 011124" type="text"
                v-model="certificateNumber_form[key]" v-bind:class="{ 'is-danger': errors.has('nomor_sertifikat')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('nomor_sertifikat')" class="help is-danger"> {{ errors.first('nomor_sertifikat')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Sertifikat</label>
            <div class="control">
              <input name="nama_sertifikat" class="input " placeholder="e.g. Leadership" type="text"
                v-model="certificateName_form[key]" v-bind:class="{ 'is-danger': errors.has('nama_sertifikat')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('nama_sertifikat')" class="help is-danger"> {{ errors.first('nama_sertifikat')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Sertifikat</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('tipe_sertifikat') }">
                <select name="tipe_sertifikat" class="select" v-model="certificateType_form[key]"
                  v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(certificateType, key) in certificateTypes" :key="key"
                    :value="certificateType.id">{{
                    certificateType.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('tipe_sertifikat')" class="help is-danger">{{errors.first('tipe_sertifikat')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama/ Badan Sertifikasi</label>
            <div class="control">
              <input name="badan_sertifikasi" class="input " placeholder="e.g. Telkom" type="text"
                v-model="institution_form[key]" v-bind:class="{ 'is-danger': errors.has('badan_sertifikasi')}"
                v-validate="'required'">
            </div>
            <p v-show="errors.has('badan_sertifikasi')" class="help is-danger"> {{ errors.first('badan_sertifikasi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kelas</label>
            <div class="control">
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('kelas') }">
                  <select name="kelas" class="select" v-model="certificateClass_form[key]" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(certificateType, key) in certificateClasses" :key="key"
                      :value="certificateType.object_code">{{
                      certificateType.object_name
                      }}</option>
                  </select>
                </div>
              </div>
              <p v-show="errors.has('kelas')" class="help is-danger"> {{ errors.first('kelas')
              }}</p>
            </div>
          </div>
        </div>
        <div class="column">
          <div class="field">
            <label class="label">stream</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('stream') }">
                <select name="stream" class="select" v-model="stream_form[key]" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(certificateType, key) in streams" :key="key" :value="certificateType.object_code">{{
                      certificateType.object_name
                      }}</option>
                </select>
              </div>
            </div>
          </div>
          <p v-show="errors.has('stream')" class="help is-danger"> {{ errors.first('stream')
              }}</p>
        </div>
        <div class="column">
          <br>
          <a class="button is-danger is-rounded" @click="deleteComponents(key)"><i class="fa fa-trash"
              aria-hidden="true"></i></a>
        </div>
      </div>
      <!-- <a class="button is-danger is-rounded" @click="deleteComponents(key)">Hapus</a> -->
    </div>

    <div class="box">
      <h4 class="subtitle is-4">Formulir Sertifikasi</h4>
      <hr>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Awal Berlaku</label>
            <div class="control">
              <input id="begin_date" data-display-mode="dialog" class="input" name="begin_date" type="date"
                placeholder="e.g 10-11-2018" v-model="startDate" data-vv-as="start date"
                v-bind:class="{ 'is-danger': errors.has('begin_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('begin_date')" class="help is-danger">{{ errors.first('begin_date') }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Akhir Berlaku</label>
            <div class="control">
              <input id="end_date" data-display-mode="dialog" class="input" name="end_date" type="date"
                placeholder="e.g 10-11-2018" v-model="endDate" data-vv-as="End date"
                v-bind:class="{ 'is-danger': errors.has('end_date')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('end_date')" class="help is-danger">{{ errors.first('end_date') }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Dikeluarkan</label>
            <div class="control">
              <input name="tanggal_dikeluarkan" class="input " placeholder="" type="date" v-model="dateIssue"
                v-bind:class="{ 'is-danger': errors.has('tanggal_dikeluarkan')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('tanggal_dikeluarkan')" class="help is-danger"> {{
              errors.first('tanggal_dikeluarkan')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tanggal Kadaluarsa</label>
            <div class="control">
              <input name="tanggal_kadeluarsa" class="input " placeholder="" type="date" v-model="expireDate"
                v-bind:class="{ 'is-danger': errors.has('tanggal_kadeluarsa')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('tanggal_kadeluarsa')" class="help is-danger"> {{ errors.first('tanggal_kadeluarsa')
              }}</p>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nomor Sertifikat</label>
            <div class="control">
              <input name="nomor_sertifikat" class="input " placeholder="" type="text" v-model="certificateNumber"
                v-bind:class="{ 'is-danger': errors.has('nomor_sertifikat')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('nomor_sertifikat')" class="help is-danger"> {{ errors.first('nomor_sertifikat')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama Sertifikat</label>
            <div class="control">
              <input name="nama_sertifikat" class="input " placeholder="" type="text" v-model="certificateName"
                v-bind:class="{ 'is-danger': errors.has('nama_sertifikat')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('nama_sertifikat')" class="help is-danger"> {{ errors.first('nama_sertifikat')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Tipe Sertifikat</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('tipe_sertifikat') }">
                <select name="tipe_sertifikat" class="select" v-model="certificateType" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(certificateType, key) in certificateTypes" :key="key"
                    :value="certificateType.id">{{
                    certificateType.value
                    }}</option>
                </select>
              </div>
              <p v-show="errors.has('tipe_sertifikat')" class="help is-danger">{{errors.first('tipe_sertifikat')
                }}</p>
            </div>
          </div>
        </div>
      </div>
      <div class="columns">
        <div class="column is-4">
          <div class="field">
            <label class="label">Nama/ Badan Sertifikasi</label>
            <div class="control">
              <input name="badan_sertifikasi" class="input " placeholder="" type="text" v-model="institution"
                v-bind:class="{ 'is-danger': errors.has('badan_sertifikasi')}" v-validate="'required'">
            </div>
            <p v-show="errors.has('badan_sertifikasi')" class="help is-danger"> {{ errors.first('badan_sertifikasi')
              }}</p>
          </div>
        </div>
        <div class="column is-4">
          <div class="field">
            <label class="label">Kelas</label>
            <div class="control">
              <div class="control">
                <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('kelas') }">
                  <select name="kelas" class="select" v-model="certificateClass" v-validate="'required'">
                    <option disabled selected>Pilih</option>
                    <option v-for="(certificateType, key) in certificateClasses" :key="key"
                      :value="certificateType.object_code">{{
                      certificateType.object_name
                      }}</option>
                  </select>
                </div>
              </div>
              <p v-show="errors.has('kelas')" class="help is-danger"> {{ errors.first('kelas')
              }}</p>
            </div>
          </div>
        </div>
        <div class="column">
          <div class="field">
            <label class="label">stream</label>
            <div class="control">
              <div class="select is-fullwidth" v-bind:class="{ 'is-danger': errors.has('stream') }">
                <select name="stream" class="select" v-model="stream" v-validate="'required'">
                  <option disabled selected>Pilih</option>
                  <option v-for="(certificateType, key) in streams" :key="key" :value="certificateType.object_code">{{
                      certificateType.object_name
                      }}</option>
                </select>
              </div>
            </div>
          </div>
          <p v-show="errors.has('stream')" class="help is-danger"> {{ errors.first('stream')
              }}</p>
        </div>
        <div class="column">
          <br>
          <a class="button is-primary is-rounded" @click="tambahComponent()">+</a>
        </div>
      </div>
    </div>
    <div class="columns">
      <div class="column">
        <a class="button is-pulled-right is-success is-rounded" @click="storeComponent()">Simpan</a>
      </div>
    </div>



  </section>
</template>

<script>
  import Breadcrumb from '~/components/Breadcrumb';
  import VueAutosuggest from "vue-autosuggest";
  import Vue from 'vue';
  Vue.use(VueAutosuggest);

  export default {
    components: {
      Breadcrumb,
    },
    data() {
      return {
        key: null,
        buscd: '',
        name: '',
        personalNumber: null,
        cUnit: '',
        cPosition: '',

        startDate: '',
        endDate: '',
        dateIssue: '',
        expireDate: '',
        certificateNumber: '',
        certificateName: '',
        certificateType: '',
        institution: '',
        certificateClass: '',
        stream: '',
        streams: [],
        certificateClasses: [],
        startDate_form: [],
        endDate_form: [],
        dateIssue_form: [],
        expireDate_form: [],
        certificateNumber_form: [],
        certificateName_form: [],
        certificateType_form: [],
        institution_form: [],
        certificateClass_form: [],
        stream_form: [],

        buscds: [],
        components: [],
        certificateTypes: [],

        personalNumber_query: this.$route.query.nik,
        buscd_query: this.$route.query.buscd,

        options: [{
          data: []
        }],
        filteredOptions: [],
        inputProps: {
          id: "autosuggest__input",
          onInputChange: this.onInputChange,
          placeholder: ""
        },
        limit: 10,

        breadcumbs: [{
            name: 'Beranda'
          },
          {
            name: 'Kompetensi'
          },
          {
            name: 'Sertifikasi'
          },
        ]
      }
    },
    created() {
      this.getCertificateType();
      this.getCertificateClass();
      this.getStream();
      this.getBUSCD();
      if (this.personalNumber_query != null) {
        this.getData();
      }
    },
    methods: {
      getData() {
        this.buscd = this.buscd_query;
        this.personalNumber = this.personalNumber_query;
        this.$axios.get('/users/' + this.buscd + '/searchprofile/' + this.personalNumber)
          .then(async response => {
            this.name = response.data.data.name;
            this.cUnit = response.data.data.unit;
            this.cPosition = response.data.data.position;
          })
          .catch(e => {
            console.log(e);
          });

        this.$axios.get('users/' + this.buscd + '/certificate/' + this.personalNumber)
          .then(response => {
            this.components = [];
            response.data.data.forEach(async (certificate, key) => {
              this.components.push({
                begin_date: certificate.begin_date,
                end_date: certificate.end_date,
                date_issue: certificate.date_issue,
                expire_date: certificate.expire_date,
                personal_number: certificate.personal_number,
                business_code: certificate.business_code,
                certificate_number: certificate.certificate_number,
                certificate_name: certificate.certificate_name,
                institution: certificate.institution,
                certificate_class: certificate.certificate_class[0].object_id,
                stream: certificate.stream[0].object_id,
                certificate_type: certificate.certificate_type[0].object_id,

              });
              this.key = key;
              this.startDate_form[this.key] = certificate.begin_date;
              this.endDate_form[this.key] = certificate.end_date;
              this.dateIssue_form[this.key] = certificate.date_issue;
              this.expireDate_form[this.key] = certificate.expire_date;
              this.certificateNumber_form[this.key] = certificate.certificate_number;
              this.certificateName_form[this.key] = certificate.certificate_name;
              this.institution_form[this.key] = certificate.institution;
              this.certificateClass_form[this.key] = certificate.certificate_class[0].object_id;
              this.stream_form[this.key] = certificate.stream[0].object_id;
              this.certificateType_form[this.key] = certificate.certificate_type[0].object_id;

            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      onSelected(option) {
        if (option == null) {
          this.personalNumber = null;
          this.name = '';
          this.cPosition = '';
          this.cUnit = '';
          this.components = [];
        } else {
          this.personalNumber = option.item;
          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')

          } else {
            this.$axios.get('/users/' + this.buscd + '/searchprofile/' + option.item)
              .then(async response => {
                this.name = response.data.data.name;
                this.cUnit = response.data.data.unit;
                this.cPosition = response.data.data.position;
              })
              .catch(e => {
                console.log(e);
              });

            this.$axios.get('users/' + this.buscd + '/certificate/' + option.item)
              .then(response => {
                this.components = [];
                response.data.data.forEach((certificate, key) => {
                  this.components.push({
                    begin_date: certificate.begin_date,
                    end_date: certificate.end_date,
                    date_issue: certificate.date_issue,
                    expire_date: certificate.expire_date,
                    personal_number: certificate.personal_number,
                    business_code: certificate.business_code,
                    certificate_number: certificate.certificate_number,
                    certificate_name: certificate.certificate_name,
                    institution: certificate.institution,
                    certificate_class: certificate.certificate_class[0].object_id,
                    stream: certificate.stream[0].object_id,
                    certificate_type: certificate.certificate_type[0].object_id,

                  });
                  this.key = key;
                  this.startDate_form[this.key] = certificate.begin_date;
                  this.endDate_form[this.key] = certificate.end_date;
                  this.dateIssue_form[this.key] = certificate.date_issue;
                  this.expireDate_form[this.key] = certificate.expire_date;
                  this.certificateNumber_form[this.key] = certificate.certificate_number;
                  this.certificateName_form[this.key] = certificate.certificate_name;
                  this.institution_form[this.key] = certificate.institution;
                  this.certificateClass_form[this.key] = certificate.certificate_class[0].object_id;
                  this.stream_form[this.key] = certificate.stream[0].object_id;
                  this.certificateType_form[this.key] = certificate.certificate_type[0].object_id;
                });
              })
              .catch(e => {
                console.log(e);
              });
          }
        }
      },
      onInputChange(text) {
        this.personalNumber = text;
        if (text === '' || text === undefined) {
          return;
        }

        this.$axios.get('/users/searchlike/' + text)
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
            const filteredData = this.options[0].data.filter(item => {
              return item.toLowerCase().indexOf(text.toLowerCase()) > -1;
            }).slice(0, this.limit);

            this.filteredOptions = [{
              data: filteredData
            }];
            //console.log(this.options[0].data)
          })

          .catch(e => {
            console.log(e);
          });
      },
      tambahComponent() {
        this.$validator.validateAll().then(async result => {
          if (!result) return;


          if (this.buscd == '') {
            alert('isi nama perusahaan terlebih dahulu !')
          } else {
            this.components.push({
              begin_date: this.startDate,
              end_date: this.endDate,
              personal_number: this.personalNumber,
              business_code: this.buscd,
              date_issue: this.dateIssue,
              expire_date: this.expireDate,
              certificate_number: this.certificateNumber,
              certificate_name: this.certificateName,
              institution: this.institution,
              certificate_class: this.certificateClass,
              stream: this.stream,
              certificate_type: this.certificateType,
            });
            this.components.forEach((certificate, key) => {
              this.key = key;
              this.startDate_form[this.key] = certificate.begin_date;
              this.endDate_form[this.key] = certificate.end_date;
              this.dateIssue_form[this.key] = certificate.date_issue;
              this.expireDate_form[this.key] = certificate.expire_date;
              this.certificateNumber_form[this.key] = certificate.certificate_number;
              this.certificateName_form[this.key] = certificate.certificate_name;
              this.institution_form[this.key] = certificate.institution;
              this.certificateClass_form[this.key] = certificate.certificate_class;
              this.stream_form[this.key] = certificate.stream;
              this.certificateType_form[this.key] = certificate.certificate_type;
            })
          }
        });
      },
      storeComponent() {
        if (this.buscd != '') {
          if (this.personalNumber_query == null) {
            if (this.name == '') {
              alert('data nik tidak ada');
            } else {
              this.components.forEach((childrens, index1) => {
                Object.assign(this.components[index1], {
                  begin_date: this.startDate_form[index1],
                  end_date: this.endDate_form[index1],
                  date_issue: this.dateIssue_form[index1],
                  expire_date: this.expireDate_form[index1],
                  certificate_number: this.certificateNumber_form[index1],
                  certificate_name: this.certificateName_form[index1],
                  institution: this.institution_form[index1],
                  certificate_class: this.certificateClass_form[index1],
                  stream: this.stream_form[index1],
                  certificate_type: this.certificateType_form[index1],
                });
              });
              swal({
                title: 'Apakah anda yakin ingin menyimpan data ini?',
                //text: "You won't be able to revert this!",
                type: 'warning',
                buttons: true,
                dangerMode: true,
              }).then((result) => {
                if (result) {
                  this.$axios.post('users/' + this.buscd + '/certificate/' + this.personalNumber, this.components)
                    .then(response => {
                      this.clearpersonalNumber()
                      swal(
                        'Data tersimpan!',
                        'Sukses menyimpan data Komunikasi.',
                        'success'
                      );
                    })
                    .catch(e => {
                      console.log(e);
                    })
                }
              });
            }
          } else {
            this.components.forEach((childrens, index1) => {
              Object.assign(this.components[index1], {
                begin_date: this.startDate_form[index1],
                end_date: this.endDate_form[index1],
                date_issue: this.dateIssue_form[index1],
                expire_date: this.expireDate_form[index1],
                certificate_number: this.certificateNumber_form[index1],
                certificate_name: this.certificateName_form[index1],
                institution: this.institution_form[index1],
                certificate_class: this.certificateClass_form[index1],
                stream: this.stream_form[index1],
                certificate_type: this.certificateType_form[index1],
              });
            });
            swal({
              title: 'Are you sure to save?',
              text: "You won't be able to revert this!",
              type: 'warning',
              buttons: true,
              dangerMode: true,
            }).then((result) => {
              if (result) {
                this.$axios.post('users/' + this.buscd + '/certificate/' + this.personalNumber, this.components)
                  .then(response => {
                    swal(
                      'Saved!',
                      'Successfully saved basic pay.',
                      'success'
                    );
                  })
                  .catch(e => {
                    console.log(e);
                  })
              }
            });
          }
        } else {
          alert('isi nama perusahaan terlebih dahulu !')

          //this.clearpersonalNumber()
        }
      },
      deleteComponents(key) {
        this.components.splice(key, 1);
        this.components.forEach((certificate, key) => {
          this.key = key;
          this.startDate_form[this.key] = certificate.begin_date;
          this.endDate_form[this.key] = certificate.end_date;
          this.dateIssue_form[this.key] = certificate.date_issue;
          this.expireDate_form[this.key] = certificate.expire_date;
          this.certificateNumber_form[this.key] = certificate.certificate_number;
          this.certificateName_form[this.key] = certificate.certificate_name;
          this.institution_form[this.key] = certificate.institution;
          this.certificateClass_form[this.key] = certificate.certificate_class;
          this.stream_form[this.key] = certificate.stream;
          this.certificateType_form[this.key] = certificate.certificate_type;
        })
      },
      clearpersonalNumber() {
        this.components = [];
        if (this.personalNumber != null) {
          this.$refs.myRefName.searchInput = '';
        }
        this.personalNumber = null;
        this.name = '';
        this.cPosition = '';
        this.cUnit = '';
        this.startDate = '';
        this.endDate = '';
        this.dateIssue = '';
        this.expireDate = '';
        this.certificateNumber = '';
        this.certificateName = '';
        this.certificateType = '';
        this.certificateClass = '';
        this.institution = '';
        this.stream = '';
        this.$nextTick(() => this.$validator.reset());
      },
      getpersonalNumber() {
        this.$axios.get('/users/personal')
          .then(response => {
            this.options[0].data = [];
            response.data.data.forEach(async (user, key) => {
              await this.options[0].data.push(
                user.personal_number,
              );
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getBUSCD() {
        this.$axios.get('/objects/companytoken/CRTFT')
          .then(response => {
            this.buscds = [];
            response.data.data.forEach(async (buscd, key) => {
              await this.buscds.push({
                objectId: buscd.business_code,
                name: buscd.company_name
              });
            });
          })
          .catch(e => {
            console.log(e);
          });
      },
      getCertificateType() {
        // this.$axios.get('/users/otype/CRTTY/object')
         this.$axios.get('ldap/api/objects?begin_date_lte='+ this.myDate +'&end_date_gte='+ this.myDate +'&object_type=CRTTY')
          .then(response => {
            this.certificateTypes = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getCertificateClass() {
        this.$axios.get('/users/otype/CLASS/object')
          .then(response => {
            this.certificateClasses = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },
      getStream() {
        this.$axios.get('/users/otype/STREM/object')
          .then(response => {
            this.streams = response.data.data;
          })
          .catch(e => {
            console.log(e)
          });
      },

    },
    middleware: ['auth']
  }

</script>

<style>
  .has-background-danger {
    background-color: #6D6D6D !important;
  }

  .button.is-danger {
    background-color: #CE1000;
    border-color: transparent;
    color: #fff;
  }

  #autosuggest__input {
    outline: none;
    position: relative;
    display: block;
    font-certificate: monospace;
    font-size: 20px;
    border: 1px solid #616161;
    padding: 4px;
    width: 100%;
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  }

  #autosuggest__input.autosuggest__input-open {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }

  .autosuggest__results-container {
    position: relative;
    width: 100%;
  }

  .autosuggest__results {
    font-weight: 300;
    margin: 0;
    position: absolute;
    z-index: 10000001;
    width: 100%;
    border: 1px solid #e0e0e0;
    border-bottom-left-radius: 4px;
    border-bottom-right-radius: 4px;
    background: white;
    padding: 0px;
    overflow: scroll;
    max-height: 200px;
  }

  .autosuggest__results ul {
    list-style: none;
    padding-left: 0;
    margin: 0;
  }

  .autosuggest__results .autosuggest__results_item {
    cursor: pointer;
    padding: 15px;
  }

  #autosuggest ul:nth-child(1)>.autosuggest__results_title {
    border-top: none;
  }

  .autosuggest__results .autosuggest__results_title {
    color: gray;
    font-size: 11px;
    margin-left: 0;
    padding: 15px 13px 5px;
    border-top: 1px solid lightgray;
  }

  .autosuggest__results .autosuggest__results_item:active,
  .autosuggest__results .autosuggest__results_item:hover,
  .autosuggest__results .autosuggest__results_item:focus,
  .autosuggest__results .autosuggest__results_item.autosuggest__results_item-highlighted {
    background-color: #ddd;
  }

</style>
