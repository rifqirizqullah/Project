<template>
  <section class="section">
    <div class="box has-text-white has-background-danger">
      Kontrak
    </div>

    <div class="box">
      <div class="columns is-multiline">
        <div class="column is-3">
          <div class="field">
            <label class="label">No referensi</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
         <div class="column is-3">
          <div class="field">
            <label class="label">Type Dokumen</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
        <div class="column is-3">
          <div class="field">
            <label class="label">No SK</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
         <div class="column is-3">
          <div class="field">
            <label class="label">Jenis SK</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
         <div class="column is-3">
          <div class="field">
            <label class="label">Deskripsi SK</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
         <div class="column is-3">
          <div class="field">
            <label class="label">Tgl Terbit</label>
            <div class="control">
              <input class="input" type="date" placeholder="Text input">
            </div>
          </div>
        </div>
         <div class="column is-3">
          <div class="field">
            <label class="label">Nik Penandatangan</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
        <div class="column is-3">
          <div class="field">
            <label class="label">Nama Penandatangan</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
         <div class="column is-3">
          <div class="field">
            <label class="label">Nama Unit</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
        <div class="column is-3">
          <div class="field">
            <label class="label">orgty</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
         <div class="column is-3">
          <div class="field">
            <label class="label">Jabatan Penandatangan</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
        <div class="column is-3">
          <div class="field">
            <label class="label">Referensi Kontrak</label>
            <div class="control">
              <input class="input" type="text" placeholder="Text input">
            </div>
          </div>
        </div>
      </div>

    </div>
    <a class="button is-success is-rounded">Save</a>
  </section>
</template>

<script>
  export default {

  }

</script>


<style>

</style>
