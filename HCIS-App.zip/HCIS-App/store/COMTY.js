import moment from 'moment'

export const state = () => ({
  list: [],
  detail: null,
  pagination: null,
  isLoading: false,
  error: null,
  api: 'ldap/api/object?object_type=COMTY',
})

export const mutations = {
  storeAll(state, data) {
    state.list = data.data;
    state.pagination = data.meta.pagination;
  },
  clearAll(state, data) {
    state.list = []
    state.detail = null
    state.pagination = null
  },
  storeDetail(state, data) {
    state.detail = data;
  },
  clearDetail(state) {
    state.detail = null
  },
  deleteOne(state, index) {
    state.list.splice(index, 1)
  },
  setLoading(state, value) {
    state.isLoading = value
  }
}

export const actions = {
  async getAll(store, params = {}) {
    store.commit('setLoading', true)
    let res = await this.$axios.get(store.state.api, {
      params: {
        begin_date_lte: moment(new Date()).format("YYYY-MM-DD"),
        end_date_gte: moment(new Date()).format("YYYY-MM-DD"),
        object_type: ['COMTY'],
        ...params
      }
    })
    store.commit('storeAll', res.data)
    store.commit('setLoading', false)
  },
  async clearAll(store) {
    await store.commit('clearAll')
  },
  async getDetail(store, object_identifier) {
    let data = await store.state.list.find(item => item.object_identifier == object_identifier);
    store.commit('storeDetail', data)
  },
  async clearDetail(store) {
    await store.commit('clearDetail')
  },
  async deleteOne(store, index) {
    store.commit('deleteOne', index)
  },
}
